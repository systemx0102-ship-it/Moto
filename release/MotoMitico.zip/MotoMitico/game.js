(()=>{var Dh="170";var b0=0,Lu=1,w0=2;var Xd=1,kh=2,Mi=3,Wi=0,Ce=1,xe=2,oi=0,Hi=1,ms=2,Du=3,ku=4,S0=5,ds=100,E0=101,T0=102,A0=103,R0=104,C0=200,P0=201,I0=202,L0=203,lc=204,cc=205,D0=206,k0=207,U0=208,N0=209,F0=210,O0=211,B0=212,z0=213,H0=214,hc=0,uc=1,dc=2,er=3,fc=4,pc=5,mc=6,gc=7,qd=0,V0=1,G0=2,Vi=0,Uh=1,Nh=2,Fh=3,ta=4,W0=5,Oh=6,Bh=7;var Yd=300,nr=301,ir=302,xc=303,vc=304,Oo=306,gs=1e3,ps=1001,yc=1002,yn=1003,X0=1004;var wa=1005;var ri=1006,El=1007;var bi=1008;var Ei=1009,$d=1010,Zd=1011,qr=1012,zh=1013,xs=1014,ai=1015,ln=1016,Hh=1017,Vh=1018,sr=1020,Kd=35902,Jd=1021,jd=1022,Xn=1023,Qd=1024,tf=1025,js=1026,rr=1027,Gh=1028,Wh=1029,ef=1030,Xh=1031;var qh=1033,to=33776,eo=33777,no=33778,io=33779,_c=35840,Mc=35841,bc=35842,wc=35843,Sc=36196,Ec=37492,Tc=37496,Ac=37808,Rc=37809,Cc=37810,Pc=37811,Ic=37812,Lc=37813,Dc=37814,kc=37815,Uc=37816,Nc=37817,Fc=37818,Oc=37819,Bc=37820,zc=37821,so=36492,Hc=36494,Vc=36495,nf=36283,Gc=36284,Wc=36285,Xc=36286;var ro=2300,qc=2301,Tl=2302,Uu=2400,Nu=2401,Fu=2402;var q0=3200,Y0=3201;var sf=0,$0=1,ii="",qe="srgb",Ji="srgb-linear",Bo="linear",pe="srgb";var Ls=7680;var Ou=519,Z0=512,K0=513,J0=514,rf=515,j0=516,Q0=517,tp=518,ep=519,Yc=35044,ea=35048;var Bu="300 es",wi=2e3,ao=2001,Xi=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;let n=this._listeners;return n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;let i=this._listeners[t];if(i!==void 0){let r=i.indexOf(e);r!==-1&&i.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;let n=this._listeners[t.type];if(n!==void 0){t.target=this;let i=n.slice(0);for(let r=0,a=i.length;r<a;r++)i[r].call(this,t);t.target=null}}},tn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];var Al=Math.PI/180,oo=180/Math.PI;function Gi(){let s=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(tn[s&255]+tn[s>>8&255]+tn[s>>16&255]+tn[s>>24&255]+"-"+tn[t&255]+tn[t>>8&255]+"-"+tn[t>>16&15|64]+tn[t>>24&255]+"-"+tn[e&63|128]+tn[e>>8&255]+"-"+tn[e>>16&255]+tn[e>>24&255]+tn[n&255]+tn[n>>8&255]+tn[n>>16&255]+tn[n>>24&255]).toLowerCase()}function Ye(s,t,e){return Math.max(t,Math.min(e,s))}function np(s,t){return(s%t+t)%t}function Rl(s,t,e){return(1-e)*s+e*t}function si(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return s/4294967295;case Uint16Array:return s/65535;case Uint8Array:return s/255;case Int32Array:return Math.max(s/2147483647,-1);case Int16Array:return Math.max(s/32767,-1);case Int8Array:return Math.max(s/127,-1);default:throw new Error("Invalid component type.")}}function ye(s,t){switch(t.constructor){case Float32Array:return s;case Uint32Array:return Math.round(s*4294967295);case Uint16Array:return Math.round(s*65535);case Uint8Array:return Math.round(s*255);case Int32Array:return Math.round(s*2147483647);case Int16Array:return Math.round(s*32767);case Int8Array:return Math.round(s*127);default:throw new Error("Invalid component type.")}}var tt=class s{constructor(t=0,e=0){s.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,n=this.y,i=t.elements;return this.x=i[0]*e+i[3]*n+i[6],this.y=i[1]*e+i[4]*n+i[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Ye(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let n=Math.cos(e),i=Math.sin(e),r=this.x-t.x,a=this.y-t.y;return this.x=r*n-a*i+t.x,this.y=r*i+a*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},Yt=class s{constructor(t,e,n,i,r,a,o,l,c){s.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,a,o,l,c)}set(t,e,n,i,r,a,o,l,c){let h=this.elements;return h[0]=t,h[1]=i,h[2]=o,h[3]=e,h[4]=r,h[5]=l,h[6]=n,h[7]=a,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,i=e.elements,r=this.elements,a=n[0],o=n[3],l=n[6],c=n[1],h=n[4],u=n[7],d=n[2],f=n[5],m=n[8],x=i[0],g=i[3],p=i[6],v=i[1],y=i[4],_=i[7],S=i[2],M=i[5],E=i[8];return r[0]=a*x+o*v+l*S,r[3]=a*g+o*y+l*M,r[6]=a*p+o*_+l*E,r[1]=c*x+h*v+u*S,r[4]=c*g+h*y+u*M,r[7]=c*p+h*_+u*E,r[2]=d*x+f*v+m*S,r[5]=d*g+f*y+m*M,r[8]=d*p+f*_+m*E,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8];return e*a*h-e*o*c-n*r*h+n*o*l+i*r*c-i*a*l}invert(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8],u=h*a-o*c,d=o*l-h*r,f=c*r-a*l,m=e*u+n*d+i*f;if(m===0)return this.set(0,0,0,0,0,0,0,0,0);let x=1/m;return t[0]=u*x,t[1]=(i*c-h*n)*x,t[2]=(o*n-i*a)*x,t[3]=d*x,t[4]=(h*e-i*l)*x,t[5]=(i*r-o*e)*x,t[6]=f*x,t[7]=(n*l-c*e)*x,t[8]=(a*e-n*r)*x,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,i,r,a,o){let l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*a+c*o)+a+t,-i*c,i*l,-i*(-c*a+l*o)+o+e,0,0,1),this}scale(t,e){return this.premultiply(Cl.makeScale(t,e)),this}rotate(t){return this.premultiply(Cl.makeRotation(-t)),this}translate(t,e){return this.premultiply(Cl.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,n=t.elements;for(let i=0;i<9;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}},Cl=new Yt;function af(s){for(let t=s.length-1;t>=0;--t)if(s[t]>=65535)return!0;return!1}function lo(s){return document.createElementNS("http://www.w3.org/1999/xhtml",s)}function ip(){let s=lo("canvas");return s.style.display="block",s}var zu={};function Hr(s){s in zu||(zu[s]=!0,console.warn(s))}function sp(s,t,e){return new Promise(function(n,i){function r(){switch(s.clientWaitSync(t,s.SYNC_FLUSH_COMMANDS_BIT,0)){case s.WAIT_FAILED:i();break;case s.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:n()}}setTimeout(r,e)})}function rp(s){let t=s.elements;t[2]=.5*t[2]+.5*t[3],t[6]=.5*t[6]+.5*t[7],t[10]=.5*t[10]+.5*t[11],t[14]=.5*t[14]+.5*t[15]}function ap(s){let t=s.elements;t[11]===-1?(t[10]=-t[10]-1,t[14]=-t[14]):(t[10]=-t[10],t[14]=-t[14]+1)}var se={enabled:!0,workingColorSpace:Ji,spaces:{},convert:function(s,t,e){return this.enabled===!1||t===e||!t||!e||(this.spaces[t].transfer===pe&&(s.r=Si(s.r),s.g=Si(s.g),s.b=Si(s.b)),this.spaces[t].primaries!==this.spaces[e].primaries&&(s.applyMatrix3(this.spaces[t].toXYZ),s.applyMatrix3(this.spaces[e].fromXYZ)),this.spaces[e].transfer===pe&&(s.r=Qs(s.r),s.g=Qs(s.g),s.b=Qs(s.b))),s},fromWorkingColorSpace:function(s,t){return this.convert(s,this.workingColorSpace,t)},toWorkingColorSpace:function(s,t){return this.convert(s,t,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===ii?Bo:this.spaces[s].transfer},getLuminanceCoefficients:function(s,t=this.workingColorSpace){return s.fromArray(this.spaces[t].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,t,e){return s.copy(this.spaces[t].toXYZ).multiply(this.spaces[e].fromXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace}};function Si(s){return s<.04045?s*.0773993808:Math.pow(s*.9478672986+.0521327014,2.4)}function Qs(s){return s<.0031308?s*12.92:1.055*Math.pow(s,.41666)-.055}var Hu=[.64,.33,.3,.6,.15,.06],Vu=[.2126,.7152,.0722],Gu=[.3127,.329],Wu=new Yt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Xu=new Yt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);se.define({[Ji]:{primaries:Hu,whitePoint:Gu,transfer:Bo,toXYZ:Wu,fromXYZ:Xu,luminanceCoefficients:Vu,workingColorSpaceConfig:{unpackColorSpace:qe},outputColorSpaceConfig:{drawingBufferColorSpace:qe}},[qe]:{primaries:Hu,whitePoint:Gu,transfer:pe,toXYZ:Wu,fromXYZ:Xu,luminanceCoefficients:Vu,outputColorSpaceConfig:{drawingBufferColorSpace:qe}}});var Ds,$c=class{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{Ds===void 0&&(Ds=lo("canvas")),Ds.width=t.width,Ds.height=t.height;let n=Ds.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),e=Ds}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=lo("canvas");e.width=t.width,e.height=t.height;let n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);let i=n.getImageData(0,0,t.width,t.height),r=i.data;for(let a=0;a<r.length;a++)r[a]=Si(r[a]/255)*255;return n.putImageData(i,0,0),e}else if(t.data){let e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(Si(e[n]/255)*255):e[n]=Si(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},op=0,co=class{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:op++}),this.uuid=Gi(),this.data=t,this.dataReady=!0,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let r;if(Array.isArray(i)){r=[];for(let a=0,o=i.length;a<o;a++)i[a].isDataTexture?r.push(Pl(i[a].image)):r.push(Pl(i[a]))}else r=Pl(i);n.url=r}return e||(t.images[this.uuid]=n),n}};function Pl(s){return typeof HTMLImageElement<"u"&&s instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&s instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&s instanceof ImageBitmap?$c.getDataURL(s):s.data?{data:Array.from(s.data),width:s.width,height:s.height,type:s.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var lp=0,fn=class s extends Xi{constructor(t=s.DEFAULT_IMAGE,e=s.DEFAULT_MAPPING,n=ps,i=ps,r=ri,a=bi,o=Xn,l=Ei,c=s.DEFAULT_ANISOTROPY,h=ii){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:lp++}),this.uuid=Gi(),this.name="",this.source=new co(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=r,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new tt(0,0),this.repeat=new tt(1,1),this.center=new tt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Yt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Yd)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case gs:t.x=t.x-Math.floor(t.x);break;case ps:t.x=t.x<0?0:1;break;case yc:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case gs:t.y=t.y-Math.floor(t.y);break;case ps:t.y=t.y<0?0:1;break;case yc:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}};fn.DEFAULT_IMAGE=null;fn.DEFAULT_MAPPING=Yd;fn.DEFAULT_ANISOTROPY=1;var ue=class s{constructor(t=0,e=0,n=0,i=1){s.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=i}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,i){return this.x=t,this.y=e,this.z=n,this.w=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,n=this.y,i=this.z,r=this.w,a=t.elements;return this.x=a[0]*e+a[4]*n+a[8]*i+a[12]*r,this.y=a[1]*e+a[5]*n+a[9]*i+a[13]*r,this.z=a[2]*e+a[6]*n+a[10]*i+a[14]*r,this.w=a[3]*e+a[7]*n+a[11]*i+a[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,i,r,l=t.elements,c=l[0],h=l[4],u=l[8],d=l[1],f=l[5],m=l[9],x=l[2],g=l[6],p=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-x)<.01&&Math.abs(m-g)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+x)<.1&&Math.abs(m+g)<.1&&Math.abs(c+f+p-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let y=(c+1)/2,_=(f+1)/2,S=(p+1)/2,M=(h+d)/4,E=(u+x)/4,A=(m+g)/4;return y>_&&y>S?y<.01?(n=0,i=.707106781,r=.707106781):(n=Math.sqrt(y),i=M/n,r=E/n):_>S?_<.01?(n=.707106781,i=0,r=.707106781):(i=Math.sqrt(_),n=M/i,r=A/i):S<.01?(n=.707106781,i=.707106781,r=0):(r=Math.sqrt(S),n=E/r,i=A/r),this.set(n,i,r,e),this}let v=Math.sqrt((g-m)*(g-m)+(u-x)*(u-x)+(d-h)*(d-h));return Math.abs(v)<.001&&(v=1),this.x=(g-m)/v,this.y=(u-x)/v,this.z=(d-h)/v,this.w=Math.acos((c+f+p-1)/2),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Zc=class extends Xi{constructor(t=1,e=1,n={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new ue(0,0,t,e),this.scissorTest=!1,this.viewport=new ue(0,0,t,e);let i={width:t,height:e,depth:1};n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:ri,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},n);let r=new fn(i,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace);r.flipY=!1,r.generateMipmaps=n.generateMipmaps,r.internalFormat=n.internalFormat,this.textures=[];let a=n.count;for(let o=0;o<a;o++)this.textures[o]=r.clone(),this.textures[o].isRenderTargetTexture=!0;this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let i=0,r=this.textures.length;i<r;i++)this.textures[i].image.width=t,this.textures[i].image.height=e,this.textures[i].image.depth=n;this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let n=0,i=t.textures.length;n<i;n++)this.textures[n]=t.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0;let e=Object.assign({},t.texture.image);return this.texture.source=new co(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},Ne=class extends Zc{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}},ho=class extends fn{constructor(t=null,e=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=yn,this.minFilter=yn,this.wrapR=ps,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}};var Kc=class extends fn{constructor(t=null,e=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:i},this.magFilter=yn,this.minFilter=yn,this.wrapR=ps,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Fe=class{constructor(t=0,e=0,n=0,i=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=i}static slerpFlat(t,e,n,i,r,a,o){let l=n[i+0],c=n[i+1],h=n[i+2],u=n[i+3],d=r[a+0],f=r[a+1],m=r[a+2],x=r[a+3];if(o===0){t[e+0]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u;return}if(o===1){t[e+0]=d,t[e+1]=f,t[e+2]=m,t[e+3]=x;return}if(u!==x||l!==d||c!==f||h!==m){let g=1-o,p=l*d+c*f+h*m+u*x,v=p>=0?1:-1,y=1-p*p;if(y>Number.EPSILON){let S=Math.sqrt(y),M=Math.atan2(S,p*v);g=Math.sin(g*M)/S,o=Math.sin(o*M)/S}let _=o*v;if(l=l*g+d*_,c=c*g+f*_,h=h*g+m*_,u=u*g+x*_,g===1-o){let S=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=S,c*=S,h*=S,u*=S}}t[e]=l,t[e+1]=c,t[e+2]=h,t[e+3]=u}static multiplyQuaternionsFlat(t,e,n,i,r,a){let o=n[i],l=n[i+1],c=n[i+2],h=n[i+3],u=r[a],d=r[a+1],f=r[a+2],m=r[a+3];return t[e]=o*m+h*u+l*f-c*d,t[e+1]=l*m+h*d+c*u-o*f,t[e+2]=c*m+h*f+o*d-l*u,t[e+3]=h*m-o*u-l*d-c*f,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,i){return this._x=t,this._y=e,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let n=t._x,i=t._y,r=t._z,a=t._order,o=Math.cos,l=Math.sin,c=o(n/2),h=o(i/2),u=o(r/2),d=l(n/2),f=l(i/2),m=l(r/2);switch(a){case"XYZ":this._x=d*h*u+c*f*m,this._y=c*f*u-d*h*m,this._z=c*h*m+d*f*u,this._w=c*h*u-d*f*m;break;case"YXZ":this._x=d*h*u+c*f*m,this._y=c*f*u-d*h*m,this._z=c*h*m-d*f*u,this._w=c*h*u+d*f*m;break;case"ZXY":this._x=d*h*u-c*f*m,this._y=c*f*u+d*h*m,this._z=c*h*m+d*f*u,this._w=c*h*u-d*f*m;break;case"ZYX":this._x=d*h*u-c*f*m,this._y=c*f*u+d*h*m,this._z=c*h*m-d*f*u,this._w=c*h*u+d*f*m;break;case"YZX":this._x=d*h*u+c*f*m,this._y=c*f*u+d*h*m,this._z=c*h*m-d*f*u,this._w=c*h*u-d*f*m;break;case"XZY":this._x=d*h*u-c*f*m,this._y=c*f*u-d*h*m,this._z=c*h*m+d*f*u,this._w=c*h*u+d*f*m;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let n=e/2,i=Math.sin(n);return this._x=t.x*i,this._y=t.y*i,this._z=t.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,n=e[0],i=e[4],r=e[8],a=e[1],o=e[5],l=e[9],c=e[2],h=e[6],u=e[10],d=n+o+u;if(d>0){let f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(h-l)*f,this._y=(r-c)*f,this._z=(a-i)*f}else if(n>o&&n>u){let f=2*Math.sqrt(1+n-o-u);this._w=(h-l)/f,this._x=.25*f,this._y=(i+a)/f,this._z=(r+c)/f}else if(o>u){let f=2*Math.sqrt(1+o-n-u);this._w=(r-c)/f,this._x=(i+a)/f,this._y=.25*f,this._z=(l+h)/f}else{let f=2*Math.sqrt(1+u-n-o);this._w=(a-i)/f,this._x=(r+c)/f,this._y=(l+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<Number.EPSILON?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Ye(this.dot(t),-1,1)))}rotateTowards(t,e){let n=this.angleTo(t);if(n===0)return this;let i=Math.min(1,e/n);return this.slerp(t,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let n=t._x,i=t._y,r=t._z,a=t._w,o=e._x,l=e._y,c=e._z,h=e._w;return this._x=n*h+a*o+i*c-r*l,this._y=i*h+a*l+r*o-n*c,this._z=r*h+a*c+n*l-i*o,this._w=a*h-n*o-i*l-r*c,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);let n=this._x,i=this._y,r=this._z,a=this._w,o=a*t._w+n*t._x+i*t._y+r*t._z;if(o<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,o=-o):this.copy(t),o>=1)return this._w=a,this._x=n,this._y=i,this._z=r,this;let l=1-o*o;if(l<=Number.EPSILON){let f=1-e;return this._w=f*a+e*this._w,this._x=f*n+e*this._x,this._y=f*i+e*this._y,this._z=f*r+e*this._z,this.normalize(),this}let c=Math.sqrt(l),h=Math.atan2(c,o),u=Math.sin((1-e)*h)/c,d=Math.sin(e*h)/c;return this._w=a*u+this._w*d,this._x=n*u+this._x*d,this._y=i*u+this._y*d,this._z=r*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){let t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),i=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(i*Math.sin(t),i*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},C=class s{constructor(t=0,e=0,n=0){s.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(qu.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(qu.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*i,this.y=r[1]*e+r[4]*n+r[7]*i,this.z=r[2]*e+r[5]*n+r[8]*i,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,n=this.y,i=this.z,r=t.elements,a=1/(r[3]*e+r[7]*n+r[11]*i+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*i+r[12])*a,this.y=(r[1]*e+r[5]*n+r[9]*i+r[13])*a,this.z=(r[2]*e+r[6]*n+r[10]*i+r[14])*a,this}applyQuaternion(t){let e=this.x,n=this.y,i=this.z,r=t.x,a=t.y,o=t.z,l=t.w,c=2*(a*i-o*n),h=2*(o*e-r*i),u=2*(r*n-a*e);return this.x=e+l*c+a*u-o*h,this.y=n+l*h+o*c-r*u,this.z=i+l*u+r*h-a*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*i,this.y=r[1]*e+r[5]*n+r[9]*i,this.z=r[2]*e+r[6]*n+r[10]*i,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let n=t.x,i=t.y,r=t.z,a=e.x,o=e.y,l=e.z;return this.x=i*l-r*o,this.y=r*a-n*l,this.z=n*o-i*a,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return Il.copy(this).projectOnVector(t),this.sub(Il)}reflect(t){return this.sub(Il.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Ye(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y,i=this.z-t.z;return e*e+n*n+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){let i=Math.sin(e)*t;return this.x=i*Math.sin(n),this.y=Math.cos(e)*t,this.z=i*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),i=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=i,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Il=new C,qu=new Fe,qn=class{constructor(t=new C(1/0,1/0,1/0),e=new C(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(Hn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(Hn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let n=Hn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let n=t.geometry;if(n!==void 0){let r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let a=0,o=r.count;a<o;a++)t.isMesh===!0?t.getVertexPosition(a,Hn):Hn.fromBufferAttribute(r,a),Hn.applyMatrix4(t.matrixWorld),this.expandByPoint(Hn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),Sa.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Sa.copy(n.boundingBox)),Sa.applyMatrix4(t.matrixWorld),this.union(Sa)}let i=t.children;for(let r=0,a=i.length;r<a;r++)this.expandByObject(i[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,Hn),Hn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Pr),Ea.subVectors(this.max,Pr),ks.subVectors(t.a,Pr),Us.subVectors(t.b,Pr),Ns.subVectors(t.c,Pr),ki.subVectors(Us,ks),Ui.subVectors(Ns,Us),rs.subVectors(ks,Ns);let e=[0,-ki.z,ki.y,0,-Ui.z,Ui.y,0,-rs.z,rs.y,ki.z,0,-ki.x,Ui.z,0,-Ui.x,rs.z,0,-rs.x,-ki.y,ki.x,0,-Ui.y,Ui.x,0,-rs.y,rs.x,0];return!Ll(e,ks,Us,Ns,Ea)||(e=[1,0,0,0,1,0,0,0,1],!Ll(e,ks,Us,Ns,Ea))?!1:(Ta.crossVectors(ki,Ui),e=[Ta.x,Ta.y,Ta.z],Ll(e,ks,Us,Ns,Ea))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Hn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Hn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(gi[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),gi[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),gi[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),gi[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),gi[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),gi[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),gi[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),gi[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(gi),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}},gi=[new C,new C,new C,new C,new C,new C,new C,new C],Hn=new C,Sa=new qn,ks=new C,Us=new C,Ns=new C,ki=new C,Ui=new C,rs=new C,Pr=new C,Ea=new C,Ta=new C,as=new C;function Ll(s,t,e,n,i){for(let r=0,a=s.length-3;r<=a;r+=3){as.fromArray(s,r);let o=i.x*Math.abs(as.x)+i.y*Math.abs(as.y)+i.z*Math.abs(as.z),l=t.dot(as),c=e.dot(as),h=n.dot(as);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>o)return!1}return!0}var cp=new qn,Ir=new C,Dl=new C,Ti=class{constructor(t=new C,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let n=this.center;e!==void 0?n.copy(e):cp.setFromPoints(t).getCenter(n);let i=0;for(let r=0,a=t.length;r<a;r++)i=Math.max(i,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(i),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Ir.subVectors(t,this.center);let e=Ir.lengthSq();if(e>this.radius*this.radius){let n=Math.sqrt(e),i=(n-this.radius)*.5;this.center.addScaledVector(Ir,i/n),this.radius+=i}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Dl.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Ir.copy(t.center).add(Dl)),this.expandByPoint(Ir.copy(t.center).sub(Dl))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}},xi=new C,kl=new C,Aa=new C,Ni=new C,Ul=new C,Ra=new C,Nl=new C,Yr=class{constructor(t=new C,e=new C(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,xi)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=xi.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(xi.copy(this.origin).addScaledVector(this.direction,e),xi.distanceToSquared(t))}distanceSqToSegment(t,e,n,i){kl.copy(t).add(e).multiplyScalar(.5),Aa.copy(e).sub(t).normalize(),Ni.copy(this.origin).sub(kl);let r=t.distanceTo(e)*.5,a=-this.direction.dot(Aa),o=Ni.dot(this.direction),l=-Ni.dot(Aa),c=Ni.lengthSq(),h=Math.abs(1-a*a),u,d,f,m;if(h>0)if(u=a*l-o,d=a*o-l,m=r*h,u>=0)if(d>=-m)if(d<=m){let x=1/h;u*=x,d*=x,f=u*(u+a*d+2*o)+d*(a*u+d+2*l)+c}else d=r,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*l)+c;else d=-r,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*l)+c;else d<=-m?(u=Math.max(0,-(-a*r+o)),d=u>0?-r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c):d<=m?(u=0,d=Math.min(Math.max(-r,-l),r),f=d*(d+2*l)+c):(u=Math.max(0,-(a*r+o)),d=u>0?r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c);else d=a>0?-r:r,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),i&&i.copy(kl).addScaledVector(Aa,d),f}intersectSphere(t,e){xi.subVectors(t.center,this.origin);let n=xi.dot(this.direction),i=xi.dot(xi)-n*n,r=t.radius*t.radius;if(i>r)return null;let a=Math.sqrt(r-i),o=n-a,l=n+a;return l<0?null:o<0?this.at(l,e):this.at(o,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){let n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,i,r,a,o,l,c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(t.min.x-d.x)*c,i=(t.max.x-d.x)*c):(n=(t.max.x-d.x)*c,i=(t.min.x-d.x)*c),h>=0?(r=(t.min.y-d.y)*h,a=(t.max.y-d.y)*h):(r=(t.max.y-d.y)*h,a=(t.min.y-d.y)*h),n>a||r>i||((r>n||isNaN(n))&&(n=r),(a<i||isNaN(i))&&(i=a),u>=0?(o=(t.min.z-d.z)*u,l=(t.max.z-d.z)*u):(o=(t.max.z-d.z)*u,l=(t.min.z-d.z)*u),n>l||o>i)||((o>n||n!==n)&&(n=o),(l<i||i!==i)&&(i=l),i<0)?null:this.at(n>=0?n:i,e)}intersectsBox(t){return this.intersectBox(t,xi)!==null}intersectTriangle(t,e,n,i,r){Ul.subVectors(e,t),Ra.subVectors(n,t),Nl.crossVectors(Ul,Ra);let a=this.direction.dot(Nl),o;if(a>0){if(i)return null;o=1}else if(a<0)o=-1,a=-a;else return null;Ni.subVectors(this.origin,t);let l=o*this.direction.dot(Ra.crossVectors(Ni,Ra));if(l<0)return null;let c=o*this.direction.dot(Ul.cross(Ni));if(c<0||l+c>a)return null;let h=-o*Ni.dot(Nl);return h<0?null:this.at(h/a,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Lt=class s{constructor(t,e,n,i,r,a,o,l,c,h,u,d,f,m,x,g){s.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,a,o,l,c,h,u,d,f,m,x,g)}set(t,e,n,i,r,a,o,l,c,h,u,d,f,m,x,g){let p=this.elements;return p[0]=t,p[4]=e,p[8]=n,p[12]=i,p[1]=r,p[5]=a,p[9]=o,p[13]=l,p[2]=c,p[6]=h,p[10]=u,p[14]=d,p[3]=f,p[7]=m,p[11]=x,p[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new s().fromArray(this.elements)}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){let e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){let e=this.elements,n=t.elements,i=1/Fs.setFromMatrixColumn(t,0).length(),r=1/Fs.setFromMatrixColumn(t,1).length(),a=1/Fs.setFromMatrixColumn(t,2).length();return e[0]=n[0]*i,e[1]=n[1]*i,e[2]=n[2]*i,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*a,e[9]=n[9]*a,e[10]=n[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,n=t.x,i=t.y,r=t.z,a=Math.cos(n),o=Math.sin(n),l=Math.cos(i),c=Math.sin(i),h=Math.cos(r),u=Math.sin(r);if(t.order==="XYZ"){let d=a*h,f=a*u,m=o*h,x=o*u;e[0]=l*h,e[4]=-l*u,e[8]=c,e[1]=f+m*c,e[5]=d-x*c,e[9]=-o*l,e[2]=x-d*c,e[6]=m+f*c,e[10]=a*l}else if(t.order==="YXZ"){let d=l*h,f=l*u,m=c*h,x=c*u;e[0]=d+x*o,e[4]=m*o-f,e[8]=a*c,e[1]=a*u,e[5]=a*h,e[9]=-o,e[2]=f*o-m,e[6]=x+d*o,e[10]=a*l}else if(t.order==="ZXY"){let d=l*h,f=l*u,m=c*h,x=c*u;e[0]=d-x*o,e[4]=-a*u,e[8]=m+f*o,e[1]=f+m*o,e[5]=a*h,e[9]=x-d*o,e[2]=-a*c,e[6]=o,e[10]=a*l}else if(t.order==="ZYX"){let d=a*h,f=a*u,m=o*h,x=o*u;e[0]=l*h,e[4]=m*c-f,e[8]=d*c+x,e[1]=l*u,e[5]=x*c+d,e[9]=f*c-m,e[2]=-c,e[6]=o*l,e[10]=a*l}else if(t.order==="YZX"){let d=a*l,f=a*c,m=o*l,x=o*c;e[0]=l*h,e[4]=x-d*u,e[8]=m*u+f,e[1]=u,e[5]=a*h,e[9]=-o*h,e[2]=-c*h,e[6]=f*u+m,e[10]=d-x*u}else if(t.order==="XZY"){let d=a*l,f=a*c,m=o*l,x=o*c;e[0]=l*h,e[4]=-u,e[8]=c*h,e[1]=d*u+x,e[5]=a*h,e[9]=f*u-m,e[2]=m*u-f,e[6]=o*h,e[10]=x*u+d}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(hp,t,up)}lookAt(t,e,n){let i=this.elements;return xn.subVectors(t,e),xn.lengthSq()===0&&(xn.z=1),xn.normalize(),Fi.crossVectors(n,xn),Fi.lengthSq()===0&&(Math.abs(n.z)===1?xn.x+=1e-4:xn.z+=1e-4,xn.normalize(),Fi.crossVectors(n,xn)),Fi.normalize(),Ca.crossVectors(xn,Fi),i[0]=Fi.x,i[4]=Ca.x,i[8]=xn.x,i[1]=Fi.y,i[5]=Ca.y,i[9]=xn.y,i[2]=Fi.z,i[6]=Ca.z,i[10]=xn.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,i=e.elements,r=this.elements,a=n[0],o=n[4],l=n[8],c=n[12],h=n[1],u=n[5],d=n[9],f=n[13],m=n[2],x=n[6],g=n[10],p=n[14],v=n[3],y=n[7],_=n[11],S=n[15],M=i[0],E=i[4],A=i[8],w=i[12],b=i[1],P=i[5],D=i[9],U=i[13],F=i[2],q=i[6],V=i[10],J=i[14],G=i[3],nt=i[7],ht=i[11],Et=i[15];return r[0]=a*M+o*b+l*F+c*G,r[4]=a*E+o*P+l*q+c*nt,r[8]=a*A+o*D+l*V+c*ht,r[12]=a*w+o*U+l*J+c*Et,r[1]=h*M+u*b+d*F+f*G,r[5]=h*E+u*P+d*q+f*nt,r[9]=h*A+u*D+d*V+f*ht,r[13]=h*w+u*U+d*J+f*Et,r[2]=m*M+x*b+g*F+p*G,r[6]=m*E+x*P+g*q+p*nt,r[10]=m*A+x*D+g*V+p*ht,r[14]=m*w+x*U+g*J+p*Et,r[3]=v*M+y*b+_*F+S*G,r[7]=v*E+y*P+_*q+S*nt,r[11]=v*A+y*D+_*V+S*ht,r[15]=v*w+y*U+_*J+S*Et,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[4],i=t[8],r=t[12],a=t[1],o=t[5],l=t[9],c=t[13],h=t[2],u=t[6],d=t[10],f=t[14],m=t[3],x=t[7],g=t[11],p=t[15];return m*(+r*l*u-i*c*u-r*o*d+n*c*d+i*o*f-n*l*f)+x*(+e*l*f-e*c*d+r*a*d-i*a*f+i*c*h-r*l*h)+g*(+e*c*u-e*o*f-r*a*u+n*a*f+r*o*h-n*c*h)+p*(-i*o*h-e*l*u+e*o*d+i*a*u-n*a*d+n*l*h)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){let i=this.elements;return t.isVector3?(i[12]=t.x,i[13]=t.y,i[14]=t.z):(i[12]=t,i[13]=e,i[14]=n),this}invert(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],h=t[8],u=t[9],d=t[10],f=t[11],m=t[12],x=t[13],g=t[14],p=t[15],v=u*g*c-x*d*c+x*l*f-o*g*f-u*l*p+o*d*p,y=m*d*c-h*g*c-m*l*f+a*g*f+h*l*p-a*d*p,_=h*x*c-m*u*c+m*o*f-a*x*f-h*o*p+a*u*p,S=m*u*l-h*x*l-m*o*d+a*x*d+h*o*g-a*u*g,M=e*v+n*y+i*_+r*S;if(M===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let E=1/M;return t[0]=v*E,t[1]=(x*d*r-u*g*r-x*i*f+n*g*f+u*i*p-n*d*p)*E,t[2]=(o*g*r-x*l*r+x*i*c-n*g*c-o*i*p+n*l*p)*E,t[3]=(u*l*r-o*d*r-u*i*c+n*d*c+o*i*f-n*l*f)*E,t[4]=y*E,t[5]=(h*g*r-m*d*r+m*i*f-e*g*f-h*i*p+e*d*p)*E,t[6]=(m*l*r-a*g*r-m*i*c+e*g*c+a*i*p-e*l*p)*E,t[7]=(a*d*r-h*l*r+h*i*c-e*d*c-a*i*f+e*l*f)*E,t[8]=_*E,t[9]=(m*u*r-h*x*r-m*n*f+e*x*f+h*n*p-e*u*p)*E,t[10]=(a*x*r-m*o*r+m*n*c-e*x*c-a*n*p+e*o*p)*E,t[11]=(h*o*r-a*u*r-h*n*c+e*u*c+a*n*f-e*o*f)*E,t[12]=S*E,t[13]=(h*x*i-m*u*i+m*n*d-e*x*d-h*n*g+e*u*g)*E,t[14]=(m*o*i-a*x*i-m*n*l+e*x*l+a*n*g-e*o*g)*E,t[15]=(a*u*i-h*o*i+h*n*l-e*u*l-a*n*d+e*o*d)*E,this}scale(t){let e=this.elements,n=t.x,i=t.y,r=t.z;return e[0]*=n,e[4]*=i,e[8]*=r,e[1]*=n,e[5]*=i,e[9]*=r,e[2]*=n,e[6]*=i,e[10]*=r,e[3]*=n,e[7]*=i,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],i=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,i))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let n=Math.cos(e),i=Math.sin(e),r=1-n,a=t.x,o=t.y,l=t.z,c=r*a,h=r*o;return this.set(c*a+n,c*o-i*l,c*l+i*o,0,c*o+i*l,h*o+n,h*l-i*a,0,c*l-i*o,h*l+i*a,r*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,i,r,a){return this.set(1,n,r,0,t,1,a,0,e,i,1,0,0,0,0,1),this}compose(t,e,n){let i=this.elements,r=e._x,a=e._y,o=e._z,l=e._w,c=r+r,h=a+a,u=o+o,d=r*c,f=r*h,m=r*u,x=a*h,g=a*u,p=o*u,v=l*c,y=l*h,_=l*u,S=n.x,M=n.y,E=n.z;return i[0]=(1-(x+p))*S,i[1]=(f+_)*S,i[2]=(m-y)*S,i[3]=0,i[4]=(f-_)*M,i[5]=(1-(d+p))*M,i[6]=(g+v)*M,i[7]=0,i[8]=(m+y)*E,i[9]=(g-v)*E,i[10]=(1-(d+x))*E,i[11]=0,i[12]=t.x,i[13]=t.y,i[14]=t.z,i[15]=1,this}decompose(t,e,n){let i=this.elements,r=Fs.set(i[0],i[1],i[2]).length(),a=Fs.set(i[4],i[5],i[6]).length(),o=Fs.set(i[8],i[9],i[10]).length();this.determinant()<0&&(r=-r),t.x=i[12],t.y=i[13],t.z=i[14],Vn.copy(this);let c=1/r,h=1/a,u=1/o;return Vn.elements[0]*=c,Vn.elements[1]*=c,Vn.elements[2]*=c,Vn.elements[4]*=h,Vn.elements[5]*=h,Vn.elements[6]*=h,Vn.elements[8]*=u,Vn.elements[9]*=u,Vn.elements[10]*=u,e.setFromRotationMatrix(Vn),n.x=r,n.y=a,n.z=o,this}makePerspective(t,e,n,i,r,a,o=wi){let l=this.elements,c=2*r/(e-t),h=2*r/(n-i),u=(e+t)/(e-t),d=(n+i)/(n-i),f,m;if(o===wi)f=-(a+r)/(a-r),m=-2*a*r/(a-r);else if(o===ao)f=-a/(a-r),m=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=h,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=f,l[14]=m,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,n,i,r,a,o=wi){let l=this.elements,c=1/(e-t),h=1/(n-i),u=1/(a-r),d=(e+t)*c,f=(n+i)*h,m,x;if(o===wi)m=(a+r)*u,x=-2*u;else if(o===ao)m=r*u,x=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-d,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-f,l[2]=0,l[6]=0,l[10]=x,l[14]=-m,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){let e=this.elements,n=t.elements;for(let i=0;i<16;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}},Fs=new C,Vn=new Lt,hp=new C(0,0,0),up=new C(1,1,1),Fi=new C,Ca=new C,xn=new C,Yu=new Lt,$u=new Fe,nn=class s{constructor(t=0,e=0,n=0,i=s.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=i}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,i=this._order){return this._x=t,this._y=e,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){let i=t.elements,r=i[0],a=i[4],o=i[8],l=i[1],c=i[5],h=i[9],u=i[2],d=i[6],f=i[10];switch(e){case"XYZ":this._y=Math.asin(Ye(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Ye(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(Ye(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-Ye(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(Ye(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(o,f));break;case"XZY":this._z=Math.asin(-Ye(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-h,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return Yu.makeRotationFromQuaternion(t),this.setFromRotationMatrix(Yu,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return $u.setFromEuler(this),this.setFromQuaternion($u,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};nn.DEFAULT_ORDER="XYZ";var uo=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},dp=0,Zu=new C,Os=new Fe,vi=new Lt,Pa=new C,Lr=new C,fp=new C,pp=new Fe,Ku=new C(1,0,0),Ju=new C(0,1,0),ju=new C(0,0,1),Qu={type:"added"},mp={type:"removed"},Bs={type:"childadded",child:null},Fl={type:"childremoved",child:null},Le=class s extends Xi{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:dp++}),this.uuid=Gi(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=s.DEFAULT_UP.clone();let t=new C,e=new nn,n=new Fe,i=new C(1,1,1);function r(){n.setFromEuler(e,!1)}function a(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new Lt},normalMatrix:{value:new Yt}}),this.matrix=new Lt,this.matrixWorld=new Lt,this.matrixAutoUpdate=s.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=s.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new uo,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return Os.setFromAxisAngle(t,e),this.quaternion.multiply(Os),this}rotateOnWorldAxis(t,e){return Os.setFromAxisAngle(t,e),this.quaternion.premultiply(Os),this}rotateX(t){return this.rotateOnAxis(Ku,t)}rotateY(t){return this.rotateOnAxis(Ju,t)}rotateZ(t){return this.rotateOnAxis(ju,t)}translateOnAxis(t,e){return Zu.copy(t).applyQuaternion(this.quaternion),this.position.add(Zu.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(Ku,t)}translateY(t){return this.translateOnAxis(Ju,t)}translateZ(t){return this.translateOnAxis(ju,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(vi.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?Pa.copy(t):Pa.set(t,e,n);let i=this.parent;this.updateWorldMatrix(!0,!1),Lr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?vi.lookAt(Lr,Pa,this.up):vi.lookAt(Pa,Lr,this.up),this.quaternion.setFromRotationMatrix(vi),i&&(vi.extractRotation(i.matrixWorld),Os.setFromRotationMatrix(vi),this.quaternion.premultiply(Os.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(Qu),Bs.child=t,this.dispatchEvent(Bs),Bs.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(mp),Fl.child=t,this.dispatchEvent(Fl),Fl.child=null),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),vi.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),vi.multiply(t.parent.matrixWorld)),t.applyMatrix4(vi),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(Qu),Bs.child=t,this.dispatchEvent(Bs),Bs.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,i=this.children.length;n<i;n++){let a=this.children[n].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);let i=this.children;for(let r=0,a=i.length;r<a;r++)i[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Lr,t,fp),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Lr,pp,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e){let n=this.parent;if(t===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),e===!0){let i=this.children;for(let r=0,a=i.length;r<a;r++)i[r].updateWorldMatrix(!1,!0)}}toJSON(t){let e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.visibility=this._visibility,i.active=this._active,i.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),i.maxInstanceCount=this._maxInstanceCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.geometryCount=this._geometryCount,i.matricesTexture=this._matricesTexture.toJSON(t),this._colorsTexture!==null&&(i.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(i.boundingSphere={center:i.boundingSphere.center.toArray(),radius:i.boundingSphere.radius}),this.boundingBox!==null&&(i.boundingBox={min:i.boundingBox.min.toArray(),max:i.boundingBox.max.toArray()}));function r(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=r(t.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let l=o.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let u=l[c];r(t.shapes,u)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(r(t.materials,this.material[l]));i.material=o}else i.material=r(t.materials,this.material);if(this.children.length>0){i.children=[];for(let o=0;o<this.children.length;o++)i.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){i.animations=[];for(let o=0;o<this.animations.length;o++){let l=this.animations[o];i.animations.push(r(t.animations,l))}}if(e){let o=a(t.geometries),l=a(t.materials),c=a(t.textures),h=a(t.images),u=a(t.shapes),d=a(t.skeletons),f=a(t.animations),m=a(t.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),f.length>0&&(n.animations=f),m.length>0&&(n.nodes=m)}return n.object=i,n;function a(o){let l=[];for(let c in o){let h=o[c];delete h.metadata,l.push(h)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){let i=t.children[n];this.add(i.clone())}return this}};Le.DEFAULT_UP=new C(0,1,0);Le.DEFAULT_MATRIX_AUTO_UPDATE=!0;Le.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var Gn=new C,yi=new C,Ol=new C,_i=new C,zs=new C,Hs=new C,td=new C,Bl=new C,zl=new C,Hl=new C,Vl=new ue,Gl=new ue,Wl=new ue,zi=class s{constructor(t=new C,e=new C,n=new C){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,i){i.subVectors(n,e),Gn.subVectors(t,e),i.cross(Gn);let r=i.lengthSq();return r>0?i.multiplyScalar(1/Math.sqrt(r)):i.set(0,0,0)}static getBarycoord(t,e,n,i,r){Gn.subVectors(i,e),yi.subVectors(n,e),Ol.subVectors(t,e);let a=Gn.dot(Gn),o=Gn.dot(yi),l=Gn.dot(Ol),c=yi.dot(yi),h=yi.dot(Ol),u=a*c-o*o;if(u===0)return r.set(0,0,0),null;let d=1/u,f=(c*l-o*h)*d,m=(a*h-o*l)*d;return r.set(1-f-m,m,f)}static containsPoint(t,e,n,i){return this.getBarycoord(t,e,n,i,_i)===null?!1:_i.x>=0&&_i.y>=0&&_i.x+_i.y<=1}static getInterpolation(t,e,n,i,r,a,o,l){return this.getBarycoord(t,e,n,i,_i)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,_i.x),l.addScaledVector(a,_i.y),l.addScaledVector(o,_i.z),l)}static getInterpolatedAttribute(t,e,n,i,r,a){return Vl.setScalar(0),Gl.setScalar(0),Wl.setScalar(0),Vl.fromBufferAttribute(t,e),Gl.fromBufferAttribute(t,n),Wl.fromBufferAttribute(t,i),a.setScalar(0),a.addScaledVector(Vl,r.x),a.addScaledVector(Gl,r.y),a.addScaledVector(Wl,r.z),a}static isFrontFacing(t,e,n,i){return Gn.subVectors(n,e),yi.subVectors(t,e),Gn.cross(yi).dot(i)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,i){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[i]),this}setFromAttributeAndIndices(t,e,n,i){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,i),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return Gn.subVectors(this.c,this.b),yi.subVectors(this.a,this.b),Gn.cross(yi).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return s.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return s.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,i,r){return s.getInterpolation(t,this.a,this.b,this.c,e,n,i,r)}containsPoint(t){return s.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return s.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let n=this.a,i=this.b,r=this.c,a,o;zs.subVectors(i,n),Hs.subVectors(r,n),Bl.subVectors(t,n);let l=zs.dot(Bl),c=Hs.dot(Bl);if(l<=0&&c<=0)return e.copy(n);zl.subVectors(t,i);let h=zs.dot(zl),u=Hs.dot(zl);if(h>=0&&u<=h)return e.copy(i);let d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return a=l/(l-h),e.copy(n).addScaledVector(zs,a);Hl.subVectors(t,r);let f=zs.dot(Hl),m=Hs.dot(Hl);if(m>=0&&f<=m)return e.copy(r);let x=f*c-l*m;if(x<=0&&c>=0&&m<=0)return o=c/(c-m),e.copy(n).addScaledVector(Hs,o);let g=h*m-f*u;if(g<=0&&u-h>=0&&f-m>=0)return td.subVectors(r,i),o=(u-h)/(u-h+(f-m)),e.copy(i).addScaledVector(td,o);let p=1/(g+x+d);return a=x*p,o=d*p,e.copy(n).addScaledVector(zs,a).addScaledVector(Hs,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},of={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Oi={h:0,s:0,l:0},Ia={h:0,s:0,l:0};function Xl(s,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?s+(t-s)*6*e:e<1/2?t:e<2/3?s+(t-s)*6*(2/3-e):s}var ot=class{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){let i=t;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=qe){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,se.toWorkingColorSpace(this,e),this}setRGB(t,e,n,i=se.workingColorSpace){return this.r=t,this.g=e,this.b=n,se.toWorkingColorSpace(this,i),this}setHSL(t,e,n,i=se.workingColorSpace){if(t=np(t,1),e=Ye(e,0,1),n=Ye(n,0,1),e===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+e):n+e-n*e,a=2*n-r;this.r=Xl(a,r,t+1/3),this.g=Xl(a,r,t),this.b=Xl(a,r,t-1/3)}return se.toWorkingColorSpace(this,i),this}setStyle(t,e=qe){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,a=i[1],o=i[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=i[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=qe){let n=of[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Si(t.r),this.g=Si(t.g),this.b=Si(t.b),this}copyLinearToSRGB(t){return this.r=Qs(t.r),this.g=Qs(t.g),this.b=Qs(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=qe){return se.fromWorkingColorSpace(en.copy(this),t),Math.round(Ye(en.r*255,0,255))*65536+Math.round(Ye(en.g*255,0,255))*256+Math.round(Ye(en.b*255,0,255))}getHexString(t=qe){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=se.workingColorSpace){se.fromWorkingColorSpace(en.copy(this),e);let n=en.r,i=en.g,r=en.b,a=Math.max(n,i,r),o=Math.min(n,i,r),l,c,h=(o+a)/2;if(o===a)l=0,c=0;else{let u=a-o;switch(c=h<=.5?u/(a+o):u/(2-a-o),a){case n:l=(i-r)/u+(i<r?6:0);break;case i:l=(r-n)/u+2;break;case r:l=(n-i)/u+4;break}l/=6}return t.h=l,t.s=c,t.l=h,t}getRGB(t,e=se.workingColorSpace){return se.fromWorkingColorSpace(en.copy(this),e),t.r=en.r,t.g=en.g,t.b=en.b,t}getStyle(t=qe){se.fromWorkingColorSpace(en.copy(this),t);let e=en.r,n=en.g,i=en.b;return t!==qe?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(t,e,n){return this.getHSL(Oi),this.setHSL(Oi.h+t,Oi.s+e,Oi.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(Oi),t.getHSL(Ia);let n=Rl(Oi.h,Ia.h,e),i=Rl(Oi.s,Ia.s,e),r=Rl(Oi.l,Ia.l,e);return this.setHSL(n,i,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,n=this.g,i=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*i,this.g=r[1]*e+r[4]*n+r[7]*i,this.b=r[2]*e+r[5]*n+r[8]*i,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},en=new ot;ot.NAMES=of;var gp=0,li=class extends Xi{static get type(){return"Material"}get type(){return this.constructor.type}set type(t){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:gp++}),this.uuid=Gi(),this.name="",this.blending=Hi,this.side=Wi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=lc,this.blendDst=cc,this.blendEquation=ds,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new ot(0,0,0),this.blendAlpha=0,this.depthFunc=er,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Ou,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ls,this.stencilZFail=Ls,this.stencilZPass=Ls,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}let i=this[e];if(i===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Hi&&(n.blending=this.blending),this.side!==Wi&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==lc&&(n.blendSrc=this.blendSrc),this.blendDst!==cc&&(n.blendDst=this.blendDst),this.blendEquation!==ds&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==er&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Ou&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Ls&&(n.stencilFail=this.stencilFail),this.stencilZFail!==Ls&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==Ls&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(r){let a=[];for(let o in r){let l=r[o];delete l.metadata,a.push(l)}return a}if(e){let r=i(t.textures),a=i(t.images);r.length>0&&(n.textures=r),a.length>0&&(n.images=a)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,n=null;if(e!==null){let i=e.length;n=new Array(i);for(let r=0;r!==i;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}},De=class extends li{static get type(){return"MeshBasicMaterial"}constructor(t){super(),this.isMeshBasicMaterial=!0,this.color=new ot(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new nn,this.combine=qd,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}};var Be=new C,La=new tt,Vt=class{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=Yc,this.updateRanges=[],this.gpuType=ai,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let i=0,r=this.itemSize;i<r;i++)this.array[t+i]=e.array[n+i];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)La.fromBufferAttribute(this,e),La.applyMatrix3(t),this.setXY(e,La.x,La.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)Be.fromBufferAttribute(this,e),Be.applyMatrix3(t),this.setXYZ(e,Be.x,Be.y,Be.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)Be.fromBufferAttribute(this,e),Be.applyMatrix4(t),this.setXYZ(e,Be.x,Be.y,Be.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Be.fromBufferAttribute(this,e),Be.applyNormalMatrix(t),this.setXYZ(e,Be.x,Be.y,Be.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Be.fromBufferAttribute(this,e),Be.transformDirection(t),this.setXYZ(e,Be.x,Be.y,Be.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=si(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=ye(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=si(e,this.array)),e}setX(t,e){return this.normalized&&(e=ye(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=si(e,this.array)),e}setY(t,e){return this.normalized&&(e=ye(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=si(e,this.array)),e}setZ(t,e){return this.normalized&&(e=ye(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=si(e,this.array)),e}setW(t,e){return this.normalized&&(e=ye(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=ye(e,this.array),n=ye(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,i){return t*=this.itemSize,this.normalized&&(e=ye(e,this.array),n=ye(n,this.array),i=ye(i,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this}setXYZW(t,e,n,i,r){return t*=this.itemSize,this.normalized&&(e=ye(e,this.array),n=ye(n,this.array),i=ye(i,this.array),r=ye(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==Yc&&(t.usage=this.usage),t}};var fo=class extends Vt{constructor(t,e,n){super(new Uint16Array(t),e,n)}};var po=class extends Vt{constructor(t,e,n){super(new Uint32Array(t),e,n)}};var wt=class extends Vt{constructor(t,e,n){super(new Float32Array(t),e,n)}},xp=0,wn=new Lt,ql=new Le,Vs=new C,vn=new qn,Dr=new qn,Xe=new C,Gt=class s extends Xi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:xp++}),this.uuid=Gi(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(af(t)?po:fo)(t,1):this.index=t,this}setIndirect(t){return this.indirect=t,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new Yt().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}let i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(t),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return wn.makeRotationFromQuaternion(t),this.applyMatrix4(wn),this}rotateX(t){return wn.makeRotationX(t),this.applyMatrix4(wn),this}rotateY(t){return wn.makeRotationY(t),this.applyMatrix4(wn),this}rotateZ(t){return wn.makeRotationZ(t),this.applyMatrix4(wn),this}translate(t,e,n){return wn.makeTranslation(t,e,n),this.applyMatrix4(wn),this}scale(t,e,n){return wn.makeScale(t,e,n),this.applyMatrix4(wn),this}lookAt(t){return ql.lookAt(t),ql.updateMatrix(),this.applyMatrix4(ql.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Vs).negate(),this.translate(Vs.x,Vs.y,Vs.z),this}setFromPoints(t){let e=this.getAttribute("position");if(e===void 0){let n=[];for(let i=0,r=t.length;i<r;i++){let a=t[i];n.push(a.x,a.y,a.z||0)}this.setAttribute("position",new wt(n,3))}else{for(let n=0,i=e.count;n<i;n++){let r=t[n];e.setXYZ(n,r.x,r.y,r.z||0)}t.length>e.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new qn);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new C(-1/0,-1/0,-1/0),new C(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,i=e.length;n<i;n++){let r=e[n];vn.setFromBufferAttribute(r),this.morphTargetsRelative?(Xe.addVectors(this.boundingBox.min,vn.min),this.boundingBox.expandByPoint(Xe),Xe.addVectors(this.boundingBox.max,vn.max),this.boundingBox.expandByPoint(Xe)):(this.boundingBox.expandByPoint(vn.min),this.boundingBox.expandByPoint(vn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ti);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new C,1/0);return}if(t){let n=this.boundingSphere.center;if(vn.setFromBufferAttribute(t),e)for(let r=0,a=e.length;r<a;r++){let o=e[r];Dr.setFromBufferAttribute(o),this.morphTargetsRelative?(Xe.addVectors(vn.min,Dr.min),vn.expandByPoint(Xe),Xe.addVectors(vn.max,Dr.max),vn.expandByPoint(Xe)):(vn.expandByPoint(Dr.min),vn.expandByPoint(Dr.max))}vn.getCenter(n);let i=0;for(let r=0,a=t.count;r<a;r++)Xe.fromBufferAttribute(t,r),i=Math.max(i,n.distanceToSquared(Xe));if(e)for(let r=0,a=e.length;r<a;r++){let o=e[r],l=this.morphTargetsRelative;for(let c=0,h=o.count;c<h;c++)Xe.fromBufferAttribute(o,c),l&&(Vs.fromBufferAttribute(t,c),Xe.add(Vs)),i=Math.max(i,n.distanceToSquared(Xe))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=e.position,i=e.normal,r=e.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Vt(new Float32Array(4*n.count),4));let a=this.getAttribute("tangent"),o=[],l=[];for(let A=0;A<n.count;A++)o[A]=new C,l[A]=new C;let c=new C,h=new C,u=new C,d=new tt,f=new tt,m=new tt,x=new C,g=new C;function p(A,w,b){c.fromBufferAttribute(n,A),h.fromBufferAttribute(n,w),u.fromBufferAttribute(n,b),d.fromBufferAttribute(r,A),f.fromBufferAttribute(r,w),m.fromBufferAttribute(r,b),h.sub(c),u.sub(c),f.sub(d),m.sub(d);let P=1/(f.x*m.y-m.x*f.y);isFinite(P)&&(x.copy(h).multiplyScalar(m.y).addScaledVector(u,-f.y).multiplyScalar(P),g.copy(u).multiplyScalar(f.x).addScaledVector(h,-m.x).multiplyScalar(P),o[A].add(x),o[w].add(x),o[b].add(x),l[A].add(g),l[w].add(g),l[b].add(g))}let v=this.groups;v.length===0&&(v=[{start:0,count:t.count}]);for(let A=0,w=v.length;A<w;++A){let b=v[A],P=b.start,D=b.count;for(let U=P,F=P+D;U<F;U+=3)p(t.getX(U+0),t.getX(U+1),t.getX(U+2))}let y=new C,_=new C,S=new C,M=new C;function E(A){S.fromBufferAttribute(i,A),M.copy(S);let w=o[A];y.copy(w),y.sub(S.multiplyScalar(S.dot(w))).normalize(),_.crossVectors(M,w);let P=_.dot(l[A])<0?-1:1;a.setXYZW(A,y.x,y.y,y.z,P)}for(let A=0,w=v.length;A<w;++A){let b=v[A],P=b.start,D=b.count;for(let U=P,F=P+D;U<F;U+=3)E(t.getX(U+0)),E(t.getX(U+1)),E(t.getX(U+2))}}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new Vt(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let d=0,f=n.count;d<f;d++)n.setXYZ(d,0,0,0);let i=new C,r=new C,a=new C,o=new C,l=new C,c=new C,h=new C,u=new C;if(t)for(let d=0,f=t.count;d<f;d+=3){let m=t.getX(d+0),x=t.getX(d+1),g=t.getX(d+2);i.fromBufferAttribute(e,m),r.fromBufferAttribute(e,x),a.fromBufferAttribute(e,g),h.subVectors(a,r),u.subVectors(i,r),h.cross(u),o.fromBufferAttribute(n,m),l.fromBufferAttribute(n,x),c.fromBufferAttribute(n,g),o.add(h),l.add(h),c.add(h),n.setXYZ(m,o.x,o.y,o.z),n.setXYZ(x,l.x,l.y,l.z),n.setXYZ(g,c.x,c.y,c.z)}else for(let d=0,f=e.count;d<f;d+=3)i.fromBufferAttribute(e,d+0),r.fromBufferAttribute(e,d+1),a.fromBufferAttribute(e,d+2),h.subVectors(a,r),u.subVectors(i,r),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)Xe.fromBufferAttribute(t,e),Xe.normalize(),t.setXYZ(e,Xe.x,Xe.y,Xe.z)}toNonIndexed(){function t(o,l){let c=o.array,h=o.itemSize,u=o.normalized,d=new c.constructor(l.length*h),f=0,m=0;for(let x=0,g=l.length;x<g;x++){o.isInterleavedBufferAttribute?f=l[x]*o.data.stride+o.offset:f=l[x]*h;for(let p=0;p<h;p++)d[m++]=c[f++]}return new Vt(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new s,n=this.index.array,i=this.attributes;for(let o in i){let l=i[o],c=t(l,n);e.setAttribute(o,c)}let r=this.morphAttributes;for(let o in r){let l=[],c=r[o];for(let h=0,u=c.length;h<u;h++){let d=c[h],f=t(d,n);l.push(f)}e.morphAttributes[o]=l}e.morphTargetsRelative=this.morphTargetsRelative;let a=this.groups;for(let o=0,l=a.length;o<l;o++){let c=a[o];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){let t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let n=this.attributes;for(let l in n){let c=n[l];t.data.attributes[l]=c.toJSON(t.data)}let i={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){let f=c[u];h.push(f.toJSON(t.data))}h.length>0&&(i[l]=h,r=!0)}r&&(t.data.morphAttributes=i,t.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(t.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let n=t.index;n!==null&&this.setIndex(n.clone(e));let i=t.attributes;for(let c in i){let h=i[c];this.setAttribute(c,h.clone(e))}let r=t.morphAttributes;for(let c in r){let h=[],u=r[c];for(let d=0,f=u.length;d<f;d++)h.push(u[d].clone(e));this.morphAttributes[c]=h}this.morphTargetsRelative=t.morphTargetsRelative;let a=t.groups;for(let c=0,h=a.length;c<h;c++){let u=a[c];this.addGroup(u.start,u.count,u.materialIndex)}let o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());let l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},ed=new Lt,os=new Yr,Da=new Ti,nd=new C,ka=new C,Ua=new C,Na=new C,Yl=new C,Fa=new C,id=new C,Oa=new C,it=class extends Le{constructor(t=new Gt,e=new De){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=i.length;r<a;r++){let o=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(t,e){let n=this.geometry,i=n.attributes.position,r=n.morphAttributes.position,a=n.morphTargetsRelative;e.fromBufferAttribute(i,t);let o=this.morphTargetInfluences;if(r&&o){Fa.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let h=o[l],u=r[l];h!==0&&(Yl.fromBufferAttribute(u,t),a?Fa.addScaledVector(Yl,h):Fa.addScaledVector(Yl.sub(e),h))}e.add(Fa)}return e}raycast(t,e){let n=this.geometry,i=this.material,r=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Da.copy(n.boundingSphere),Da.applyMatrix4(r),os.copy(t.ray).recast(t.near),!(Da.containsPoint(os.origin)===!1&&(os.intersectSphere(Da,nd)===null||os.origin.distanceToSquared(nd)>(t.far-t.near)**2))&&(ed.copy(r).invert(),os.copy(t.ray).applyMatrix4(ed),!(n.boundingBox!==null&&os.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,os)))}_computeIntersections(t,e,n){let i,r=this.geometry,a=this.material,o=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,d=r.groups,f=r.drawRange;if(o!==null)if(Array.isArray(a))for(let m=0,x=d.length;m<x;m++){let g=d[m],p=a[g.materialIndex],v=Math.max(g.start,f.start),y=Math.min(o.count,Math.min(g.start+g.count,f.start+f.count));for(let _=v,S=y;_<S;_+=3){let M=o.getX(_),E=o.getX(_+1),A=o.getX(_+2);i=Ba(this,p,t,n,c,h,u,M,E,A),i&&(i.faceIndex=Math.floor(_/3),i.face.materialIndex=g.materialIndex,e.push(i))}}else{let m=Math.max(0,f.start),x=Math.min(o.count,f.start+f.count);for(let g=m,p=x;g<p;g+=3){let v=o.getX(g),y=o.getX(g+1),_=o.getX(g+2);i=Ba(this,a,t,n,c,h,u,v,y,_),i&&(i.faceIndex=Math.floor(g/3),e.push(i))}}else if(l!==void 0)if(Array.isArray(a))for(let m=0,x=d.length;m<x;m++){let g=d[m],p=a[g.materialIndex],v=Math.max(g.start,f.start),y=Math.min(l.count,Math.min(g.start+g.count,f.start+f.count));for(let _=v,S=y;_<S;_+=3){let M=_,E=_+1,A=_+2;i=Ba(this,p,t,n,c,h,u,M,E,A),i&&(i.faceIndex=Math.floor(_/3),i.face.materialIndex=g.materialIndex,e.push(i))}}else{let m=Math.max(0,f.start),x=Math.min(l.count,f.start+f.count);for(let g=m,p=x;g<p;g+=3){let v=g,y=g+1,_=g+2;i=Ba(this,a,t,n,c,h,u,v,y,_),i&&(i.faceIndex=Math.floor(g/3),e.push(i))}}}};function vp(s,t,e,n,i,r,a,o){let l;if(t.side===Ce?l=n.intersectTriangle(a,r,i,!0,o):l=n.intersectTriangle(i,r,a,t.side===Wi,o),l===null)return null;Oa.copy(o),Oa.applyMatrix4(s.matrixWorld);let c=e.ray.origin.distanceTo(Oa);return c<e.near||c>e.far?null:{distance:c,point:Oa.clone(),object:s}}function Ba(s,t,e,n,i,r,a,o,l,c){s.getVertexPosition(o,ka),s.getVertexPosition(l,Ua),s.getVertexPosition(c,Na);let h=vp(s,t,e,n,ka,Ua,Na,id);if(h){let u=new C;zi.getBarycoord(id,ka,Ua,Na,u),i&&(h.uv=zi.getInterpolatedAttribute(i,o,l,c,u,new tt)),r&&(h.uv1=zi.getInterpolatedAttribute(r,o,l,c,u,new tt)),a&&(h.normal=zi.getInterpolatedAttribute(a,o,l,c,u,new C),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));let d={a:o,b:l,c,normal:new C,materialIndex:0};zi.getNormal(ka,Ua,Na,d.normal),h.face=d,h.barycoord=u}return h}var jt=class s extends Gt{constructor(t=1,e=1,n=1,i=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:i,heightSegments:r,depthSegments:a};let o=this;i=Math.floor(i),r=Math.floor(r),a=Math.floor(a);let l=[],c=[],h=[],u=[],d=0,f=0;m("z","y","x",-1,-1,n,e,t,a,r,0),m("z","y","x",1,-1,n,e,-t,a,r,1),m("x","z","y",1,1,t,n,e,i,a,2),m("x","z","y",1,-1,t,n,-e,i,a,3),m("x","y","z",1,-1,t,e,n,i,r,4),m("x","y","z",-1,-1,t,e,-n,i,r,5),this.setIndex(l),this.setAttribute("position",new wt(c,3)),this.setAttribute("normal",new wt(h,3)),this.setAttribute("uv",new wt(u,2));function m(x,g,p,v,y,_,S,M,E,A,w){let b=_/E,P=S/A,D=_/2,U=S/2,F=M/2,q=E+1,V=A+1,J=0,G=0,nt=new C;for(let ht=0;ht<V;ht++){let Et=ht*P-U;for(let Ot=0;Ot<q;Ot++){let re=Ot*b-D;nt[x]=re*v,nt[g]=Et*y,nt[p]=F,c.push(nt.x,nt.y,nt.z),nt[x]=0,nt[g]=0,nt[p]=M>0?1:-1,h.push(nt.x,nt.y,nt.z),u.push(Ot/E),u.push(1-ht/A),J+=1}}for(let ht=0;ht<A;ht++)for(let Et=0;Et<E;Et++){let Ot=d+Et+q*ht,re=d+Et+q*(ht+1),Z=d+(Et+1)+q*(ht+1),st=d+(Et+1)+q*ht;l.push(Ot,re,st),l.push(re,Z,st),G+=6}o.addGroup(f,G,w),f+=G,d+=J}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};function ar(s){let t={};for(let e in s){t[e]={};for(let n in s[e]){let i=s[e][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?i.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=i.clone():Array.isArray(i)?t[e][n]=i.slice():t[e][n]=i}}return t}function on(s){let t={};for(let e=0;e<s.length;e++){let n=ar(s[e]);for(let i in n)t[i]=n[i]}return t}function yp(s){let t=[];for(let e=0;e<s.length;e++)t.push(s[e].clone());return t}function lf(s){let t=s.getRenderTarget();return t===null?s.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:se.workingColorSpace}var Tn={clone:ar,merge:on},_p=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Mp=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,ve=class extends li{static get type(){return"ShaderMaterial"}constructor(t){super(),this.isShaderMaterial=!0,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=_p,this.fragmentShader=Mp,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=ar(t.uniforms),this.uniformsGroups=yp(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let i in this.uniforms){let a=this.uniforms[i].value;a&&a.isTexture?e.uniforms[i]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[i]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[i]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[i]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[i]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[i]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[i]={type:"m4",value:a.toArray()}:e.uniforms[i]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let n={};for(let i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}},mo=class extends Le{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Lt,this.projectionMatrix=new Lt,this.projectionMatrixInverse=new Lt,this.coordinateSystem=wi}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},Bi=new C,sd=new tt,rd=new tt,Ue=class extends mo{constructor(t=50,e=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=oo*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(Al*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return oo*2*Math.atan(Math.tan(Al*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){Bi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(Bi.x,Bi.y).multiplyScalar(-t/Bi.z),Bi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Bi.x,Bi.y).multiplyScalar(-t/Bi.z)}getViewSize(t,e){return this.getViewBounds(t,sd,rd),e.subVectors(rd,sd)}setViewOffset(t,e,n,i,r,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(Al*.5*this.fov)/this.zoom,n=2*e,i=this.aspect*n,r=-.5*i,a=this.view;if(this.view!==null&&this.view.enabled){let l=a.fullWidth,c=a.fullHeight;r+=a.offsetX*i/l,e-=a.offsetY*n/c,i*=a.width/l,n*=a.height/c}let o=this.filmOffset;o!==0&&(r+=t*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+i,e,e-n,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}},Gs=-90,Ws=1,Jc=class extends Le{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let i=new Ue(Gs,Ws,t,e);i.layers=this.layers,this.add(i);let r=new Ue(Gs,Ws,t,e);r.layers=this.layers,this.add(r);let a=new Ue(Gs,Ws,t,e);a.layers=this.layers,this.add(a);let o=new Ue(Gs,Ws,t,e);o.layers=this.layers,this.add(o);let l=new Ue(Gs,Ws,t,e);l.layers=this.layers,this.add(l);let c=new Ue(Gs,Ws,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[n,i,r,a,o,l]=e;for(let c of e)this.remove(c);if(t===wi)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===ao)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:i}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,a,o,l,c,h]=this.children,u=t.getRenderTarget(),d=t.getActiveCubeFace(),f=t.getActiveMipmapLevel(),m=t.xr.enabled;t.xr.enabled=!1;let x=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,i),t.render(e,r),t.setRenderTarget(n,1,i),t.render(e,a),t.setRenderTarget(n,2,i),t.render(e,o),t.setRenderTarget(n,3,i),t.render(e,l),t.setRenderTarget(n,4,i),t.render(e,c),n.texture.generateMipmaps=x,t.setRenderTarget(n,5,i),t.render(e,h),t.setRenderTarget(u,d,f),t.xr.enabled=m,n.texture.needsPMREMUpdate=!0}},go=class extends fn{constructor(t,e,n,i,r,a,o,l,c,h){t=t!==void 0?t:[],e=e!==void 0?e:nr,super(t,e,n,i,r,a,o,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},jc=class extends Ne{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let n={width:t,height:t,depth:1},i=[n,n,n,n,n,n];this.texture=new go(i,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:ri}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new jt(5,5,5),r=new ve({name:"CubemapFromEquirect",uniforms:ar(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Ce,blending:oi});r.uniforms.tEquirect.value=e;let a=new it(i,r),o=e.minFilter;return e.minFilter===bi&&(e.minFilter=ri),new Jc(1,10,this).update(t,a),e.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(t,e,n,i){let r=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,n,i);t.setRenderTarget(r)}},$l=new C,bp=new C,wp=new Yt,Wn=class{constructor(t=new C(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,i){return this.normal.set(t,e,n),this.constant=i,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){let i=$l.subVectors(n,e).cross(bp.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(i,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){let n=t.delta($l),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let r=-(t.start.dot(this.normal)+this.constant)/i;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){let e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let n=e||wp.getNormalMatrix(t),i=this.coplanarPoint($l).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}},ls=new Ti,za=new C,$r=class{constructor(t=new Wn,e=new Wn,n=new Wn,i=new Wn,r=new Wn,a=new Wn){this.planes=[t,e,n,i,r,a]}set(t,e,n,i,r,a){let o=this.planes;return o[0].copy(t),o[1].copy(e),o[2].copy(n),o[3].copy(i),o[4].copy(r),o[5].copy(a),this}copy(t){let e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=wi){let n=this.planes,i=t.elements,r=i[0],a=i[1],o=i[2],l=i[3],c=i[4],h=i[5],u=i[6],d=i[7],f=i[8],m=i[9],x=i[10],g=i[11],p=i[12],v=i[13],y=i[14],_=i[15];if(n[0].setComponents(l-r,d-c,g-f,_-p).normalize(),n[1].setComponents(l+r,d+c,g+f,_+p).normalize(),n[2].setComponents(l+a,d+h,g+m,_+v).normalize(),n[3].setComponents(l-a,d-h,g-m,_-v).normalize(),n[4].setComponents(l-o,d-u,g-x,_-y).normalize(),e===wi)n[5].setComponents(l+o,d+u,g+x,_+y).normalize();else if(e===ao)n[5].setComponents(o,u,x,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),ls.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),ls.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(ls)}intersectsSprite(t){return ls.center.set(0,0,0),ls.radius=.7071067811865476,ls.applyMatrix4(t.matrixWorld),this.intersectsSphere(ls)}intersectsSphere(t){let e=this.planes,n=t.center,i=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<i)return!1;return!0}intersectsBox(t){let e=this.planes;for(let n=0;n<6;n++){let i=e[n];if(za.x=i.normal.x>0?t.max.x:t.min.x,za.y=i.normal.y>0?t.max.y:t.min.y,za.z=i.normal.z>0?t.max.z:t.min.z,i.distanceToPoint(za)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function cf(){let s=null,t=!1,e=null,n=null;function i(r,a){e(r,a),n=s.requestAnimationFrame(i)}return{start:function(){t!==!0&&e!==null&&(n=s.requestAnimationFrame(i),t=!0)},stop:function(){s.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){s=r}}}function Sp(s){let t=new WeakMap;function e(o,l){let c=o.array,h=o.usage,u=c.byteLength,d=s.createBuffer();s.bindBuffer(l,d),s.bufferData(l,c,h),o.onUploadCallback();let f;if(c instanceof Float32Array)f=s.FLOAT;else if(c instanceof Uint16Array)o.isFloat16BufferAttribute?f=s.HALF_FLOAT:f=s.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=s.SHORT;else if(c instanceof Uint32Array)f=s.UNSIGNED_INT;else if(c instanceof Int32Array)f=s.INT;else if(c instanceof Int8Array)f=s.BYTE;else if(c instanceof Uint8Array)f=s.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=s.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:d,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:u}}function n(o,l,c){let h=l.array,u=l.updateRanges;if(s.bindBuffer(c,o),u.length===0)s.bufferSubData(c,0,h);else{u.sort((f,m)=>f.start-m.start);let d=0;for(let f=1;f<u.length;f++){let m=u[d],x=u[f];x.start<=m.start+m.count+1?m.count=Math.max(m.count,x.start+x.count-m.start):(++d,u[d]=x)}u.length=d+1;for(let f=0,m=u.length;f<m;f++){let x=u[f];s.bufferSubData(c,x.start*h.BYTES_PER_ELEMENT,h,x.start,x.count)}l.clearUpdateRanges()}l.onUploadCallback()}function i(o){return o.isInterleavedBufferAttribute&&(o=o.data),t.get(o)}function r(o){o.isInterleavedBufferAttribute&&(o=o.data);let l=t.get(o);l&&(s.deleteBuffer(l.buffer),t.delete(o))}function a(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){let h=t.get(o);(!h||h.version<o.version)&&t.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}let c=t.get(o);if(c===void 0)t.set(o,e(o,l));else if(c.version<o.version){if(c.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,o,l),c.version=o.version}}return{get:i,remove:r,update:a}}var we=class s extends Gt{constructor(t=1,e=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:i};let r=t/2,a=e/2,o=Math.floor(n),l=Math.floor(i),c=o+1,h=l+1,u=t/o,d=e/l,f=[],m=[],x=[],g=[];for(let p=0;p<h;p++){let v=p*d-a;for(let y=0;y<c;y++){let _=y*u-r;m.push(_,-v,0),x.push(0,0,1),g.push(y/o),g.push(1-p/l)}}for(let p=0;p<l;p++)for(let v=0;v<o;v++){let y=v+c*p,_=v+c*(p+1),S=v+1+c*(p+1),M=v+1+c*p;f.push(y,_,M),f.push(_,S,M)}this.setIndex(f),this.setAttribute("position",new wt(m,3)),this.setAttribute("normal",new wt(x,3)),this.setAttribute("uv",new wt(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.width,t.height,t.widthSegments,t.heightSegments)}},Ep=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Tp=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Ap=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Rp=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Cp=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Pp=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Ip=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Lp=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Dp=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,kp=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Up=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Np=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Fp=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Op=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Bp=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,zp=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Hp=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Vp=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Gp=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Wp=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Xp=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,qp=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Yp=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,$p=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Zp=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Kp=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Jp=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,jp=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Qp=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,tm=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,em="gl_FragColor = linearToOutputTexel( gl_FragColor );",nm=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,im=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,sm=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,rm=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,am=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,om=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,lm=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,cm=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,hm=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,um=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,dm=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,fm=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,pm=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,mm=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,gm=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,xm=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,vm=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,ym=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,_m=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Mm=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,bm=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,wm=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Sm=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Em=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Tm=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Am=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Rm=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Cm=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Pm=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Im=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Lm=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Dm=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,km=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Um=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Nm=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Fm=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Om=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Bm=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,zm=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Hm=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Vm=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Gm=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Wm=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Xm=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,qm=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Ym=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,$m=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Zm=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Km=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Jm=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,jm=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Qm=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,tg=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,eg=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,ng=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,ig=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,sg=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,rg=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,ag=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,og=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,lg=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,cg=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,hg=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,ug=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,dg=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,fg=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,pg=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,mg=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,gg=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,xg=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,vg=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,yg=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,_g=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Mg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,bg=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,wg=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,Sg=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Eg=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Tg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Ag=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Rg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Cg=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Pg=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Ig=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Lg=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Dg=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,kg=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Ug=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ng=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Fg=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Og=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Bg=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,zg=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Hg=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Vg=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Gg=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Wg=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Xg=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,qg=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Yg=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,$g=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Zg=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Kg=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Jg=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,jg=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Qg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,t1=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,e1=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,n1=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,i1=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Kt={alphahash_fragment:Ep,alphahash_pars_fragment:Tp,alphamap_fragment:Ap,alphamap_pars_fragment:Rp,alphatest_fragment:Cp,alphatest_pars_fragment:Pp,aomap_fragment:Ip,aomap_pars_fragment:Lp,batching_pars_vertex:Dp,batching_vertex:kp,begin_vertex:Up,beginnormal_vertex:Np,bsdfs:Fp,iridescence_fragment:Op,bumpmap_pars_fragment:Bp,clipping_planes_fragment:zp,clipping_planes_pars_fragment:Hp,clipping_planes_pars_vertex:Vp,clipping_planes_vertex:Gp,color_fragment:Wp,color_pars_fragment:Xp,color_pars_vertex:qp,color_vertex:Yp,common:$p,cube_uv_reflection_fragment:Zp,defaultnormal_vertex:Kp,displacementmap_pars_vertex:Jp,displacementmap_vertex:jp,emissivemap_fragment:Qp,emissivemap_pars_fragment:tm,colorspace_fragment:em,colorspace_pars_fragment:nm,envmap_fragment:im,envmap_common_pars_fragment:sm,envmap_pars_fragment:rm,envmap_pars_vertex:am,envmap_physical_pars_fragment:xm,envmap_vertex:om,fog_vertex:lm,fog_pars_vertex:cm,fog_fragment:hm,fog_pars_fragment:um,gradientmap_pars_fragment:dm,lightmap_pars_fragment:fm,lights_lambert_fragment:pm,lights_lambert_pars_fragment:mm,lights_pars_begin:gm,lights_toon_fragment:vm,lights_toon_pars_fragment:ym,lights_phong_fragment:_m,lights_phong_pars_fragment:Mm,lights_physical_fragment:bm,lights_physical_pars_fragment:wm,lights_fragment_begin:Sm,lights_fragment_maps:Em,lights_fragment_end:Tm,logdepthbuf_fragment:Am,logdepthbuf_pars_fragment:Rm,logdepthbuf_pars_vertex:Cm,logdepthbuf_vertex:Pm,map_fragment:Im,map_pars_fragment:Lm,map_particle_fragment:Dm,map_particle_pars_fragment:km,metalnessmap_fragment:Um,metalnessmap_pars_fragment:Nm,morphinstance_vertex:Fm,morphcolor_vertex:Om,morphnormal_vertex:Bm,morphtarget_pars_vertex:zm,morphtarget_vertex:Hm,normal_fragment_begin:Vm,normal_fragment_maps:Gm,normal_pars_fragment:Wm,normal_pars_vertex:Xm,normal_vertex:qm,normalmap_pars_fragment:Ym,clearcoat_normal_fragment_begin:$m,clearcoat_normal_fragment_maps:Zm,clearcoat_pars_fragment:Km,iridescence_pars_fragment:Jm,opaque_fragment:jm,packing:Qm,premultiplied_alpha_fragment:tg,project_vertex:eg,dithering_fragment:ng,dithering_pars_fragment:ig,roughnessmap_fragment:sg,roughnessmap_pars_fragment:rg,shadowmap_pars_fragment:ag,shadowmap_pars_vertex:og,shadowmap_vertex:lg,shadowmask_pars_fragment:cg,skinbase_vertex:hg,skinning_pars_vertex:ug,skinning_vertex:dg,skinnormal_vertex:fg,specularmap_fragment:pg,specularmap_pars_fragment:mg,tonemapping_fragment:gg,tonemapping_pars_fragment:xg,transmission_fragment:vg,transmission_pars_fragment:yg,uv_pars_fragment:_g,uv_pars_vertex:Mg,uv_vertex:bg,worldpos_vertex:wg,background_vert:Sg,background_frag:Eg,backgroundCube_vert:Tg,backgroundCube_frag:Ag,cube_vert:Rg,cube_frag:Cg,depth_vert:Pg,depth_frag:Ig,distanceRGBA_vert:Lg,distanceRGBA_frag:Dg,equirect_vert:kg,equirect_frag:Ug,linedashed_vert:Ng,linedashed_frag:Fg,meshbasic_vert:Og,meshbasic_frag:Bg,meshlambert_vert:zg,meshlambert_frag:Hg,meshmatcap_vert:Vg,meshmatcap_frag:Gg,meshnormal_vert:Wg,meshnormal_frag:Xg,meshphong_vert:qg,meshphong_frag:Yg,meshphysical_vert:$g,meshphysical_frag:Zg,meshtoon_vert:Kg,meshtoon_frag:Jg,points_vert:jg,points_frag:Qg,shadow_vert:t1,shadow_frag:e1,sprite_vert:n1,sprite_frag:i1},ut={common:{diffuse:{value:new ot(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Yt},alphaMap:{value:null},alphaMapTransform:{value:new Yt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Yt}},envmap:{envMap:{value:null},envMapRotation:{value:new Yt},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Yt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Yt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Yt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Yt},normalScale:{value:new tt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Yt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Yt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Yt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Yt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new ot(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new ot(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Yt},alphaTest:{value:0},uvTransform:{value:new Yt}},sprite:{diffuse:{value:new ot(16777215)},opacity:{value:1},center:{value:new tt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Yt},alphaMap:{value:null},alphaMapTransform:{value:new Yt},alphaTest:{value:0}}},ni={basic:{uniforms:on([ut.common,ut.specularmap,ut.envmap,ut.aomap,ut.lightmap,ut.fog]),vertexShader:Kt.meshbasic_vert,fragmentShader:Kt.meshbasic_frag},lambert:{uniforms:on([ut.common,ut.specularmap,ut.envmap,ut.aomap,ut.lightmap,ut.emissivemap,ut.bumpmap,ut.normalmap,ut.displacementmap,ut.fog,ut.lights,{emissive:{value:new ot(0)}}]),vertexShader:Kt.meshlambert_vert,fragmentShader:Kt.meshlambert_frag},phong:{uniforms:on([ut.common,ut.specularmap,ut.envmap,ut.aomap,ut.lightmap,ut.emissivemap,ut.bumpmap,ut.normalmap,ut.displacementmap,ut.fog,ut.lights,{emissive:{value:new ot(0)},specular:{value:new ot(1118481)},shininess:{value:30}}]),vertexShader:Kt.meshphong_vert,fragmentShader:Kt.meshphong_frag},standard:{uniforms:on([ut.common,ut.envmap,ut.aomap,ut.lightmap,ut.emissivemap,ut.bumpmap,ut.normalmap,ut.displacementmap,ut.roughnessmap,ut.metalnessmap,ut.fog,ut.lights,{emissive:{value:new ot(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Kt.meshphysical_vert,fragmentShader:Kt.meshphysical_frag},toon:{uniforms:on([ut.common,ut.aomap,ut.lightmap,ut.emissivemap,ut.bumpmap,ut.normalmap,ut.displacementmap,ut.gradientmap,ut.fog,ut.lights,{emissive:{value:new ot(0)}}]),vertexShader:Kt.meshtoon_vert,fragmentShader:Kt.meshtoon_frag},matcap:{uniforms:on([ut.common,ut.bumpmap,ut.normalmap,ut.displacementmap,ut.fog,{matcap:{value:null}}]),vertexShader:Kt.meshmatcap_vert,fragmentShader:Kt.meshmatcap_frag},points:{uniforms:on([ut.points,ut.fog]),vertexShader:Kt.points_vert,fragmentShader:Kt.points_frag},dashed:{uniforms:on([ut.common,ut.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Kt.linedashed_vert,fragmentShader:Kt.linedashed_frag},depth:{uniforms:on([ut.common,ut.displacementmap]),vertexShader:Kt.depth_vert,fragmentShader:Kt.depth_frag},normal:{uniforms:on([ut.common,ut.bumpmap,ut.normalmap,ut.displacementmap,{opacity:{value:1}}]),vertexShader:Kt.meshnormal_vert,fragmentShader:Kt.meshnormal_frag},sprite:{uniforms:on([ut.sprite,ut.fog]),vertexShader:Kt.sprite_vert,fragmentShader:Kt.sprite_frag},background:{uniforms:{uvTransform:{value:new Yt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Kt.background_vert,fragmentShader:Kt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Yt}},vertexShader:Kt.backgroundCube_vert,fragmentShader:Kt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Kt.cube_vert,fragmentShader:Kt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Kt.equirect_vert,fragmentShader:Kt.equirect_frag},distanceRGBA:{uniforms:on([ut.common,ut.displacementmap,{referencePosition:{value:new C},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Kt.distanceRGBA_vert,fragmentShader:Kt.distanceRGBA_frag},shadow:{uniforms:on([ut.lights,ut.fog,{color:{value:new ot(0)},opacity:{value:1}}]),vertexShader:Kt.shadow_vert,fragmentShader:Kt.shadow_frag}};ni.physical={uniforms:on([ni.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Yt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Yt},clearcoatNormalScale:{value:new tt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Yt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Yt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Yt},sheen:{value:0},sheenColor:{value:new ot(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Yt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Yt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Yt},transmissionSamplerSize:{value:new tt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Yt},attenuationDistance:{value:0},attenuationColor:{value:new ot(0)},specularColor:{value:new ot(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Yt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Yt},anisotropyVector:{value:new tt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Yt}}]),vertexShader:Kt.meshphysical_vert,fragmentShader:Kt.meshphysical_frag};var Ha={r:0,b:0,g:0},cs=new nn,s1=new Lt;function r1(s,t,e,n,i,r,a){let o=new ot(0),l=r===!0?0:1,c,h,u=null,d=0,f=null;function m(v){let y=v.isScene===!0?v.background:null;return y&&y.isTexture&&(y=(v.backgroundBlurriness>0?e:t).get(y)),y}function x(v){let y=!1,_=m(v);_===null?p(o,l):_&&_.isColor&&(p(_,1),y=!0);let S=s.xr.getEnvironmentBlendMode();S==="additive"?n.buffers.color.setClear(0,0,0,1,a):S==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,a),(s.autoClear||y)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),s.clear(s.autoClearColor,s.autoClearDepth,s.autoClearStencil))}function g(v,y){let _=m(y);_&&(_.isCubeTexture||_.mapping===Oo)?(h===void 0&&(h=new it(new jt(1,1,1),new ve({name:"BackgroundCubeMaterial",uniforms:ar(ni.backgroundCube.uniforms),vertexShader:ni.backgroundCube.vertexShader,fragmentShader:ni.backgroundCube.fragmentShader,side:Ce,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(S,M,E){this.matrixWorld.copyPosition(E.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(h)),cs.copy(y.backgroundRotation),cs.x*=-1,cs.y*=-1,cs.z*=-1,_.isCubeTexture&&_.isRenderTargetTexture===!1&&(cs.y*=-1,cs.z*=-1),h.material.uniforms.envMap.value=_,h.material.uniforms.flipEnvMap.value=_.isCubeTexture&&_.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=y.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=y.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(s1.makeRotationFromEuler(cs)),h.material.toneMapped=se.getTransfer(_.colorSpace)!==pe,(u!==_||d!==_.version||f!==s.toneMapping)&&(h.material.needsUpdate=!0,u=_,d=_.version,f=s.toneMapping),h.layers.enableAll(),v.unshift(h,h.geometry,h.material,0,0,null)):_&&_.isTexture&&(c===void 0&&(c=new it(new we(2,2),new ve({name:"BackgroundMaterial",uniforms:ar(ni.background.uniforms),vertexShader:ni.background.vertexShader,fragmentShader:ni.background.fragmentShader,side:Wi,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(c)),c.material.uniforms.t2D.value=_,c.material.uniforms.backgroundIntensity.value=y.backgroundIntensity,c.material.toneMapped=se.getTransfer(_.colorSpace)!==pe,_.matrixAutoUpdate===!0&&_.updateMatrix(),c.material.uniforms.uvTransform.value.copy(_.matrix),(u!==_||d!==_.version||f!==s.toneMapping)&&(c.material.needsUpdate=!0,u=_,d=_.version,f=s.toneMapping),c.layers.enableAll(),v.unshift(c,c.geometry,c.material,0,0,null))}function p(v,y){v.getRGB(Ha,lf(s)),n.buffers.color.setClear(Ha.r,Ha.g,Ha.b,y,a)}return{getClearColor:function(){return o},setClearColor:function(v,y=1){o.set(v),l=y,p(o,l)},getClearAlpha:function(){return l},setClearAlpha:function(v){l=v,p(o,l)},render:x,addToRenderList:g}}function a1(s,t){let e=s.getParameter(s.MAX_VERTEX_ATTRIBS),n={},i=d(null),r=i,a=!1;function o(b,P,D,U,F){let q=!1,V=u(U,D,P);r!==V&&(r=V,c(r.object)),q=f(b,U,D,F),q&&m(b,U,D,F),F!==null&&t.update(F,s.ELEMENT_ARRAY_BUFFER),(q||a)&&(a=!1,_(b,P,D,U),F!==null&&s.bindBuffer(s.ELEMENT_ARRAY_BUFFER,t.get(F).buffer))}function l(){return s.createVertexArray()}function c(b){return s.bindVertexArray(b)}function h(b){return s.deleteVertexArray(b)}function u(b,P,D){let U=D.wireframe===!0,F=n[b.id];F===void 0&&(F={},n[b.id]=F);let q=F[P.id];q===void 0&&(q={},F[P.id]=q);let V=q[U];return V===void 0&&(V=d(l()),q[U]=V),V}function d(b){let P=[],D=[],U=[];for(let F=0;F<e;F++)P[F]=0,D[F]=0,U[F]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:P,enabledAttributes:D,attributeDivisors:U,object:b,attributes:{},index:null}}function f(b,P,D,U){let F=r.attributes,q=P.attributes,V=0,J=D.getAttributes();for(let G in J)if(J[G].location>=0){let ht=F[G],Et=q[G];if(Et===void 0&&(G==="instanceMatrix"&&b.instanceMatrix&&(Et=b.instanceMatrix),G==="instanceColor"&&b.instanceColor&&(Et=b.instanceColor)),ht===void 0||ht.attribute!==Et||Et&&ht.data!==Et.data)return!0;V++}return r.attributesNum!==V||r.index!==U}function m(b,P,D,U){let F={},q=P.attributes,V=0,J=D.getAttributes();for(let G in J)if(J[G].location>=0){let ht=q[G];ht===void 0&&(G==="instanceMatrix"&&b.instanceMatrix&&(ht=b.instanceMatrix),G==="instanceColor"&&b.instanceColor&&(ht=b.instanceColor));let Et={};Et.attribute=ht,ht&&ht.data&&(Et.data=ht.data),F[G]=Et,V++}r.attributes=F,r.attributesNum=V,r.index=U}function x(){let b=r.newAttributes;for(let P=0,D=b.length;P<D;P++)b[P]=0}function g(b){p(b,0)}function p(b,P){let D=r.newAttributes,U=r.enabledAttributes,F=r.attributeDivisors;D[b]=1,U[b]===0&&(s.enableVertexAttribArray(b),U[b]=1),F[b]!==P&&(s.vertexAttribDivisor(b,P),F[b]=P)}function v(){let b=r.newAttributes,P=r.enabledAttributes;for(let D=0,U=P.length;D<U;D++)P[D]!==b[D]&&(s.disableVertexAttribArray(D),P[D]=0)}function y(b,P,D,U,F,q,V){V===!0?s.vertexAttribIPointer(b,P,D,F,q):s.vertexAttribPointer(b,P,D,U,F,q)}function _(b,P,D,U){x();let F=U.attributes,q=D.getAttributes(),V=P.defaultAttributeValues;for(let J in q){let G=q[J];if(G.location>=0){let nt=F[J];if(nt===void 0&&(J==="instanceMatrix"&&b.instanceMatrix&&(nt=b.instanceMatrix),J==="instanceColor"&&b.instanceColor&&(nt=b.instanceColor)),nt!==void 0){let ht=nt.normalized,Et=nt.itemSize,Ot=t.get(nt);if(Ot===void 0)continue;let re=Ot.buffer,Z=Ot.type,st=Ot.bytesPerElement,Tt=Z===s.INT||Z===s.UNSIGNED_INT||nt.gpuType===zh;if(nt.isInterleavedBufferAttribute){let dt=nt.data,yt=dt.stride,Nt=nt.offset;if(dt.isInstancedInterleavedBuffer){for(let Jt=0;Jt<G.locationSize;Jt++)p(G.location+Jt,dt.meshPerAttribute);b.isInstancedMesh!==!0&&U._maxInstanceCount===void 0&&(U._maxInstanceCount=dt.meshPerAttribute*dt.count)}else for(let Jt=0;Jt<G.locationSize;Jt++)g(G.location+Jt);s.bindBuffer(s.ARRAY_BUFFER,re);for(let Jt=0;Jt<G.locationSize;Jt++)y(G.location+Jt,Et/G.locationSize,Z,ht,yt*st,(Nt+Et/G.locationSize*Jt)*st,Tt)}else{if(nt.isInstancedBufferAttribute){for(let dt=0;dt<G.locationSize;dt++)p(G.location+dt,nt.meshPerAttribute);b.isInstancedMesh!==!0&&U._maxInstanceCount===void 0&&(U._maxInstanceCount=nt.meshPerAttribute*nt.count)}else for(let dt=0;dt<G.locationSize;dt++)g(G.location+dt);s.bindBuffer(s.ARRAY_BUFFER,re);for(let dt=0;dt<G.locationSize;dt++)y(G.location+dt,Et/G.locationSize,Z,ht,Et*st,Et/G.locationSize*dt*st,Tt)}}else if(V!==void 0){let ht=V[J];if(ht!==void 0)switch(ht.length){case 2:s.vertexAttrib2fv(G.location,ht);break;case 3:s.vertexAttrib3fv(G.location,ht);break;case 4:s.vertexAttrib4fv(G.location,ht);break;default:s.vertexAttrib1fv(G.location,ht)}}}}v()}function S(){A();for(let b in n){let P=n[b];for(let D in P){let U=P[D];for(let F in U)h(U[F].object),delete U[F];delete P[D]}delete n[b]}}function M(b){if(n[b.id]===void 0)return;let P=n[b.id];for(let D in P){let U=P[D];for(let F in U)h(U[F].object),delete U[F];delete P[D]}delete n[b.id]}function E(b){for(let P in n){let D=n[P];if(D[b.id]===void 0)continue;let U=D[b.id];for(let F in U)h(U[F].object),delete U[F];delete D[b.id]}}function A(){w(),a=!0,r!==i&&(r=i,c(r.object))}function w(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:o,reset:A,resetDefaultState:w,dispose:S,releaseStatesOfGeometry:M,releaseStatesOfProgram:E,initAttributes:x,enableAttribute:g,disableUnusedAttributes:v}}function o1(s,t,e){let n;function i(c){n=c}function r(c,h){s.drawArrays(n,c,h),e.update(h,n,1)}function a(c,h,u){u!==0&&(s.drawArraysInstanced(n,c,h,u),e.update(h,n,u))}function o(c,h,u){if(u===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,h,0,u);let f=0;for(let m=0;m<u;m++)f+=h[m];e.update(f,n,1)}function l(c,h,u,d){if(u===0)return;let f=t.get("WEBGL_multi_draw");if(f===null)for(let m=0;m<c.length;m++)a(c[m],h[m],d[m]);else{f.multiDrawArraysInstancedWEBGL(n,c,0,h,0,d,0,u);let m=0;for(let x=0;x<u;x++)m+=h[x]*d[x];e.update(m,n,1)}}this.setMode=i,this.render=r,this.renderInstances=a,this.renderMultiDraw=o,this.renderMultiDrawInstances=l}function l1(s,t,e,n){let i;function r(){if(i!==void 0)return i;if(t.has("EXT_texture_filter_anisotropic")===!0){let E=t.get("EXT_texture_filter_anisotropic");i=s.getParameter(E.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function a(E){return!(E!==Xn&&n.convert(E)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(E){let A=E===ln&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(E!==Ei&&n.convert(E)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_TYPE)&&E!==ai&&!A)}function l(E){if(E==="highp"){if(s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.HIGH_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.HIGH_FLOAT).precision>0)return"highp";E="mediump"}return E==="mediump"&&s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.MEDIUM_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=e.precision!==void 0?e.precision:"highp",h=l(c);h!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);let u=e.logarithmicDepthBuffer===!0,d=e.reverseDepthBuffer===!0&&t.has("EXT_clip_control"),f=s.getParameter(s.MAX_TEXTURE_IMAGE_UNITS),m=s.getParameter(s.MAX_VERTEX_TEXTURE_IMAGE_UNITS),x=s.getParameter(s.MAX_TEXTURE_SIZE),g=s.getParameter(s.MAX_CUBE_MAP_TEXTURE_SIZE),p=s.getParameter(s.MAX_VERTEX_ATTRIBS),v=s.getParameter(s.MAX_VERTEX_UNIFORM_VECTORS),y=s.getParameter(s.MAX_VARYING_VECTORS),_=s.getParameter(s.MAX_FRAGMENT_UNIFORM_VECTORS),S=m>0,M=s.getParameter(s.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:a,textureTypeReadable:o,precision:c,logarithmicDepthBuffer:u,reverseDepthBuffer:d,maxTextures:f,maxVertexTextures:m,maxTextureSize:x,maxCubemapSize:g,maxAttributes:p,maxVertexUniforms:v,maxVaryings:y,maxFragmentUniforms:_,vertexTextures:S,maxSamples:M}}function c1(s){let t=this,e=null,n=0,i=!1,r=!1,a=new Wn,o=new Yt,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){let f=u.length!==0||d||n!==0||i;return i=d,n=u.length,f},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,d){e=h(u,d,0)},this.setState=function(u,d,f){let m=u.clippingPlanes,x=u.clipIntersection,g=u.clipShadows,p=s.get(u);if(!i||m===null||m.length===0||r&&!g)r?h(null):c();else{let v=r?0:n,y=v*4,_=p.clippingState||null;l.value=_,_=h(m,d,y,f);for(let S=0;S!==y;++S)_[S]=e[S];p.clippingState=_,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=v}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function h(u,d,f,m){let x=u!==null?u.length:0,g=null;if(x!==0){if(g=l.value,m!==!0||g===null){let p=f+x*4,v=d.matrixWorldInverse;o.getNormalMatrix(v),(g===null||g.length<p)&&(g=new Float32Array(p));for(let y=0,_=f;y!==x;++y,_+=4)a.copy(u[y]).applyMatrix4(v,o),a.normal.toArray(g,_),g[_+3]=a.constant}l.value=g,l.needsUpdate=!0}return t.numPlanes=x,t.numIntersection=0,g}}function h1(s){let t=new WeakMap;function e(a,o){return o===xc?a.mapping=nr:o===vc&&(a.mapping=ir),a}function n(a){if(a&&a.isTexture){let o=a.mapping;if(o===xc||o===vc)if(t.has(a)){let l=t.get(a).texture;return e(l,a.mapping)}else{let l=a.image;if(l&&l.height>0){let c=new jc(l.height);return c.fromEquirectangularTexture(s,a),t.set(a,c),a.addEventListener("dispose",i),e(c.texture,a.mapping)}else return null}}return a}function i(a){let o=a.target;o.removeEventListener("dispose",i);let l=t.get(o);l!==void 0&&(t.delete(o),l.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}var qi=class extends mo{constructor(t=-1,e=1,n=1,i=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=i,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,i,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=i,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2,r=n-t,a=n+t,o=i+e,l=i-e;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,a=r+c*this.view.width,o-=h*this.view.offsetY,l=o-h*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},Js=4,ad=[.125,.215,.35,.446,.526,.582],fs=20,Zl=new qi,od=new ot,Kl=null,Jl=0,jl=0,Ql=!1,us=(1+Math.sqrt(5))/2,Xs=1/us,ld=[new C(-us,Xs,0),new C(us,Xs,0),new C(-Xs,0,us),new C(Xs,0,us),new C(0,us,-Xs),new C(0,us,Xs),new C(-1,1,-1),new C(1,1,-1),new C(-1,1,1),new C(1,1,1)],Yi=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,i=100){Kl=this._renderer.getRenderTarget(),Jl=this._renderer.getActiveCubeFace(),jl=this._renderer.getActiveMipmapLevel(),Ql=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,n,i,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=ud(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=hd(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(Kl,Jl,jl),this._renderer.xr.enabled=Ql,t.scissorTest=!1,Va(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===nr||t.mapping===ir?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Kl=this._renderer.getRenderTarget(),Jl=this._renderer.getActiveCubeFace(),jl=this._renderer.getActiveMipmapLevel(),Ql=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:ri,minFilter:ri,generateMipmaps:!1,type:ln,format:Xn,colorSpace:Ji,depthBuffer:!1},i=cd(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=cd(t,e,n);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=u1(r)),this._blurMaterial=d1(r,t,e)}return i}_compileMaterial(t){let e=new it(this._lodPlanes[0],t);this._renderer.compile(e,Zl)}_sceneToCubeUV(t,e,n,i){let o=new Ue(90,1,e,n),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],h=this._renderer,u=h.autoClear,d=h.toneMapping;h.getClearColor(od),h.toneMapping=Vi,h.autoClear=!1;let f=new De({name:"PMREM.Background",side:Ce,depthWrite:!1,depthTest:!1}),m=new it(new jt,f),x=!1,g=t.background;g?g.isColor&&(f.color.copy(g),t.background=null,x=!0):(f.color.copy(od),x=!0);for(let p=0;p<6;p++){let v=p%3;v===0?(o.up.set(0,l[p],0),o.lookAt(c[p],0,0)):v===1?(o.up.set(0,0,l[p]),o.lookAt(0,c[p],0)):(o.up.set(0,l[p],0),o.lookAt(0,0,c[p]));let y=this._cubeSize;Va(i,v*y,p>2?y:0,y,y),h.setRenderTarget(i),x&&h.render(m,o),h.render(t,o)}m.geometry.dispose(),m.material.dispose(),h.toneMapping=d,h.autoClear=u,t.background=g}_textureToCubeUV(t,e){let n=this._renderer,i=t.mapping===nr||t.mapping===ir;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=ud()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=hd());let r=i?this._cubemapMaterial:this._equirectMaterial,a=new it(this._lodPlanes[0],r),o=r.uniforms;o.envMap.value=t;let l=this._cubeSize;Va(e,0,0,3*l,2*l),n.setRenderTarget(e),n.render(a,Zl)}_applyPMREM(t){let e=this._renderer,n=e.autoClear;e.autoClear=!1;let i=this._lodPlanes.length;for(let r=1;r<i;r++){let a=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),o=ld[(i-r-1)%ld.length];this._blur(t,r-1,r,a,o)}e.autoClear=n}_blur(t,e,n,i,r){let a=this._pingPongRenderTarget;this._halfBlur(t,a,e,n,i,"latitudinal",r),this._halfBlur(a,t,n,n,i,"longitudinal",r)}_halfBlur(t,e,n,i,r,a,o){let l=this._renderer,c=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=3,u=new it(this._lodPlanes[i],c),d=c.uniforms,f=this._sizeLods[n]-1,m=isFinite(r)?Math.PI/(2*f):2*Math.PI/(2*fs-1),x=r/m,g=isFinite(r)?1+Math.floor(h*x):fs;g>fs&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${g} samples when the maximum is set to ${fs}`);let p=[],v=0;for(let E=0;E<fs;++E){let A=E/x,w=Math.exp(-A*A/2);p.push(w),E===0?v+=w:E<g&&(v+=2*w)}for(let E=0;E<p.length;E++)p[E]=p[E]/v;d.envMap.value=t.texture,d.samples.value=g,d.weights.value=p,d.latitudinal.value=a==="latitudinal",o&&(d.poleAxis.value=o);let{_lodMax:y}=this;d.dTheta.value=m,d.mipInt.value=y-n;let _=this._sizeLods[i],S=3*_*(i>y-Js?i-y+Js:0),M=4*(this._cubeSize-_);Va(e,S,M,3*_,2*_),l.setRenderTarget(e),l.render(u,Zl)}};function u1(s){let t=[],e=[],n=[],i=s,r=s-Js+1+ad.length;for(let a=0;a<r;a++){let o=Math.pow(2,i);e.push(o);let l=1/o;a>s-Js?l=ad[a-s+Js-1]:a===0&&(l=0),n.push(l);let c=1/(o-2),h=-c,u=1+c,d=[h,h,u,h,u,u,h,h,u,u,h,u],f=6,m=6,x=3,g=2,p=1,v=new Float32Array(x*m*f),y=new Float32Array(g*m*f),_=new Float32Array(p*m*f);for(let M=0;M<f;M++){let E=M%3*2/3-1,A=M>2?0:-1,w=[E,A,0,E+2/3,A,0,E+2/3,A+1,0,E,A,0,E+2/3,A+1,0,E,A+1,0];v.set(w,x*m*M),y.set(d,g*m*M);let b=[M,M,M,M,M,M];_.set(b,p*m*M)}let S=new Gt;S.setAttribute("position",new Vt(v,x)),S.setAttribute("uv",new Vt(y,g)),S.setAttribute("faceIndex",new Vt(_,p)),t.push(S),i>Js&&i--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function cd(s,t,e){let n=new Ne(s,t,e);return n.texture.mapping=Oo,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Va(s,t,e,n,i){s.viewport.set(t,e,n,i),s.scissor.set(t,e,n,i)}function d1(s,t,e){let n=new Float32Array(fs),i=new C(0,1,0);return new ve({name:"SphericalGaussianBlur",defines:{n:fs,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:Yh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:oi,depthTest:!1,depthWrite:!1})}function hd(){return new ve({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Yh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:oi,depthTest:!1,depthWrite:!1})}function ud(){return new ve({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Yh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:oi,depthTest:!1,depthWrite:!1})}function Yh(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function f1(s){let t=new WeakMap,e=null;function n(o){if(o&&o.isTexture){let l=o.mapping,c=l===xc||l===vc,h=l===nr||l===ir;if(c||h){let u=t.get(o),d=u!==void 0?u.texture.pmremVersion:0;if(o.isRenderTargetTexture&&o.pmremVersion!==d)return e===null&&(e=new Yi(s)),u=c?e.fromEquirectangular(o,u):e.fromCubemap(o,u),u.texture.pmremVersion=o.pmremVersion,t.set(o,u),u.texture;if(u!==void 0)return u.texture;{let f=o.image;return c&&f&&f.height>0||h&&f&&i(f)?(e===null&&(e=new Yi(s)),u=c?e.fromEquirectangular(o):e.fromCubemap(o),u.texture.pmremVersion=o.pmremVersion,t.set(o,u),o.addEventListener("dispose",r),u.texture):null}}}return o}function i(o){let l=0,c=6;for(let h=0;h<c;h++)o[h]!==void 0&&l++;return l===c}function r(o){let l=o.target;l.removeEventListener("dispose",r);let c=t.get(l);c!==void 0&&(t.delete(l),c.dispose())}function a(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:a}}function p1(s){let t={};function e(n){if(t[n]!==void 0)return t[n];let i;switch(n){case"WEBGL_depth_texture":i=s.getExtension("WEBGL_depth_texture")||s.getExtension("MOZ_WEBGL_depth_texture")||s.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":i=s.getExtension("EXT_texture_filter_anisotropic")||s.getExtension("MOZ_EXT_texture_filter_anisotropic")||s.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":i=s.getExtension("WEBGL_compressed_texture_s3tc")||s.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||s.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":i=s.getExtension("WEBGL_compressed_texture_pvrtc")||s.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:i=s.getExtension(n)}return t[n]=i,i}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){let i=e(n);return i===null&&Hr("THREE.WebGLRenderer: "+n+" extension not supported."),i}}}function m1(s,t,e,n){let i={},r=new WeakMap;function a(u){let d=u.target;d.index!==null&&t.remove(d.index);for(let m in d.attributes)t.remove(d.attributes[m]);for(let m in d.morphAttributes){let x=d.morphAttributes[m];for(let g=0,p=x.length;g<p;g++)t.remove(x[g])}d.removeEventListener("dispose",a),delete i[d.id];let f=r.get(d);f&&(t.remove(f),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,e.memory.geometries--}function o(u,d){return i[d.id]===!0||(d.addEventListener("dispose",a),i[d.id]=!0,e.memory.geometries++),d}function l(u){let d=u.attributes;for(let m in d)t.update(d[m],s.ARRAY_BUFFER);let f=u.morphAttributes;for(let m in f){let x=f[m];for(let g=0,p=x.length;g<p;g++)t.update(x[g],s.ARRAY_BUFFER)}}function c(u){let d=[],f=u.index,m=u.attributes.position,x=0;if(f!==null){let v=f.array;x=f.version;for(let y=0,_=v.length;y<_;y+=3){let S=v[y+0],M=v[y+1],E=v[y+2];d.push(S,M,M,E,E,S)}}else if(m!==void 0){let v=m.array;x=m.version;for(let y=0,_=v.length/3-1;y<_;y+=3){let S=y+0,M=y+1,E=y+2;d.push(S,M,M,E,E,S)}}else return;let g=new(af(d)?po:fo)(d,1);g.version=x;let p=r.get(u);p&&t.remove(p),r.set(u,g)}function h(u){let d=r.get(u);if(d){let f=u.index;f!==null&&d.version<f.version&&c(u)}else c(u);return r.get(u)}return{get:o,update:l,getWireframeAttribute:h}}function g1(s,t,e){let n;function i(d){n=d}let r,a;function o(d){r=d.type,a=d.bytesPerElement}function l(d,f){s.drawElements(n,f,r,d*a),e.update(f,n,1)}function c(d,f,m){m!==0&&(s.drawElementsInstanced(n,f,r,d*a,m),e.update(f,n,m))}function h(d,f,m){if(m===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,f,0,r,d,0,m);let g=0;for(let p=0;p<m;p++)g+=f[p];e.update(g,n,1)}function u(d,f,m,x){if(m===0)return;let g=t.get("WEBGL_multi_draw");if(g===null)for(let p=0;p<d.length;p++)c(d[p]/a,f[p],x[p]);else{g.multiDrawElementsInstancedWEBGL(n,f,0,r,d,0,x,0,m);let p=0;for(let v=0;v<m;v++)p+=f[v]*x[v];e.update(p,n,1)}}this.setMode=i,this.setIndex=o,this.render=l,this.renderInstances=c,this.renderMultiDraw=h,this.renderMultiDrawInstances=u}function x1(s){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,a,o){switch(e.calls++,a){case s.TRIANGLES:e.triangles+=o*(r/3);break;case s.LINES:e.lines+=o*(r/2);break;case s.LINE_STRIP:e.lines+=o*(r-1);break;case s.LINE_LOOP:e.lines+=o*r;break;case s.POINTS:e.points+=o*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function i(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:i,update:n}}function v1(s,t,e){let n=new WeakMap,i=new ue;function r(a,o,l){let c=a.morphTargetInfluences,h=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,u=h!==void 0?h.length:0,d=n.get(o);if(d===void 0||d.count!==u){let w=function(){E.dispose(),n.delete(o),o.removeEventListener("dispose",w)};d!==void 0&&d.texture.dispose();let f=o.morphAttributes.position!==void 0,m=o.morphAttributes.normal!==void 0,x=o.morphAttributes.color!==void 0,g=o.morphAttributes.position||[],p=o.morphAttributes.normal||[],v=o.morphAttributes.color||[],y=0;f===!0&&(y=1),m===!0&&(y=2),x===!0&&(y=3);let _=o.attributes.position.count*y,S=1;_>t.maxTextureSize&&(S=Math.ceil(_/t.maxTextureSize),_=t.maxTextureSize);let M=new Float32Array(_*S*4*u),E=new ho(M,_,S,u);E.type=ai,E.needsUpdate=!0;let A=y*4;for(let b=0;b<u;b++){let P=g[b],D=p[b],U=v[b],F=_*S*4*b;for(let q=0;q<P.count;q++){let V=q*A;f===!0&&(i.fromBufferAttribute(P,q),M[F+V+0]=i.x,M[F+V+1]=i.y,M[F+V+2]=i.z,M[F+V+3]=0),m===!0&&(i.fromBufferAttribute(D,q),M[F+V+4]=i.x,M[F+V+5]=i.y,M[F+V+6]=i.z,M[F+V+7]=0),x===!0&&(i.fromBufferAttribute(U,q),M[F+V+8]=i.x,M[F+V+9]=i.y,M[F+V+10]=i.z,M[F+V+11]=U.itemSize===4?i.w:1)}}d={count:u,texture:E,size:new tt(_,S)},n.set(o,d),o.addEventListener("dispose",w)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)l.getUniforms().setValue(s,"morphTexture",a.morphTexture,e);else{let f=0;for(let x=0;x<c.length;x++)f+=c[x];let m=o.morphTargetsRelative?1:1-f;l.getUniforms().setValue(s,"morphTargetBaseInfluence",m),l.getUniforms().setValue(s,"morphTargetInfluences",c)}l.getUniforms().setValue(s,"morphTargetsTexture",d.texture,e),l.getUniforms().setValue(s,"morphTargetsTextureSize",d.size)}return{update:r}}function y1(s,t,e,n){let i=new WeakMap;function r(l){let c=n.render.frame,h=l.geometry,u=t.get(l,h);if(i.get(u)!==c&&(t.update(u),i.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",o)===!1&&l.addEventListener("dispose",o),i.get(l)!==c&&(e.update(l.instanceMatrix,s.ARRAY_BUFFER),l.instanceColor!==null&&e.update(l.instanceColor,s.ARRAY_BUFFER),i.set(l,c))),l.isSkinnedMesh){let d=l.skeleton;i.get(d)!==c&&(d.update(),i.set(d,c))}return u}function a(){i=new WeakMap}function o(l){let c=l.target;c.removeEventListener("dispose",o),e.remove(c.instanceMatrix),c.instanceColor!==null&&e.remove(c.instanceColor)}return{update:r,dispose:a}}var xo=class extends fn{constructor(t,e,n,i,r,a,o,l,c,h=js){if(h!==js&&h!==rr)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===js&&(n=xs),n===void 0&&h===rr&&(n=sr),super(null,i,r,a,o,l,h,n,c),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=o!==void 0?o:yn,this.minFilter=l!==void 0?l:yn,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}},hf=new fn,dd=new xo(1,1),uf=new ho,df=new Kc,ff=new go,fd=[],pd=[],md=new Float32Array(16),gd=new Float32Array(9),xd=new Float32Array(4);function dr(s,t,e){let n=s[0];if(n<=0||n>0)return s;let i=t*e,r=fd[i];if(r===void 0&&(r=new Float32Array(i),fd[i]=r),t!==0){n.toArray(r,0);for(let a=1,o=0;a!==t;++a)o+=e,s[a].toArray(r,o)}return r}function Ve(s,t){if(s.length!==t.length)return!1;for(let e=0,n=s.length;e<n;e++)if(s[e]!==t[e])return!1;return!0}function Ge(s,t){for(let e=0,n=t.length;e<n;e++)s[e]=t[e]}function zo(s,t){let e=pd[t];e===void 0&&(e=new Int32Array(t),pd[t]=e);for(let n=0;n!==t;++n)e[n]=s.allocateTextureUnit();return e}function _1(s,t){let e=this.cache;e[0]!==t&&(s.uniform1f(this.addr,t),e[0]=t)}function M1(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ve(e,t))return;s.uniform2fv(this.addr,t),Ge(e,t)}}function b1(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(s.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Ve(e,t))return;s.uniform3fv(this.addr,t),Ge(e,t)}}function w1(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ve(e,t))return;s.uniform4fv(this.addr,t),Ge(e,t)}}function S1(s,t){let e=this.cache,n=t.elements;if(n===void 0){if(Ve(e,t))return;s.uniformMatrix2fv(this.addr,!1,t),Ge(e,t)}else{if(Ve(e,n))return;xd.set(n),s.uniformMatrix2fv(this.addr,!1,xd),Ge(e,n)}}function E1(s,t){let e=this.cache,n=t.elements;if(n===void 0){if(Ve(e,t))return;s.uniformMatrix3fv(this.addr,!1,t),Ge(e,t)}else{if(Ve(e,n))return;gd.set(n),s.uniformMatrix3fv(this.addr,!1,gd),Ge(e,n)}}function T1(s,t){let e=this.cache,n=t.elements;if(n===void 0){if(Ve(e,t))return;s.uniformMatrix4fv(this.addr,!1,t),Ge(e,t)}else{if(Ve(e,n))return;md.set(n),s.uniformMatrix4fv(this.addr,!1,md),Ge(e,n)}}function A1(s,t){let e=this.cache;e[0]!==t&&(s.uniform1i(this.addr,t),e[0]=t)}function R1(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ve(e,t))return;s.uniform2iv(this.addr,t),Ge(e,t)}}function C1(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ve(e,t))return;s.uniform3iv(this.addr,t),Ge(e,t)}}function P1(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ve(e,t))return;s.uniform4iv(this.addr,t),Ge(e,t)}}function I1(s,t){let e=this.cache;e[0]!==t&&(s.uniform1ui(this.addr,t),e[0]=t)}function L1(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(s.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Ve(e,t))return;s.uniform2uiv(this.addr,t),Ge(e,t)}}function D1(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(s.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Ve(e,t))return;s.uniform3uiv(this.addr,t),Ge(e,t)}}function k1(s,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(s.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Ve(e,t))return;s.uniform4uiv(this.addr,t),Ge(e,t)}}function U1(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i);let r;this.type===s.SAMPLER_2D_SHADOW?(dd.compareFunction=rf,r=dd):r=hf,e.setTexture2D(t||r,i)}function N1(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture3D(t||df,i)}function F1(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTextureCube(t||ff,i)}function O1(s,t,e){let n=this.cache,i=e.allocateTextureUnit();n[0]!==i&&(s.uniform1i(this.addr,i),n[0]=i),e.setTexture2DArray(t||uf,i)}function B1(s){switch(s){case 5126:return _1;case 35664:return M1;case 35665:return b1;case 35666:return w1;case 35674:return S1;case 35675:return E1;case 35676:return T1;case 5124:case 35670:return A1;case 35667:case 35671:return R1;case 35668:case 35672:return C1;case 35669:case 35673:return P1;case 5125:return I1;case 36294:return L1;case 36295:return D1;case 36296:return k1;case 35678:case 36198:case 36298:case 36306:case 35682:return U1;case 35679:case 36299:case 36307:return N1;case 35680:case 36300:case 36308:case 36293:return F1;case 36289:case 36303:case 36311:case 36292:return O1}}function z1(s,t){s.uniform1fv(this.addr,t)}function H1(s,t){let e=dr(t,this.size,2);s.uniform2fv(this.addr,e)}function V1(s,t){let e=dr(t,this.size,3);s.uniform3fv(this.addr,e)}function G1(s,t){let e=dr(t,this.size,4);s.uniform4fv(this.addr,e)}function W1(s,t){let e=dr(t,this.size,4);s.uniformMatrix2fv(this.addr,!1,e)}function X1(s,t){let e=dr(t,this.size,9);s.uniformMatrix3fv(this.addr,!1,e)}function q1(s,t){let e=dr(t,this.size,16);s.uniformMatrix4fv(this.addr,!1,e)}function Y1(s,t){s.uniform1iv(this.addr,t)}function $1(s,t){s.uniform2iv(this.addr,t)}function Z1(s,t){s.uniform3iv(this.addr,t)}function K1(s,t){s.uniform4iv(this.addr,t)}function J1(s,t){s.uniform1uiv(this.addr,t)}function j1(s,t){s.uniform2uiv(this.addr,t)}function Q1(s,t){s.uniform3uiv(this.addr,t)}function tx(s,t){s.uniform4uiv(this.addr,t)}function ex(s,t,e){let n=this.cache,i=t.length,r=zo(e,i);Ve(n,r)||(s.uniform1iv(this.addr,r),Ge(n,r));for(let a=0;a!==i;++a)e.setTexture2D(t[a]||hf,r[a])}function nx(s,t,e){let n=this.cache,i=t.length,r=zo(e,i);Ve(n,r)||(s.uniform1iv(this.addr,r),Ge(n,r));for(let a=0;a!==i;++a)e.setTexture3D(t[a]||df,r[a])}function ix(s,t,e){let n=this.cache,i=t.length,r=zo(e,i);Ve(n,r)||(s.uniform1iv(this.addr,r),Ge(n,r));for(let a=0;a!==i;++a)e.setTextureCube(t[a]||ff,r[a])}function sx(s,t,e){let n=this.cache,i=t.length,r=zo(e,i);Ve(n,r)||(s.uniform1iv(this.addr,r),Ge(n,r));for(let a=0;a!==i;++a)e.setTexture2DArray(t[a]||uf,r[a])}function rx(s){switch(s){case 5126:return z1;case 35664:return H1;case 35665:return V1;case 35666:return G1;case 35674:return W1;case 35675:return X1;case 35676:return q1;case 5124:case 35670:return Y1;case 35667:case 35671:return $1;case 35668:case 35672:return Z1;case 35669:case 35673:return K1;case 5125:return J1;case 36294:return j1;case 36295:return Q1;case 36296:return tx;case 35678:case 36198:case 36298:case 36306:case 35682:return ex;case 35679:case 36299:case 36307:return nx;case 35680:case 36300:case 36308:case 36293:return ix;case 36289:case 36303:case 36311:case 36292:return sx}}var Qc=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=B1(e.type)}},th=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=rx(e.type)}},eh=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){let i=this.seq;for(let r=0,a=i.length;r!==a;++r){let o=i[r];o.setValue(t,e[o.id],n)}}},tc=/(\w+)(\])?(\[|\.)?/g;function vd(s,t){s.seq.push(t),s.map[t.id]=t}function ax(s,t,e){let n=s.name,i=n.length;for(tc.lastIndex=0;;){let r=tc.exec(n),a=tc.lastIndex,o=r[1],l=r[2]==="]",c=r[3];if(l&&(o=o|0),c===void 0||c==="["&&a+2===i){vd(e,c===void 0?new Qc(o,s,t):new th(o,s,t));break}else{let u=e.map[o];u===void 0&&(u=new eh(o),vd(e,u)),e=u}}}var tr=class{constructor(t,e){this.seq=[],this.map={};let n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let i=0;i<n;++i){let r=t.getActiveUniform(e,i),a=t.getUniformLocation(e,r.name);ax(r,a,this)}}setValue(t,e,n,i){let r=this.map[e];r!==void 0&&r.setValue(t,n,i)}setOptional(t,e,n){let i=e[n];i!==void 0&&this.setValue(t,n,i)}static upload(t,e,n,i){for(let r=0,a=e.length;r!==a;++r){let o=e[r],l=n[o.id];l.needsUpdate!==!1&&o.setValue(t,l.value,i)}}static seqWithValue(t,e){let n=[];for(let i=0,r=t.length;i!==r;++i){let a=t[i];a.id in e&&n.push(a)}return n}};function yd(s,t,e){let n=s.createShader(t);return s.shaderSource(n,e),s.compileShader(n),n}var ox=37297,lx=0;function cx(s,t){let e=s.split(`
`),n=[],i=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let a=i;a<r;a++){let o=a+1;n.push(`${o===t?">":" "} ${o}: ${e[a]}`)}return n.join(`
`)}var _d=new Yt;function hx(s){se._getMatrix(_d,se.workingColorSpace,s);let t=`mat3( ${_d.elements.map(e=>e.toFixed(4))} )`;switch(se.getTransfer(s)){case Bo:return[t,"LinearTransferOETF"];case pe:return[t,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",s),[t,"LinearTransferOETF"]}}function Md(s,t,e){let n=s.getShaderParameter(t,s.COMPILE_STATUS),i=s.getShaderInfoLog(t).trim();if(n&&i==="")return"";let r=/ERROR: 0:(\d+)/.exec(i);if(r){let a=parseInt(r[1]);return e.toUpperCase()+`

`+i+`

`+cx(s.getShaderSource(t),a)}else return i}function ux(s,t){let e=hx(t);return[`vec4 ${s}( vec4 value ) {`,`	return ${e[1]}( vec4( value.rgb * ${e[0]}, value.a ) );`,"}"].join(`
`)}function dx(s,t){let e;switch(t){case Uh:e="Linear";break;case Nh:e="Reinhard";break;case Fh:e="Cineon";break;case ta:e="ACESFilmic";break;case Oh:e="AgX";break;case Bh:e="Neutral";break;case W0:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+s+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}var Ga=new C;function fx(){se.getLuminanceCoefficients(Ga);let s=Ga.x.toFixed(4),t=Ga.y.toFixed(4),e=Ga.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${s}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function px(s){return[s.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",s.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Vr).join(`
`)}function mx(s){let t=[];for(let e in s){let n=s[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function gx(s,t){let e={},n=s.getProgramParameter(t,s.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){let r=s.getActiveAttrib(t,i),a=r.name,o=1;r.type===s.FLOAT_MAT2&&(o=2),r.type===s.FLOAT_MAT3&&(o=3),r.type===s.FLOAT_MAT4&&(o=4),e[a]={type:r.type,location:s.getAttribLocation(t,a),locationSize:o}}return e}function Vr(s){return s!==""}function bd(s,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return s.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function wd(s,t){return s.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var xx=/^[ \t]*#include +<([\w\d./]+)>/gm;function nh(s){return s.replace(xx,yx)}var vx=new Map;function yx(s,t){let e=Kt[t];if(e===void 0){let n=vx.get(t);if(n!==void 0)e=Kt[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return nh(e)}var _x=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Sd(s){return s.replace(_x,Mx)}function Mx(s,t,e,n){let i="";for(let r=parseInt(t);r<parseInt(e);r++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return i}function Ed(s){let t=`precision ${s.precision} float;
	precision ${s.precision} int;
	precision ${s.precision} sampler2D;
	precision ${s.precision} samplerCube;
	precision ${s.precision} sampler3D;
	precision ${s.precision} sampler2DArray;
	precision ${s.precision} sampler2DShadow;
	precision ${s.precision} samplerCubeShadow;
	precision ${s.precision} sampler2DArrayShadow;
	precision ${s.precision} isampler2D;
	precision ${s.precision} isampler3D;
	precision ${s.precision} isamplerCube;
	precision ${s.precision} isampler2DArray;
	precision ${s.precision} usampler2D;
	precision ${s.precision} usampler3D;
	precision ${s.precision} usamplerCube;
	precision ${s.precision} usampler2DArray;
	`;return s.precision==="highp"?t+=`
#define HIGH_PRECISION`:s.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:s.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function bx(s){let t="SHADOWMAP_TYPE_BASIC";return s.shadowMapType===Xd?t="SHADOWMAP_TYPE_PCF":s.shadowMapType===kh?t="SHADOWMAP_TYPE_PCF_SOFT":s.shadowMapType===Mi&&(t="SHADOWMAP_TYPE_VSM"),t}function wx(s){let t="ENVMAP_TYPE_CUBE";if(s.envMap)switch(s.envMapMode){case nr:case ir:t="ENVMAP_TYPE_CUBE";break;case Oo:t="ENVMAP_TYPE_CUBE_UV";break}return t}function Sx(s){let t="ENVMAP_MODE_REFLECTION";if(s.envMap)switch(s.envMapMode){case ir:t="ENVMAP_MODE_REFRACTION";break}return t}function Ex(s){let t="ENVMAP_BLENDING_NONE";if(s.envMap)switch(s.combine){case qd:t="ENVMAP_BLENDING_MULTIPLY";break;case V0:t="ENVMAP_BLENDING_MIX";break;case G0:t="ENVMAP_BLENDING_ADD";break}return t}function Tx(s){let t=s.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),7*16)),texelHeight:n,maxMip:e}}function Ax(s,t,e,n){let i=s.getContext(),r=e.defines,a=e.vertexShader,o=e.fragmentShader,l=bx(e),c=wx(e),h=Sx(e),u=Ex(e),d=Tx(e),f=px(e),m=mx(r),x=i.createProgram(),g,p,v=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(g=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,m].filter(Vr).join(`
`),g.length>0&&(g+=`
`),p=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,m].filter(Vr).join(`
`),p.length>0&&(p+=`
`)):(g=[Ed(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,m,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Vr).join(`
`),p=[Ed(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,m,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+h:"",e.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor||e.batchingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Vi?"#define TONE_MAPPING":"",e.toneMapping!==Vi?Kt.tonemapping_pars_fragment:"",e.toneMapping!==Vi?dx("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Kt.colorspace_pars_fragment,ux("linearToOutputTexel",e.outputColorSpace),fx(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(Vr).join(`
`)),a=nh(a),a=bd(a,e),a=wd(a,e),o=nh(o),o=bd(o,e),o=wd(o,e),a=Sd(a),o=Sd(o),e.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,g=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+g,p=["#define varying in",e.glslVersion===Bu?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Bu?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);let y=v+g+a,_=v+p+o,S=yd(i,i.VERTEX_SHADER,y),M=yd(i,i.FRAGMENT_SHADER,_);i.attachShader(x,S),i.attachShader(x,M),e.index0AttributeName!==void 0?i.bindAttribLocation(x,0,e.index0AttributeName):e.morphTargets===!0&&i.bindAttribLocation(x,0,"position"),i.linkProgram(x);function E(P){if(s.debug.checkShaderErrors){let D=i.getProgramInfoLog(x).trim(),U=i.getShaderInfoLog(S).trim(),F=i.getShaderInfoLog(M).trim(),q=!0,V=!0;if(i.getProgramParameter(x,i.LINK_STATUS)===!1)if(q=!1,typeof s.debug.onShaderError=="function")s.debug.onShaderError(i,x,S,M);else{let J=Md(i,S,"vertex"),G=Md(i,M,"fragment");console.error("THREE.WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(x,i.VALIDATE_STATUS)+`

Material Name: `+P.name+`
Material Type: `+P.type+`

Program Info Log: `+D+`
`+J+`
`+G)}else D!==""?console.warn("THREE.WebGLProgram: Program Info Log:",D):(U===""||F==="")&&(V=!1);V&&(P.diagnostics={runnable:q,programLog:D,vertexShader:{log:U,prefix:g},fragmentShader:{log:F,prefix:p}})}i.deleteShader(S),i.deleteShader(M),A=new tr(i,x),w=gx(i,x)}let A;this.getUniforms=function(){return A===void 0&&E(this),A};let w;this.getAttributes=function(){return w===void 0&&E(this),w};let b=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return b===!1&&(b=i.getProgramParameter(x,ox)),b},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(x),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=lx++,this.cacheKey=t,this.usedTimes=1,this.program=x,this.vertexShader=S,this.fragmentShader=M,this}var Rx=0,ih=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){let e=t.vertexShader,n=t.fragmentShader,i=this._getShaderStage(e),r=this._getShaderStage(n),a=this._getShaderCacheForMaterial(t);return a.has(i)===!1&&(a.add(i),i.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){let e=this.shaderCache,n=e.get(t);return n===void 0&&(n=new sh(t),e.set(t,n)),n}},sh=class{constructor(t){this.id=Rx++,this.code=t,this.usedTimes=0}};function Cx(s,t,e,n,i,r,a){let o=new uo,l=new ih,c=new Set,h=[],u=i.logarithmicDepthBuffer,d=i.vertexTextures,f=i.precision,m={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function x(w){return c.add(w),w===0?"uv":`uv${w}`}function g(w,b,P,D,U){let F=D.fog,q=U.geometry,V=w.isMeshStandardMaterial?D.environment:null,J=(w.isMeshStandardMaterial?e:t).get(w.envMap||V),G=J&&J.mapping===Oo?J.image.height:null,nt=m[w.type];w.precision!==null&&(f=i.getMaxPrecision(w.precision),f!==w.precision&&console.warn("THREE.WebGLProgram.getParameters:",w.precision,"not supported, using",f,"instead."));let ht=q.morphAttributes.position||q.morphAttributes.normal||q.morphAttributes.color,Et=ht!==void 0?ht.length:0,Ot=0;q.morphAttributes.position!==void 0&&(Ot=1),q.morphAttributes.normal!==void 0&&(Ot=2),q.morphAttributes.color!==void 0&&(Ot=3);let re,Z,st,Tt;if(nt){let ge=ni[nt];re=ge.vertexShader,Z=ge.fragmentShader}else re=w.vertexShader,Z=w.fragmentShader,l.update(w),st=l.getVertexShaderID(w),Tt=l.getFragmentShaderID(w);let dt=s.getRenderTarget(),yt=s.state.buffers.depth.getReversed(),Nt=U.isInstancedMesh===!0,Jt=U.isBatchedMesh===!0,me=!!w.map,ee=!!w.matcap,Ae=!!J,B=!!w.aoMap,Je=!!w.lightMap,ne=!!w.bumpMap,ie=!!w.normalMap,Ut=!!w.displacementMap,_e=!!w.emissiveMap,Dt=!!w.metalnessMap,L=!!w.roughnessMap,T=w.anisotropy>0,H=w.clearcoat>0,j=w.dispersion>0,et=w.iridescence>0,K=w.sheen>0,_t=w.transmission>0,ft=T&&!!w.anisotropyMap,xt=H&&!!w.clearcoatMap,oe=H&&!!w.clearcoatNormalMap,lt=H&&!!w.clearcoatRoughnessMap,Mt=et&&!!w.iridescenceMap,Ft=et&&!!w.iridescenceThicknessMap,Bt=K&&!!w.sheenColorMap,bt=K&&!!w.sheenRoughnessMap,ae=!!w.specularMap,Zt=!!w.specularColorMap,Me=!!w.specularIntensityMap,N=_t&&!!w.transmissionMap,pt=_t&&!!w.thicknessMap,Y=!!w.gradientMap,Q=!!w.alphaMap,vt=w.alphaTest>0,mt=!!w.alphaHash,Xt=!!w.extensions,Ie=Vi;w.toneMapped&&(dt===null||dt.isXRRenderTarget===!0)&&(Ie=s.toneMapping);let Qe={shaderID:nt,shaderType:w.type,shaderName:w.name,vertexShader:re,fragmentShader:Z,defines:w.defines,customVertexShaderID:st,customFragmentShaderID:Tt,isRawShaderMaterial:w.isRawShaderMaterial===!0,glslVersion:w.glslVersion,precision:f,batching:Jt,batchingColor:Jt&&U._colorsTexture!==null,instancing:Nt,instancingColor:Nt&&U.instanceColor!==null,instancingMorph:Nt&&U.morphTexture!==null,supportsVertexTextures:d,outputColorSpace:dt===null?s.outputColorSpace:dt.isXRRenderTarget===!0?dt.texture.colorSpace:Ji,alphaToCoverage:!!w.alphaToCoverage,map:me,matcap:ee,envMap:Ae,envMapMode:Ae&&J.mapping,envMapCubeUVHeight:G,aoMap:B,lightMap:Je,bumpMap:ne,normalMap:ie,displacementMap:d&&Ut,emissiveMap:_e,normalMapObjectSpace:ie&&w.normalMapType===$0,normalMapTangentSpace:ie&&w.normalMapType===sf,metalnessMap:Dt,roughnessMap:L,anisotropy:T,anisotropyMap:ft,clearcoat:H,clearcoatMap:xt,clearcoatNormalMap:oe,clearcoatRoughnessMap:lt,dispersion:j,iridescence:et,iridescenceMap:Mt,iridescenceThicknessMap:Ft,sheen:K,sheenColorMap:Bt,sheenRoughnessMap:bt,specularMap:ae,specularColorMap:Zt,specularIntensityMap:Me,transmission:_t,transmissionMap:N,thicknessMap:pt,gradientMap:Y,opaque:w.transparent===!1&&w.blending===Hi&&w.alphaToCoverage===!1,alphaMap:Q,alphaTest:vt,alphaHash:mt,combine:w.combine,mapUv:me&&x(w.map.channel),aoMapUv:B&&x(w.aoMap.channel),lightMapUv:Je&&x(w.lightMap.channel),bumpMapUv:ne&&x(w.bumpMap.channel),normalMapUv:ie&&x(w.normalMap.channel),displacementMapUv:Ut&&x(w.displacementMap.channel),emissiveMapUv:_e&&x(w.emissiveMap.channel),metalnessMapUv:Dt&&x(w.metalnessMap.channel),roughnessMapUv:L&&x(w.roughnessMap.channel),anisotropyMapUv:ft&&x(w.anisotropyMap.channel),clearcoatMapUv:xt&&x(w.clearcoatMap.channel),clearcoatNormalMapUv:oe&&x(w.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:lt&&x(w.clearcoatRoughnessMap.channel),iridescenceMapUv:Mt&&x(w.iridescenceMap.channel),iridescenceThicknessMapUv:Ft&&x(w.iridescenceThicknessMap.channel),sheenColorMapUv:Bt&&x(w.sheenColorMap.channel),sheenRoughnessMapUv:bt&&x(w.sheenRoughnessMap.channel),specularMapUv:ae&&x(w.specularMap.channel),specularColorMapUv:Zt&&x(w.specularColorMap.channel),specularIntensityMapUv:Me&&x(w.specularIntensityMap.channel),transmissionMapUv:N&&x(w.transmissionMap.channel),thicknessMapUv:pt&&x(w.thicknessMap.channel),alphaMapUv:Q&&x(w.alphaMap.channel),vertexTangents:!!q.attributes.tangent&&(ie||T),vertexColors:w.vertexColors,vertexAlphas:w.vertexColors===!0&&!!q.attributes.color&&q.attributes.color.itemSize===4,pointsUvs:U.isPoints===!0&&!!q.attributes.uv&&(me||Q),fog:!!F,useFog:w.fog===!0,fogExp2:!!F&&F.isFogExp2,flatShading:w.flatShading===!0,sizeAttenuation:w.sizeAttenuation===!0,logarithmicDepthBuffer:u,reverseDepthBuffer:yt,skinning:U.isSkinnedMesh===!0,morphTargets:q.morphAttributes.position!==void 0,morphNormals:q.morphAttributes.normal!==void 0,morphColors:q.morphAttributes.color!==void 0,morphTargetsCount:Et,morphTextureStride:Ot,numDirLights:b.directional.length,numPointLights:b.point.length,numSpotLights:b.spot.length,numSpotLightMaps:b.spotLightMap.length,numRectAreaLights:b.rectArea.length,numHemiLights:b.hemi.length,numDirLightShadows:b.directionalShadowMap.length,numPointLightShadows:b.pointShadowMap.length,numSpotLightShadows:b.spotShadowMap.length,numSpotLightShadowsWithMaps:b.numSpotLightShadowsWithMaps,numLightProbes:b.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:w.dithering,shadowMapEnabled:s.shadowMap.enabled&&P.length>0,shadowMapType:s.shadowMap.type,toneMapping:Ie,decodeVideoTexture:me&&w.map.isVideoTexture===!0&&se.getTransfer(w.map.colorSpace)===pe,decodeVideoTextureEmissive:_e&&w.emissiveMap.isVideoTexture===!0&&se.getTransfer(w.emissiveMap.colorSpace)===pe,premultipliedAlpha:w.premultipliedAlpha,doubleSided:w.side===xe,flipSided:w.side===Ce,useDepthPacking:w.depthPacking>=0,depthPacking:w.depthPacking||0,index0AttributeName:w.index0AttributeName,extensionClipCullDistance:Xt&&w.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Xt&&w.extensions.multiDraw===!0||Jt)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:w.customProgramCacheKey()};return Qe.vertexUv1s=c.has(1),Qe.vertexUv2s=c.has(2),Qe.vertexUv3s=c.has(3),c.clear(),Qe}function p(w){let b=[];if(w.shaderID?b.push(w.shaderID):(b.push(w.customVertexShaderID),b.push(w.customFragmentShaderID)),w.defines!==void 0)for(let P in w.defines)b.push(P),b.push(w.defines[P]);return w.isRawShaderMaterial===!1&&(v(b,w),y(b,w),b.push(s.outputColorSpace)),b.push(w.customProgramCacheKey),b.join()}function v(w,b){w.push(b.precision),w.push(b.outputColorSpace),w.push(b.envMapMode),w.push(b.envMapCubeUVHeight),w.push(b.mapUv),w.push(b.alphaMapUv),w.push(b.lightMapUv),w.push(b.aoMapUv),w.push(b.bumpMapUv),w.push(b.normalMapUv),w.push(b.displacementMapUv),w.push(b.emissiveMapUv),w.push(b.metalnessMapUv),w.push(b.roughnessMapUv),w.push(b.anisotropyMapUv),w.push(b.clearcoatMapUv),w.push(b.clearcoatNormalMapUv),w.push(b.clearcoatRoughnessMapUv),w.push(b.iridescenceMapUv),w.push(b.iridescenceThicknessMapUv),w.push(b.sheenColorMapUv),w.push(b.sheenRoughnessMapUv),w.push(b.specularMapUv),w.push(b.specularColorMapUv),w.push(b.specularIntensityMapUv),w.push(b.transmissionMapUv),w.push(b.thicknessMapUv),w.push(b.combine),w.push(b.fogExp2),w.push(b.sizeAttenuation),w.push(b.morphTargetsCount),w.push(b.morphAttributeCount),w.push(b.numDirLights),w.push(b.numPointLights),w.push(b.numSpotLights),w.push(b.numSpotLightMaps),w.push(b.numHemiLights),w.push(b.numRectAreaLights),w.push(b.numDirLightShadows),w.push(b.numPointLightShadows),w.push(b.numSpotLightShadows),w.push(b.numSpotLightShadowsWithMaps),w.push(b.numLightProbes),w.push(b.shadowMapType),w.push(b.toneMapping),w.push(b.numClippingPlanes),w.push(b.numClipIntersection),w.push(b.depthPacking)}function y(w,b){o.disableAll(),b.supportsVertexTextures&&o.enable(0),b.instancing&&o.enable(1),b.instancingColor&&o.enable(2),b.instancingMorph&&o.enable(3),b.matcap&&o.enable(4),b.envMap&&o.enable(5),b.normalMapObjectSpace&&o.enable(6),b.normalMapTangentSpace&&o.enable(7),b.clearcoat&&o.enable(8),b.iridescence&&o.enable(9),b.alphaTest&&o.enable(10),b.vertexColors&&o.enable(11),b.vertexAlphas&&o.enable(12),b.vertexUv1s&&o.enable(13),b.vertexUv2s&&o.enable(14),b.vertexUv3s&&o.enable(15),b.vertexTangents&&o.enable(16),b.anisotropy&&o.enable(17),b.alphaHash&&o.enable(18),b.batching&&o.enable(19),b.dispersion&&o.enable(20),b.batchingColor&&o.enable(21),w.push(o.mask),o.disableAll(),b.fog&&o.enable(0),b.useFog&&o.enable(1),b.flatShading&&o.enable(2),b.logarithmicDepthBuffer&&o.enable(3),b.reverseDepthBuffer&&o.enable(4),b.skinning&&o.enable(5),b.morphTargets&&o.enable(6),b.morphNormals&&o.enable(7),b.morphColors&&o.enable(8),b.premultipliedAlpha&&o.enable(9),b.shadowMapEnabled&&o.enable(10),b.doubleSided&&o.enable(11),b.flipSided&&o.enable(12),b.useDepthPacking&&o.enable(13),b.dithering&&o.enable(14),b.transmission&&o.enable(15),b.sheen&&o.enable(16),b.opaque&&o.enable(17),b.pointsUvs&&o.enable(18),b.decodeVideoTexture&&o.enable(19),b.decodeVideoTextureEmissive&&o.enable(20),b.alphaToCoverage&&o.enable(21),w.push(o.mask)}function _(w){let b=m[w.type],P;if(b){let D=ni[b];P=Tn.clone(D.uniforms)}else P=w.uniforms;return P}function S(w,b){let P;for(let D=0,U=h.length;D<U;D++){let F=h[D];if(F.cacheKey===b){P=F,++P.usedTimes;break}}return P===void 0&&(P=new Ax(s,b,w,r),h.push(P)),P}function M(w){if(--w.usedTimes===0){let b=h.indexOf(w);h[b]=h[h.length-1],h.pop(),w.destroy()}}function E(w){l.remove(w)}function A(){l.dispose()}return{getParameters:g,getProgramCacheKey:p,getUniforms:_,acquireProgram:S,releaseProgram:M,releaseShaderCache:E,programs:h,dispose:A}}function Px(){let s=new WeakMap;function t(a){return s.has(a)}function e(a){let o=s.get(a);return o===void 0&&(o={},s.set(a,o)),o}function n(a){s.delete(a)}function i(a,o,l){s.get(a)[o]=l}function r(){s=new WeakMap}return{has:t,get:e,remove:n,update:i,dispose:r}}function Ix(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.material.id!==t.material.id?s.material.id-t.material.id:s.z!==t.z?s.z-t.z:s.id-t.id}function Td(s,t){return s.groupOrder!==t.groupOrder?s.groupOrder-t.groupOrder:s.renderOrder!==t.renderOrder?s.renderOrder-t.renderOrder:s.z!==t.z?t.z-s.z:s.id-t.id}function Ad(){let s=[],t=0,e=[],n=[],i=[];function r(){t=0,e.length=0,n.length=0,i.length=0}function a(u,d,f,m,x,g){let p=s[t];return p===void 0?(p={id:u.id,object:u,geometry:d,material:f,groupOrder:m,renderOrder:u.renderOrder,z:x,group:g},s[t]=p):(p.id=u.id,p.object=u,p.geometry=d,p.material=f,p.groupOrder=m,p.renderOrder=u.renderOrder,p.z=x,p.group=g),t++,p}function o(u,d,f,m,x,g){let p=a(u,d,f,m,x,g);f.transmission>0?n.push(p):f.transparent===!0?i.push(p):e.push(p)}function l(u,d,f,m,x,g){let p=a(u,d,f,m,x,g);f.transmission>0?n.unshift(p):f.transparent===!0?i.unshift(p):e.unshift(p)}function c(u,d){e.length>1&&e.sort(u||Ix),n.length>1&&n.sort(d||Td),i.length>1&&i.sort(d||Td)}function h(){for(let u=t,d=s.length;u<d;u++){let f=s[u];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:e,transmissive:n,transparent:i,init:r,push:o,unshift:l,finish:h,sort:c}}function Lx(){let s=new WeakMap;function t(n,i){let r=s.get(n),a;return r===void 0?(a=new Ad,s.set(n,[a])):i>=r.length?(a=new Ad,r.push(a)):a=r[i],a}function e(){s=new WeakMap}return{get:t,dispose:e}}function Dx(){let s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new C,color:new ot};break;case"SpotLight":e={position:new C,direction:new C,color:new ot,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new C,color:new ot,distance:0,decay:0};break;case"HemisphereLight":e={direction:new C,skyColor:new ot,groundColor:new ot};break;case"RectAreaLight":e={color:new ot,position:new C,halfWidth:new C,halfHeight:new C};break}return s[t.id]=e,e}}}function kx(){let s={};return{get:function(t){if(s[t.id]!==void 0)return s[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new tt};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new tt};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new tt,shadowCameraNear:1,shadowCameraFar:1e3};break}return s[t.id]=e,e}}}var Ux=0;function Nx(s,t){return(t.castShadow?2:0)-(s.castShadow?2:0)+(t.map?1:0)-(s.map?1:0)}function Fx(s){let t=new Dx,e=kx(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new C);let i=new C,r=new Lt,a=new Lt;function o(c){let h=0,u=0,d=0;for(let w=0;w<9;w++)n.probe[w].set(0,0,0);let f=0,m=0,x=0,g=0,p=0,v=0,y=0,_=0,S=0,M=0,E=0;c.sort(Nx);for(let w=0,b=c.length;w<b;w++){let P=c[w],D=P.color,U=P.intensity,F=P.distance,q=P.shadow&&P.shadow.map?P.shadow.map.texture:null;if(P.isAmbientLight)h+=D.r*U,u+=D.g*U,d+=D.b*U;else if(P.isLightProbe){for(let V=0;V<9;V++)n.probe[V].addScaledVector(P.sh.coefficients[V],U);E++}else if(P.isDirectionalLight){let V=t.get(P);if(V.color.copy(P.color).multiplyScalar(P.intensity),P.castShadow){let J=P.shadow,G=e.get(P);G.shadowIntensity=J.intensity,G.shadowBias=J.bias,G.shadowNormalBias=J.normalBias,G.shadowRadius=J.radius,G.shadowMapSize=J.mapSize,n.directionalShadow[f]=G,n.directionalShadowMap[f]=q,n.directionalShadowMatrix[f]=P.shadow.matrix,v++}n.directional[f]=V,f++}else if(P.isSpotLight){let V=t.get(P);V.position.setFromMatrixPosition(P.matrixWorld),V.color.copy(D).multiplyScalar(U),V.distance=F,V.coneCos=Math.cos(P.angle),V.penumbraCos=Math.cos(P.angle*(1-P.penumbra)),V.decay=P.decay,n.spot[x]=V;let J=P.shadow;if(P.map&&(n.spotLightMap[S]=P.map,S++,J.updateMatrices(P),P.castShadow&&M++),n.spotLightMatrix[x]=J.matrix,P.castShadow){let G=e.get(P);G.shadowIntensity=J.intensity,G.shadowBias=J.bias,G.shadowNormalBias=J.normalBias,G.shadowRadius=J.radius,G.shadowMapSize=J.mapSize,n.spotShadow[x]=G,n.spotShadowMap[x]=q,_++}x++}else if(P.isRectAreaLight){let V=t.get(P);V.color.copy(D).multiplyScalar(U),V.halfWidth.set(P.width*.5,0,0),V.halfHeight.set(0,P.height*.5,0),n.rectArea[g]=V,g++}else if(P.isPointLight){let V=t.get(P);if(V.color.copy(P.color).multiplyScalar(P.intensity),V.distance=P.distance,V.decay=P.decay,P.castShadow){let J=P.shadow,G=e.get(P);G.shadowIntensity=J.intensity,G.shadowBias=J.bias,G.shadowNormalBias=J.normalBias,G.shadowRadius=J.radius,G.shadowMapSize=J.mapSize,G.shadowCameraNear=J.camera.near,G.shadowCameraFar=J.camera.far,n.pointShadow[m]=G,n.pointShadowMap[m]=q,n.pointShadowMatrix[m]=P.shadow.matrix,y++}n.point[m]=V,m++}else if(P.isHemisphereLight){let V=t.get(P);V.skyColor.copy(P.color).multiplyScalar(U),V.groundColor.copy(P.groundColor).multiplyScalar(U),n.hemi[p]=V,p++}}g>0&&(s.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=ut.LTC_FLOAT_1,n.rectAreaLTC2=ut.LTC_FLOAT_2):(n.rectAreaLTC1=ut.LTC_HALF_1,n.rectAreaLTC2=ut.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=d;let A=n.hash;(A.directionalLength!==f||A.pointLength!==m||A.spotLength!==x||A.rectAreaLength!==g||A.hemiLength!==p||A.numDirectionalShadows!==v||A.numPointShadows!==y||A.numSpotShadows!==_||A.numSpotMaps!==S||A.numLightProbes!==E)&&(n.directional.length=f,n.spot.length=x,n.rectArea.length=g,n.point.length=m,n.hemi.length=p,n.directionalShadow.length=v,n.directionalShadowMap.length=v,n.pointShadow.length=y,n.pointShadowMap.length=y,n.spotShadow.length=_,n.spotShadowMap.length=_,n.directionalShadowMatrix.length=v,n.pointShadowMatrix.length=y,n.spotLightMatrix.length=_+S-M,n.spotLightMap.length=S,n.numSpotLightShadowsWithMaps=M,n.numLightProbes=E,A.directionalLength=f,A.pointLength=m,A.spotLength=x,A.rectAreaLength=g,A.hemiLength=p,A.numDirectionalShadows=v,A.numPointShadows=y,A.numSpotShadows=_,A.numSpotMaps=S,A.numLightProbes=E,n.version=Ux++)}function l(c,h){let u=0,d=0,f=0,m=0,x=0,g=h.matrixWorldInverse;for(let p=0,v=c.length;p<v;p++){let y=c[p];if(y.isDirectionalLight){let _=n.directional[u];_.direction.setFromMatrixPosition(y.matrixWorld),i.setFromMatrixPosition(y.target.matrixWorld),_.direction.sub(i),_.direction.transformDirection(g),u++}else if(y.isSpotLight){let _=n.spot[f];_.position.setFromMatrixPosition(y.matrixWorld),_.position.applyMatrix4(g),_.direction.setFromMatrixPosition(y.matrixWorld),i.setFromMatrixPosition(y.target.matrixWorld),_.direction.sub(i),_.direction.transformDirection(g),f++}else if(y.isRectAreaLight){let _=n.rectArea[m];_.position.setFromMatrixPosition(y.matrixWorld),_.position.applyMatrix4(g),a.identity(),r.copy(y.matrixWorld),r.premultiply(g),a.extractRotation(r),_.halfWidth.set(y.width*.5,0,0),_.halfHeight.set(0,y.height*.5,0),_.halfWidth.applyMatrix4(a),_.halfHeight.applyMatrix4(a),m++}else if(y.isPointLight){let _=n.point[d];_.position.setFromMatrixPosition(y.matrixWorld),_.position.applyMatrix4(g),d++}else if(y.isHemisphereLight){let _=n.hemi[x];_.direction.setFromMatrixPosition(y.matrixWorld),_.direction.transformDirection(g),x++}}}return{setup:o,setupView:l,state:n}}function Rd(s){let t=new Fx(s),e=[],n=[];function i(h){c.camera=h,e.length=0,n.length=0}function r(h){e.push(h)}function a(h){n.push(h)}function o(){t.setup(e)}function l(h){t.setupView(e,h)}let c={lightsArray:e,shadowsArray:n,camera:null,lights:t,transmissionRenderTarget:{}};return{init:i,state:c,setupLights:o,setupLightsView:l,pushLight:r,pushShadow:a}}function Ox(s){let t=new WeakMap;function e(i,r=0){let a=t.get(i),o;return a===void 0?(o=new Rd(s),t.set(i,[o])):r>=a.length?(o=new Rd(s),a.push(o)):o=a[r],o}function n(){t=new WeakMap}return{get:e,dispose:n}}var rh=class extends li{static get type(){return"MeshDepthMaterial"}constructor(t){super(),this.isMeshDepthMaterial=!0,this.depthPacking=q0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},ah=class extends li{static get type(){return"MeshDistanceMaterial"}constructor(t){super(),this.isMeshDistanceMaterial=!0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}},Bx=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,zx=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function Hx(s,t,e){let n=new $r,i=new tt,r=new tt,a=new ue,o=new rh({depthPacking:Y0}),l=new ah,c={},h=e.maxTextureSize,u={[Wi]:Ce,[Ce]:Wi,[xe]:xe},d=new ve({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new tt},radius:{value:4}},vertexShader:Bx,fragmentShader:zx}),f=d.clone();f.defines.HORIZONTAL_PASS=1;let m=new Gt;m.setAttribute("position",new Vt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let x=new it(m,d),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Xd;let p=this.type;this.render=function(M,E,A){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||M.length===0)return;let w=s.getRenderTarget(),b=s.getActiveCubeFace(),P=s.getActiveMipmapLevel(),D=s.state;D.setBlending(oi),D.buffers.color.setClear(1,1,1,1),D.buffers.depth.setTest(!0),D.setScissorTest(!1);let U=p!==Mi&&this.type===Mi,F=p===Mi&&this.type!==Mi;for(let q=0,V=M.length;q<V;q++){let J=M[q],G=J.shadow;if(G===void 0){console.warn("THREE.WebGLShadowMap:",J,"has no shadow.");continue}if(G.autoUpdate===!1&&G.needsUpdate===!1)continue;i.copy(G.mapSize);let nt=G.getFrameExtents();if(i.multiply(nt),r.copy(G.mapSize),(i.x>h||i.y>h)&&(i.x>h&&(r.x=Math.floor(h/nt.x),i.x=r.x*nt.x,G.mapSize.x=r.x),i.y>h&&(r.y=Math.floor(h/nt.y),i.y=r.y*nt.y,G.mapSize.y=r.y)),G.map===null||U===!0||F===!0){let Et=this.type!==Mi?{minFilter:yn,magFilter:yn}:{};G.map!==null&&G.map.dispose(),G.map=new Ne(i.x,i.y,Et),G.map.texture.name=J.name+".shadowMap",G.camera.updateProjectionMatrix()}s.setRenderTarget(G.map),s.clear();let ht=G.getViewportCount();for(let Et=0;Et<ht;Et++){let Ot=G.getViewport(Et);a.set(r.x*Ot.x,r.y*Ot.y,r.x*Ot.z,r.y*Ot.w),D.viewport(a),G.updateMatrices(J,Et),n=G.getFrustum(),_(E,A,G.camera,J,this.type)}G.isPointLightShadow!==!0&&this.type===Mi&&v(G,A),G.needsUpdate=!1}p=this.type,g.needsUpdate=!1,s.setRenderTarget(w,b,P)};function v(M,E){let A=t.update(x);d.defines.VSM_SAMPLES!==M.blurSamples&&(d.defines.VSM_SAMPLES=M.blurSamples,f.defines.VSM_SAMPLES=M.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),M.mapPass===null&&(M.mapPass=new Ne(i.x,i.y)),d.uniforms.shadow_pass.value=M.map.texture,d.uniforms.resolution.value=M.mapSize,d.uniforms.radius.value=M.radius,s.setRenderTarget(M.mapPass),s.clear(),s.renderBufferDirect(E,null,A,d,x,null),f.uniforms.shadow_pass.value=M.mapPass.texture,f.uniforms.resolution.value=M.mapSize,f.uniforms.radius.value=M.radius,s.setRenderTarget(M.map),s.clear(),s.renderBufferDirect(E,null,A,f,x,null)}function y(M,E,A,w){let b=null,P=A.isPointLight===!0?M.customDistanceMaterial:M.customDepthMaterial;if(P!==void 0)b=P;else if(b=A.isPointLight===!0?l:o,s.localClippingEnabled&&E.clipShadows===!0&&Array.isArray(E.clippingPlanes)&&E.clippingPlanes.length!==0||E.displacementMap&&E.displacementScale!==0||E.alphaMap&&E.alphaTest>0||E.map&&E.alphaTest>0){let D=b.uuid,U=E.uuid,F=c[D];F===void 0&&(F={},c[D]=F);let q=F[U];q===void 0&&(q=b.clone(),F[U]=q,E.addEventListener("dispose",S)),b=q}if(b.visible=E.visible,b.wireframe=E.wireframe,w===Mi?b.side=E.shadowSide!==null?E.shadowSide:E.side:b.side=E.shadowSide!==null?E.shadowSide:u[E.side],b.alphaMap=E.alphaMap,b.alphaTest=E.alphaTest,b.map=E.map,b.clipShadows=E.clipShadows,b.clippingPlanes=E.clippingPlanes,b.clipIntersection=E.clipIntersection,b.displacementMap=E.displacementMap,b.displacementScale=E.displacementScale,b.displacementBias=E.displacementBias,b.wireframeLinewidth=E.wireframeLinewidth,b.linewidth=E.linewidth,A.isPointLight===!0&&b.isMeshDistanceMaterial===!0){let D=s.properties.get(b);D.light=A}return b}function _(M,E,A,w,b){if(M.visible===!1)return;if(M.layers.test(E.layers)&&(M.isMesh||M.isLine||M.isPoints)&&(M.castShadow||M.receiveShadow&&b===Mi)&&(!M.frustumCulled||n.intersectsObject(M))){M.modelViewMatrix.multiplyMatrices(A.matrixWorldInverse,M.matrixWorld);let U=t.update(M),F=M.material;if(Array.isArray(F)){let q=U.groups;for(let V=0,J=q.length;V<J;V++){let G=q[V],nt=F[G.materialIndex];if(nt&&nt.visible){let ht=y(M,nt,w,b);M.onBeforeShadow(s,M,E,A,U,ht,G),s.renderBufferDirect(A,null,U,ht,M,G),M.onAfterShadow(s,M,E,A,U,ht,G)}}}else if(F.visible){let q=y(M,F,w,b);M.onBeforeShadow(s,M,E,A,U,q,null),s.renderBufferDirect(A,null,U,q,M,null),M.onAfterShadow(s,M,E,A,U,q,null)}}let D=M.children;for(let U=0,F=D.length;U<F;U++)_(D[U],E,A,w,b)}function S(M){M.target.removeEventListener("dispose",S);for(let A in c){let w=c[A],b=M.target.uuid;b in w&&(w[b].dispose(),delete w[b])}}}var Vx={[hc]:uc,[dc]:mc,[fc]:gc,[er]:pc,[uc]:hc,[mc]:dc,[gc]:fc,[pc]:er};function Gx(s,t){function e(){let N=!1,pt=new ue,Y=null,Q=new ue(0,0,0,0);return{setMask:function(vt){Y!==vt&&!N&&(s.colorMask(vt,vt,vt,vt),Y=vt)},setLocked:function(vt){N=vt},setClear:function(vt,mt,Xt,Ie,Qe){Qe===!0&&(vt*=Ie,mt*=Ie,Xt*=Ie),pt.set(vt,mt,Xt,Ie),Q.equals(pt)===!1&&(s.clearColor(vt,mt,Xt,Ie),Q.copy(pt))},reset:function(){N=!1,Y=null,Q.set(-1,0,0,0)}}}function n(){let N=!1,pt=!1,Y=null,Q=null,vt=null;return{setReversed:function(mt){if(pt!==mt){let Xt=t.get("EXT_clip_control");pt?Xt.clipControlEXT(Xt.LOWER_LEFT_EXT,Xt.ZERO_TO_ONE_EXT):Xt.clipControlEXT(Xt.LOWER_LEFT_EXT,Xt.NEGATIVE_ONE_TO_ONE_EXT);let Ie=vt;vt=null,this.setClear(Ie)}pt=mt},getReversed:function(){return pt},setTest:function(mt){mt?dt(s.DEPTH_TEST):yt(s.DEPTH_TEST)},setMask:function(mt){Y!==mt&&!N&&(s.depthMask(mt),Y=mt)},setFunc:function(mt){if(pt&&(mt=Vx[mt]),Q!==mt){switch(mt){case hc:s.depthFunc(s.NEVER);break;case uc:s.depthFunc(s.ALWAYS);break;case dc:s.depthFunc(s.LESS);break;case er:s.depthFunc(s.LEQUAL);break;case fc:s.depthFunc(s.EQUAL);break;case pc:s.depthFunc(s.GEQUAL);break;case mc:s.depthFunc(s.GREATER);break;case gc:s.depthFunc(s.NOTEQUAL);break;default:s.depthFunc(s.LEQUAL)}Q=mt}},setLocked:function(mt){N=mt},setClear:function(mt){vt!==mt&&(pt&&(mt=1-mt),s.clearDepth(mt),vt=mt)},reset:function(){N=!1,Y=null,Q=null,vt=null,pt=!1}}}function i(){let N=!1,pt=null,Y=null,Q=null,vt=null,mt=null,Xt=null,Ie=null,Qe=null;return{setTest:function(ge){N||(ge?dt(s.STENCIL_TEST):yt(s.STENCIL_TEST))},setMask:function(ge){pt!==ge&&!N&&(s.stencilMask(ge),pt=ge)},setFunc:function(ge,Bn,pi){(Y!==ge||Q!==Bn||vt!==pi)&&(s.stencilFunc(ge,Bn,pi),Y=ge,Q=Bn,vt=pi)},setOp:function(ge,Bn,pi){(mt!==ge||Xt!==Bn||Ie!==pi)&&(s.stencilOp(ge,Bn,pi),mt=ge,Xt=Bn,Ie=pi)},setLocked:function(ge){N=ge},setClear:function(ge){Qe!==ge&&(s.clearStencil(ge),Qe=ge)},reset:function(){N=!1,pt=null,Y=null,Q=null,vt=null,mt=null,Xt=null,Ie=null,Qe=null}}}let r=new e,a=new n,o=new i,l=new WeakMap,c=new WeakMap,h={},u={},d=new WeakMap,f=[],m=null,x=!1,g=null,p=null,v=null,y=null,_=null,S=null,M=null,E=new ot(0,0,0),A=0,w=!1,b=null,P=null,D=null,U=null,F=null,q=s.getParameter(s.MAX_COMBINED_TEXTURE_IMAGE_UNITS),V=!1,J=0,G=s.getParameter(s.VERSION);G.indexOf("WebGL")!==-1?(J=parseFloat(/^WebGL (\d)/.exec(G)[1]),V=J>=1):G.indexOf("OpenGL ES")!==-1&&(J=parseFloat(/^OpenGL ES (\d)/.exec(G)[1]),V=J>=2);let nt=null,ht={},Et=s.getParameter(s.SCISSOR_BOX),Ot=s.getParameter(s.VIEWPORT),re=new ue().fromArray(Et),Z=new ue().fromArray(Ot);function st(N,pt,Y,Q){let vt=new Uint8Array(4),mt=s.createTexture();s.bindTexture(N,mt),s.texParameteri(N,s.TEXTURE_MIN_FILTER,s.NEAREST),s.texParameteri(N,s.TEXTURE_MAG_FILTER,s.NEAREST);for(let Xt=0;Xt<Y;Xt++)N===s.TEXTURE_3D||N===s.TEXTURE_2D_ARRAY?s.texImage3D(pt,0,s.RGBA,1,1,Q,0,s.RGBA,s.UNSIGNED_BYTE,vt):s.texImage2D(pt+Xt,0,s.RGBA,1,1,0,s.RGBA,s.UNSIGNED_BYTE,vt);return mt}let Tt={};Tt[s.TEXTURE_2D]=st(s.TEXTURE_2D,s.TEXTURE_2D,1),Tt[s.TEXTURE_CUBE_MAP]=st(s.TEXTURE_CUBE_MAP,s.TEXTURE_CUBE_MAP_POSITIVE_X,6),Tt[s.TEXTURE_2D_ARRAY]=st(s.TEXTURE_2D_ARRAY,s.TEXTURE_2D_ARRAY,1,1),Tt[s.TEXTURE_3D]=st(s.TEXTURE_3D,s.TEXTURE_3D,1,1),r.setClear(0,0,0,1),a.setClear(1),o.setClear(0),dt(s.DEPTH_TEST),a.setFunc(er),ne(!1),ie(Lu),dt(s.CULL_FACE),B(oi);function dt(N){h[N]!==!0&&(s.enable(N),h[N]=!0)}function yt(N){h[N]!==!1&&(s.disable(N),h[N]=!1)}function Nt(N,pt){return u[N]!==pt?(s.bindFramebuffer(N,pt),u[N]=pt,N===s.DRAW_FRAMEBUFFER&&(u[s.FRAMEBUFFER]=pt),N===s.FRAMEBUFFER&&(u[s.DRAW_FRAMEBUFFER]=pt),!0):!1}function Jt(N,pt){let Y=f,Q=!1;if(N){Y=d.get(pt),Y===void 0&&(Y=[],d.set(pt,Y));let vt=N.textures;if(Y.length!==vt.length||Y[0]!==s.COLOR_ATTACHMENT0){for(let mt=0,Xt=vt.length;mt<Xt;mt++)Y[mt]=s.COLOR_ATTACHMENT0+mt;Y.length=vt.length,Q=!0}}else Y[0]!==s.BACK&&(Y[0]=s.BACK,Q=!0);Q&&s.drawBuffers(Y)}function me(N){return m!==N?(s.useProgram(N),m=N,!0):!1}let ee={[ds]:s.FUNC_ADD,[E0]:s.FUNC_SUBTRACT,[T0]:s.FUNC_REVERSE_SUBTRACT};ee[A0]=s.MIN,ee[R0]=s.MAX;let Ae={[C0]:s.ZERO,[P0]:s.ONE,[I0]:s.SRC_COLOR,[lc]:s.SRC_ALPHA,[F0]:s.SRC_ALPHA_SATURATE,[U0]:s.DST_COLOR,[D0]:s.DST_ALPHA,[L0]:s.ONE_MINUS_SRC_COLOR,[cc]:s.ONE_MINUS_SRC_ALPHA,[N0]:s.ONE_MINUS_DST_COLOR,[k0]:s.ONE_MINUS_DST_ALPHA,[O0]:s.CONSTANT_COLOR,[B0]:s.ONE_MINUS_CONSTANT_COLOR,[z0]:s.CONSTANT_ALPHA,[H0]:s.ONE_MINUS_CONSTANT_ALPHA};function B(N,pt,Y,Q,vt,mt,Xt,Ie,Qe,ge){if(N===oi){x===!0&&(yt(s.BLEND),x=!1);return}if(x===!1&&(dt(s.BLEND),x=!0),N!==S0){if(N!==g||ge!==w){if((p!==ds||_!==ds)&&(s.blendEquation(s.FUNC_ADD),p=ds,_=ds),ge)switch(N){case Hi:s.blendFuncSeparate(s.ONE,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case ms:s.blendFunc(s.ONE,s.ONE);break;case Du:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case ku:s.blendFuncSeparate(s.ZERO,s.SRC_COLOR,s.ZERO,s.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",N);break}else switch(N){case Hi:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case ms:s.blendFunc(s.SRC_ALPHA,s.ONE);break;case Du:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case ku:s.blendFunc(s.ZERO,s.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",N);break}v=null,y=null,S=null,M=null,E.set(0,0,0),A=0,g=N,w=ge}return}vt=vt||pt,mt=mt||Y,Xt=Xt||Q,(pt!==p||vt!==_)&&(s.blendEquationSeparate(ee[pt],ee[vt]),p=pt,_=vt),(Y!==v||Q!==y||mt!==S||Xt!==M)&&(s.blendFuncSeparate(Ae[Y],Ae[Q],Ae[mt],Ae[Xt]),v=Y,y=Q,S=mt,M=Xt),(Ie.equals(E)===!1||Qe!==A)&&(s.blendColor(Ie.r,Ie.g,Ie.b,Qe),E.copy(Ie),A=Qe),g=N,w=!1}function Je(N,pt){N.side===xe?yt(s.CULL_FACE):dt(s.CULL_FACE);let Y=N.side===Ce;pt&&(Y=!Y),ne(Y),N.blending===Hi&&N.transparent===!1?B(oi):B(N.blending,N.blendEquation,N.blendSrc,N.blendDst,N.blendEquationAlpha,N.blendSrcAlpha,N.blendDstAlpha,N.blendColor,N.blendAlpha,N.premultipliedAlpha),a.setFunc(N.depthFunc),a.setTest(N.depthTest),a.setMask(N.depthWrite),r.setMask(N.colorWrite);let Q=N.stencilWrite;o.setTest(Q),Q&&(o.setMask(N.stencilWriteMask),o.setFunc(N.stencilFunc,N.stencilRef,N.stencilFuncMask),o.setOp(N.stencilFail,N.stencilZFail,N.stencilZPass)),_e(N.polygonOffset,N.polygonOffsetFactor,N.polygonOffsetUnits),N.alphaToCoverage===!0?dt(s.SAMPLE_ALPHA_TO_COVERAGE):yt(s.SAMPLE_ALPHA_TO_COVERAGE)}function ne(N){b!==N&&(N?s.frontFace(s.CW):s.frontFace(s.CCW),b=N)}function ie(N){N!==b0?(dt(s.CULL_FACE),N!==P&&(N===Lu?s.cullFace(s.BACK):N===w0?s.cullFace(s.FRONT):s.cullFace(s.FRONT_AND_BACK))):yt(s.CULL_FACE),P=N}function Ut(N){N!==D&&(V&&s.lineWidth(N),D=N)}function _e(N,pt,Y){N?(dt(s.POLYGON_OFFSET_FILL),(U!==pt||F!==Y)&&(s.polygonOffset(pt,Y),U=pt,F=Y)):yt(s.POLYGON_OFFSET_FILL)}function Dt(N){N?dt(s.SCISSOR_TEST):yt(s.SCISSOR_TEST)}function L(N){N===void 0&&(N=s.TEXTURE0+q-1),nt!==N&&(s.activeTexture(N),nt=N)}function T(N,pt,Y){Y===void 0&&(nt===null?Y=s.TEXTURE0+q-1:Y=nt);let Q=ht[Y];Q===void 0&&(Q={type:void 0,texture:void 0},ht[Y]=Q),(Q.type!==N||Q.texture!==pt)&&(nt!==Y&&(s.activeTexture(Y),nt=Y),s.bindTexture(N,pt||Tt[N]),Q.type=N,Q.texture=pt)}function H(){let N=ht[nt];N!==void 0&&N.type!==void 0&&(s.bindTexture(N.type,null),N.type=void 0,N.texture=void 0)}function j(){try{s.compressedTexImage2D.apply(s,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function et(){try{s.compressedTexImage3D.apply(s,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function K(){try{s.texSubImage2D.apply(s,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function _t(){try{s.texSubImage3D.apply(s,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function ft(){try{s.compressedTexSubImage2D.apply(s,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function xt(){try{s.compressedTexSubImage3D.apply(s,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function oe(){try{s.texStorage2D.apply(s,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function lt(){try{s.texStorage3D.apply(s,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Mt(){try{s.texImage2D.apply(s,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Ft(){try{s.texImage3D.apply(s,arguments)}catch(N){console.error("THREE.WebGLState:",N)}}function Bt(N){re.equals(N)===!1&&(s.scissor(N.x,N.y,N.z,N.w),re.copy(N))}function bt(N){Z.equals(N)===!1&&(s.viewport(N.x,N.y,N.z,N.w),Z.copy(N))}function ae(N,pt){let Y=c.get(pt);Y===void 0&&(Y=new WeakMap,c.set(pt,Y));let Q=Y.get(N);Q===void 0&&(Q=s.getUniformBlockIndex(pt,N.name),Y.set(N,Q))}function Zt(N,pt){let Q=c.get(pt).get(N);l.get(pt)!==Q&&(s.uniformBlockBinding(pt,Q,N.__bindingPointIndex),l.set(pt,Q))}function Me(){s.disable(s.BLEND),s.disable(s.CULL_FACE),s.disable(s.DEPTH_TEST),s.disable(s.POLYGON_OFFSET_FILL),s.disable(s.SCISSOR_TEST),s.disable(s.STENCIL_TEST),s.disable(s.SAMPLE_ALPHA_TO_COVERAGE),s.blendEquation(s.FUNC_ADD),s.blendFunc(s.ONE,s.ZERO),s.blendFuncSeparate(s.ONE,s.ZERO,s.ONE,s.ZERO),s.blendColor(0,0,0,0),s.colorMask(!0,!0,!0,!0),s.clearColor(0,0,0,0),s.depthMask(!0),s.depthFunc(s.LESS),a.setReversed(!1),s.clearDepth(1),s.stencilMask(4294967295),s.stencilFunc(s.ALWAYS,0,4294967295),s.stencilOp(s.KEEP,s.KEEP,s.KEEP),s.clearStencil(0),s.cullFace(s.BACK),s.frontFace(s.CCW),s.polygonOffset(0,0),s.activeTexture(s.TEXTURE0),s.bindFramebuffer(s.FRAMEBUFFER,null),s.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),s.bindFramebuffer(s.READ_FRAMEBUFFER,null),s.useProgram(null),s.lineWidth(1),s.scissor(0,0,s.canvas.width,s.canvas.height),s.viewport(0,0,s.canvas.width,s.canvas.height),h={},nt=null,ht={},u={},d=new WeakMap,f=[],m=null,x=!1,g=null,p=null,v=null,y=null,_=null,S=null,M=null,E=new ot(0,0,0),A=0,w=!1,b=null,P=null,D=null,U=null,F=null,re.set(0,0,s.canvas.width,s.canvas.height),Z.set(0,0,s.canvas.width,s.canvas.height),r.reset(),a.reset(),o.reset()}return{buffers:{color:r,depth:a,stencil:o},enable:dt,disable:yt,bindFramebuffer:Nt,drawBuffers:Jt,useProgram:me,setBlending:B,setMaterial:Je,setFlipSided:ne,setCullFace:ie,setLineWidth:Ut,setPolygonOffset:_e,setScissorTest:Dt,activeTexture:L,bindTexture:T,unbindTexture:H,compressedTexImage2D:j,compressedTexImage3D:et,texImage2D:Mt,texImage3D:Ft,updateUBOMapping:ae,uniformBlockBinding:Zt,texStorage2D:oe,texStorage3D:lt,texSubImage2D:K,texSubImage3D:_t,compressedTexSubImage2D:ft,compressedTexSubImage3D:xt,scissor:Bt,viewport:bt,reset:Me}}function Cd(s,t,e,n){let i=Wx(n);switch(e){case Jd:return s*t;case Qd:return s*t;case tf:return s*t*2;case Gh:return s*t/i.components*i.byteLength;case Wh:return s*t/i.components*i.byteLength;case ef:return s*t*2/i.components*i.byteLength;case Xh:return s*t*2/i.components*i.byteLength;case jd:return s*t*3/i.components*i.byteLength;case Xn:return s*t*4/i.components*i.byteLength;case qh:return s*t*4/i.components*i.byteLength;case to:case eo:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case no:case io:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case Mc:case wc:return Math.max(s,16)*Math.max(t,8)/4;case _c:case bc:return Math.max(s,8)*Math.max(t,8)/2;case Sc:case Ec:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*8;case Tc:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case Ac:return Math.floor((s+3)/4)*Math.floor((t+3)/4)*16;case Rc:return Math.floor((s+4)/5)*Math.floor((t+3)/4)*16;case Cc:return Math.floor((s+4)/5)*Math.floor((t+4)/5)*16;case Pc:return Math.floor((s+5)/6)*Math.floor((t+4)/5)*16;case Ic:return Math.floor((s+5)/6)*Math.floor((t+5)/6)*16;case Lc:return Math.floor((s+7)/8)*Math.floor((t+4)/5)*16;case Dc:return Math.floor((s+7)/8)*Math.floor((t+5)/6)*16;case kc:return Math.floor((s+7)/8)*Math.floor((t+7)/8)*16;case Uc:return Math.floor((s+9)/10)*Math.floor((t+4)/5)*16;case Nc:return Math.floor((s+9)/10)*Math.floor((t+5)/6)*16;case Fc:return Math.floor((s+9)/10)*Math.floor((t+7)/8)*16;case Oc:return Math.floor((s+9)/10)*Math.floor((t+9)/10)*16;case Bc:return Math.floor((s+11)/12)*Math.floor((t+9)/10)*16;case zc:return Math.floor((s+11)/12)*Math.floor((t+11)/12)*16;case so:case Hc:case Vc:return Math.ceil(s/4)*Math.ceil(t/4)*16;case nf:case Gc:return Math.ceil(s/4)*Math.ceil(t/4)*8;case Wc:case Xc:return Math.ceil(s/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function Wx(s){switch(s){case Ei:case $d:return{byteLength:1,components:1};case qr:case Zd:case ln:return{byteLength:2,components:1};case Hh:case Vh:return{byteLength:2,components:4};case xs:case zh:case ai:return{byteLength:4,components:1};case Kd:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${s}.`)}function Xx(s,t,e,n,i,r,a){let o=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new tt,h=new WeakMap,u,d=new WeakMap,f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function m(L,T){return f?new OffscreenCanvas(L,T):lo("canvas")}function x(L,T,H){let j=1,et=Dt(L);if((et.width>H||et.height>H)&&(j=H/Math.max(et.width,et.height)),j<1)if(typeof HTMLImageElement<"u"&&L instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&L instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&L instanceof ImageBitmap||typeof VideoFrame<"u"&&L instanceof VideoFrame){let K=Math.floor(j*et.width),_t=Math.floor(j*et.height);u===void 0&&(u=m(K,_t));let ft=T?m(K,_t):u;return ft.width=K,ft.height=_t,ft.getContext("2d").drawImage(L,0,0,K,_t),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+et.width+"x"+et.height+") to ("+K+"x"+_t+")."),ft}else return"data"in L&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+et.width+"x"+et.height+")."),L;return L}function g(L){return L.generateMipmaps}function p(L){s.generateMipmap(L)}function v(L){return L.isWebGLCubeRenderTarget?s.TEXTURE_CUBE_MAP:L.isWebGL3DRenderTarget?s.TEXTURE_3D:L.isWebGLArrayRenderTarget||L.isCompressedArrayTexture?s.TEXTURE_2D_ARRAY:s.TEXTURE_2D}function y(L,T,H,j,et=!1){if(L!==null){if(s[L]!==void 0)return s[L];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+L+"'")}let K=T;if(T===s.RED&&(H===s.FLOAT&&(K=s.R32F),H===s.HALF_FLOAT&&(K=s.R16F),H===s.UNSIGNED_BYTE&&(K=s.R8)),T===s.RED_INTEGER&&(H===s.UNSIGNED_BYTE&&(K=s.R8UI),H===s.UNSIGNED_SHORT&&(K=s.R16UI),H===s.UNSIGNED_INT&&(K=s.R32UI),H===s.BYTE&&(K=s.R8I),H===s.SHORT&&(K=s.R16I),H===s.INT&&(K=s.R32I)),T===s.RG&&(H===s.FLOAT&&(K=s.RG32F),H===s.HALF_FLOAT&&(K=s.RG16F),H===s.UNSIGNED_BYTE&&(K=s.RG8)),T===s.RG_INTEGER&&(H===s.UNSIGNED_BYTE&&(K=s.RG8UI),H===s.UNSIGNED_SHORT&&(K=s.RG16UI),H===s.UNSIGNED_INT&&(K=s.RG32UI),H===s.BYTE&&(K=s.RG8I),H===s.SHORT&&(K=s.RG16I),H===s.INT&&(K=s.RG32I)),T===s.RGB_INTEGER&&(H===s.UNSIGNED_BYTE&&(K=s.RGB8UI),H===s.UNSIGNED_SHORT&&(K=s.RGB16UI),H===s.UNSIGNED_INT&&(K=s.RGB32UI),H===s.BYTE&&(K=s.RGB8I),H===s.SHORT&&(K=s.RGB16I),H===s.INT&&(K=s.RGB32I)),T===s.RGBA_INTEGER&&(H===s.UNSIGNED_BYTE&&(K=s.RGBA8UI),H===s.UNSIGNED_SHORT&&(K=s.RGBA16UI),H===s.UNSIGNED_INT&&(K=s.RGBA32UI),H===s.BYTE&&(K=s.RGBA8I),H===s.SHORT&&(K=s.RGBA16I),H===s.INT&&(K=s.RGBA32I)),T===s.RGB&&H===s.UNSIGNED_INT_5_9_9_9_REV&&(K=s.RGB9_E5),T===s.RGBA){let _t=et?Bo:se.getTransfer(j);H===s.FLOAT&&(K=s.RGBA32F),H===s.HALF_FLOAT&&(K=s.RGBA16F),H===s.UNSIGNED_BYTE&&(K=_t===pe?s.SRGB8_ALPHA8:s.RGBA8),H===s.UNSIGNED_SHORT_4_4_4_4&&(K=s.RGBA4),H===s.UNSIGNED_SHORT_5_5_5_1&&(K=s.RGB5_A1)}return(K===s.R16F||K===s.R32F||K===s.RG16F||K===s.RG32F||K===s.RGBA16F||K===s.RGBA32F)&&t.get("EXT_color_buffer_float"),K}function _(L,T){let H;return L?T===null||T===xs||T===sr?H=s.DEPTH24_STENCIL8:T===ai?H=s.DEPTH32F_STENCIL8:T===qr&&(H=s.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):T===null||T===xs||T===sr?H=s.DEPTH_COMPONENT24:T===ai?H=s.DEPTH_COMPONENT32F:T===qr&&(H=s.DEPTH_COMPONENT16),H}function S(L,T){return g(L)===!0||L.isFramebufferTexture&&L.minFilter!==yn&&L.minFilter!==ri?Math.log2(Math.max(T.width,T.height))+1:L.mipmaps!==void 0&&L.mipmaps.length>0?L.mipmaps.length:L.isCompressedTexture&&Array.isArray(L.image)?T.mipmaps.length:1}function M(L){let T=L.target;T.removeEventListener("dispose",M),A(T),T.isVideoTexture&&h.delete(T)}function E(L){let T=L.target;T.removeEventListener("dispose",E),b(T)}function A(L){let T=n.get(L);if(T.__webglInit===void 0)return;let H=L.source,j=d.get(H);if(j){let et=j[T.__cacheKey];et.usedTimes--,et.usedTimes===0&&w(L),Object.keys(j).length===0&&d.delete(H)}n.remove(L)}function w(L){let T=n.get(L);s.deleteTexture(T.__webglTexture);let H=L.source,j=d.get(H);delete j[T.__cacheKey],a.memory.textures--}function b(L){let T=n.get(L);if(L.depthTexture&&(L.depthTexture.dispose(),n.remove(L.depthTexture)),L.isWebGLCubeRenderTarget)for(let j=0;j<6;j++){if(Array.isArray(T.__webglFramebuffer[j]))for(let et=0;et<T.__webglFramebuffer[j].length;et++)s.deleteFramebuffer(T.__webglFramebuffer[j][et]);else s.deleteFramebuffer(T.__webglFramebuffer[j]);T.__webglDepthbuffer&&s.deleteRenderbuffer(T.__webglDepthbuffer[j])}else{if(Array.isArray(T.__webglFramebuffer))for(let j=0;j<T.__webglFramebuffer.length;j++)s.deleteFramebuffer(T.__webglFramebuffer[j]);else s.deleteFramebuffer(T.__webglFramebuffer);if(T.__webglDepthbuffer&&s.deleteRenderbuffer(T.__webglDepthbuffer),T.__webglMultisampledFramebuffer&&s.deleteFramebuffer(T.__webglMultisampledFramebuffer),T.__webglColorRenderbuffer)for(let j=0;j<T.__webglColorRenderbuffer.length;j++)T.__webglColorRenderbuffer[j]&&s.deleteRenderbuffer(T.__webglColorRenderbuffer[j]);T.__webglDepthRenderbuffer&&s.deleteRenderbuffer(T.__webglDepthRenderbuffer)}let H=L.textures;for(let j=0,et=H.length;j<et;j++){let K=n.get(H[j]);K.__webglTexture&&(s.deleteTexture(K.__webglTexture),a.memory.textures--),n.remove(H[j])}n.remove(L)}let P=0;function D(){P=0}function U(){let L=P;return L>=i.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+L+" texture units while this GPU supports only "+i.maxTextures),P+=1,L}function F(L){let T=[];return T.push(L.wrapS),T.push(L.wrapT),T.push(L.wrapR||0),T.push(L.magFilter),T.push(L.minFilter),T.push(L.anisotropy),T.push(L.internalFormat),T.push(L.format),T.push(L.type),T.push(L.generateMipmaps),T.push(L.premultiplyAlpha),T.push(L.flipY),T.push(L.unpackAlignment),T.push(L.colorSpace),T.join()}function q(L,T){let H=n.get(L);if(L.isVideoTexture&&Ut(L),L.isRenderTargetTexture===!1&&L.version>0&&H.__version!==L.version){let j=L.image;if(j===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(j.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{Z(H,L,T);return}}e.bindTexture(s.TEXTURE_2D,H.__webglTexture,s.TEXTURE0+T)}function V(L,T){let H=n.get(L);if(L.version>0&&H.__version!==L.version){Z(H,L,T);return}e.bindTexture(s.TEXTURE_2D_ARRAY,H.__webglTexture,s.TEXTURE0+T)}function J(L,T){let H=n.get(L);if(L.version>0&&H.__version!==L.version){Z(H,L,T);return}e.bindTexture(s.TEXTURE_3D,H.__webglTexture,s.TEXTURE0+T)}function G(L,T){let H=n.get(L);if(L.version>0&&H.__version!==L.version){st(H,L,T);return}e.bindTexture(s.TEXTURE_CUBE_MAP,H.__webglTexture,s.TEXTURE0+T)}let nt={[gs]:s.REPEAT,[ps]:s.CLAMP_TO_EDGE,[yc]:s.MIRRORED_REPEAT},ht={[yn]:s.NEAREST,[X0]:s.NEAREST_MIPMAP_NEAREST,[wa]:s.NEAREST_MIPMAP_LINEAR,[ri]:s.LINEAR,[El]:s.LINEAR_MIPMAP_NEAREST,[bi]:s.LINEAR_MIPMAP_LINEAR},Et={[Z0]:s.NEVER,[ep]:s.ALWAYS,[K0]:s.LESS,[rf]:s.LEQUAL,[J0]:s.EQUAL,[tp]:s.GEQUAL,[j0]:s.GREATER,[Q0]:s.NOTEQUAL};function Ot(L,T){if(T.type===ai&&t.has("OES_texture_float_linear")===!1&&(T.magFilter===ri||T.magFilter===El||T.magFilter===wa||T.magFilter===bi||T.minFilter===ri||T.minFilter===El||T.minFilter===wa||T.minFilter===bi)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),s.texParameteri(L,s.TEXTURE_WRAP_S,nt[T.wrapS]),s.texParameteri(L,s.TEXTURE_WRAP_T,nt[T.wrapT]),(L===s.TEXTURE_3D||L===s.TEXTURE_2D_ARRAY)&&s.texParameteri(L,s.TEXTURE_WRAP_R,nt[T.wrapR]),s.texParameteri(L,s.TEXTURE_MAG_FILTER,ht[T.magFilter]),s.texParameteri(L,s.TEXTURE_MIN_FILTER,ht[T.minFilter]),T.compareFunction&&(s.texParameteri(L,s.TEXTURE_COMPARE_MODE,s.COMPARE_REF_TO_TEXTURE),s.texParameteri(L,s.TEXTURE_COMPARE_FUNC,Et[T.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(T.magFilter===yn||T.minFilter!==wa&&T.minFilter!==bi||T.type===ai&&t.has("OES_texture_float_linear")===!1)return;if(T.anisotropy>1||n.get(T).__currentAnisotropy){let H=t.get("EXT_texture_filter_anisotropic");s.texParameterf(L,H.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(T.anisotropy,i.getMaxAnisotropy())),n.get(T).__currentAnisotropy=T.anisotropy}}}function re(L,T){let H=!1;L.__webglInit===void 0&&(L.__webglInit=!0,T.addEventListener("dispose",M));let j=T.source,et=d.get(j);et===void 0&&(et={},d.set(j,et));let K=F(T);if(K!==L.__cacheKey){et[K]===void 0&&(et[K]={texture:s.createTexture(),usedTimes:0},a.memory.textures++,H=!0),et[K].usedTimes++;let _t=et[L.__cacheKey];_t!==void 0&&(et[L.__cacheKey].usedTimes--,_t.usedTimes===0&&w(T)),L.__cacheKey=K,L.__webglTexture=et[K].texture}return H}function Z(L,T,H){let j=s.TEXTURE_2D;(T.isDataArrayTexture||T.isCompressedArrayTexture)&&(j=s.TEXTURE_2D_ARRAY),T.isData3DTexture&&(j=s.TEXTURE_3D);let et=re(L,T),K=T.source;e.bindTexture(j,L.__webglTexture,s.TEXTURE0+H);let _t=n.get(K);if(K.version!==_t.__version||et===!0){e.activeTexture(s.TEXTURE0+H);let ft=se.getPrimaries(se.workingColorSpace),xt=T.colorSpace===ii?null:se.getPrimaries(T.colorSpace),oe=T.colorSpace===ii||ft===xt?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,T.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,T.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,oe);let lt=x(T.image,!1,i.maxTextureSize);lt=_e(T,lt);let Mt=r.convert(T.format,T.colorSpace),Ft=r.convert(T.type),Bt=y(T.internalFormat,Mt,Ft,T.colorSpace,T.isVideoTexture);Ot(j,T);let bt,ae=T.mipmaps,Zt=T.isVideoTexture!==!0,Me=_t.__version===void 0||et===!0,N=K.dataReady,pt=S(T,lt);if(T.isDepthTexture)Bt=_(T.format===rr,T.type),Me&&(Zt?e.texStorage2D(s.TEXTURE_2D,1,Bt,lt.width,lt.height):e.texImage2D(s.TEXTURE_2D,0,Bt,lt.width,lt.height,0,Mt,Ft,null));else if(T.isDataTexture)if(ae.length>0){Zt&&Me&&e.texStorage2D(s.TEXTURE_2D,pt,Bt,ae[0].width,ae[0].height);for(let Y=0,Q=ae.length;Y<Q;Y++)bt=ae[Y],Zt?N&&e.texSubImage2D(s.TEXTURE_2D,Y,0,0,bt.width,bt.height,Mt,Ft,bt.data):e.texImage2D(s.TEXTURE_2D,Y,Bt,bt.width,bt.height,0,Mt,Ft,bt.data);T.generateMipmaps=!1}else Zt?(Me&&e.texStorage2D(s.TEXTURE_2D,pt,Bt,lt.width,lt.height),N&&e.texSubImage2D(s.TEXTURE_2D,0,0,0,lt.width,lt.height,Mt,Ft,lt.data)):e.texImage2D(s.TEXTURE_2D,0,Bt,lt.width,lt.height,0,Mt,Ft,lt.data);else if(T.isCompressedTexture)if(T.isCompressedArrayTexture){Zt&&Me&&e.texStorage3D(s.TEXTURE_2D_ARRAY,pt,Bt,ae[0].width,ae[0].height,lt.depth);for(let Y=0,Q=ae.length;Y<Q;Y++)if(bt=ae[Y],T.format!==Xn)if(Mt!==null)if(Zt){if(N)if(T.layerUpdates.size>0){let vt=Cd(bt.width,bt.height,T.format,T.type);for(let mt of T.layerUpdates){let Xt=bt.data.subarray(mt*vt/bt.data.BYTES_PER_ELEMENT,(mt+1)*vt/bt.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,Y,0,0,mt,bt.width,bt.height,1,Mt,Xt)}T.clearLayerUpdates()}else e.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,Y,0,0,0,bt.width,bt.height,lt.depth,Mt,bt.data)}else e.compressedTexImage3D(s.TEXTURE_2D_ARRAY,Y,Bt,bt.width,bt.height,lt.depth,0,bt.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Zt?N&&e.texSubImage3D(s.TEXTURE_2D_ARRAY,Y,0,0,0,bt.width,bt.height,lt.depth,Mt,Ft,bt.data):e.texImage3D(s.TEXTURE_2D_ARRAY,Y,Bt,bt.width,bt.height,lt.depth,0,Mt,Ft,bt.data)}else{Zt&&Me&&e.texStorage2D(s.TEXTURE_2D,pt,Bt,ae[0].width,ae[0].height);for(let Y=0,Q=ae.length;Y<Q;Y++)bt=ae[Y],T.format!==Xn?Mt!==null?Zt?N&&e.compressedTexSubImage2D(s.TEXTURE_2D,Y,0,0,bt.width,bt.height,Mt,bt.data):e.compressedTexImage2D(s.TEXTURE_2D,Y,Bt,bt.width,bt.height,0,bt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Zt?N&&e.texSubImage2D(s.TEXTURE_2D,Y,0,0,bt.width,bt.height,Mt,Ft,bt.data):e.texImage2D(s.TEXTURE_2D,Y,Bt,bt.width,bt.height,0,Mt,Ft,bt.data)}else if(T.isDataArrayTexture)if(Zt){if(Me&&e.texStorage3D(s.TEXTURE_2D_ARRAY,pt,Bt,lt.width,lt.height,lt.depth),N)if(T.layerUpdates.size>0){let Y=Cd(lt.width,lt.height,T.format,T.type);for(let Q of T.layerUpdates){let vt=lt.data.subarray(Q*Y/lt.data.BYTES_PER_ELEMENT,(Q+1)*Y/lt.data.BYTES_PER_ELEMENT);e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,Q,lt.width,lt.height,1,Mt,Ft,vt)}T.clearLayerUpdates()}else e.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,0,lt.width,lt.height,lt.depth,Mt,Ft,lt.data)}else e.texImage3D(s.TEXTURE_2D_ARRAY,0,Bt,lt.width,lt.height,lt.depth,0,Mt,Ft,lt.data);else if(T.isData3DTexture)Zt?(Me&&e.texStorage3D(s.TEXTURE_3D,pt,Bt,lt.width,lt.height,lt.depth),N&&e.texSubImage3D(s.TEXTURE_3D,0,0,0,0,lt.width,lt.height,lt.depth,Mt,Ft,lt.data)):e.texImage3D(s.TEXTURE_3D,0,Bt,lt.width,lt.height,lt.depth,0,Mt,Ft,lt.data);else if(T.isFramebufferTexture){if(Me)if(Zt)e.texStorage2D(s.TEXTURE_2D,pt,Bt,lt.width,lt.height);else{let Y=lt.width,Q=lt.height;for(let vt=0;vt<pt;vt++)e.texImage2D(s.TEXTURE_2D,vt,Bt,Y,Q,0,Mt,Ft,null),Y>>=1,Q>>=1}}else if(ae.length>0){if(Zt&&Me){let Y=Dt(ae[0]);e.texStorage2D(s.TEXTURE_2D,pt,Bt,Y.width,Y.height)}for(let Y=0,Q=ae.length;Y<Q;Y++)bt=ae[Y],Zt?N&&e.texSubImage2D(s.TEXTURE_2D,Y,0,0,Mt,Ft,bt):e.texImage2D(s.TEXTURE_2D,Y,Bt,Mt,Ft,bt);T.generateMipmaps=!1}else if(Zt){if(Me){let Y=Dt(lt);e.texStorage2D(s.TEXTURE_2D,pt,Bt,Y.width,Y.height)}N&&e.texSubImage2D(s.TEXTURE_2D,0,0,0,Mt,Ft,lt)}else e.texImage2D(s.TEXTURE_2D,0,Bt,Mt,Ft,lt);g(T)&&p(j),_t.__version=K.version,T.onUpdate&&T.onUpdate(T)}L.__version=T.version}function st(L,T,H){if(T.image.length!==6)return;let j=re(L,T),et=T.source;e.bindTexture(s.TEXTURE_CUBE_MAP,L.__webglTexture,s.TEXTURE0+H);let K=n.get(et);if(et.version!==K.__version||j===!0){e.activeTexture(s.TEXTURE0+H);let _t=se.getPrimaries(se.workingColorSpace),ft=T.colorSpace===ii?null:se.getPrimaries(T.colorSpace),xt=T.colorSpace===ii||_t===ft?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,T.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,T.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,xt);let oe=T.isCompressedTexture||T.image[0].isCompressedTexture,lt=T.image[0]&&T.image[0].isDataTexture,Mt=[];for(let Q=0;Q<6;Q++)!oe&&!lt?Mt[Q]=x(T.image[Q],!0,i.maxCubemapSize):Mt[Q]=lt?T.image[Q].image:T.image[Q],Mt[Q]=_e(T,Mt[Q]);let Ft=Mt[0],Bt=r.convert(T.format,T.colorSpace),bt=r.convert(T.type),ae=y(T.internalFormat,Bt,bt,T.colorSpace),Zt=T.isVideoTexture!==!0,Me=K.__version===void 0||j===!0,N=et.dataReady,pt=S(T,Ft);Ot(s.TEXTURE_CUBE_MAP,T);let Y;if(oe){Zt&&Me&&e.texStorage2D(s.TEXTURE_CUBE_MAP,pt,ae,Ft.width,Ft.height);for(let Q=0;Q<6;Q++){Y=Mt[Q].mipmaps;for(let vt=0;vt<Y.length;vt++){let mt=Y[vt];T.format!==Xn?Bt!==null?Zt?N&&e.compressedTexSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt,0,0,mt.width,mt.height,Bt,mt.data):e.compressedTexImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt,ae,mt.width,mt.height,0,mt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Zt?N&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt,0,0,mt.width,mt.height,Bt,bt,mt.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt,ae,mt.width,mt.height,0,Bt,bt,mt.data)}}}else{if(Y=T.mipmaps,Zt&&Me){Y.length>0&&pt++;let Q=Dt(Mt[0]);e.texStorage2D(s.TEXTURE_CUBE_MAP,pt,ae,Q.width,Q.height)}for(let Q=0;Q<6;Q++)if(lt){Zt?N&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,0,0,Mt[Q].width,Mt[Q].height,Bt,bt,Mt[Q].data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,ae,Mt[Q].width,Mt[Q].height,0,Bt,bt,Mt[Q].data);for(let vt=0;vt<Y.length;vt++){let Xt=Y[vt].image[Q].image;Zt?N&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt+1,0,0,Xt.width,Xt.height,Bt,bt,Xt.data):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt+1,ae,Xt.width,Xt.height,0,Bt,bt,Xt.data)}}else{Zt?N&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,0,0,Bt,bt,Mt[Q]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0,ae,Bt,bt,Mt[Q]);for(let vt=0;vt<Y.length;vt++){let mt=Y[vt];Zt?N&&e.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt+1,0,0,Bt,bt,mt.image[Q]):e.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Q,vt+1,ae,Bt,bt,mt.image[Q])}}}g(T)&&p(s.TEXTURE_CUBE_MAP),K.__version=et.version,T.onUpdate&&T.onUpdate(T)}L.__version=T.version}function Tt(L,T,H,j,et,K){let _t=r.convert(H.format,H.colorSpace),ft=r.convert(H.type),xt=y(H.internalFormat,_t,ft,H.colorSpace),oe=n.get(T),lt=n.get(H);if(lt.__renderTarget=T,!oe.__hasExternalTextures){let Mt=Math.max(1,T.width>>K),Ft=Math.max(1,T.height>>K);et===s.TEXTURE_3D||et===s.TEXTURE_2D_ARRAY?e.texImage3D(et,K,xt,Mt,Ft,T.depth,0,_t,ft,null):e.texImage2D(et,K,xt,Mt,Ft,0,_t,ft,null)}e.bindFramebuffer(s.FRAMEBUFFER,L),ie(T)?o.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,j,et,lt.__webglTexture,0,ne(T)):(et===s.TEXTURE_2D||et>=s.TEXTURE_CUBE_MAP_POSITIVE_X&&et<=s.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&s.framebufferTexture2D(s.FRAMEBUFFER,j,et,lt.__webglTexture,K),e.bindFramebuffer(s.FRAMEBUFFER,null)}function dt(L,T,H){if(s.bindRenderbuffer(s.RENDERBUFFER,L),T.depthBuffer){let j=T.depthTexture,et=j&&j.isDepthTexture?j.type:null,K=_(T.stencilBuffer,et),_t=T.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,ft=ne(T);ie(T)?o.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,ft,K,T.width,T.height):H?s.renderbufferStorageMultisample(s.RENDERBUFFER,ft,K,T.width,T.height):s.renderbufferStorage(s.RENDERBUFFER,K,T.width,T.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,_t,s.RENDERBUFFER,L)}else{let j=T.textures;for(let et=0;et<j.length;et++){let K=j[et],_t=r.convert(K.format,K.colorSpace),ft=r.convert(K.type),xt=y(K.internalFormat,_t,ft,K.colorSpace),oe=ne(T);H&&ie(T)===!1?s.renderbufferStorageMultisample(s.RENDERBUFFER,oe,xt,T.width,T.height):ie(T)?o.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,oe,xt,T.width,T.height):s.renderbufferStorage(s.RENDERBUFFER,xt,T.width,T.height)}}s.bindRenderbuffer(s.RENDERBUFFER,null)}function yt(L,T){if(T&&T.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(s.FRAMEBUFFER,L),!(T.depthTexture&&T.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");let j=n.get(T.depthTexture);j.__renderTarget=T,(!j.__webglTexture||T.depthTexture.image.width!==T.width||T.depthTexture.image.height!==T.height)&&(T.depthTexture.image.width=T.width,T.depthTexture.image.height=T.height,T.depthTexture.needsUpdate=!0),q(T.depthTexture,0);let et=j.__webglTexture,K=ne(T);if(T.depthTexture.format===js)ie(T)?o.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,et,0,K):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,et,0);else if(T.depthTexture.format===rr)ie(T)?o.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,et,0,K):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,et,0);else throw new Error("Unknown depthTexture format")}function Nt(L){let T=n.get(L),H=L.isWebGLCubeRenderTarget===!0;if(T.__boundDepthTexture!==L.depthTexture){let j=L.depthTexture;if(T.__depthDisposeCallback&&T.__depthDisposeCallback(),j){let et=()=>{delete T.__boundDepthTexture,delete T.__depthDisposeCallback,j.removeEventListener("dispose",et)};j.addEventListener("dispose",et),T.__depthDisposeCallback=et}T.__boundDepthTexture=j}if(L.depthTexture&&!T.__autoAllocateDepthBuffer){if(H)throw new Error("target.depthTexture not supported in Cube render targets");yt(T.__webglFramebuffer,L)}else if(H){T.__webglDepthbuffer=[];for(let j=0;j<6;j++)if(e.bindFramebuffer(s.FRAMEBUFFER,T.__webglFramebuffer[j]),T.__webglDepthbuffer[j]===void 0)T.__webglDepthbuffer[j]=s.createRenderbuffer(),dt(T.__webglDepthbuffer[j],L,!1);else{let et=L.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,K=T.__webglDepthbuffer[j];s.bindRenderbuffer(s.RENDERBUFFER,K),s.framebufferRenderbuffer(s.FRAMEBUFFER,et,s.RENDERBUFFER,K)}}else if(e.bindFramebuffer(s.FRAMEBUFFER,T.__webglFramebuffer),T.__webglDepthbuffer===void 0)T.__webglDepthbuffer=s.createRenderbuffer(),dt(T.__webglDepthbuffer,L,!1);else{let j=L.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,et=T.__webglDepthbuffer;s.bindRenderbuffer(s.RENDERBUFFER,et),s.framebufferRenderbuffer(s.FRAMEBUFFER,j,s.RENDERBUFFER,et)}e.bindFramebuffer(s.FRAMEBUFFER,null)}function Jt(L,T,H){let j=n.get(L);T!==void 0&&Tt(j.__webglFramebuffer,L,L.texture,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,0),H!==void 0&&Nt(L)}function me(L){let T=L.texture,H=n.get(L),j=n.get(T);L.addEventListener("dispose",E);let et=L.textures,K=L.isWebGLCubeRenderTarget===!0,_t=et.length>1;if(_t||(j.__webglTexture===void 0&&(j.__webglTexture=s.createTexture()),j.__version=T.version,a.memory.textures++),K){H.__webglFramebuffer=[];for(let ft=0;ft<6;ft++)if(T.mipmaps&&T.mipmaps.length>0){H.__webglFramebuffer[ft]=[];for(let xt=0;xt<T.mipmaps.length;xt++)H.__webglFramebuffer[ft][xt]=s.createFramebuffer()}else H.__webglFramebuffer[ft]=s.createFramebuffer()}else{if(T.mipmaps&&T.mipmaps.length>0){H.__webglFramebuffer=[];for(let ft=0;ft<T.mipmaps.length;ft++)H.__webglFramebuffer[ft]=s.createFramebuffer()}else H.__webglFramebuffer=s.createFramebuffer();if(_t)for(let ft=0,xt=et.length;ft<xt;ft++){let oe=n.get(et[ft]);oe.__webglTexture===void 0&&(oe.__webglTexture=s.createTexture(),a.memory.textures++)}if(L.samples>0&&ie(L)===!1){H.__webglMultisampledFramebuffer=s.createFramebuffer(),H.__webglColorRenderbuffer=[],e.bindFramebuffer(s.FRAMEBUFFER,H.__webglMultisampledFramebuffer);for(let ft=0;ft<et.length;ft++){let xt=et[ft];H.__webglColorRenderbuffer[ft]=s.createRenderbuffer(),s.bindRenderbuffer(s.RENDERBUFFER,H.__webglColorRenderbuffer[ft]);let oe=r.convert(xt.format,xt.colorSpace),lt=r.convert(xt.type),Mt=y(xt.internalFormat,oe,lt,xt.colorSpace,L.isXRRenderTarget===!0),Ft=ne(L);s.renderbufferStorageMultisample(s.RENDERBUFFER,Ft,Mt,L.width,L.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+ft,s.RENDERBUFFER,H.__webglColorRenderbuffer[ft])}s.bindRenderbuffer(s.RENDERBUFFER,null),L.depthBuffer&&(H.__webglDepthRenderbuffer=s.createRenderbuffer(),dt(H.__webglDepthRenderbuffer,L,!0)),e.bindFramebuffer(s.FRAMEBUFFER,null)}}if(K){e.bindTexture(s.TEXTURE_CUBE_MAP,j.__webglTexture),Ot(s.TEXTURE_CUBE_MAP,T);for(let ft=0;ft<6;ft++)if(T.mipmaps&&T.mipmaps.length>0)for(let xt=0;xt<T.mipmaps.length;xt++)Tt(H.__webglFramebuffer[ft][xt],L,T,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+ft,xt);else Tt(H.__webglFramebuffer[ft],L,T,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+ft,0);g(T)&&p(s.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(_t){for(let ft=0,xt=et.length;ft<xt;ft++){let oe=et[ft],lt=n.get(oe);e.bindTexture(s.TEXTURE_2D,lt.__webglTexture),Ot(s.TEXTURE_2D,oe),Tt(H.__webglFramebuffer,L,oe,s.COLOR_ATTACHMENT0+ft,s.TEXTURE_2D,0),g(oe)&&p(s.TEXTURE_2D)}e.unbindTexture()}else{let ft=s.TEXTURE_2D;if((L.isWebGL3DRenderTarget||L.isWebGLArrayRenderTarget)&&(ft=L.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),e.bindTexture(ft,j.__webglTexture),Ot(ft,T),T.mipmaps&&T.mipmaps.length>0)for(let xt=0;xt<T.mipmaps.length;xt++)Tt(H.__webglFramebuffer[xt],L,T,s.COLOR_ATTACHMENT0,ft,xt);else Tt(H.__webglFramebuffer,L,T,s.COLOR_ATTACHMENT0,ft,0);g(T)&&p(ft),e.unbindTexture()}L.depthBuffer&&Nt(L)}function ee(L){let T=L.textures;for(let H=0,j=T.length;H<j;H++){let et=T[H];if(g(et)){let K=v(L),_t=n.get(et).__webglTexture;e.bindTexture(K,_t),p(K),e.unbindTexture()}}}let Ae=[],B=[];function Je(L){if(L.samples>0){if(ie(L)===!1){let T=L.textures,H=L.width,j=L.height,et=s.COLOR_BUFFER_BIT,K=L.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,_t=n.get(L),ft=T.length>1;if(ft)for(let xt=0;xt<T.length;xt++)e.bindFramebuffer(s.FRAMEBUFFER,_t.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+xt,s.RENDERBUFFER,null),e.bindFramebuffer(s.FRAMEBUFFER,_t.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+xt,s.TEXTURE_2D,null,0);e.bindFramebuffer(s.READ_FRAMEBUFFER,_t.__webglMultisampledFramebuffer),e.bindFramebuffer(s.DRAW_FRAMEBUFFER,_t.__webglFramebuffer);for(let xt=0;xt<T.length;xt++){if(L.resolveDepthBuffer&&(L.depthBuffer&&(et|=s.DEPTH_BUFFER_BIT),L.stencilBuffer&&L.resolveStencilBuffer&&(et|=s.STENCIL_BUFFER_BIT)),ft){s.framebufferRenderbuffer(s.READ_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.RENDERBUFFER,_t.__webglColorRenderbuffer[xt]);let oe=n.get(T[xt]).__webglTexture;s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,oe,0)}s.blitFramebuffer(0,0,H,j,0,0,H,j,et,s.NEAREST),l===!0&&(Ae.length=0,B.length=0,Ae.push(s.COLOR_ATTACHMENT0+xt),L.depthBuffer&&L.resolveDepthBuffer===!1&&(Ae.push(K),B.push(K),s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,B)),s.invalidateFramebuffer(s.READ_FRAMEBUFFER,Ae))}if(e.bindFramebuffer(s.READ_FRAMEBUFFER,null),e.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),ft)for(let xt=0;xt<T.length;xt++){e.bindFramebuffer(s.FRAMEBUFFER,_t.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+xt,s.RENDERBUFFER,_t.__webglColorRenderbuffer[xt]);let oe=n.get(T[xt]).__webglTexture;e.bindFramebuffer(s.FRAMEBUFFER,_t.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+xt,s.TEXTURE_2D,oe,0)}e.bindFramebuffer(s.DRAW_FRAMEBUFFER,_t.__webglMultisampledFramebuffer)}else if(L.depthBuffer&&L.resolveDepthBuffer===!1&&l){let T=L.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,[T])}}}function ne(L){return Math.min(i.maxSamples,L.samples)}function ie(L){let T=n.get(L);return L.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&T.__useRenderToTexture!==!1}function Ut(L){let T=a.render.frame;h.get(L)!==T&&(h.set(L,T),L.update())}function _e(L,T){let H=L.colorSpace,j=L.format,et=L.type;return L.isCompressedTexture===!0||L.isVideoTexture===!0||H!==Ji&&H!==ii&&(se.getTransfer(H)===pe?(j!==Xn||et!==Ei)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",H)),T}function Dt(L){return typeof HTMLImageElement<"u"&&L instanceof HTMLImageElement?(c.width=L.naturalWidth||L.width,c.height=L.naturalHeight||L.height):typeof VideoFrame<"u"&&L instanceof VideoFrame?(c.width=L.displayWidth,c.height=L.displayHeight):(c.width=L.width,c.height=L.height),c}this.allocateTextureUnit=U,this.resetTextureUnits=D,this.setTexture2D=q,this.setTexture2DArray=V,this.setTexture3D=J,this.setTextureCube=G,this.rebindTextures=Jt,this.setupRenderTarget=me,this.updateRenderTargetMipmap=ee,this.updateMultisampleRenderTarget=Je,this.setupDepthRenderbuffer=Nt,this.setupFrameBufferTexture=Tt,this.useMultisampledRTT=ie}function qx(s,t){function e(n,i=ii){let r,a=se.getTransfer(i);if(n===Ei)return s.UNSIGNED_BYTE;if(n===Hh)return s.UNSIGNED_SHORT_4_4_4_4;if(n===Vh)return s.UNSIGNED_SHORT_5_5_5_1;if(n===Kd)return s.UNSIGNED_INT_5_9_9_9_REV;if(n===$d)return s.BYTE;if(n===Zd)return s.SHORT;if(n===qr)return s.UNSIGNED_SHORT;if(n===zh)return s.INT;if(n===xs)return s.UNSIGNED_INT;if(n===ai)return s.FLOAT;if(n===ln)return s.HALF_FLOAT;if(n===Jd)return s.ALPHA;if(n===jd)return s.RGB;if(n===Xn)return s.RGBA;if(n===Qd)return s.LUMINANCE;if(n===tf)return s.LUMINANCE_ALPHA;if(n===js)return s.DEPTH_COMPONENT;if(n===rr)return s.DEPTH_STENCIL;if(n===Gh)return s.RED;if(n===Wh)return s.RED_INTEGER;if(n===ef)return s.RG;if(n===Xh)return s.RG_INTEGER;if(n===qh)return s.RGBA_INTEGER;if(n===to||n===eo||n===no||n===io)if(a===pe)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===to)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===eo)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===no)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===io)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===to)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===eo)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===no)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===io)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===_c||n===Mc||n===bc||n===wc)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===_c)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Mc)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===bc)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===wc)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===Sc||n===Ec||n===Tc)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(n===Sc||n===Ec)return a===pe?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===Tc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===Ac||n===Rc||n===Cc||n===Pc||n===Ic||n===Lc||n===Dc||n===kc||n===Uc||n===Nc||n===Fc||n===Oc||n===Bc||n===zc)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(n===Ac)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Rc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Cc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Pc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Ic)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Lc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Dc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===kc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Uc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Nc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Fc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Oc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Bc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===zc)return a===pe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===so||n===Hc||n===Vc)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(n===so)return a===pe?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===Hc)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Vc)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===nf||n===Gc||n===Wc||n===Xc)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(n===so)return r.COMPRESSED_RED_RGTC1_EXT;if(n===Gc)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Wc)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Xc)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===sr?s.UNSIGNED_INT_24_8:s[n]!==void 0?s[n]:null}return{convert:e}}var oh=class extends Ue{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}},Qt=class extends Le{constructor(){super(),this.isGroup=!0,this.type="Group"}},Yx={type:"move"},Gr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Qt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Qt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new C,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new C),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Qt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new C,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new C),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let i=null,r=null,a=null,o=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){a=!0;for(let x of t.hand.values()){let g=e.getJointPose(x,n),p=this._getHandJoint(c,x);g!==null&&(p.matrix.fromArray(g.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=g.radius),p.visible=g!==null}let h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),f=.02,m=.005;c.inputState.pinching&&d>f+m?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&d<=f-m&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));o!==null&&(i=e.getPose(t.targetRaySpace,n),i===null&&r!==null&&(i=r),i!==null&&(o.matrix.fromArray(i.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,i.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(i.linearVelocity)):o.hasLinearVelocity=!1,i.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(i.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Yx)))}return o!==null&&(o.visible=i!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let n=new Qt;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}},$x=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Zx=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,lh=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e,n){if(this.texture===null){let i=new fn,r=t.properties.get(i);r.__webglTexture=e.texture,(e.depthNear!=n.depthNear||e.depthFar!=n.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=i}}getMesh(t){if(this.texture!==null&&this.mesh===null){let e=t.cameras[0].viewport,n=new ve({vertexShader:$x,fragmentShader:Zx,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new it(new we(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},ch=class extends Xi{constructor(t,e){super();let n=this,i=null,r=1,a=null,o="local-floor",l=1,c=null,h=null,u=null,d=null,f=null,m=null,x=new lh,g=e.getContextAttributes(),p=null,v=null,y=[],_=[],S=new tt,M=null,E=new Ue;E.viewport=new ue;let A=new Ue;A.viewport=new ue;let w=[E,A],b=new oh,P=null,D=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Z){let st=y[Z];return st===void 0&&(st=new Gr,y[Z]=st),st.getTargetRaySpace()},this.getControllerGrip=function(Z){let st=y[Z];return st===void 0&&(st=new Gr,y[Z]=st),st.getGripSpace()},this.getHand=function(Z){let st=y[Z];return st===void 0&&(st=new Gr,y[Z]=st),st.getHandSpace()};function U(Z){let st=_.indexOf(Z.inputSource);if(st===-1)return;let Tt=y[st];Tt!==void 0&&(Tt.update(Z.inputSource,Z.frame,c||a),Tt.dispatchEvent({type:Z.type,data:Z.inputSource}))}function F(){i.removeEventListener("select",U),i.removeEventListener("selectstart",U),i.removeEventListener("selectend",U),i.removeEventListener("squeeze",U),i.removeEventListener("squeezestart",U),i.removeEventListener("squeezeend",U),i.removeEventListener("end",F),i.removeEventListener("inputsourceschange",q);for(let Z=0;Z<y.length;Z++){let st=_[Z];st!==null&&(_[Z]=null,y[Z].disconnect(st))}P=null,D=null,x.reset(),t.setRenderTarget(p),f=null,d=null,u=null,i=null,v=null,re.stop(),n.isPresenting=!1,t.setPixelRatio(M),t.setSize(S.width,S.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Z){r=Z,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Z){o=Z,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(Z){c=Z},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return u},this.getFrame=function(){return m},this.getSession=function(){return i},this.setSession=async function(Z){if(i=Z,i!==null){if(p=t.getRenderTarget(),i.addEventListener("select",U),i.addEventListener("selectstart",U),i.addEventListener("selectend",U),i.addEventListener("squeeze",U),i.addEventListener("squeezestart",U),i.addEventListener("squeezeend",U),i.addEventListener("end",F),i.addEventListener("inputsourceschange",q),g.xrCompatible!==!0&&await e.makeXRCompatible(),M=t.getPixelRatio(),t.getSize(S),i.renderState.layers===void 0){let st={antialias:g.antialias,alpha:!0,depth:g.depth,stencil:g.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(i,e,st),i.updateRenderState({baseLayer:f}),t.setPixelRatio(1),t.setSize(f.framebufferWidth,f.framebufferHeight,!1),v=new Ne(f.framebufferWidth,f.framebufferHeight,{format:Xn,type:Ei,colorSpace:t.outputColorSpace,stencilBuffer:g.stencil})}else{let st=null,Tt=null,dt=null;g.depth&&(dt=g.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,st=g.stencil?rr:js,Tt=g.stencil?sr:xs);let yt={colorFormat:e.RGBA8,depthFormat:dt,scaleFactor:r};u=new XRWebGLBinding(i,e),d=u.createProjectionLayer(yt),i.updateRenderState({layers:[d]}),t.setPixelRatio(1),t.setSize(d.textureWidth,d.textureHeight,!1),v=new Ne(d.textureWidth,d.textureHeight,{format:Xn,type:Ei,depthTexture:new xo(d.textureWidth,d.textureHeight,Tt,void 0,void 0,void 0,void 0,void 0,void 0,st),stencilBuffer:g.stencil,colorSpace:t.outputColorSpace,samples:g.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1})}v.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await i.requestReferenceSpace(o),re.setContext(i),re.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode},this.getDepthTexture=function(){return x.getDepthTexture()};function q(Z){for(let st=0;st<Z.removed.length;st++){let Tt=Z.removed[st],dt=_.indexOf(Tt);dt>=0&&(_[dt]=null,y[dt].disconnect(Tt))}for(let st=0;st<Z.added.length;st++){let Tt=Z.added[st],dt=_.indexOf(Tt);if(dt===-1){for(let Nt=0;Nt<y.length;Nt++)if(Nt>=_.length){_.push(Tt),dt=Nt;break}else if(_[Nt]===null){_[Nt]=Tt,dt=Nt;break}if(dt===-1)break}let yt=y[dt];yt&&yt.connect(Tt)}}let V=new C,J=new C;function G(Z,st,Tt){V.setFromMatrixPosition(st.matrixWorld),J.setFromMatrixPosition(Tt.matrixWorld);let dt=V.distanceTo(J),yt=st.projectionMatrix.elements,Nt=Tt.projectionMatrix.elements,Jt=yt[14]/(yt[10]-1),me=yt[14]/(yt[10]+1),ee=(yt[9]+1)/yt[5],Ae=(yt[9]-1)/yt[5],B=(yt[8]-1)/yt[0],Je=(Nt[8]+1)/Nt[0],ne=Jt*B,ie=Jt*Je,Ut=dt/(-B+Je),_e=Ut*-B;if(st.matrixWorld.decompose(Z.position,Z.quaternion,Z.scale),Z.translateX(_e),Z.translateZ(Ut),Z.matrixWorld.compose(Z.position,Z.quaternion,Z.scale),Z.matrixWorldInverse.copy(Z.matrixWorld).invert(),yt[10]===-1)Z.projectionMatrix.copy(st.projectionMatrix),Z.projectionMatrixInverse.copy(st.projectionMatrixInverse);else{let Dt=Jt+Ut,L=me+Ut,T=ne-_e,H=ie+(dt-_e),j=ee*me/L*Dt,et=Ae*me/L*Dt;Z.projectionMatrix.makePerspective(T,H,j,et,Dt,L),Z.projectionMatrixInverse.copy(Z.projectionMatrix).invert()}}function nt(Z,st){st===null?Z.matrixWorld.copy(Z.matrix):Z.matrixWorld.multiplyMatrices(st.matrixWorld,Z.matrix),Z.matrixWorldInverse.copy(Z.matrixWorld).invert()}this.updateCamera=function(Z){if(i===null)return;let st=Z.near,Tt=Z.far;x.texture!==null&&(x.depthNear>0&&(st=x.depthNear),x.depthFar>0&&(Tt=x.depthFar)),b.near=A.near=E.near=st,b.far=A.far=E.far=Tt,(P!==b.near||D!==b.far)&&(i.updateRenderState({depthNear:b.near,depthFar:b.far}),P=b.near,D=b.far),E.layers.mask=Z.layers.mask|2,A.layers.mask=Z.layers.mask|4,b.layers.mask=E.layers.mask|A.layers.mask;let dt=Z.parent,yt=b.cameras;nt(b,dt);for(let Nt=0;Nt<yt.length;Nt++)nt(yt[Nt],dt);yt.length===2?G(b,E,A):b.projectionMatrix.copy(E.projectionMatrix),ht(Z,b,dt)};function ht(Z,st,Tt){Tt===null?Z.matrix.copy(st.matrixWorld):(Z.matrix.copy(Tt.matrixWorld),Z.matrix.invert(),Z.matrix.multiply(st.matrixWorld)),Z.matrix.decompose(Z.position,Z.quaternion,Z.scale),Z.updateMatrixWorld(!0),Z.projectionMatrix.copy(st.projectionMatrix),Z.projectionMatrixInverse.copy(st.projectionMatrixInverse),Z.isPerspectiveCamera&&(Z.fov=oo*2*Math.atan(1/Z.projectionMatrix.elements[5]),Z.zoom=1)}this.getCamera=function(){return b},this.getFoveation=function(){if(!(d===null&&f===null))return l},this.setFoveation=function(Z){l=Z,d!==null&&(d.fixedFoveation=Z),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=Z)},this.hasDepthSensing=function(){return x.texture!==null},this.getDepthSensingMesh=function(){return x.getMesh(b)};let Et=null;function Ot(Z,st){if(h=st.getViewerPose(c||a),m=st,h!==null){let Tt=h.views;f!==null&&(t.setRenderTargetFramebuffer(v,f.framebuffer),t.setRenderTarget(v));let dt=!1;Tt.length!==b.cameras.length&&(b.cameras.length=0,dt=!0);for(let Nt=0;Nt<Tt.length;Nt++){let Jt=Tt[Nt],me=null;if(f!==null)me=f.getViewport(Jt);else{let Ae=u.getViewSubImage(d,Jt);me=Ae.viewport,Nt===0&&(t.setRenderTargetTextures(v,Ae.colorTexture,d.ignoreDepthValues?void 0:Ae.depthStencilTexture),t.setRenderTarget(v))}let ee=w[Nt];ee===void 0&&(ee=new Ue,ee.layers.enable(Nt),ee.viewport=new ue,w[Nt]=ee),ee.matrix.fromArray(Jt.transform.matrix),ee.matrix.decompose(ee.position,ee.quaternion,ee.scale),ee.projectionMatrix.fromArray(Jt.projectionMatrix),ee.projectionMatrixInverse.copy(ee.projectionMatrix).invert(),ee.viewport.set(me.x,me.y,me.width,me.height),Nt===0&&(b.matrix.copy(ee.matrix),b.matrix.decompose(b.position,b.quaternion,b.scale)),dt===!0&&b.cameras.push(ee)}let yt=i.enabledFeatures;if(yt&&yt.includes("depth-sensing")){let Nt=u.getDepthInformation(Tt[0]);Nt&&Nt.isValid&&Nt.texture&&x.init(t,Nt,i.renderState)}}for(let Tt=0;Tt<y.length;Tt++){let dt=_[Tt],yt=y[Tt];dt!==null&&yt!==void 0&&yt.update(dt,st,c||a)}Et&&Et(Z,st),st.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:st}),m=null}let re=new cf;re.setAnimationLoop(Ot),this.setAnimationLoop=function(Z){Et=Z},this.dispose=function(){}}},hs=new nn,Kx=new Lt;function Jx(s,t){function e(g,p){g.matrixAutoUpdate===!0&&g.updateMatrix(),p.value.copy(g.matrix)}function n(g,p){p.color.getRGB(g.fogColor.value,lf(s)),p.isFog?(g.fogNear.value=p.near,g.fogFar.value=p.far):p.isFogExp2&&(g.fogDensity.value=p.density)}function i(g,p,v,y,_){p.isMeshBasicMaterial||p.isMeshLambertMaterial?r(g,p):p.isMeshToonMaterial?(r(g,p),u(g,p)):p.isMeshPhongMaterial?(r(g,p),h(g,p)):p.isMeshStandardMaterial?(r(g,p),d(g,p),p.isMeshPhysicalMaterial&&f(g,p,_)):p.isMeshMatcapMaterial?(r(g,p),m(g,p)):p.isMeshDepthMaterial?r(g,p):p.isMeshDistanceMaterial?(r(g,p),x(g,p)):p.isMeshNormalMaterial?r(g,p):p.isLineBasicMaterial?(a(g,p),p.isLineDashedMaterial&&o(g,p)):p.isPointsMaterial?l(g,p,v,y):p.isSpriteMaterial?c(g,p):p.isShadowMaterial?(g.color.value.copy(p.color),g.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function r(g,p){g.opacity.value=p.opacity,p.color&&g.diffuse.value.copy(p.color),p.emissive&&g.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(g.map.value=p.map,e(p.map,g.mapTransform)),p.alphaMap&&(g.alphaMap.value=p.alphaMap,e(p.alphaMap,g.alphaMapTransform)),p.bumpMap&&(g.bumpMap.value=p.bumpMap,e(p.bumpMap,g.bumpMapTransform),g.bumpScale.value=p.bumpScale,p.side===Ce&&(g.bumpScale.value*=-1)),p.normalMap&&(g.normalMap.value=p.normalMap,e(p.normalMap,g.normalMapTransform),g.normalScale.value.copy(p.normalScale),p.side===Ce&&g.normalScale.value.negate()),p.displacementMap&&(g.displacementMap.value=p.displacementMap,e(p.displacementMap,g.displacementMapTransform),g.displacementScale.value=p.displacementScale,g.displacementBias.value=p.displacementBias),p.emissiveMap&&(g.emissiveMap.value=p.emissiveMap,e(p.emissiveMap,g.emissiveMapTransform)),p.specularMap&&(g.specularMap.value=p.specularMap,e(p.specularMap,g.specularMapTransform)),p.alphaTest>0&&(g.alphaTest.value=p.alphaTest);let v=t.get(p),y=v.envMap,_=v.envMapRotation;y&&(g.envMap.value=y,hs.copy(_),hs.x*=-1,hs.y*=-1,hs.z*=-1,y.isCubeTexture&&y.isRenderTargetTexture===!1&&(hs.y*=-1,hs.z*=-1),g.envMapRotation.value.setFromMatrix4(Kx.makeRotationFromEuler(hs)),g.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,g.reflectivity.value=p.reflectivity,g.ior.value=p.ior,g.refractionRatio.value=p.refractionRatio),p.lightMap&&(g.lightMap.value=p.lightMap,g.lightMapIntensity.value=p.lightMapIntensity,e(p.lightMap,g.lightMapTransform)),p.aoMap&&(g.aoMap.value=p.aoMap,g.aoMapIntensity.value=p.aoMapIntensity,e(p.aoMap,g.aoMapTransform))}function a(g,p){g.diffuse.value.copy(p.color),g.opacity.value=p.opacity,p.map&&(g.map.value=p.map,e(p.map,g.mapTransform))}function o(g,p){g.dashSize.value=p.dashSize,g.totalSize.value=p.dashSize+p.gapSize,g.scale.value=p.scale}function l(g,p,v,y){g.diffuse.value.copy(p.color),g.opacity.value=p.opacity,g.size.value=p.size*v,g.scale.value=y*.5,p.map&&(g.map.value=p.map,e(p.map,g.uvTransform)),p.alphaMap&&(g.alphaMap.value=p.alphaMap,e(p.alphaMap,g.alphaMapTransform)),p.alphaTest>0&&(g.alphaTest.value=p.alphaTest)}function c(g,p){g.diffuse.value.copy(p.color),g.opacity.value=p.opacity,g.rotation.value=p.rotation,p.map&&(g.map.value=p.map,e(p.map,g.mapTransform)),p.alphaMap&&(g.alphaMap.value=p.alphaMap,e(p.alphaMap,g.alphaMapTransform)),p.alphaTest>0&&(g.alphaTest.value=p.alphaTest)}function h(g,p){g.specular.value.copy(p.specular),g.shininess.value=Math.max(p.shininess,1e-4)}function u(g,p){p.gradientMap&&(g.gradientMap.value=p.gradientMap)}function d(g,p){g.metalness.value=p.metalness,p.metalnessMap&&(g.metalnessMap.value=p.metalnessMap,e(p.metalnessMap,g.metalnessMapTransform)),g.roughness.value=p.roughness,p.roughnessMap&&(g.roughnessMap.value=p.roughnessMap,e(p.roughnessMap,g.roughnessMapTransform)),p.envMap&&(g.envMapIntensity.value=p.envMapIntensity)}function f(g,p,v){g.ior.value=p.ior,p.sheen>0&&(g.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),g.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(g.sheenColorMap.value=p.sheenColorMap,e(p.sheenColorMap,g.sheenColorMapTransform)),p.sheenRoughnessMap&&(g.sheenRoughnessMap.value=p.sheenRoughnessMap,e(p.sheenRoughnessMap,g.sheenRoughnessMapTransform))),p.clearcoat>0&&(g.clearcoat.value=p.clearcoat,g.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(g.clearcoatMap.value=p.clearcoatMap,e(p.clearcoatMap,g.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(g.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,e(p.clearcoatRoughnessMap,g.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(g.clearcoatNormalMap.value=p.clearcoatNormalMap,e(p.clearcoatNormalMap,g.clearcoatNormalMapTransform),g.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===Ce&&g.clearcoatNormalScale.value.negate())),p.dispersion>0&&(g.dispersion.value=p.dispersion),p.iridescence>0&&(g.iridescence.value=p.iridescence,g.iridescenceIOR.value=p.iridescenceIOR,g.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],g.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(g.iridescenceMap.value=p.iridescenceMap,e(p.iridescenceMap,g.iridescenceMapTransform)),p.iridescenceThicknessMap&&(g.iridescenceThicknessMap.value=p.iridescenceThicknessMap,e(p.iridescenceThicknessMap,g.iridescenceThicknessMapTransform))),p.transmission>0&&(g.transmission.value=p.transmission,g.transmissionSamplerMap.value=v.texture,g.transmissionSamplerSize.value.set(v.width,v.height),p.transmissionMap&&(g.transmissionMap.value=p.transmissionMap,e(p.transmissionMap,g.transmissionMapTransform)),g.thickness.value=p.thickness,p.thicknessMap&&(g.thicknessMap.value=p.thicknessMap,e(p.thicknessMap,g.thicknessMapTransform)),g.attenuationDistance.value=p.attenuationDistance,g.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(g.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(g.anisotropyMap.value=p.anisotropyMap,e(p.anisotropyMap,g.anisotropyMapTransform))),g.specularIntensity.value=p.specularIntensity,g.specularColor.value.copy(p.specularColor),p.specularColorMap&&(g.specularColorMap.value=p.specularColorMap,e(p.specularColorMap,g.specularColorMapTransform)),p.specularIntensityMap&&(g.specularIntensityMap.value=p.specularIntensityMap,e(p.specularIntensityMap,g.specularIntensityMapTransform))}function m(g,p){p.matcap&&(g.matcap.value=p.matcap)}function x(g,p){let v=t.get(p).light;g.referencePosition.value.setFromMatrixPosition(v.matrixWorld),g.nearDistance.value=v.shadow.camera.near,g.farDistance.value=v.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:i}}function jx(s,t,e,n){let i={},r={},a=[],o=s.getParameter(s.MAX_UNIFORM_BUFFER_BINDINGS);function l(v,y){let _=y.program;n.uniformBlockBinding(v,_)}function c(v,y){let _=i[v.id];_===void 0&&(m(v),_=h(v),i[v.id]=_,v.addEventListener("dispose",g));let S=y.program;n.updateUBOMapping(v,S);let M=t.render.frame;r[v.id]!==M&&(d(v),r[v.id]=M)}function h(v){let y=u();v.__bindingPointIndex=y;let _=s.createBuffer(),S=v.__size,M=v.usage;return s.bindBuffer(s.UNIFORM_BUFFER,_),s.bufferData(s.UNIFORM_BUFFER,S,M),s.bindBuffer(s.UNIFORM_BUFFER,null),s.bindBufferBase(s.UNIFORM_BUFFER,y,_),_}function u(){for(let v=0;v<o;v++)if(a.indexOf(v)===-1)return a.push(v),v;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(v){let y=i[v.id],_=v.uniforms,S=v.__cache;s.bindBuffer(s.UNIFORM_BUFFER,y);for(let M=0,E=_.length;M<E;M++){let A=Array.isArray(_[M])?_[M]:[_[M]];for(let w=0,b=A.length;w<b;w++){let P=A[w];if(f(P,M,w,S)===!0){let D=P.__offset,U=Array.isArray(P.value)?P.value:[P.value],F=0;for(let q=0;q<U.length;q++){let V=U[q],J=x(V);typeof V=="number"||typeof V=="boolean"?(P.__data[0]=V,s.bufferSubData(s.UNIFORM_BUFFER,D+F,P.__data)):V.isMatrix3?(P.__data[0]=V.elements[0],P.__data[1]=V.elements[1],P.__data[2]=V.elements[2],P.__data[3]=0,P.__data[4]=V.elements[3],P.__data[5]=V.elements[4],P.__data[6]=V.elements[5],P.__data[7]=0,P.__data[8]=V.elements[6],P.__data[9]=V.elements[7],P.__data[10]=V.elements[8],P.__data[11]=0):(V.toArray(P.__data,F),F+=J.storage/Float32Array.BYTES_PER_ELEMENT)}s.bufferSubData(s.UNIFORM_BUFFER,D,P.__data)}}}s.bindBuffer(s.UNIFORM_BUFFER,null)}function f(v,y,_,S){let M=v.value,E=y+"_"+_;if(S[E]===void 0)return typeof M=="number"||typeof M=="boolean"?S[E]=M:S[E]=M.clone(),!0;{let A=S[E];if(typeof M=="number"||typeof M=="boolean"){if(A!==M)return S[E]=M,!0}else if(A.equals(M)===!1)return A.copy(M),!0}return!1}function m(v){let y=v.uniforms,_=0,S=16;for(let E=0,A=y.length;E<A;E++){let w=Array.isArray(y[E])?y[E]:[y[E]];for(let b=0,P=w.length;b<P;b++){let D=w[b],U=Array.isArray(D.value)?D.value:[D.value];for(let F=0,q=U.length;F<q;F++){let V=U[F],J=x(V),G=_%S,nt=G%J.boundary,ht=G+nt;_+=nt,ht!==0&&S-ht<J.storage&&(_+=S-ht),D.__data=new Float32Array(J.storage/Float32Array.BYTES_PER_ELEMENT),D.__offset=_,_+=J.storage}}}let M=_%S;return M>0&&(_+=S-M),v.__size=_,v.__cache={},this}function x(v){let y={boundary:0,storage:0};return typeof v=="number"||typeof v=="boolean"?(y.boundary=4,y.storage=4):v.isVector2?(y.boundary=8,y.storage=8):v.isVector3||v.isColor?(y.boundary=16,y.storage=12):v.isVector4?(y.boundary=16,y.storage=16):v.isMatrix3?(y.boundary=48,y.storage=48):v.isMatrix4?(y.boundary=64,y.storage=64):v.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",v),y}function g(v){let y=v.target;y.removeEventListener("dispose",g);let _=a.indexOf(y.__bindingPointIndex);a.splice(_,1),s.deleteBuffer(i[y.id]),delete i[y.id],delete r[y.id]}function p(){for(let v in i)s.deleteBuffer(i[v]);a=[],i={},r={}}return{bind:l,update:c,dispose:p}}var vo=class{constructor(t={}){let{canvas:e=ip(),context:n=null,depth:i=!0,stencil:r=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reverseDepthBuffer:d=!1}=t;this.isWebGLRenderer=!0;let f;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");f=n.getContextAttributes().alpha}else f=a;let m=new Uint32Array(4),x=new Int32Array(4),g=null,p=null,v=[],y=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=qe,this.toneMapping=Vi,this.toneMappingExposure=1;let _=this,S=!1,M=0,E=0,A=null,w=-1,b=null,P=new ue,D=new ue,U=null,F=new ot(0),q=0,V=e.width,J=e.height,G=1,nt=null,ht=null,Et=new ue(0,0,V,J),Ot=new ue(0,0,V,J),re=!1,Z=new $r,st=!1,Tt=!1,dt=new Lt,yt=new Lt,Nt=new C,Jt=new ue,me={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},ee=!1;function Ae(){return A===null?G:1}let B=n;function Je(R,O){return e.getContext(R,O)}try{let R={alpha:!0,depth:i,stencil:r,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${Dh}`),e.addEventListener("webglcontextlost",Q,!1),e.addEventListener("webglcontextrestored",vt,!1),e.addEventListener("webglcontextcreationerror",mt,!1),B===null){let O="webgl2";if(B=Je(O,R),B===null)throw Je(O)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(R){throw console.error("THREE.WebGLRenderer: "+R.message),R}let ne,ie,Ut,_e,Dt,L,T,H,j,et,K,_t,ft,xt,oe,lt,Mt,Ft,Bt,bt,ae,Zt,Me,N;function pt(){ne=new p1(B),ne.init(),Zt=new qx(B,ne),ie=new l1(B,ne,t,Zt),Ut=new Gx(B,ne),ie.reverseDepthBuffer&&d&&Ut.buffers.depth.setReversed(!0),_e=new x1(B),Dt=new Px,L=new Xx(B,ne,Ut,Dt,ie,Zt,_e),T=new h1(_),H=new f1(_),j=new Sp(B),Me=new a1(B,j),et=new m1(B,j,_e,Me),K=new y1(B,et,j,_e),Bt=new v1(B,ie,L),lt=new c1(Dt),_t=new Cx(_,T,H,ne,ie,Me,lt),ft=new Jx(_,Dt),xt=new Lx,oe=new Ox(ne),Ft=new r1(_,T,H,Ut,K,f,l),Mt=new Hx(_,K,ie),N=new jx(B,_e,ie,Ut),bt=new o1(B,ne,_e),ae=new g1(B,ne,_e),_e.programs=_t.programs,_.capabilities=ie,_.extensions=ne,_.properties=Dt,_.renderLists=xt,_.shadowMap=Mt,_.state=Ut,_.info=_e}pt();let Y=new ch(_,B);this.xr=Y,this.getContext=function(){return B},this.getContextAttributes=function(){return B.getContextAttributes()},this.forceContextLoss=function(){let R=ne.get("WEBGL_lose_context");R&&R.loseContext()},this.forceContextRestore=function(){let R=ne.get("WEBGL_lose_context");R&&R.restoreContext()},this.getPixelRatio=function(){return G},this.setPixelRatio=function(R){R!==void 0&&(G=R,this.setSize(V,J,!1))},this.getSize=function(R){return R.set(V,J)},this.setSize=function(R,O,W=!0){if(Y.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}V=R,J=O,e.width=Math.floor(R*G),e.height=Math.floor(O*G),W===!0&&(e.style.width=R+"px",e.style.height=O+"px"),this.setViewport(0,0,R,O)},this.getDrawingBufferSize=function(R){return R.set(V*G,J*G).floor()},this.setDrawingBufferSize=function(R,O,W){V=R,J=O,G=W,e.width=Math.floor(R*W),e.height=Math.floor(O*W),this.setViewport(0,0,R,O)},this.getCurrentViewport=function(R){return R.copy(P)},this.getViewport=function(R){return R.copy(Et)},this.setViewport=function(R,O,W,X){R.isVector4?Et.set(R.x,R.y,R.z,R.w):Et.set(R,O,W,X),Ut.viewport(P.copy(Et).multiplyScalar(G).round())},this.getScissor=function(R){return R.copy(Ot)},this.setScissor=function(R,O,W,X){R.isVector4?Ot.set(R.x,R.y,R.z,R.w):Ot.set(R,O,W,X),Ut.scissor(D.copy(Ot).multiplyScalar(G).round())},this.getScissorTest=function(){return re},this.setScissorTest=function(R){Ut.setScissorTest(re=R)},this.setOpaqueSort=function(R){nt=R},this.setTransparentSort=function(R){ht=R},this.getClearColor=function(R){return R.copy(Ft.getClearColor())},this.setClearColor=function(){Ft.setClearColor.apply(Ft,arguments)},this.getClearAlpha=function(){return Ft.getClearAlpha()},this.setClearAlpha=function(){Ft.setClearAlpha.apply(Ft,arguments)},this.clear=function(R=!0,O=!0,W=!0){let X=0;if(R){let z=!1;if(A!==null){let ct=A.texture.format;z=ct===qh||ct===Xh||ct===Wh}if(z){let ct=A.texture.type,gt=ct===Ei||ct===xs||ct===qr||ct===sr||ct===Hh||ct===Vh,At=Ft.getClearColor(),Rt=Ft.getClearAlpha(),zt=At.r,qt=At.g,Ct=At.b;gt?(m[0]=zt,m[1]=qt,m[2]=Ct,m[3]=Rt,B.clearBufferuiv(B.COLOR,0,m)):(x[0]=zt,x[1]=qt,x[2]=Ct,x[3]=Rt,B.clearBufferiv(B.COLOR,0,x))}else X|=B.COLOR_BUFFER_BIT}O&&(X|=B.DEPTH_BUFFER_BIT),W&&(X|=B.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),B.clear(X)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",Q,!1),e.removeEventListener("webglcontextrestored",vt,!1),e.removeEventListener("webglcontextcreationerror",mt,!1),xt.dispose(),oe.dispose(),Dt.dispose(),T.dispose(),H.dispose(),K.dispose(),Me.dispose(),N.dispose(),_t.dispose(),Y.dispose(),Y.removeEventListener("sessionstart",Su),Y.removeEventListener("sessionend",Eu),ss.stop()};function Q(R){R.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),S=!0}function vt(){console.log("THREE.WebGLRenderer: Context Restored."),S=!1;let R=_e.autoReset,O=Mt.enabled,W=Mt.autoUpdate,X=Mt.needsUpdate,z=Mt.type;pt(),_e.autoReset=R,Mt.enabled=O,Mt.autoUpdate=W,Mt.needsUpdate=X,Mt.type=z}function mt(R){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",R.statusMessage)}function Xt(R){let O=R.target;O.removeEventListener("dispose",Xt),Ie(O)}function Ie(R){Qe(R),Dt.remove(R)}function Qe(R){let O=Dt.get(R).programs;O!==void 0&&(O.forEach(function(W){_t.releaseProgram(W)}),R.isShaderMaterial&&_t.releaseShaderCache(R))}this.renderBufferDirect=function(R,O,W,X,z,ct){O===null&&(O=me);let gt=z.isMesh&&z.matrixWorld.determinant()<0,At=y0(R,O,W,X,z);Ut.setMaterial(X,gt);let Rt=W.index,zt=1;if(X.wireframe===!0){if(Rt=et.getWireframeAttribute(W),Rt===void 0)return;zt=2}let qt=W.drawRange,Ct=W.attributes.position,he=qt.start*zt,be=(qt.start+qt.count)*zt;ct!==null&&(he=Math.max(he,ct.start*zt),be=Math.min(be,(ct.start+ct.count)*zt)),Rt!==null?(he=Math.max(he,0),be=Math.min(be,Rt.count)):Ct!=null&&(he=Math.max(he,0),be=Math.min(be,Ct.count));let Ee=be-he;if(Ee<0||Ee===1/0)return;Me.setup(z,X,At,W,Rt);let dn,de=bt;if(Rt!==null&&(dn=j.get(Rt),de=ae,de.setIndex(dn)),z.isMesh)X.wireframe===!0?(Ut.setLineWidth(X.wireframeLinewidth*Ae()),de.setMode(B.LINES)):de.setMode(B.TRIANGLES);else if(z.isLine){let Pt=X.linewidth;Pt===void 0&&(Pt=1),Ut.setLineWidth(Pt*Ae()),z.isLineSegments?de.setMode(B.LINES):z.isLineLoop?de.setMode(B.LINE_LOOP):de.setMode(B.LINE_STRIP)}else z.isPoints?de.setMode(B.POINTS):z.isSprite&&de.setMode(B.TRIANGLES);if(z.isBatchedMesh)if(z._multiDrawInstances!==null)de.renderMultiDrawInstances(z._multiDrawStarts,z._multiDrawCounts,z._multiDrawCount,z._multiDrawInstances);else if(ne.get("WEBGL_multi_draw"))de.renderMultiDraw(z._multiDrawStarts,z._multiDrawCounts,z._multiDrawCount);else{let Pt=z._multiDrawStarts,mi=z._multiDrawCounts,fe=z._multiDrawCount,zn=Rt?j.get(Rt).bytesPerElement:1,Is=Dt.get(X).currentProgram.getUniforms();for(let gn=0;gn<fe;gn++)Is.setValue(B,"_gl_DrawID",gn),de.render(Pt[gn]/zn,mi[gn])}else if(z.isInstancedMesh)de.renderInstances(he,Ee,z.count);else if(W.isInstancedBufferGeometry){let Pt=W._maxInstanceCount!==void 0?W._maxInstanceCount:1/0,mi=Math.min(W.instanceCount,Pt);de.renderInstances(he,Ee,mi)}else de.render(he,Ee)};function ge(R,O,W){R.transparent===!0&&R.side===xe&&R.forceSinglePass===!1?(R.side=Ce,R.needsUpdate=!0,ba(R,O,W),R.side=Wi,R.needsUpdate=!0,ba(R,O,W),R.side=xe):ba(R,O,W)}this.compile=function(R,O,W=null){W===null&&(W=R),p=oe.get(W),p.init(O),y.push(p),W.traverseVisible(function(z){z.isLight&&z.layers.test(O.layers)&&(p.pushLight(z),z.castShadow&&p.pushShadow(z))}),R!==W&&R.traverseVisible(function(z){z.isLight&&z.layers.test(O.layers)&&(p.pushLight(z),z.castShadow&&p.pushShadow(z))}),p.setupLights();let X=new Set;return R.traverse(function(z){if(!(z.isMesh||z.isPoints||z.isLine||z.isSprite))return;let ct=z.material;if(ct)if(Array.isArray(ct))for(let gt=0;gt<ct.length;gt++){let At=ct[gt];ge(At,W,z),X.add(At)}else ge(ct,W,z),X.add(ct)}),y.pop(),p=null,X},this.compileAsync=function(R,O,W=null){let X=this.compile(R,O,W);return new Promise(z=>{function ct(){if(X.forEach(function(gt){Dt.get(gt).currentProgram.isReady()&&X.delete(gt)}),X.size===0){z(R);return}setTimeout(ct,10)}ne.get("KHR_parallel_shader_compile")!==null?ct():setTimeout(ct,10)})};let Bn=null;function pi(R){Bn&&Bn(R)}function Su(){ss.stop()}function Eu(){ss.start()}let ss=new cf;ss.setAnimationLoop(pi),typeof self<"u"&&ss.setContext(self),this.setAnimationLoop=function(R){Bn=R,Y.setAnimationLoop(R),R===null?ss.stop():ss.start()},Y.addEventListener("sessionstart",Su),Y.addEventListener("sessionend",Eu),this.render=function(R,O){if(O!==void 0&&O.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(S===!0)return;if(R.matrixWorldAutoUpdate===!0&&R.updateMatrixWorld(),O.parent===null&&O.matrixWorldAutoUpdate===!0&&O.updateMatrixWorld(),Y.enabled===!0&&Y.isPresenting===!0&&(Y.cameraAutoUpdate===!0&&Y.updateCamera(O),O=Y.getCamera()),R.isScene===!0&&R.onBeforeRender(_,R,O,A),p=oe.get(R,y.length),p.init(O),y.push(p),yt.multiplyMatrices(O.projectionMatrix,O.matrixWorldInverse),Z.setFromProjectionMatrix(yt),Tt=this.localClippingEnabled,st=lt.init(this.clippingPlanes,Tt),g=xt.get(R,v.length),g.init(),v.push(g),Y.enabled===!0&&Y.isPresenting===!0){let ct=_.xr.getDepthSensingMesh();ct!==null&&Sl(ct,O,-1/0,_.sortObjects)}Sl(R,O,0,_.sortObjects),g.finish(),_.sortObjects===!0&&g.sort(nt,ht),ee=Y.enabled===!1||Y.isPresenting===!1||Y.hasDepthSensing()===!1,ee&&Ft.addToRenderList(g,R),this.info.render.frame++,st===!0&&lt.beginShadows();let W=p.state.shadowsArray;Mt.render(W,R,O),st===!0&&lt.endShadows(),this.info.autoReset===!0&&this.info.reset();let X=g.opaque,z=g.transmissive;if(p.setupLights(),O.isArrayCamera){let ct=O.cameras;if(z.length>0)for(let gt=0,At=ct.length;gt<At;gt++){let Rt=ct[gt];Au(X,z,R,Rt)}ee&&Ft.render(R);for(let gt=0,At=ct.length;gt<At;gt++){let Rt=ct[gt];Tu(g,R,Rt,Rt.viewport)}}else z.length>0&&Au(X,z,R,O),ee&&Ft.render(R),Tu(g,R,O);A!==null&&(L.updateMultisampleRenderTarget(A),L.updateRenderTargetMipmap(A)),R.isScene===!0&&R.onAfterRender(_,R,O),Me.resetDefaultState(),w=-1,b=null,y.pop(),y.length>0?(p=y[y.length-1],st===!0&&lt.setGlobalState(_.clippingPlanes,p.state.camera)):p=null,v.pop(),v.length>0?g=v[v.length-1]:g=null};function Sl(R,O,W,X){if(R.visible===!1)return;if(R.layers.test(O.layers)){if(R.isGroup)W=R.renderOrder;else if(R.isLOD)R.autoUpdate===!0&&R.update(O);else if(R.isLight)p.pushLight(R),R.castShadow&&p.pushShadow(R);else if(R.isSprite){if(!R.frustumCulled||Z.intersectsSprite(R)){X&&Jt.setFromMatrixPosition(R.matrixWorld).applyMatrix4(yt);let gt=K.update(R),At=R.material;At.visible&&g.push(R,gt,At,W,Jt.z,null)}}else if((R.isMesh||R.isLine||R.isPoints)&&(!R.frustumCulled||Z.intersectsObject(R))){let gt=K.update(R),At=R.material;if(X&&(R.boundingSphere!==void 0?(R.boundingSphere===null&&R.computeBoundingSphere(),Jt.copy(R.boundingSphere.center)):(gt.boundingSphere===null&&gt.computeBoundingSphere(),Jt.copy(gt.boundingSphere.center)),Jt.applyMatrix4(R.matrixWorld).applyMatrix4(yt)),Array.isArray(At)){let Rt=gt.groups;for(let zt=0,qt=Rt.length;zt<qt;zt++){let Ct=Rt[zt],he=At[Ct.materialIndex];he&&he.visible&&g.push(R,gt,he,W,Jt.z,Ct)}}else At.visible&&g.push(R,gt,At,W,Jt.z,null)}}let ct=R.children;for(let gt=0,At=ct.length;gt<At;gt++)Sl(ct[gt],O,W,X)}function Tu(R,O,W,X){let z=R.opaque,ct=R.transmissive,gt=R.transparent;p.setupLightsView(W),st===!0&&lt.setGlobalState(_.clippingPlanes,W),X&&Ut.viewport(P.copy(X)),z.length>0&&Ma(z,O,W),ct.length>0&&Ma(ct,O,W),gt.length>0&&Ma(gt,O,W),Ut.buffers.depth.setTest(!0),Ut.buffers.depth.setMask(!0),Ut.buffers.color.setMask(!0),Ut.setPolygonOffset(!1)}function Au(R,O,W,X){if((W.isScene===!0?W.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[X.id]===void 0&&(p.state.transmissionRenderTarget[X.id]=new Ne(1,1,{generateMipmaps:!0,type:ne.has("EXT_color_buffer_half_float")||ne.has("EXT_color_buffer_float")?ln:Ei,minFilter:bi,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:se.workingColorSpace}));let ct=p.state.transmissionRenderTarget[X.id],gt=X.viewport||P;ct.setSize(gt.z,gt.w);let At=_.getRenderTarget();_.setRenderTarget(ct),_.getClearColor(F),q=_.getClearAlpha(),q<1&&_.setClearColor(16777215,.5),_.clear(),ee&&Ft.render(W);let Rt=_.toneMapping;_.toneMapping=Vi;let zt=X.viewport;if(X.viewport!==void 0&&(X.viewport=void 0),p.setupLightsView(X),st===!0&&lt.setGlobalState(_.clippingPlanes,X),Ma(R,W,X),L.updateMultisampleRenderTarget(ct),L.updateRenderTargetMipmap(ct),ne.has("WEBGL_multisampled_render_to_texture")===!1){let qt=!1;for(let Ct=0,he=O.length;Ct<he;Ct++){let be=O[Ct],Ee=be.object,dn=be.geometry,de=be.material,Pt=be.group;if(de.side===xe&&Ee.layers.test(X.layers)){let mi=de.side;de.side=Ce,de.needsUpdate=!0,Ru(Ee,W,X,dn,de,Pt),de.side=mi,de.needsUpdate=!0,qt=!0}}qt===!0&&(L.updateMultisampleRenderTarget(ct),L.updateRenderTargetMipmap(ct))}_.setRenderTarget(At),_.setClearColor(F,q),zt!==void 0&&(X.viewport=zt),_.toneMapping=Rt}function Ma(R,O,W){let X=O.isScene===!0?O.overrideMaterial:null;for(let z=0,ct=R.length;z<ct;z++){let gt=R[z],At=gt.object,Rt=gt.geometry,zt=X===null?gt.material:X,qt=gt.group;At.layers.test(W.layers)&&Ru(At,O,W,Rt,zt,qt)}}function Ru(R,O,W,X,z,ct){R.onBeforeRender(_,O,W,X,z,ct),R.modelViewMatrix.multiplyMatrices(W.matrixWorldInverse,R.matrixWorld),R.normalMatrix.getNormalMatrix(R.modelViewMatrix),z.onBeforeRender(_,O,W,X,R,ct),z.transparent===!0&&z.side===xe&&z.forceSinglePass===!1?(z.side=Ce,z.needsUpdate=!0,_.renderBufferDirect(W,O,X,z,R,ct),z.side=Wi,z.needsUpdate=!0,_.renderBufferDirect(W,O,X,z,R,ct),z.side=xe):_.renderBufferDirect(W,O,X,z,R,ct),R.onAfterRender(_,O,W,X,z,ct)}function ba(R,O,W){O.isScene!==!0&&(O=me);let X=Dt.get(R),z=p.state.lights,ct=p.state.shadowsArray,gt=z.state.version,At=_t.getParameters(R,z.state,ct,O,W),Rt=_t.getProgramCacheKey(At),zt=X.programs;X.environment=R.isMeshStandardMaterial?O.environment:null,X.fog=O.fog,X.envMap=(R.isMeshStandardMaterial?H:T).get(R.envMap||X.environment),X.envMapRotation=X.environment!==null&&R.envMap===null?O.environmentRotation:R.envMapRotation,zt===void 0&&(R.addEventListener("dispose",Xt),zt=new Map,X.programs=zt);let qt=zt.get(Rt);if(qt!==void 0){if(X.currentProgram===qt&&X.lightsStateVersion===gt)return Pu(R,At),qt}else At.uniforms=_t.getUniforms(R),R.onBeforeCompile(At,_),qt=_t.acquireProgram(At,Rt),zt.set(Rt,qt),X.uniforms=At.uniforms;let Ct=X.uniforms;return(!R.isShaderMaterial&&!R.isRawShaderMaterial||R.clipping===!0)&&(Ct.clippingPlanes=lt.uniform),Pu(R,At),X.needsLights=M0(R),X.lightsStateVersion=gt,X.needsLights&&(Ct.ambientLightColor.value=z.state.ambient,Ct.lightProbe.value=z.state.probe,Ct.directionalLights.value=z.state.directional,Ct.directionalLightShadows.value=z.state.directionalShadow,Ct.spotLights.value=z.state.spot,Ct.spotLightShadows.value=z.state.spotShadow,Ct.rectAreaLights.value=z.state.rectArea,Ct.ltc_1.value=z.state.rectAreaLTC1,Ct.ltc_2.value=z.state.rectAreaLTC2,Ct.pointLights.value=z.state.point,Ct.pointLightShadows.value=z.state.pointShadow,Ct.hemisphereLights.value=z.state.hemi,Ct.directionalShadowMap.value=z.state.directionalShadowMap,Ct.directionalShadowMatrix.value=z.state.directionalShadowMatrix,Ct.spotShadowMap.value=z.state.spotShadowMap,Ct.spotLightMatrix.value=z.state.spotLightMatrix,Ct.spotLightMap.value=z.state.spotLightMap,Ct.pointShadowMap.value=z.state.pointShadowMap,Ct.pointShadowMatrix.value=z.state.pointShadowMatrix),X.currentProgram=qt,X.uniformsList=null,qt}function Cu(R){if(R.uniformsList===null){let O=R.currentProgram.getUniforms();R.uniformsList=tr.seqWithValue(O.seq,R.uniforms)}return R.uniformsList}function Pu(R,O){let W=Dt.get(R);W.outputColorSpace=O.outputColorSpace,W.batching=O.batching,W.batchingColor=O.batchingColor,W.instancing=O.instancing,W.instancingColor=O.instancingColor,W.instancingMorph=O.instancingMorph,W.skinning=O.skinning,W.morphTargets=O.morphTargets,W.morphNormals=O.morphNormals,W.morphColors=O.morphColors,W.morphTargetsCount=O.morphTargetsCount,W.numClippingPlanes=O.numClippingPlanes,W.numIntersection=O.numClipIntersection,W.vertexAlphas=O.vertexAlphas,W.vertexTangents=O.vertexTangents,W.toneMapping=O.toneMapping}function y0(R,O,W,X,z){O.isScene!==!0&&(O=me),L.resetTextureUnits();let ct=O.fog,gt=X.isMeshStandardMaterial?O.environment:null,At=A===null?_.outputColorSpace:A.isXRRenderTarget===!0?A.texture.colorSpace:Ji,Rt=(X.isMeshStandardMaterial?H:T).get(X.envMap||gt),zt=X.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,qt=!!W.attributes.tangent&&(!!X.normalMap||X.anisotropy>0),Ct=!!W.morphAttributes.position,he=!!W.morphAttributes.normal,be=!!W.morphAttributes.color,Ee=Vi;X.toneMapped&&(A===null||A.isXRRenderTarget===!0)&&(Ee=_.toneMapping);let dn=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,de=dn!==void 0?dn.length:0,Pt=Dt.get(X),mi=p.state.lights;if(st===!0&&(Tt===!0||R!==b)){let bn=R===b&&X.id===w;lt.setState(X,R,bn)}let fe=!1;X.version===Pt.__version?(Pt.needsLights&&Pt.lightsStateVersion!==mi.state.version||Pt.outputColorSpace!==At||z.isBatchedMesh&&Pt.batching===!1||!z.isBatchedMesh&&Pt.batching===!0||z.isBatchedMesh&&Pt.batchingColor===!0&&z.colorTexture===null||z.isBatchedMesh&&Pt.batchingColor===!1&&z.colorTexture!==null||z.isInstancedMesh&&Pt.instancing===!1||!z.isInstancedMesh&&Pt.instancing===!0||z.isSkinnedMesh&&Pt.skinning===!1||!z.isSkinnedMesh&&Pt.skinning===!0||z.isInstancedMesh&&Pt.instancingColor===!0&&z.instanceColor===null||z.isInstancedMesh&&Pt.instancingColor===!1&&z.instanceColor!==null||z.isInstancedMesh&&Pt.instancingMorph===!0&&z.morphTexture===null||z.isInstancedMesh&&Pt.instancingMorph===!1&&z.morphTexture!==null||Pt.envMap!==Rt||X.fog===!0&&Pt.fog!==ct||Pt.numClippingPlanes!==void 0&&(Pt.numClippingPlanes!==lt.numPlanes||Pt.numIntersection!==lt.numIntersection)||Pt.vertexAlphas!==zt||Pt.vertexTangents!==qt||Pt.morphTargets!==Ct||Pt.morphNormals!==he||Pt.morphColors!==be||Pt.toneMapping!==Ee||Pt.morphTargetsCount!==de)&&(fe=!0):(fe=!0,Pt.__version=X.version);let zn=Pt.currentProgram;fe===!0&&(zn=ba(X,O,z));let Is=!1,gn=!1,Rr=!1,Te=zn.getUniforms(),ei=Pt.uniforms;if(Ut.useProgram(zn.program)&&(Is=!0,gn=!0,Rr=!0),X.id!==w&&(w=X.id,gn=!0),Is||b!==R){Ut.buffers.depth.getReversed()?(dt.copy(R.projectionMatrix),rp(dt),ap(dt),Te.setValue(B,"projectionMatrix",dt)):Te.setValue(B,"projectionMatrix",R.projectionMatrix),Te.setValue(B,"viewMatrix",R.matrixWorldInverse);let Li=Te.map.cameraPosition;Li!==void 0&&Li.setValue(B,Nt.setFromMatrixPosition(R.matrixWorld)),ie.logarithmicDepthBuffer&&Te.setValue(B,"logDepthBufFC",2/(Math.log(R.far+1)/Math.LN2)),(X.isMeshPhongMaterial||X.isMeshToonMaterial||X.isMeshLambertMaterial||X.isMeshBasicMaterial||X.isMeshStandardMaterial||X.isShaderMaterial)&&Te.setValue(B,"isOrthographic",R.isOrthographicCamera===!0),b!==R&&(b=R,gn=!0,Rr=!0)}if(z.isSkinnedMesh){Te.setOptional(B,z,"bindMatrix"),Te.setOptional(B,z,"bindMatrixInverse");let bn=z.skeleton;bn&&(bn.boneTexture===null&&bn.computeBoneTexture(),Te.setValue(B,"boneTexture",bn.boneTexture,L))}z.isBatchedMesh&&(Te.setOptional(B,z,"batchingTexture"),Te.setValue(B,"batchingTexture",z._matricesTexture,L),Te.setOptional(B,z,"batchingIdTexture"),Te.setValue(B,"batchingIdTexture",z._indirectTexture,L),Te.setOptional(B,z,"batchingColorTexture"),z._colorsTexture!==null&&Te.setValue(B,"batchingColorTexture",z._colorsTexture,L));let Cr=W.morphAttributes;if((Cr.position!==void 0||Cr.normal!==void 0||Cr.color!==void 0)&&Bt.update(z,W,zn),(gn||Pt.receiveShadow!==z.receiveShadow)&&(Pt.receiveShadow=z.receiveShadow,Te.setValue(B,"receiveShadow",z.receiveShadow)),X.isMeshGouraudMaterial&&X.envMap!==null&&(ei.envMap.value=Rt,ei.flipEnvMap.value=Rt.isCubeTexture&&Rt.isRenderTargetTexture===!1?-1:1),X.isMeshStandardMaterial&&X.envMap===null&&O.environment!==null&&(ei.envMapIntensity.value=O.environmentIntensity),gn&&(Te.setValue(B,"toneMappingExposure",_.toneMappingExposure),Pt.needsLights&&_0(ei,Rr),ct&&X.fog===!0&&ft.refreshFogUniforms(ei,ct),ft.refreshMaterialUniforms(ei,X,G,J,p.state.transmissionRenderTarget[R.id]),tr.upload(B,Cu(Pt),ei,L)),X.isShaderMaterial&&X.uniformsNeedUpdate===!0&&(tr.upload(B,Cu(Pt),ei,L),X.uniformsNeedUpdate=!1),X.isSpriteMaterial&&Te.setValue(B,"center",z.center),Te.setValue(B,"modelViewMatrix",z.modelViewMatrix),Te.setValue(B,"normalMatrix",z.normalMatrix),Te.setValue(B,"modelMatrix",z.matrixWorld),X.isShaderMaterial||X.isRawShaderMaterial){let bn=X.uniformsGroups;for(let Li=0,Di=bn.length;Li<Di;Li++){let Iu=bn[Li];N.update(Iu,zn),N.bind(Iu,zn)}}return zn}function _0(R,O){R.ambientLightColor.needsUpdate=O,R.lightProbe.needsUpdate=O,R.directionalLights.needsUpdate=O,R.directionalLightShadows.needsUpdate=O,R.pointLights.needsUpdate=O,R.pointLightShadows.needsUpdate=O,R.spotLights.needsUpdate=O,R.spotLightShadows.needsUpdate=O,R.rectAreaLights.needsUpdate=O,R.hemisphereLights.needsUpdate=O}function M0(R){return R.isMeshLambertMaterial||R.isMeshToonMaterial||R.isMeshPhongMaterial||R.isMeshStandardMaterial||R.isShadowMaterial||R.isShaderMaterial&&R.lights===!0}this.getActiveCubeFace=function(){return M},this.getActiveMipmapLevel=function(){return E},this.getRenderTarget=function(){return A},this.setRenderTargetTextures=function(R,O,W){Dt.get(R.texture).__webglTexture=O,Dt.get(R.depthTexture).__webglTexture=W;let X=Dt.get(R);X.__hasExternalTextures=!0,X.__autoAllocateDepthBuffer=W===void 0,X.__autoAllocateDepthBuffer||ne.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),X.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(R,O){let W=Dt.get(R);W.__webglFramebuffer=O,W.__useDefaultFramebuffer=O===void 0},this.setRenderTarget=function(R,O=0,W=0){A=R,M=O,E=W;let X=!0,z=null,ct=!1,gt=!1;if(R){let Rt=Dt.get(R);if(Rt.__useDefaultFramebuffer!==void 0)Ut.bindFramebuffer(B.FRAMEBUFFER,null),X=!1;else if(Rt.__webglFramebuffer===void 0)L.setupRenderTarget(R);else if(Rt.__hasExternalTextures)L.rebindTextures(R,Dt.get(R.texture).__webglTexture,Dt.get(R.depthTexture).__webglTexture);else if(R.depthBuffer){let Ct=R.depthTexture;if(Rt.__boundDepthTexture!==Ct){if(Ct!==null&&Dt.has(Ct)&&(R.width!==Ct.image.width||R.height!==Ct.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");L.setupDepthRenderbuffer(R)}}let zt=R.texture;(zt.isData3DTexture||zt.isDataArrayTexture||zt.isCompressedArrayTexture)&&(gt=!0);let qt=Dt.get(R).__webglFramebuffer;R.isWebGLCubeRenderTarget?(Array.isArray(qt[O])?z=qt[O][W]:z=qt[O],ct=!0):R.samples>0&&L.useMultisampledRTT(R)===!1?z=Dt.get(R).__webglMultisampledFramebuffer:Array.isArray(qt)?z=qt[W]:z=qt,P.copy(R.viewport),D.copy(R.scissor),U=R.scissorTest}else P.copy(Et).multiplyScalar(G).floor(),D.copy(Ot).multiplyScalar(G).floor(),U=re;if(Ut.bindFramebuffer(B.FRAMEBUFFER,z)&&X&&Ut.drawBuffers(R,z),Ut.viewport(P),Ut.scissor(D),Ut.setScissorTest(U),ct){let Rt=Dt.get(R.texture);B.framebufferTexture2D(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_CUBE_MAP_POSITIVE_X+O,Rt.__webglTexture,W)}else if(gt){let Rt=Dt.get(R.texture),zt=O||0;B.framebufferTextureLayer(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,Rt.__webglTexture,W||0,zt)}w=-1},this.readRenderTargetPixels=function(R,O,W,X,z,ct,gt){if(!(R&&R.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let At=Dt.get(R).__webglFramebuffer;if(R.isWebGLCubeRenderTarget&&gt!==void 0&&(At=At[gt]),At){Ut.bindFramebuffer(B.FRAMEBUFFER,At);try{let Rt=R.texture,zt=Rt.format,qt=Rt.type;if(!ie.textureFormatReadable(zt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!ie.textureTypeReadable(qt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}O>=0&&O<=R.width-X&&W>=0&&W<=R.height-z&&B.readPixels(O,W,X,z,Zt.convert(zt),Zt.convert(qt),ct)}finally{let Rt=A!==null?Dt.get(A).__webglFramebuffer:null;Ut.bindFramebuffer(B.FRAMEBUFFER,Rt)}}},this.readRenderTargetPixelsAsync=async function(R,O,W,X,z,ct,gt){if(!(R&&R.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let At=Dt.get(R).__webglFramebuffer;if(R.isWebGLCubeRenderTarget&&gt!==void 0&&(At=At[gt]),At){let Rt=R.texture,zt=Rt.format,qt=Rt.type;if(!ie.textureFormatReadable(zt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!ie.textureTypeReadable(qt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(O>=0&&O<=R.width-X&&W>=0&&W<=R.height-z){Ut.bindFramebuffer(B.FRAMEBUFFER,At);let Ct=B.createBuffer();B.bindBuffer(B.PIXEL_PACK_BUFFER,Ct),B.bufferData(B.PIXEL_PACK_BUFFER,ct.byteLength,B.STREAM_READ),B.readPixels(O,W,X,z,Zt.convert(zt),Zt.convert(qt),0);let he=A!==null?Dt.get(A).__webglFramebuffer:null;Ut.bindFramebuffer(B.FRAMEBUFFER,he);let be=B.fenceSync(B.SYNC_GPU_COMMANDS_COMPLETE,0);return B.flush(),await sp(B,be,4),B.bindBuffer(B.PIXEL_PACK_BUFFER,Ct),B.getBufferSubData(B.PIXEL_PACK_BUFFER,0,ct),B.deleteBuffer(Ct),B.deleteSync(be),ct}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(R,O=null,W=0){R.isTexture!==!0&&(Hr("WebGLRenderer: copyFramebufferToTexture function signature has changed."),O=arguments[0]||null,R=arguments[1]);let X=Math.pow(2,-W),z=Math.floor(R.image.width*X),ct=Math.floor(R.image.height*X),gt=O!==null?O.x:0,At=O!==null?O.y:0;L.setTexture2D(R,0),B.copyTexSubImage2D(B.TEXTURE_2D,W,0,0,gt,At,z,ct),Ut.unbindTexture()},this.copyTextureToTexture=function(R,O,W=null,X=null,z=0){R.isTexture!==!0&&(Hr("WebGLRenderer: copyTextureToTexture function signature has changed."),X=arguments[0]||null,R=arguments[1],O=arguments[2],z=arguments[3]||0,W=null);let ct,gt,At,Rt,zt,qt,Ct,he,be,Ee=R.isCompressedTexture?R.mipmaps[z]:R.image;W!==null?(ct=W.max.x-W.min.x,gt=W.max.y-W.min.y,At=W.isBox3?W.max.z-W.min.z:1,Rt=W.min.x,zt=W.min.y,qt=W.isBox3?W.min.z:0):(ct=Ee.width,gt=Ee.height,At=Ee.depth||1,Rt=0,zt=0,qt=0),X!==null?(Ct=X.x,he=X.y,be=X.z):(Ct=0,he=0,be=0);let dn=Zt.convert(O.format),de=Zt.convert(O.type),Pt;O.isData3DTexture?(L.setTexture3D(O,0),Pt=B.TEXTURE_3D):O.isDataArrayTexture||O.isCompressedArrayTexture?(L.setTexture2DArray(O,0),Pt=B.TEXTURE_2D_ARRAY):(L.setTexture2D(O,0),Pt=B.TEXTURE_2D),B.pixelStorei(B.UNPACK_FLIP_Y_WEBGL,O.flipY),B.pixelStorei(B.UNPACK_PREMULTIPLY_ALPHA_WEBGL,O.premultiplyAlpha),B.pixelStorei(B.UNPACK_ALIGNMENT,O.unpackAlignment);let mi=B.getParameter(B.UNPACK_ROW_LENGTH),fe=B.getParameter(B.UNPACK_IMAGE_HEIGHT),zn=B.getParameter(B.UNPACK_SKIP_PIXELS),Is=B.getParameter(B.UNPACK_SKIP_ROWS),gn=B.getParameter(B.UNPACK_SKIP_IMAGES);B.pixelStorei(B.UNPACK_ROW_LENGTH,Ee.width),B.pixelStorei(B.UNPACK_IMAGE_HEIGHT,Ee.height),B.pixelStorei(B.UNPACK_SKIP_PIXELS,Rt),B.pixelStorei(B.UNPACK_SKIP_ROWS,zt),B.pixelStorei(B.UNPACK_SKIP_IMAGES,qt);let Rr=R.isDataArrayTexture||R.isData3DTexture,Te=O.isDataArrayTexture||O.isData3DTexture;if(R.isRenderTargetTexture||R.isDepthTexture){let ei=Dt.get(R),Cr=Dt.get(O),bn=Dt.get(ei.__renderTarget),Li=Dt.get(Cr.__renderTarget);Ut.bindFramebuffer(B.READ_FRAMEBUFFER,bn.__webglFramebuffer),Ut.bindFramebuffer(B.DRAW_FRAMEBUFFER,Li.__webglFramebuffer);for(let Di=0;Di<At;Di++)Rr&&B.framebufferTextureLayer(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,Dt.get(R).__webglTexture,z,qt+Di),R.isDepthTexture?(Te&&B.framebufferTextureLayer(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,Dt.get(O).__webglTexture,z,be+Di),B.blitFramebuffer(Rt,zt,ct,gt,Ct,he,ct,gt,B.DEPTH_BUFFER_BIT,B.NEAREST)):Te?B.copyTexSubImage3D(Pt,z,Ct,he,be+Di,Rt,zt,ct,gt):B.copyTexSubImage2D(Pt,z,Ct,he,be+Di,Rt,zt,ct,gt);Ut.bindFramebuffer(B.READ_FRAMEBUFFER,null),Ut.bindFramebuffer(B.DRAW_FRAMEBUFFER,null)}else Te?R.isDataTexture||R.isData3DTexture?B.texSubImage3D(Pt,z,Ct,he,be,ct,gt,At,dn,de,Ee.data):O.isCompressedArrayTexture?B.compressedTexSubImage3D(Pt,z,Ct,he,be,ct,gt,At,dn,Ee.data):B.texSubImage3D(Pt,z,Ct,he,be,ct,gt,At,dn,de,Ee):R.isDataTexture?B.texSubImage2D(B.TEXTURE_2D,z,Ct,he,ct,gt,dn,de,Ee.data):R.isCompressedTexture?B.compressedTexSubImage2D(B.TEXTURE_2D,z,Ct,he,Ee.width,Ee.height,dn,Ee.data):B.texSubImage2D(B.TEXTURE_2D,z,Ct,he,ct,gt,dn,de,Ee);B.pixelStorei(B.UNPACK_ROW_LENGTH,mi),B.pixelStorei(B.UNPACK_IMAGE_HEIGHT,fe),B.pixelStorei(B.UNPACK_SKIP_PIXELS,zn),B.pixelStorei(B.UNPACK_SKIP_ROWS,Is),B.pixelStorei(B.UNPACK_SKIP_IMAGES,gn),z===0&&O.generateMipmaps&&B.generateMipmap(Pt),Ut.unbindTexture()},this.copyTextureToTexture3D=function(R,O,W=null,X=null,z=0){return R.isTexture!==!0&&(Hr("WebGLRenderer: copyTextureToTexture3D function signature has changed."),W=arguments[0]||null,X=arguments[1]||null,R=arguments[2],O=arguments[3],z=arguments[4]||0),Hr('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(R,O,W,X,z)},this.initRenderTarget=function(R){Dt.get(R).__webglFramebuffer===void 0&&L.setupRenderTarget(R)},this.initTexture=function(R){R.isCubeTexture?L.setTextureCube(R,0):R.isData3DTexture?L.setTexture3D(R,0):R.isDataArrayTexture||R.isCompressedArrayTexture?L.setTexture2DArray(R,0):L.setTexture2D(R,0),Ut.unbindTexture()},this.resetState=function(){M=0,E=0,A=null,Ut.reset(),Me.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return wi}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorspace=se._getDrawingBufferColorSpace(t),e.unpackColorSpace=se._getUnpackColorSpace()}},yo=class s{constructor(t,e=25e-5){this.isFogExp2=!0,this.name="",this.color=new ot(t),this.density=e}clone(){return new s(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}},_o=class s{constructor(t,e=1,n=1e3){this.isFog=!0,this.name="",this.color=new ot(t),this.near=e,this.far=n}clone(){return new s(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},pn=class extends Le{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new nn,this.environmentIntensity=1,this.environmentRotation=new nn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(e.object.environmentIntensity=this.environmentIntensity),e.object.environmentRotation=this.environmentRotation.toArray(),e}},Mo=class{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=Yc,this.updateRanges=[],this.version=0,this.uuid=Gi()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,n){t*=this.stride,n*=e.stride;for(let i=0,r=this.stride;i<r;i++)this.array[t+i]=e.array[n+i];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Gi()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(e,this.stride);return n.setUsage(this.usage),n}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Gi()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},an=new C,Zr=class s{constructor(t,e,n,i=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=n,this.normalized=i}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,n=this.data.count;e<n;e++)an.fromBufferAttribute(this,e),an.applyMatrix4(t),this.setXYZ(e,an.x,an.y,an.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)an.fromBufferAttribute(this,e),an.applyNormalMatrix(t),this.setXYZ(e,an.x,an.y,an.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)an.fromBufferAttribute(this,e),an.transformDirection(t),this.setXYZ(e,an.x,an.y,an.z);return this}getComponent(t,e){let n=this.array[t*this.data.stride+this.offset+e];return this.normalized&&(n=si(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=ye(n,this.array)),this.data.array[t*this.data.stride+this.offset+e]=n,this}setX(t,e){return this.normalized&&(e=ye(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=ye(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=ye(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=ye(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=si(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=si(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=si(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=si(e,this.array)),e}setXY(t,e,n){return t=t*this.data.stride+this.offset,this.normalized&&(e=ye(e,this.array),n=ye(n,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this}setXYZ(t,e,n,i){return t=t*this.data.stride+this.offset,this.normalized&&(e=ye(e,this.array),n=ye(n,this.array),i=ye(i,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=i,this}setXYZW(t,e,n,i,r){return t=t*this.data.stride+this.offset,this.normalized&&(e=ye(e,this.array),n=ye(n,this.array),i=ye(i,this.array),r=ye(r,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=i,this.data.array[t+3]=r,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let n=0;n<this.count;n++){let i=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[i+r])}return new Vt(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new s(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let n=0;n<this.count;n++){let i=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[i+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},Kr=class extends li{static get type(){return"SpriteMaterial"}constructor(t){super(),this.isSpriteMaterial=!0,this.color=new ot(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},qs,kr=new C,Ys=new C,$s=new C,Zs=new tt,Ur=new tt,pf=new Lt,Wa=new C,Nr=new C,Xa=new C,Pd=new tt,ec=new tt,Id=new tt,bo=class extends Le{constructor(t=new Kr){if(super(),this.isSprite=!0,this.type="Sprite",qs===void 0){qs=new Gt;let e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new Mo(e,5);qs.setIndex([0,1,2,0,2,3]),qs.setAttribute("position",new Zr(n,3,0,!1)),qs.setAttribute("uv",new Zr(n,2,3,!1))}this.geometry=qs,this.material=t,this.center=new tt(.5,.5)}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Ys.setFromMatrixScale(this.matrixWorld),pf.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),$s.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Ys.multiplyScalar(-$s.z);let n=this.material.rotation,i,r;n!==0&&(r=Math.cos(n),i=Math.sin(n));let a=this.center;qa(Wa.set(-.5,-.5,0),$s,a,Ys,i,r),qa(Nr.set(.5,-.5,0),$s,a,Ys,i,r),qa(Xa.set(.5,.5,0),$s,a,Ys,i,r),Pd.set(0,0),ec.set(1,0),Id.set(1,1);let o=t.ray.intersectTriangle(Wa,Nr,Xa,!1,kr);if(o===null&&(qa(Nr.set(-.5,.5,0),$s,a,Ys,i,r),ec.set(0,1),o=t.ray.intersectTriangle(Wa,Xa,Nr,!1,kr),o===null))return;let l=t.ray.origin.distanceTo(kr);l<t.near||l>t.far||e.push({distance:l,point:kr.clone(),uv:zi.getInterpolation(kr,Wa,Nr,Xa,Pd,ec,Id,new tt),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}};function qa(s,t,e,n,i,r){Zs.subVectors(s,e).addScalar(.5).multiply(n),i!==void 0?(Ur.x=r*Zs.x-i*Zs.y,Ur.y=i*Zs.x+r*Zs.y):Ur.copy(Zs),s.copy(t),s.x+=Ur.x,s.y+=Ur.y,s.applyMatrix4(pf)}var hh=class extends fn{constructor(t=null,e=1,n=1,i,r,a,o,l,c=yn,h=yn,u,d){super(null,a,o,l,c,h,i,r,u,d),this.isDataTexture=!0,this.image={data:t,width:e,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Jr=class extends Vt{constructor(t,e,n,i=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=i}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){let t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}},Ks=new Lt,Ld=new Lt,Ya=[],Dd=new qn,Qx=new Lt,Fr=new it,Or=new Ti,Yn=class extends it{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new Jr(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let i=0;i<n;i++)this.setMatrixAt(i,Qx)}computeBoundingBox(){let t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new qn),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Ks),Dd.copy(t.boundingBox).applyMatrix4(Ks),this.boundingBox.union(Dd)}computeBoundingSphere(){let t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Ti),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Ks),Or.copy(t.boundingSphere).applyMatrix4(Ks),this.boundingSphere.union(Or)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.morphTexture!==null&&(this.morphTexture=t.morphTexture.clone()),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){let n=e.morphTargetInfluences,i=this.morphTexture.source.data.data,r=n.length+1,a=t*r+1;for(let o=0;o<n.length;o++)n[o]=i[a+o]}raycast(t,e){let n=this.matrixWorld,i=this.count;if(Fr.geometry=this.geometry,Fr.material=this.material,Fr.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Or.copy(this.boundingSphere),Or.applyMatrix4(n),t.ray.intersectsSphere(Or)!==!1))for(let r=0;r<i;r++){this.getMatrixAt(r,Ks),Ld.multiplyMatrices(n,Ks),Fr.matrixWorld=Ld,Fr.raycast(t,Ya);for(let a=0,o=Ya.length;a<o;a++){let l=Ya[a];l.instanceId=r,l.object=this,e.push(l)}Ya.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new Jr(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}setMorphAt(t,e){let n=e.morphTargetInfluences,i=n.length+1;this.morphTexture===null&&(this.morphTexture=new hh(new Float32Array(i*this.count),i,this.count,Gh,ai));let r=this.morphTexture.source.data.data,a=0;for(let c=0;c<n.length;c++)a+=n[c];let o=this.geometry.morphTargetsRelative?1:1-a,l=i*t;r[l]=o,r.set(n,l+1)}updateMorphTargets(){}dispose(){return this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null),this}};var uh=class extends li{static get type(){return"LineBasicMaterial"}constructor(t){super(),this.isLineBasicMaterial=!0,this.color=new ot(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}},wo=new C,So=new C,kd=new Lt,Br=new Yr,$a=new Ti,nc=new C,Ud=new C,dh=class extends Le{constructor(t=new Gt,e=new uh){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){let t=this.geometry;if(t.index===null){let e=t.attributes.position,n=[0];for(let i=1,r=e.count;i<r;i++)wo.fromBufferAttribute(e,i-1),So.fromBufferAttribute(e,i),n[i]=n[i-1],n[i]+=wo.distanceTo(So);t.setAttribute("lineDistance",new wt(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(t,e){let n=this.geometry,i=this.matrixWorld,r=t.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),$a.copy(n.boundingSphere),$a.applyMatrix4(i),$a.radius+=r,t.ray.intersectsSphere($a)===!1)return;kd.copy(i).invert(),Br.copy(t.ray).applyMatrix4(kd);let o=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=this.isLineSegments?2:1,h=n.index,d=n.attributes.position;if(h!==null){let f=Math.max(0,a.start),m=Math.min(h.count,a.start+a.count);for(let x=f,g=m-1;x<g;x+=c){let p=h.getX(x),v=h.getX(x+1),y=Za(this,t,Br,l,p,v);y&&e.push(y)}if(this.isLineLoop){let x=h.getX(m-1),g=h.getX(f),p=Za(this,t,Br,l,x,g);p&&e.push(p)}}else{let f=Math.max(0,a.start),m=Math.min(d.count,a.start+a.count);for(let x=f,g=m-1;x<g;x+=c){let p=Za(this,t,Br,l,x,x+1);p&&e.push(p)}if(this.isLineLoop){let x=Za(this,t,Br,l,m-1,f);x&&e.push(x)}}}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=i.length;r<a;r++){let o=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}};function Za(s,t,e,n,i,r){let a=s.geometry.attributes.position;if(wo.fromBufferAttribute(a,i),So.fromBufferAttribute(a,r),e.distanceSqToSegment(wo,So,nc,Ud)>n)return;nc.applyMatrix4(s.matrixWorld);let l=t.ray.origin.distanceTo(nc);if(!(l<t.near||l>t.far))return{distance:l,point:Ud.clone().applyMatrix4(s.matrixWorld),index:i,face:null,faceIndex:null,barycoord:null,object:s}}var Nd=new C,Fd=new C,Eo=class extends dh{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let t=this.geometry;if(t.index===null){let e=t.attributes.position,n=[];for(let i=0,r=e.count;i<r;i+=2)Nd.fromBufferAttribute(e,i),Fd.fromBufferAttribute(e,i+1),n[i]=i===0?0:n[i-1],n[i+1]=n[i]+Nd.distanceTo(Fd);t.setAttribute("lineDistance",new wt(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}};var or=class extends li{static get type(){return"PointsMaterial"}constructor(t){super(),this.isPointsMaterial=!0,this.color=new ot(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},Od=new Lt,fh=new Yr,Ka=new Ti,Ja=new C,Ai=class extends Le{constructor(t=new Gt,e=new or){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){let n=this.geometry,i=this.matrixWorld,r=t.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ka.copy(n.boundingSphere),Ka.applyMatrix4(i),Ka.radius+=r,t.ray.intersectsSphere(Ka)===!1)return;Od.copy(i).invert(),fh.copy(t.ray).applyMatrix4(Od);let o=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=n.index,u=n.attributes.position;if(c!==null){let d=Math.max(0,a.start),f=Math.min(c.count,a.start+a.count);for(let m=d,x=f;m<x;m++){let g=c.getX(m);Ja.fromBufferAttribute(u,g),Bd(Ja,g,l,i,t,e,this)}}else{let d=Math.max(0,a.start),f=Math.min(u.count,a.start+a.count);for(let m=d,x=f;m<x;m++)Ja.fromBufferAttribute(u,m),Bd(Ja,m,l,i,t,e,this)}}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let i=e[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=i.length;r<a;r++){let o=i[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}};function Bd(s,t,e,n,i,r,a){let o=fh.distanceSqToPoint(s);if(o<e){let l=new C;fh.closestPointToPoint(s,l),l.applyMatrix4(n);let c=i.ray.origin.distanceTo(l);if(c<i.near||c>i.far)return;r.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:t,face:null,faceIndex:null,barycoord:null,object:a})}}var lr=class extends fn{constructor(t,e,n,i,r,a,o,l,c){super(t,e,n,i,r,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},Sn=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){let n=this.getUtoTmapping(t);return this.getPoint(n,e)}getPoints(t=5){let e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return e}getSpacedPoints(t=5){let e=[];for(let n=0;n<=t;n++)e.push(this.getPointAt(n/t));return e}getLength(){let t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let e=[],n,i=this.getPoint(0),r=0;e.push(0);for(let a=1;a<=t;a++)n=this.getPoint(a/t),r+=n.distanceTo(i),e.push(r),i=n;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){let n=this.getLengths(),i=0,r=n.length,a;e?a=e:a=t*n[r-1];let o=0,l=r-1,c;for(;o<=l;)if(i=Math.floor(o+(l-o)/2),c=n[i]-a,c<0)o=i+1;else if(c>0)l=i-1;else{l=i;break}if(i=l,n[i]===a)return i/(r-1);let h=n[i],d=n[i+1]-h,f=(a-h)/d;return(i+f)/(r-1)}getTangent(t,e){let i=t-1e-4,r=t+1e-4;i<0&&(i=0),r>1&&(r=1);let a=this.getPoint(i),o=this.getPoint(r),l=e||(a.isVector2?new tt:new C);return l.copy(o).sub(a).normalize(),l}getTangentAt(t,e){let n=this.getUtoTmapping(t);return this.getTangent(n,e)}computeFrenetFrames(t,e){let n=new C,i=[],r=[],a=[],o=new C,l=new Lt;for(let f=0;f<=t;f++){let m=f/t;i[f]=this.getTangentAt(m,new C)}r[0]=new C,a[0]=new C;let c=Number.MAX_VALUE,h=Math.abs(i[0].x),u=Math.abs(i[0].y),d=Math.abs(i[0].z);h<=c&&(c=h,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),d<=c&&n.set(0,0,1),o.crossVectors(i[0],n).normalize(),r[0].crossVectors(i[0],o),a[0].crossVectors(i[0],r[0]);for(let f=1;f<=t;f++){if(r[f]=r[f-1].clone(),a[f]=a[f-1].clone(),o.crossVectors(i[f-1],i[f]),o.length()>Number.EPSILON){o.normalize();let m=Math.acos(Ye(i[f-1].dot(i[f]),-1,1));r[f].applyMatrix4(l.makeRotationAxis(o,m))}a[f].crossVectors(i[f],r[f])}if(e===!0){let f=Math.acos(Ye(r[0].dot(r[t]),-1,1));f/=t,i[0].dot(o.crossVectors(r[0],r[t]))>0&&(f=-f);for(let m=1;m<=t;m++)r[m].applyMatrix4(l.makeRotationAxis(i[m],f*m)),a[m].crossVectors(i[m],r[m])}return{tangents:i,normals:r,binormals:a}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){let t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}},jr=class extends Sn{constructor(t=0,e=0,n=1,i=1,r=0,a=Math.PI*2,o=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=n,this.yRadius=i,this.aStartAngle=r,this.aEndAngle=a,this.aClockwise=o,this.aRotation=l}getPoint(t,e=new tt){let n=e,i=Math.PI*2,r=this.aEndAngle-this.aStartAngle,a=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=i;for(;r>i;)r-=i;r<Number.EPSILON&&(a?r=0:r=i),this.aClockwise===!0&&!a&&(r===i?r=-i:r=r-i);let o=this.aStartAngle+t*r,l=this.aX+this.xRadius*Math.cos(o),c=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){let h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),d=l-this.aX,f=c-this.aY;l=d*h-f*u+this.aX,c=d*u+f*h+this.aY}return n.set(l,c)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){let t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}},ph=class extends jr{constructor(t,e,n,i,r,a){super(t,e,n,n,i,r,a),this.isArcCurve=!0,this.type="ArcCurve"}};function $h(){let s=0,t=0,e=0,n=0;function i(r,a,o,l){s=r,t=o,e=-3*r+3*a-2*o-l,n=2*r-2*a+o+l}return{initCatmullRom:function(r,a,o,l,c){i(a,o,c*(o-r),c*(l-a))},initNonuniformCatmullRom:function(r,a,o,l,c,h,u){let d=(a-r)/c-(o-r)/(c+h)+(o-a)/h,f=(o-a)/h-(l-a)/(h+u)+(l-o)/u;d*=h,f*=h,i(a,o,d,f)},calc:function(r){let a=r*r,o=a*r;return s+t*r+e*a+n*o}}}var ja=new C,ic=new $h,sc=new $h,rc=new $h,En=class extends Sn{constructor(t=[],e=!1,n="centripetal",i=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=n,this.tension=i}getPoint(t,e=new C){let n=e,i=this.points,r=i.length,a=(r-(this.closed?0:1))*t,o=Math.floor(a),l=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/r)+1)*r:l===0&&o===r-1&&(o=r-2,l=1);let c,h;this.closed||o>0?c=i[(o-1)%r]:(ja.subVectors(i[0],i[1]).add(i[0]),c=ja);let u=i[o%r],d=i[(o+1)%r];if(this.closed||o+2<r?h=i[(o+2)%r]:(ja.subVectors(i[r-1],i[r-2]).add(i[r-1]),h=ja),this.curveType==="centripetal"||this.curveType==="chordal"){let f=this.curveType==="chordal"?.5:.25,m=Math.pow(c.distanceToSquared(u),f),x=Math.pow(u.distanceToSquared(d),f),g=Math.pow(d.distanceToSquared(h),f);x<1e-4&&(x=1),m<1e-4&&(m=x),g<1e-4&&(g=x),ic.initNonuniformCatmullRom(c.x,u.x,d.x,h.x,m,x,g),sc.initNonuniformCatmullRom(c.y,u.y,d.y,h.y,m,x,g),rc.initNonuniformCatmullRom(c.z,u.z,d.z,h.z,m,x,g)}else this.curveType==="catmullrom"&&(ic.initCatmullRom(c.x,u.x,d.x,h.x,this.tension),sc.initCatmullRom(c.y,u.y,d.y,h.y,this.tension),rc.initCatmullRom(c.z,u.z,d.z,h.z,this.tension));return n.set(ic.calc(l),sc.calc(l),rc.calc(l)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let i=t.points[e];this.points.push(i.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){let i=this.points[e];t.points.push(i.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let i=t.points[e];this.points.push(new C().fromArray(i))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}};function zd(s,t,e,n,i){let r=(n-t)*.5,a=(i-e)*.5,o=s*s,l=s*o;return(2*e-2*n+r+a)*l+(-3*e+3*n-2*r-a)*o+r*s+e}function tv(s,t){let e=1-s;return e*e*t}function ev(s,t){return 2*(1-s)*s*t}function nv(s,t){return s*s*t}function Wr(s,t,e,n){return tv(s,t)+ev(s,e)+nv(s,n)}function iv(s,t){let e=1-s;return e*e*e*t}function sv(s,t){let e=1-s;return 3*e*e*s*t}function rv(s,t){return 3*(1-s)*s*s*t}function av(s,t){return s*s*s*t}function Xr(s,t,e,n,i){return iv(s,t)+sv(s,e)+rv(s,n)+av(s,i)}var To=class extends Sn{constructor(t=new tt,e=new tt,n=new tt,i=new tt){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=n,this.v3=i}getPoint(t,e=new tt){let n=e,i=this.v0,r=this.v1,a=this.v2,o=this.v3;return n.set(Xr(t,i.x,r.x,a.x,o.x),Xr(t,i.y,r.y,a.y,o.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},mh=class extends Sn{constructor(t=new C,e=new C,n=new C,i=new C){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=n,this.v3=i}getPoint(t,e=new C){let n=e,i=this.v0,r=this.v1,a=this.v2,o=this.v3;return n.set(Xr(t,i.x,r.x,a.x,o.x),Xr(t,i.y,r.y,a.y,o.y),Xr(t,i.z,r.z,a.z,o.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}},Ao=class extends Sn{constructor(t=new tt,e=new tt){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new tt){let n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new tt){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},gh=class extends Sn{constructor(t=new C,e=new C){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new C){let n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new C){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Ro=class extends Sn{constructor(t=new tt,e=new tt,n=new tt){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new tt){let n=e,i=this.v0,r=this.v1,a=this.v2;return n.set(Wr(t,i.x,r.x,a.x),Wr(t,i.y,r.y,a.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Co=class extends Sn{constructor(t=new C,e=new C,n=new C){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new C){let n=e,i=this.v0,r=this.v1,a=this.v2;return n.set(Wr(t,i.x,r.x,a.x),Wr(t,i.y,r.y,a.y),Wr(t,i.z,r.z,a.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){let t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}},Po=class extends Sn{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new tt){let n=e,i=this.points,r=(i.length-1)*t,a=Math.floor(r),o=r-a,l=i[a===0?a:a-1],c=i[a],h=i[a>i.length-2?i.length-1:a+1],u=i[a>i.length-3?i.length-1:a+2];return n.set(zd(o,l.x,c.x,h.x,u.x),zd(o,l.y,c.y,h.y,u.y)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let i=t.points[e];this.points.push(i.clone())}return this}toJSON(){let t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){let i=this.points[e];t.points.push(i.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){let i=t.points[e];this.points.push(new tt().fromArray(i))}return this}},xh=Object.freeze({__proto__:null,ArcCurve:ph,CatmullRomCurve3:En,CubicBezierCurve:To,CubicBezierCurve3:mh,EllipseCurve:jr,LineCurve:Ao,LineCurve3:gh,QuadraticBezierCurve:Ro,QuadraticBezierCurve3:Co,SplineCurve:Po}),vh=class extends Sn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(t){this.curves.push(t)}closePath(){let t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);if(!t.equals(e)){let n=t.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new xh[n](e,t))}return this}getPoint(t,e){let n=t*this.getLength(),i=this.getCurveLengths(),r=0;for(;r<i.length;){if(i[r]>=n){let a=i[r]-n,o=this.curves[r],l=o.getLength(),c=l===0?0:1-a/l;return o.getPointAt(c,e)}r++}return null}getLength(){let t=this.getCurveLengths();return t[t.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let t=[],e=0;for(let n=0,i=this.curves.length;n<i;n++)e+=this.curves[n].getLength(),t.push(e);return this.cacheLengths=t,t}getSpacedPoints(t=40){let e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return this.autoClose&&e.push(e[0]),e}getPoints(t=12){let e=[],n;for(let i=0,r=this.curves;i<r.length;i++){let a=r[i],o=a.isEllipseCurve?t*2:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?t*a.points.length:t,l=a.getPoints(o);for(let c=0;c<l.length;c++){let h=l[c];n&&n.equals(h)||(e.push(h),n=h)}}return this.autoClose&&e.length>1&&!e[e.length-1].equals(e[0])&&e.push(e[0]),e}copy(t){super.copy(t),this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){let i=t.curves[e];this.curves.push(i.clone())}return this.autoClose=t.autoClose,this}toJSON(){let t=super.toJSON();t.autoClose=this.autoClose,t.curves=[];for(let e=0,n=this.curves.length;e<n;e++){let i=this.curves[e];t.curves.push(i.toJSON())}return t}fromJSON(t){super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];for(let e=0,n=t.curves.length;e<n;e++){let i=t.curves[e];this.curves.push(new xh[i.type]().fromJSON(i))}return this}},yh=class extends vh{constructor(t){super(),this.type="Path",this.currentPoint=new tt,t&&this.setFromPoints(t)}setFromPoints(t){this.moveTo(t[0].x,t[0].y);for(let e=1,n=t.length;e<n;e++)this.lineTo(t[e].x,t[e].y);return this}moveTo(t,e){return this.currentPoint.set(t,e),this}lineTo(t,e){let n=new Ao(this.currentPoint.clone(),new tt(t,e));return this.curves.push(n),this.currentPoint.set(t,e),this}quadraticCurveTo(t,e,n,i){let r=new Ro(this.currentPoint.clone(),new tt(t,e),new tt(n,i));return this.curves.push(r),this.currentPoint.set(n,i),this}bezierCurveTo(t,e,n,i,r,a){let o=new To(this.currentPoint.clone(),new tt(t,e),new tt(n,i),new tt(r,a));return this.curves.push(o),this.currentPoint.set(r,a),this}splineThru(t){let e=[this.currentPoint.clone()].concat(t),n=new Po(e);return this.curves.push(n),this.currentPoint.copy(t[t.length-1]),this}arc(t,e,n,i,r,a){let o=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(t+o,e+l,n,i,r,a),this}absarc(t,e,n,i,r,a){return this.absellipse(t,e,n,n,i,r,a),this}ellipse(t,e,n,i,r,a,o,l){let c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(t+c,e+h,n,i,r,a,o,l),this}absellipse(t,e,n,i,r,a,o,l){let c=new jr(t,e,n,i,r,a,o,l);if(this.curves.length>0){let u=c.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(c);let h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(t){return super.copy(t),this.currentPoint.copy(t.currentPoint),this}toJSON(){let t=super.toJSON();return t.currentPoint=this.currentPoint.toArray(),t}fromJSON(t){return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this}},vs=class s extends Gt{constructor(t=[new tt(0,-.5),new tt(.5,0),new tt(0,.5)],e=12,n=0,i=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:t,segments:e,phiStart:n,phiLength:i},e=Math.floor(e),i=Ye(i,0,Math.PI*2);let r=[],a=[],o=[],l=[],c=[],h=1/e,u=new C,d=new tt,f=new C,m=new C,x=new C,g=0,p=0;for(let v=0;v<=t.length-1;v++)switch(v){case 0:g=t[v+1].x-t[v].x,p=t[v+1].y-t[v].y,f.x=p*1,f.y=-g,f.z=p*0,x.copy(f),f.normalize(),l.push(f.x,f.y,f.z);break;case t.length-1:l.push(x.x,x.y,x.z);break;default:g=t[v+1].x-t[v].x,p=t[v+1].y-t[v].y,f.x=p*1,f.y=-g,f.z=p*0,m.copy(f),f.x+=x.x,f.y+=x.y,f.z+=x.z,f.normalize(),l.push(f.x,f.y,f.z),x.copy(m)}for(let v=0;v<=e;v++){let y=n+v*h*i,_=Math.sin(y),S=Math.cos(y);for(let M=0;M<=t.length-1;M++){u.x=t[M].x*_,u.y=t[M].y,u.z=t[M].x*S,a.push(u.x,u.y,u.z),d.x=v/e,d.y=M/(t.length-1),o.push(d.x,d.y);let E=l[3*M+0]*_,A=l[3*M+1],w=l[3*M+0]*S;c.push(E,A,w)}}for(let v=0;v<e;v++)for(let y=0;y<t.length-1;y++){let _=y+v*t.length,S=_,M=_+t.length,E=_+t.length+1,A=_+1;r.push(S,M,A),r.push(E,A,M)}this.setIndex(r),this.setAttribute("position",new wt(a,3)),this.setAttribute("uv",new wt(o,2)),this.setAttribute("normal",new wt(c,3))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.points,t.segments,t.phiStart,t.phiLength)}},Io=class s extends vs{constructor(t=1,e=1,n=4,i=8){let r=new yh;r.absarc(0,-e/2,t,Math.PI*1.5,0),r.absarc(0,e/2,t,0,Math.PI*.5),super(r.getPoints(n),i),this.type="CapsuleGeometry",this.parameters={radius:t,length:e,capSegments:n,radialSegments:i}}static fromJSON(t){return new s(t.radius,t.length,t.capSegments,t.radialSegments)}},ys=class s extends Gt{constructor(t=1,e=32,n=0,i=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:i},e=Math.max(3,e);let r=[],a=[],o=[],l=[],c=new C,h=new tt;a.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let u=0,d=3;u<=e;u++,d+=3){let f=n+u/e*i;c.x=t*Math.cos(f),c.y=t*Math.sin(f),a.push(c.x,c.y,c.z),o.push(0,0,1),h.x=(a[d]/t+1)/2,h.y=(a[d+1]/t+1)/2,l.push(h.x,h.y)}for(let u=1;u<=e;u++)r.push(u,u+1,0);this.setIndex(r),this.setAttribute("position",new wt(a,3)),this.setAttribute("normal",new wt(o,3)),this.setAttribute("uv",new wt(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.radius,t.segments,t.thetaStart,t.thetaLength)}},ke=class s extends Gt{constructor(t=1,e=1,n=1,i=32,r=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:i,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:l};let c=this;i=Math.floor(i),r=Math.floor(r);let h=[],u=[],d=[],f=[],m=0,x=[],g=n/2,p=0;v(),a===!1&&(t>0&&y(!0),e>0&&y(!1)),this.setIndex(h),this.setAttribute("position",new wt(u,3)),this.setAttribute("normal",new wt(d,3)),this.setAttribute("uv",new wt(f,2));function v(){let _=new C,S=new C,M=0,E=(e-t)/n;for(let A=0;A<=r;A++){let w=[],b=A/r,P=b*(e-t)+t;for(let D=0;D<=i;D++){let U=D/i,F=U*l+o,q=Math.sin(F),V=Math.cos(F);S.x=P*q,S.y=-b*n+g,S.z=P*V,u.push(S.x,S.y,S.z),_.set(q,E,V).normalize(),d.push(_.x,_.y,_.z),f.push(U,1-b),w.push(m++)}x.push(w)}for(let A=0;A<i;A++)for(let w=0;w<r;w++){let b=x[w][A],P=x[w+1][A],D=x[w+1][A+1],U=x[w][A+1];(t>0||w!==0)&&(h.push(b,P,U),M+=3),(e>0||w!==r-1)&&(h.push(P,D,U),M+=3)}c.addGroup(p,M,0),p+=M}function y(_){let S=m,M=new tt,E=new C,A=0,w=_===!0?t:e,b=_===!0?1:-1;for(let D=1;D<=i;D++)u.push(0,g*b,0),d.push(0,b,0),f.push(.5,.5),m++;let P=m;for(let D=0;D<=i;D++){let F=D/i*l+o,q=Math.cos(F),V=Math.sin(F);E.x=w*V,E.y=g*b,E.z=w*q,u.push(E.x,E.y,E.z),d.push(0,b,0),M.x=q*.5+.5,M.y=V*.5*b+.5,f.push(M.x,M.y),m++}for(let D=0;D<i;D++){let U=S+D,F=P+D;_===!0?h.push(F,F+1,U):h.push(F+1,F,U),A+=3}c.addGroup(p,A,_===!0?1:2),p+=A}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},_s=class s extends ke{constructor(t=1,e=1,n=32,i=1,r=!1,a=0,o=Math.PI*2){super(0,t,e,n,i,r,a,o),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:n,heightSegments:i,openEnded:r,thetaStart:a,thetaLength:o}}static fromJSON(t){return new s(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Lo=class s extends Gt{constructor(t=[],e=[],n=1,i=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:n,detail:i};let r=[],a=[];o(i),c(n),h(),this.setAttribute("position",new wt(r,3)),this.setAttribute("normal",new wt(r.slice(),3)),this.setAttribute("uv",new wt(a,2)),i===0?this.computeVertexNormals():this.normalizeNormals();function o(v){let y=new C,_=new C,S=new C;for(let M=0;M<e.length;M+=3)f(e[M+0],y),f(e[M+1],_),f(e[M+2],S),l(y,_,S,v)}function l(v,y,_,S){let M=S+1,E=[];for(let A=0;A<=M;A++){E[A]=[];let w=v.clone().lerp(_,A/M),b=y.clone().lerp(_,A/M),P=M-A;for(let D=0;D<=P;D++)D===0&&A===M?E[A][D]=w:E[A][D]=w.clone().lerp(b,D/P)}for(let A=0;A<M;A++)for(let w=0;w<2*(M-A)-1;w++){let b=Math.floor(w/2);w%2===0?(d(E[A][b+1]),d(E[A+1][b]),d(E[A][b])):(d(E[A][b+1]),d(E[A+1][b+1]),d(E[A+1][b]))}}function c(v){let y=new C;for(let _=0;_<r.length;_+=3)y.x=r[_+0],y.y=r[_+1],y.z=r[_+2],y.normalize().multiplyScalar(v),r[_+0]=y.x,r[_+1]=y.y,r[_+2]=y.z}function h(){let v=new C;for(let y=0;y<r.length;y+=3){v.x=r[y+0],v.y=r[y+1],v.z=r[y+2];let _=g(v)/2/Math.PI+.5,S=p(v)/Math.PI+.5;a.push(_,1-S)}m(),u()}function u(){for(let v=0;v<a.length;v+=6){let y=a[v+0],_=a[v+2],S=a[v+4],M=Math.max(y,_,S),E=Math.min(y,_,S);M>.9&&E<.1&&(y<.2&&(a[v+0]+=1),_<.2&&(a[v+2]+=1),S<.2&&(a[v+4]+=1))}}function d(v){r.push(v.x,v.y,v.z)}function f(v,y){let _=v*3;y.x=t[_+0],y.y=t[_+1],y.z=t[_+2]}function m(){let v=new C,y=new C,_=new C,S=new C,M=new tt,E=new tt,A=new tt;for(let w=0,b=0;w<r.length;w+=9,b+=6){v.set(r[w+0],r[w+1],r[w+2]),y.set(r[w+3],r[w+4],r[w+5]),_.set(r[w+6],r[w+7],r[w+8]),M.set(a[b+0],a[b+1]),E.set(a[b+2],a[b+3]),A.set(a[b+4],a[b+5]),S.copy(v).add(y).add(_).divideScalar(3);let P=g(S);x(M,b+0,v,P),x(E,b+2,y,P),x(A,b+4,_,P)}}function x(v,y,_,S){S<0&&v.x===1&&(a[y]=v.x-1),_.x===0&&_.z===0&&(a[y]=S/2/Math.PI+.5)}function g(v){return Math.atan2(v.z,-v.x)}function p(v){return Math.atan2(-v.y,Math.sqrt(v.x*v.x+v.z*v.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.vertices,t.indices,t.radius,t.details)}},Do=class s extends Lo{constructor(t=1,e=0){let n=(1+Math.sqrt(5))/2,i=1/n,r=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-i,-n,0,-i,n,0,i,-n,0,i,n,-i,-n,0,-i,n,0,i,-n,0,i,n,0,-n,0,-i,n,0,-i,-n,0,i,n,0,i],a=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(r,a,t,e),this.type="DodecahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new s(t.radius,t.detail)}};var ko=class s extends Lo{constructor(t=1,e=0){let n=(1+Math.sqrt(5))/2,i=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(i,r,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new s(t.radius,t.detail)}};var Ms=class s extends Gt{constructor(t=.5,e=1,n=32,i=1,r=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:n,phiSegments:i,thetaStart:r,thetaLength:a},n=Math.max(3,n),i=Math.max(1,i);let o=[],l=[],c=[],h=[],u=t,d=(e-t)/i,f=new C,m=new tt;for(let x=0;x<=i;x++){for(let g=0;g<=n;g++){let p=r+g/n*a;f.x=u*Math.cos(p),f.y=u*Math.sin(p),l.push(f.x,f.y,f.z),c.push(0,0,1),m.x=(f.x/e+1)/2,m.y=(f.y/e+1)/2,h.push(m.x,m.y)}u+=d}for(let x=0;x<i;x++){let g=x*(n+1);for(let p=0;p<n;p++){let v=p+g,y=v,_=v+n+1,S=v+n+2,M=v+1;o.push(y,_,M),o.push(_,S,M)}}this.setIndex(o),this.setAttribute("position",new wt(l,3)),this.setAttribute("normal",new wt(c,3)),this.setAttribute("uv",new wt(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}};var mn=class s extends Gt{constructor(t=1,e=32,n=16,i=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:i,phiLength:r,thetaStart:a,thetaLength:o},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));let l=Math.min(a+o,Math.PI),c=0,h=[],u=new C,d=new C,f=[],m=[],x=[],g=[];for(let p=0;p<=n;p++){let v=[],y=p/n,_=0;p===0&&a===0?_=.5/e:p===n&&l===Math.PI&&(_=-.5/e);for(let S=0;S<=e;S++){let M=S/e;u.x=-t*Math.cos(i+M*r)*Math.sin(a+y*o),u.y=t*Math.cos(a+y*o),u.z=t*Math.sin(i+M*r)*Math.sin(a+y*o),m.push(u.x,u.y,u.z),d.copy(u).normalize(),x.push(d.x,d.y,d.z),g.push(M+_,1-y),v.push(c++)}h.push(v)}for(let p=0;p<n;p++)for(let v=0;v<e;v++){let y=h[p][v+1],_=h[p][v],S=h[p+1][v],M=h[p+1][v+1];(p!==0||a>0)&&f.push(y,_,M),(p!==n-1||l<Math.PI)&&f.push(_,S,M)}this.setIndex(f),this.setAttribute("position",new wt(m,3)),this.setAttribute("normal",new wt(x,3)),this.setAttribute("uv",new wt(g,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};var $i=class s extends Gt{constructor(t=1,e=.4,n=12,i=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:n,tubularSegments:i,arc:r},n=Math.floor(n),i=Math.floor(i);let a=[],o=[],l=[],c=[],h=new C,u=new C,d=new C;for(let f=0;f<=n;f++)for(let m=0;m<=i;m++){let x=m/i*r,g=f/n*Math.PI*2;u.x=(t+e*Math.cos(g))*Math.cos(x),u.y=(t+e*Math.cos(g))*Math.sin(x),u.z=e*Math.sin(g),o.push(u.x,u.y,u.z),h.x=t*Math.cos(x),h.y=t*Math.sin(x),d.subVectors(u,h).normalize(),l.push(d.x,d.y,d.z),c.push(m/i),c.push(f/n)}for(let f=1;f<=n;f++)for(let m=1;m<=i;m++){let x=(i+1)*f+m-1,g=(i+1)*(f-1)+m-1,p=(i+1)*(f-1)+m,v=(i+1)*f+m;a.push(x,g,v),a.push(g,p,v)}this.setIndex(a),this.setAttribute("position",new wt(o,3)),this.setAttribute("normal",new wt(l,3)),this.setAttribute("uv",new wt(c,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new s(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}};var ci=class s extends Gt{constructor(t=new Co(new C(-1,-1,0),new C(-1,1,0),new C(1,1,0)),e=64,n=1,i=8,r=!1){super(),this.type="TubeGeometry",this.parameters={path:t,tubularSegments:e,radius:n,radialSegments:i,closed:r};let a=t.computeFrenetFrames(e,r);this.tangents=a.tangents,this.normals=a.normals,this.binormals=a.binormals;let o=new C,l=new C,c=new tt,h=new C,u=[],d=[],f=[],m=[];x(),this.setIndex(m),this.setAttribute("position",new wt(u,3)),this.setAttribute("normal",new wt(d,3)),this.setAttribute("uv",new wt(f,2));function x(){for(let y=0;y<e;y++)g(y);g(r===!1?e:0),v(),p()}function g(y){h=t.getPointAt(y/e,h);let _=a.normals[y],S=a.binormals[y];for(let M=0;M<=i;M++){let E=M/i*Math.PI*2,A=Math.sin(E),w=-Math.cos(E);l.x=w*_.x+A*S.x,l.y=w*_.y+A*S.y,l.z=w*_.z+A*S.z,l.normalize(),d.push(l.x,l.y,l.z),o.x=h.x+n*l.x,o.y=h.y+n*l.y,o.z=h.z+n*l.z,u.push(o.x,o.y,o.z)}}function p(){for(let y=1;y<=e;y++)for(let _=1;_<=i;_++){let S=(i+1)*(y-1)+(_-1),M=(i+1)*y+(_-1),E=(i+1)*y+_,A=(i+1)*(y-1)+_;m.push(S,M,A),m.push(M,E,A)}}function v(){for(let y=0;y<=e;y++)for(let _=0;_<=i;_++)c.x=y/e,c.y=_/i,f.push(c.x,c.y)}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){let t=super.toJSON();return t.path=this.parameters.path.toJSON(),t}static fromJSON(t){return new s(new xh[t.path.type]().fromJSON(t.path),t.tubularSegments,t.radius,t.radialSegments,t.closed)}};var Uo=class extends ve{static get type(){return"RawShaderMaterial"}constructor(t){super(t),this.isRawShaderMaterial=!0}},at=class extends li{static get type(){return"MeshStandardMaterial"}constructor(t){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.color=new ot(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new ot(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=sf,this.normalScale=new tt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new nn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}},$n=class extends at{static get type(){return"MeshPhysicalMaterial"}constructor(t){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new tt(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Ye(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(e){this.ior=(1+.4*e)/(1-.4*e)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new ot(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new ot(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new ot(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(t)}get anisotropy(){return this._anisotropy}set anisotropy(t){this._anisotropy>0!=t>0&&this.version++,this._anisotropy=t}get clearcoat(){return this._clearcoat}set clearcoat(t){this._clearcoat>0!=t>0&&this.version++,this._clearcoat=t}get iridescence(){return this._iridescence}set iridescence(t){this._iridescence>0!=t>0&&this.version++,this._iridescence=t}get dispersion(){return this._dispersion}set dispersion(t){this._dispersion>0!=t>0&&this.version++,this._dispersion=t}get sheen(){return this._sheen}set sheen(t){this._sheen>0!=t>0&&this.version++,this._sheen=t}get transmission(){return this._transmission}set transmission(t){this._transmission>0!=t>0&&this.version++,this._transmission=t}copy(t){return super.copy(t),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=t.anisotropy,this.anisotropyRotation=t.anisotropyRotation,this.anisotropyMap=t.anisotropyMap,this.clearcoat=t.clearcoat,this.clearcoatMap=t.clearcoatMap,this.clearcoatRoughness=t.clearcoatRoughness,this.clearcoatRoughnessMap=t.clearcoatRoughnessMap,this.clearcoatNormalMap=t.clearcoatNormalMap,this.clearcoatNormalScale.copy(t.clearcoatNormalScale),this.dispersion=t.dispersion,this.ior=t.ior,this.iridescence=t.iridescence,this.iridescenceMap=t.iridescenceMap,this.iridescenceIOR=t.iridescenceIOR,this.iridescenceThicknessRange=[...t.iridescenceThicknessRange],this.iridescenceThicknessMap=t.iridescenceThicknessMap,this.sheen=t.sheen,this.sheenColor.copy(t.sheenColor),this.sheenColorMap=t.sheenColorMap,this.sheenRoughness=t.sheenRoughness,this.sheenRoughnessMap=t.sheenRoughnessMap,this.transmission=t.transmission,this.transmissionMap=t.transmissionMap,this.thickness=t.thickness,this.thicknessMap=t.thicknessMap,this.attenuationDistance=t.attenuationDistance,this.attenuationColor.copy(t.attenuationColor),this.specularIntensity=t.specularIntensity,this.specularIntensityMap=t.specularIntensityMap,this.specularColor.copy(t.specularColor),this.specularColorMap=t.specularColorMap,this}};function Qa(s,t,e){return!s||!e&&s.constructor===t?s:typeof t.BYTES_PER_ELEMENT=="number"?new t(s):Array.prototype.slice.call(s)}function ov(s){return ArrayBuffer.isView(s)&&!(s instanceof DataView)}var cr=class{constructor(t,e,n,i){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=i!==void 0?i:new e.constructor(n),this.sampleValues=e,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,n=this._cachedIndex,i=e[n],r=e[n-1];n:{t:{let a;e:{i:if(!(t<i)){for(let o=n+2;;){if(i===void 0){if(t<r)break i;return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===o)break;if(r=i,i=e[++n],t<i)break t}a=e.length;break e}if(!(t>=r)){let o=e[1];t<o&&(n=2,r=o);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(i=r,r=e[--n-1],t>=r)break t}a=n,n=0;break e}break n}for(;n<a;){let o=n+a>>>1;t<e[o]?a=o:n=o+1}if(i=e[n],r=e[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===void 0)return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,i)}return this.interpolate_(n,r,t,i)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,n=this.sampleValues,i=this.valueSize,r=t*i;for(let a=0;a!==i;++a)e[a]=n[r+a];return e}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},_h=class extends cr{constructor(t,e,n,i){super(t,e,n,i),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Uu,endingEnd:Uu}}intervalChanged_(t,e,n){let i=this.parameterPositions,r=t-2,a=t+1,o=i[r],l=i[a];if(o===void 0)switch(this.getSettings_().endingStart){case Nu:r=t,o=2*e-n;break;case Fu:r=i.length-2,o=e+i[r]-i[r+1];break;default:r=t,o=n}if(l===void 0)switch(this.getSettings_().endingEnd){case Nu:a=t,l=2*n-e;break;case Fu:a=1,l=n+i[1]-i[0];break;default:a=t-1,l=e}let c=(n-e)*.5,h=this.valueSize;this._weightPrev=c/(e-o),this._weightNext=c/(l-n),this._offsetPrev=r*h,this._offsetNext=a*h}interpolate_(t,e,n,i){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=t*o,c=l-o,h=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,m=(n-e)/(i-e),x=m*m,g=x*m,p=-d*g+2*d*x-d*m,v=(1+d)*g+(-1.5-2*d)*x+(-.5+d)*m+1,y=(-1-f)*g+(1.5+f)*x+.5*m,_=f*g-f*x;for(let S=0;S!==o;++S)r[S]=p*a[h+S]+v*a[c+S]+y*a[l+S]+_*a[u+S];return r}},Mh=class extends cr{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t,e,n,i){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=t*o,c=l-o,h=(n-e)/(i-e),u=1-h;for(let d=0;d!==o;++d)r[d]=a[c+d]*u+a[l+d]*h;return r}},bh=class extends cr{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t){return this.copySampleValue_(t-1)}},Zn=class{constructor(t,e,n,i){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=Qa(e,this.TimeBufferType),this.values=Qa(n,this.ValueBufferType),this.setInterpolation(i||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,n;if(e.toJSON!==this.toJSON)n=e.toJSON(t);else{n={name:t.name,times:Qa(t.times,Array),values:Qa(t.values,Array)};let i=t.getInterpolation();i!==t.DefaultInterpolation&&(n.interpolation=i)}return n.type=t.ValueTypeName,n}InterpolantFactoryMethodDiscrete(t){return new bh(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new Mh(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new _h(this.times,this.values,this.getValueSize(),t)}setInterpolation(t){let e;switch(t){case ro:e=this.InterpolantFactoryMethodDiscrete;break;case qc:e=this.InterpolantFactoryMethodLinear;break;case Tl:e=this.InterpolantFactoryMethodSmooth;break}if(e===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return ro;case this.InterpolantFactoryMethodLinear:return qc;case this.InterpolantFactoryMethodSmooth:return Tl}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let n=0,i=e.length;n!==i;++n)e[n]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let n=0,i=e.length;n!==i;++n)e[n]*=t}return this}trim(t,e){let n=this.times,i=n.length,r=0,a=i-1;for(;r!==i&&n[r]<t;)++r;for(;a!==-1&&n[a]>e;)--a;if(++a,r!==0||a!==i){r>=a&&(a=Math.max(a,1),r=a-1);let o=this.getValueSize();this.times=n.slice(r,a),this.values=this.values.slice(r*o,a*o)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),t=!1);let n=this.times,i=this.values,r=n.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),t=!1);let a=null;for(let o=0;o!==r;o++){let l=n[o];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,l),t=!1;break}if(a!==null&&a>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,l,a),t=!1;break}a=l}if(i!==void 0&&ov(i))for(let o=0,l=i.length;o!==l;++o){let c=i[o];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,c),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),n=this.getValueSize(),i=this.getInterpolation()===Tl,r=t.length-1,a=1;for(let o=1;o<r;++o){let l=!1,c=t[o],h=t[o+1];if(c!==h&&(o!==1||c!==t[0]))if(i)l=!0;else{let u=o*n,d=u-n,f=u+n;for(let m=0;m!==n;++m){let x=e[u+m];if(x!==e[d+m]||x!==e[f+m]){l=!0;break}}}if(l){if(o!==a){t[a]=t[o];let u=o*n,d=a*n;for(let f=0;f!==n;++f)e[d+f]=e[u+f]}++a}}if(r>0){t[a]=t[r];for(let o=r*n,l=a*n,c=0;c!==n;++c)e[l+c]=e[o+c];++a}return a!==t.length?(this.times=t.slice(0,a),this.values=e.slice(0,a*n)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),n=this.constructor,i=new n(this.name,t,e);return i.createInterpolant=this.createInterpolant,i}};Zn.prototype.TimeBufferType=Float32Array;Zn.prototype.ValueBufferType=Float32Array;Zn.prototype.DefaultInterpolation=qc;var bs=class extends Zn{constructor(t,e,n){super(t,e,n)}};bs.prototype.ValueTypeName="bool";bs.prototype.ValueBufferType=Array;bs.prototype.DefaultInterpolation=ro;bs.prototype.InterpolantFactoryMethodLinear=void 0;bs.prototype.InterpolantFactoryMethodSmooth=void 0;var wh=class extends Zn{};wh.prototype.ValueTypeName="color";var Sh=class extends Zn{};Sh.prototype.ValueTypeName="number";var Eh=class extends cr{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t,e,n,i){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=(n-e)/(i-e),c=t*o;for(let h=c+o;c!==h;c+=4)Fe.slerpFlat(r,0,a,c-o,a,c,l);return r}},No=class extends Zn{InterpolantFactoryMethodLinear(t){return new Eh(this.times,this.values,this.getValueSize(),t)}};No.prototype.ValueTypeName="quaternion";No.prototype.InterpolantFactoryMethodSmooth=void 0;var ws=class extends Zn{constructor(t,e,n){super(t,e,n)}};ws.prototype.ValueTypeName="string";ws.prototype.ValueBufferType=Array;ws.prototype.DefaultInterpolation=ro;ws.prototype.InterpolantFactoryMethodLinear=void 0;ws.prototype.InterpolantFactoryMethodSmooth=void 0;var Th=class extends Zn{};Th.prototype.ValueTypeName="vector";var Ah=class{constructor(t,e,n){let i=this,r=!1,a=0,o=0,l,c=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=n,this.itemStart=function(h){o++,r===!1&&i.onStart!==void 0&&i.onStart(h,a,o),r=!0},this.itemEnd=function(h){a++,i.onProgress!==void 0&&i.onProgress(h,a,o),a===o&&(r=!1,i.onLoad!==void 0&&i.onLoad())},this.itemError=function(h){i.onError!==void 0&&i.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){let u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,d=c.length;u<d;u+=2){let f=c[u],m=c[u+1];if(f.global&&(f.lastIndex=0),f.test(h))return m}return null}}},lv=new Ah,Rh=class{constructor(t){this.manager=t!==void 0?t:lv,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(t,e){let n=this;return new Promise(function(i,r){n.load(t,i,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}};Rh.DEFAULT_MATERIAL_NAME="__DEFAULT";var hr=class extends Le{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new ot(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(e.object.target=this.target.uuid),e}},Zi=class extends hr{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Le.DEFAULT_UP),this.updateMatrix(),this.groundColor=new ot(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}},ac=new Lt,Hd=new C,Vd=new C,Qr=class{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new tt(512,512),this.map=null,this.mapPass=null,this.matrix=new Lt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new $r,this._frameExtents=new tt(1,1),this._viewportCount=1,this._viewports=[new ue(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera,n=this.matrix;Hd.setFromMatrixPosition(t.matrixWorld),e.position.copy(Hd),Vd.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(Vd),e.updateMatrixWorld(),ac.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(ac),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(ac)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return this.intensity!==1&&(t.intensity=this.intensity),this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}},Ch=class extends Qr{constructor(){super(new Ue(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(t){let e=this.camera,n=oo*2*t.angle*this.focus,i=this.mapSize.width/this.mapSize.height,r=t.distance||e.far;(n!==e.fov||i!==e.aspect||r!==e.far)&&(e.fov=n,e.aspect=i,e.far=r,e.updateProjectionMatrix()),super.updateMatrices(t)}copy(t){return super.copy(t),this.focus=t.focus,this}},Ki=class extends hr{constructor(t,e,n=0,i=Math.PI/3,r=0,a=2){super(t,e),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(Le.DEFAULT_UP),this.updateMatrix(),this.target=new Le,this.distance=n,this.angle=i,this.penumbra=r,this.decay=a,this.map=null,this.shadow=new Ch}get power(){return this.intensity*Math.PI}set power(t){this.intensity=t/Math.PI}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.angle=t.angle,this.penumbra=t.penumbra,this.decay=t.decay,this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}},Gd=new Lt,zr=new C,oc=new C,Ph=class extends Qr{constructor(){super(new Ue(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new tt(4,2),this._viewportCount=6,this._viewports=[new ue(2,1,1,1),new ue(0,1,1,1),new ue(3,1,1,1),new ue(1,1,1,1),new ue(3,0,1,1),new ue(1,0,1,1)],this._cubeDirections=[new C(1,0,0),new C(-1,0,0),new C(0,0,1),new C(0,0,-1),new C(0,1,0),new C(0,-1,0)],this._cubeUps=[new C(0,1,0),new C(0,1,0),new C(0,1,0),new C(0,1,0),new C(0,0,1),new C(0,0,-1)]}updateMatrices(t,e=0){let n=this.camera,i=this.matrix,r=t.distance||n.far;r!==n.far&&(n.far=r,n.updateProjectionMatrix()),zr.setFromMatrixPosition(t.matrixWorld),n.position.copy(zr),oc.copy(n.position),oc.add(this._cubeDirections[e]),n.up.copy(this._cubeUps[e]),n.lookAt(oc),n.updateMatrixWorld(),i.makeTranslation(-zr.x,-zr.y,-zr.z),Gd.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Gd)}},ur=class extends hr{constructor(t,e,n=0,i=2){super(t,e),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=i,this.shadow=new Ph}get power(){return this.intensity*4*Math.PI}set power(t){this.intensity=t/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this}},Ih=class extends Qr{constructor(){super(new qi(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Ss=class extends hr{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Le.DEFAULT_UP),this.updateMatrix(),this.target=new Le,this.shadow=new Ih}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}};var Fo=class{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=Wd(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let e=Wd();t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t}return t}};function Wd(){return performance.now()}var Zh="\\[\\]\\.:\\/",cv=new RegExp("["+Zh+"]","g"),Kh="[^"+Zh+"]",hv="[^"+Zh.replace("\\.","")+"]",uv=/((?:WC+[\/:])*)/.source.replace("WC",Kh),dv=/(WCOD+)?/.source.replace("WCOD",hv),fv=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",Kh),pv=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",Kh),mv=new RegExp("^"+uv+dv+fv+pv+"$"),gv=["material","materials","bones","map"],Lh=class{constructor(t,e,n){let i=n||Re.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,i)}getValue(t,e){this.bind();let n=this._targetGroup.nCachedObjects_,i=this._bindings[n];i!==void 0&&i.getValue(t,e)}setValue(t,e){let n=this._bindings;for(let i=this._targetGroup.nCachedObjects_,r=n.length;i!==r;++i)n[i].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].unbind()}},Re=class s{constructor(t,e,n){this.path=e,this.parsedPath=n||s.parseTrackName(e),this.node=s.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,n){return t&&t.isAnimationObjectGroup?new s.Composite(t,e,n):new s(t,e,n)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(cv,"")}static parseTrackName(t){let e=mv.exec(t);if(e===null)throw new Error("PropertyBinding: Cannot parse trackName: "+t);let n={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},i=n.nodeName&&n.nodeName.lastIndexOf(".");if(i!==void 0&&i!==-1){let r=n.nodeName.substring(i+1);gv.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,i),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+t);return n}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let n=t.skeleton.getBoneByName(e);if(n!==void 0)return n}if(t.children){let n=function(r){for(let a=0;a<r.length;a++){let o=r[a];if(o.name===e||o.uuid===e)return o;let l=n(o.children);if(l)return l}return null},i=n(t.children);if(i)return i}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)t[e++]=n[i]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,n=e.objectName,i=e.propertyName,r=e.propertyIndex;if(t||(t=s.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=e.objectIndex;switch(n){case"materials":if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let h=0;h<t.length;h++)if(t[h].name===c){c=h;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[n]}if(c!==void 0){if(t[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[c]}}let a=t[i];if(a===void 0){let c=e.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+i+" but it wasn't found.",t);return}let o=this.Versioning.None;this.targetObject=t,t.needsUpdate!==void 0?o=this.Versioning.NeedsUpdate:t.matrixWorldNeedsUpdate!==void 0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(i==="morphTargetInfluences"){if(!t.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=r}else a.fromArray!==void 0&&a.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(l=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=i;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};Re.Composite=Lh;Re.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};Re.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};Re.prototype.GetterByBindingType=[Re.prototype._getValue_direct,Re.prototype._getValue_array,Re.prototype._getValue_arrayElement,Re.prototype._getValue_toArray];Re.prototype.SetterByBindingTypeAndVersioning=[[Re.prototype._setValue_direct,Re.prototype._setValue_direct_setNeedsUpdate,Re.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Re.prototype._setValue_array,Re.prototype._setValue_array_setNeedsUpdate,Re.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Re.prototype._setValue_arrayElement,Re.prototype._setValue_arrayElement_setNeedsUpdate,Re.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Re.prototype._setValue_fromArray,Re.prototype._setValue_fromArray_setNeedsUpdate,Re.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var ry=new Float32Array(1);typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Dh}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Dh);var Ho={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};var _n=class{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}},xv=new qi(-1,1,1,-1,0,1),Jh=class extends Gt{constructor(){super(),this.setAttribute("position",new wt([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new wt([0,2,0,0,2,0],2))}},vv=new Jh,ji=class{constructor(t){this._mesh=new it(vv,t)}dispose(){this._mesh.geometry.dispose()}render(t){t.render(this._mesh,xv)}get material(){return this._mesh.material}set material(t){this._mesh.material=t}};var fr=class extends _n{constructor(t,e){super(),this.textureID=e!==void 0?e:"tDiffuse",t instanceof ve?(this.uniforms=t.uniforms,this.material=t):t&&(this.uniforms=Tn.clone(t.uniforms),this.material=new ve({name:t.name!==void 0?t.name:"unspecified",defines:Object.assign({},t.defines),uniforms:this.uniforms,vertexShader:t.vertexShader,fragmentShader:t.fragmentShader})),this.fsQuad=new ji(this.material)}render(t,e,n){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=n.texture),this.fsQuad.material=this.material,this.renderToScreen?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(e),this.clear&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),this.fsQuad.render(t))}dispose(){this.material.dispose(),this.fsQuad.dispose()}};var na=class extends _n{constructor(t,e){super(),this.scene=t,this.camera=e,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(t,e,n){let i=t.getContext(),r=t.state;r.buffers.color.setMask(!1),r.buffers.depth.setMask(!1),r.buffers.color.setLocked(!0),r.buffers.depth.setLocked(!0);let a,o;this.inverse?(a=0,o=1):(a=1,o=0),r.buffers.stencil.setTest(!0),r.buffers.stencil.setOp(i.REPLACE,i.REPLACE,i.REPLACE),r.buffers.stencil.setFunc(i.ALWAYS,a,4294967295),r.buffers.stencil.setClear(o),r.buffers.stencil.setLocked(!0),t.setRenderTarget(n),this.clear&&t.clear(),t.render(this.scene,this.camera),t.setRenderTarget(e),this.clear&&t.clear(),t.render(this.scene,this.camera),r.buffers.color.setLocked(!1),r.buffers.depth.setLocked(!1),r.buffers.color.setMask(!0),r.buffers.depth.setMask(!0),r.buffers.stencil.setLocked(!1),r.buffers.stencil.setFunc(i.EQUAL,1,4294967295),r.buffers.stencil.setOp(i.KEEP,i.KEEP,i.KEEP),r.buffers.stencil.setLocked(!0)}},Vo=class extends _n{constructor(){super(),this.needsSwap=!1}render(t){t.state.buffers.stencil.setLocked(!1),t.state.buffers.stencil.setTest(!1)}};var Go=class{constructor(t,e){if(this.renderer=t,this._pixelRatio=t.getPixelRatio(),e===void 0){let n=t.getSize(new tt);this._width=n.width,this._height=n.height,e=new Ne(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:ln}),e.texture.name="EffectComposer.rt1"}else this._width=e.width,this._height=e.height;this.renderTarget1=e,this.renderTarget2=e.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new fr(Ho),this.copyPass.material.blending=oi,this.clock=new Fo}swapBuffers(){let t=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=t}addPass(t){this.passes.push(t),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(t,e){this.passes.splice(e,0,t),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(t){let e=this.passes.indexOf(t);e!==-1&&this.passes.splice(e,1)}isLastEnabledPass(t){for(let e=t+1;e<this.passes.length;e++)if(this.passes[e].enabled)return!1;return!0}render(t){t===void 0&&(t=this.clock.getDelta());let e=this.renderer.getRenderTarget(),n=!1;for(let i=0,r=this.passes.length;i<r;i++){let a=this.passes[i];if(a.enabled!==!1){if(a.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(i),a.render(this.renderer,this.writeBuffer,this.readBuffer,t,n),a.needsSwap){if(n){let o=this.renderer.getContext(),l=this.renderer.state.buffers.stencil;l.setFunc(o.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,t),l.setFunc(o.EQUAL,1,4294967295)}this.swapBuffers()}na!==void 0&&(a instanceof na?n=!0:a instanceof Vo&&(n=!1))}}this.renderer.setRenderTarget(e)}reset(t){if(t===void 0){let e=this.renderer.getSize(new tt);this._pixelRatio=this.renderer.getPixelRatio(),this._width=e.width,this._height=e.height,t=this.renderTarget1.clone(),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=t,this.renderTarget2=t.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(t,e){this._width=t,this._height=e;let n=this._width*this._pixelRatio,i=this._height*this._pixelRatio;this.renderTarget1.setSize(n,i),this.renderTarget2.setSize(n,i);for(let r=0;r<this.passes.length;r++)this.passes[r].setSize(n,i)}setPixelRatio(t){this._pixelRatio=t,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}};var Wo=class extends _n{constructor(t,e,n=null,i=null,r=null){super(),this.scene=t,this.camera=e,this.overrideMaterial=n,this.clearColor=i,this.clearAlpha=r,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this._oldClearColor=new ot}render(t,e,n){let i=t.autoClear;t.autoClear=!1;let r,a;this.overrideMaterial!==null&&(a=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(t.getClearColor(this._oldClearColor),t.setClearColor(this.clearColor,t.getClearAlpha())),this.clearAlpha!==null&&(r=t.getClearAlpha(),t.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&t.clearDepth(),t.setRenderTarget(this.renderToScreen?null:n),this.clear===!0&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),t.render(this.scene,this.camera),this.clearColor!==null&&t.setClearColor(this._oldClearColor),this.clearAlpha!==null&&t.setClearAlpha(r),this.overrideMaterial!==null&&(this.scene.overrideMaterial=a),t.autoClear=i}};var mf={name:"LuminosityHighPassShader",shaderID:"luminosityHighPass",uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new ot(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			float v = luminance( texel.xyz );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};var pr=class s extends _n{constructor(t,e,n,i){super(),this.strength=e!==void 0?e:1,this.radius=n,this.threshold=i,this.resolution=t!==void 0?new tt(t.x,t.y):new tt(256,256),this.clearColor=new ot(0,0,0),this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let r=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);this.renderTargetBright=new Ne(r,a,{type:ln}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let u=0;u<this.nMips;u++){let d=new Ne(r,a,{type:ln});d.texture.name="UnrealBloomPass.h"+u,d.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(d);let f=new Ne(r,a,{type:ln});f.texture.name="UnrealBloomPass.v"+u,f.texture.generateMipmaps=!1,this.renderTargetsVertical.push(f),r=Math.round(r/2),a=Math.round(a/2)}let o=mf;this.highPassUniforms=Tn.clone(o.uniforms),this.highPassUniforms.luminosityThreshold.value=i,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new ve({uniforms:this.highPassUniforms,vertexShader:o.vertexShader,fragmentShader:o.fragmentShader}),this.separableBlurMaterials=[];let l=[3,5,7,9,11];r=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);for(let u=0;u<this.nMips;u++)this.separableBlurMaterials.push(this.getSeperableBlurMaterial(l[u])),this.separableBlurMaterials[u].uniforms.invSize.value=new tt(1/r,1/a),r=Math.round(r/2),a=Math.round(a/2);this.compositeMaterial=this.getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=e,this.compositeMaterial.uniforms.bloomRadius.value=.1;let c=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=c,this.bloomTintColors=[new C(1,1,1),new C(1,1,1),new C(1,1,1),new C(1,1,1),new C(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors;let h=Ho;this.copyUniforms=Tn.clone(h.uniforms),this.blendMaterial=new ve({uniforms:this.copyUniforms,vertexShader:h.vertexShader,fragmentShader:h.fragmentShader,blending:ms,depthTest:!1,depthWrite:!1,transparent:!0}),this.enabled=!0,this.needsSwap=!1,this._oldClearColor=new ot,this.oldClearAlpha=1,this.basic=new De,this.fsQuad=new ji(null)}dispose(){for(let t=0;t<this.renderTargetsHorizontal.length;t++)this.renderTargetsHorizontal[t].dispose();for(let t=0;t<this.renderTargetsVertical.length;t++)this.renderTargetsVertical[t].dispose();this.renderTargetBright.dispose();for(let t=0;t<this.separableBlurMaterials.length;t++)this.separableBlurMaterials[t].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this.basic.dispose(),this.fsQuad.dispose()}setSize(t,e){let n=Math.round(t/2),i=Math.round(e/2);this.renderTargetBright.setSize(n,i);for(let r=0;r<this.nMips;r++)this.renderTargetsHorizontal[r].setSize(n,i),this.renderTargetsVertical[r].setSize(n,i),this.separableBlurMaterials[r].uniforms.invSize.value=new tt(1/n,1/i),n=Math.round(n/2),i=Math.round(i/2)}render(t,e,n,i,r){t.getClearColor(this._oldClearColor),this.oldClearAlpha=t.getClearAlpha();let a=t.autoClear;t.autoClear=!1,t.setClearColor(this.clearColor,0),r&&t.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this.fsQuad.material=this.basic,this.basic.map=n.texture,t.setRenderTarget(null),t.clear(),this.fsQuad.render(t)),this.highPassUniforms.tDiffuse.value=n.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this.fsQuad.material=this.materialHighPassFilter,t.setRenderTarget(this.renderTargetBright),t.clear(),this.fsQuad.render(t);let o=this.renderTargetBright;for(let l=0;l<this.nMips;l++)this.fsQuad.material=this.separableBlurMaterials[l],this.separableBlurMaterials[l].uniforms.colorTexture.value=o.texture,this.separableBlurMaterials[l].uniforms.direction.value=s.BlurDirectionX,t.setRenderTarget(this.renderTargetsHorizontal[l]),t.clear(),this.fsQuad.render(t),this.separableBlurMaterials[l].uniforms.colorTexture.value=this.renderTargetsHorizontal[l].texture,this.separableBlurMaterials[l].uniforms.direction.value=s.BlurDirectionY,t.setRenderTarget(this.renderTargetsVertical[l]),t.clear(),this.fsQuad.render(t),o=this.renderTargetsVertical[l];this.fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,t.setRenderTarget(this.renderTargetsHorizontal[0]),t.clear(),this.fsQuad.render(t),this.fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,r&&t.state.buffers.stencil.setTest(!0),this.renderToScreen?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(n),this.fsQuad.render(t)),t.setClearColor(this._oldClearColor,this.oldClearAlpha),t.autoClear=a}getSeperableBlurMaterial(t){let e=[];for(let n=0;n<t;n++)e.push(.39894*Math.exp(-.5*n*n/(t*t))/t);return new ve({defines:{KERNEL_RADIUS:t},uniforms:{colorTexture:{value:null},invSize:{value:new tt(.5,.5)},direction:{value:new tt(.5,.5)},gaussianCoefficients:{value:e}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`#include <common>
				varying vec2 vUv;
				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {
					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;
					for( int i = 1; i < KERNEL_RADIUS; i ++ ) {
						float x = float(i);
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += (sample1 + sample2) * w;
						weightSum += 2.0 * w;
					}
					gl_FragColor = vec4(diffuseSum/weightSum, 1.0);
				}`})}getCompositeMaterial(t){return new ve({defines:{NUM_MIPS:t},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`varying vec2 vUv;
				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor(const in float factor) {
					float mirrorFactor = 1.2 - factor;
					return mix(factor, mirrorFactor, bloomRadius);
				}

				void main() {
					gl_FragColor = bloomStrength * ( lerpBloomFactor(bloomFactors[0]) * vec4(bloomTintColors[0], 1.0) * texture2D(blurTexture1, vUv) +
						lerpBloomFactor(bloomFactors[1]) * vec4(bloomTintColors[1], 1.0) * texture2D(blurTexture2, vUv) +
						lerpBloomFactor(bloomFactors[2]) * vec4(bloomTintColors[2], 1.0) * texture2D(blurTexture3, vUv) +
						lerpBloomFactor(bloomFactors[3]) * vec4(bloomTintColors[3], 1.0) * texture2D(blurTexture4, vUv) +
						lerpBloomFactor(bloomFactors[4]) * vec4(bloomTintColors[4], 1.0) * texture2D(blurTexture5, vUv) );
				}`})}};pr.BlurDirectionX=new tt(1,0);pr.BlurDirectionY=new tt(0,1);var gf={name:"OutputShader",uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`
	
		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#elif defined( NEUTRAL_TONE_MAPPING )

				gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`};var Xo=class extends _n{constructor(){super();let t=gf;this.uniforms=Tn.clone(t.uniforms),this.material=new Uo({name:t.name,uniforms:this.uniforms,vertexShader:t.vertexShader,fragmentShader:t.fragmentShader}),this.fsQuad=new ji(this.material),this._outputColorSpace=null,this._toneMapping=null}render(t,e,n){this.uniforms.tDiffuse.value=n.texture,this.uniforms.toneMappingExposure.value=t.toneMappingExposure,(this._outputColorSpace!==t.outputColorSpace||this._toneMapping!==t.toneMapping)&&(this._outputColorSpace=t.outputColorSpace,this._toneMapping=t.toneMapping,this.material.defines={},se.getTransfer(this._outputColorSpace)===pe&&(this.material.defines.SRGB_TRANSFER=""),this._toneMapping===Uh?this.material.defines.LINEAR_TONE_MAPPING="":this._toneMapping===Nh?this.material.defines.REINHARD_TONE_MAPPING="":this._toneMapping===Fh?this.material.defines.CINEON_TONE_MAPPING="":this._toneMapping===ta?this.material.defines.ACES_FILMIC_TONE_MAPPING="":this._toneMapping===Oh?this.material.defines.AGX_TONE_MAPPING="":this._toneMapping===Bh&&(this.material.defines.NEUTRAL_TONE_MAPPING=""),this.material.needsUpdate=!0),this.renderToScreen===!0?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(e),this.clear&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),this.fsQuad.render(t))}dispose(){this.material.dispose(),this.fsQuad.dispose()}};var jh="motomitico.save.v1",Yo={bajo:{label:"BAJO",pixelRatio:.75,shadows:0,bloom:!1,msaa:0,density:.45,post:!1,terrainRes:128,maxDpr:1},medio:{label:"MEDIO",pixelRatio:1,shadows:1024,bloom:!0,msaa:0,density:.7,post:!0,terrainRes:160,maxDpr:1},alto:{label:"ALTO",pixelRatio:1,shadows:2048,bloom:!0,msaa:4,density:1,post:!0,terrainRes:200,maxDpr:1.5},ultra:{label:"ULTRA",pixelRatio:1,shadows:4096,bloom:!0,msaa:4,density:1.35,post:!0,terrainRes:256,maxDpr:2}},xf=typeof navigator<"u"&&/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent),Qh={settings:{quality:xf?"medio":"alto",resScale:1,motionBlur:!0,masterVol:.85,musicVol:.55,sfxVol:.9,units:"kmh",transmission:"auto",camera:0,showFps:!1,touch:xf,vibration:!0,laps:3,rivals:7,difficulty:"normal",assist:!0},records:{},ghosts:{},champ:null,stats:{races:0,wins:0,podiums:0,km:0,crashes:0,topSpeed:0},garage:{bike:"raptor",livery:{}},trophies:{}};function qo(s,t){if(!t||typeof t!="object")return s;let e=Array.isArray(s)?[...s]:{...s};for(let n of Object.keys(t))s&&typeof s[n]=="object"&&s[n]!==null&&!Array.isArray(s[n])?e[n]=qo(s[n],t[n]):e[n]=t[n];return e}var tu=class{constructor(){this.data=qo(Qh,null);try{let t=localStorage.getItem(jh);t&&(this.data=qo(Qh,JSON.parse(t)))}catch{}Yo[this.data.settings.quality]||(this.data.settings.quality="alto")}get settings(){return this.data.settings}get quality(){return Yo[this.data.settings.quality]}save(){try{localStorage.setItem(jh,JSON.stringify(this.data))}catch{try{this.data.ghosts={},localStorage.setItem(jh,JSON.stringify(this.data))}catch{}}}reset(){this.data=qo(Qh,null),this.save()}},rt=new tu;var $=(s,t,e)=>s<t?t:s>e?e:s,ia=(s,t,e)=>s+(t-s)*e;var sa=(s,t,e)=>{let n=$((e-s)/(t-s),0,1);return n*n*(3-2*n)},Ze=(s,t,e,n)=>s+(t-s)*(1-Math.exp(-e*n));var vf=Math.PI*2,Ny=Math.PI/180;function sn(s){for(;s>Math.PI;)s-=vf;for(;s<-Math.PI;)s+=vf;return s}function yf(s,t,e){return Math.abs(t-s)<=e?t:s+Math.sign(t-s)*e}function $t(s=1){let t=s>>>0,e=()=>{t|=0,t=t+1831565813|0;let n=Math.imul(t^t>>>15,1|t);return n=n+Math.imul(n^n>>>7,61|n)^n,((n^n>>>14)>>>0)/4294967296};return e.range=(n,i)=>n+(i-n)*e(),e.int=(n,i)=>Math.floor(n+(i-n+1)*e()),e.pick=n=>n[Math.floor(e()*n.length)],e.sign=()=>e()<.5?-1:1,e}var eu=[[1,1],[-1,1],[1,-1],[-1,-1],[1,0],[-1,0],[0,1],[0,-1]],Es=class{constructor(t=1){let e=$t(t),n=new Uint8Array(256);for(let i=0;i<256;i++)n[i]=i;for(let i=255;i>0;i--){let r=Math.floor(e()*(i+1)),a=n[i];n[i]=n[r],n[r]=a}this.perm=new Uint8Array(512);for(let i=0;i<512;i++)this.perm[i]=n[i&255]}noise(t,e){let n=.5*(Math.sqrt(3)-1),i=(3-Math.sqrt(3))/6,r=this.perm,a=(t+e)*n,o=Math.floor(t+a),l=Math.floor(e+a),c=(o+l)*i,h=t-(o-c),u=e-(l-c),d=h>u?1:0,f=h>u?0:1,m=h-d+i,x=u-f+i,g=h-1+2*i,p=u-1+2*i,v=o&255,y=l&255,_=0,S=0,M=0,E=.5-h*h-u*u;if(E>0){let b=eu[r[v+r[y]]&7];E*=E,_=E*E*(b[0]*h+b[1]*u)}let A=.5-m*m-x*x;if(A>0){let b=eu[r[v+d+r[y+f]]&7];A*=A,S=A*A*(b[0]*m+b[1]*x)}let w=.5-g*g-p*p;if(w>0){let b=eu[r[v+1+r[y+1]]&7];w*=w,M=w*w*(b[0]*g+b[1]*p)}return 70*(_+S+M)}fbm(t,e,n=4,i=2,r=.5){let a=1,o=1,l=0,c=0;for(let h=0;h<n;h++)l+=a*this.noise(t*o,e*o),c+=a,a*=r,o*=i;return l/c}ridged(t,e,n=4){let i=1,r=1,a=0,o=0;for(let l=0;l<n;l++)a+=i*(1-Math.abs(this.noise(t*r,e*r))),o+=i,i*=.5,r*=2;return a/o}},nu=class{constructor(t=1,e=16){let n=$t(t);this.period=e,this.v=new Float32Array(e*e);for(let i=0;i<this.v.length;i++)this.v[i]=n()*2-1}at(t,e){let n=this.period;return t=(t%n+n)%n,e=(e%n+n)%n,this.v[e*n+t]}sample(t,e){let n=this.period,i=t*n,r=e*n,a=Math.floor(i),o=Math.floor(r),l=i-a,c=r-o;l=l*l*(3-2*l),c=c*c*(3-2*c);let h=this.at(a,o),u=this.at(a+1,o),d=this.at(a,o+1),f=this.at(a+1,o+1);return ia(ia(h,u,l),ia(d,f,l),c)}};function je(s,t=4,e=5){let n=[];for(let i=0;i<e;i++)n.push(new nu(s+i*101,t<<i));return(i,r)=>{let a=0,o=1,l=0;for(let c=0;c<e;c++)a+=n[c].sample(i,r)*o,l+=o,o*=.5;return a/l}}function Ke(s,t=!0){if(!isFinite(s)||s<=0)return t?"-:--.---":"-:--";let e=Math.floor(s/6e4),n=Math.floor(s%6e4/1e3),i=Math.floor(s%1e3);return t?`${e}:${String(n).padStart(2,"0")}.${String(i).padStart(3,"0")}`:`${e}:${String(n).padStart(2,"0")}`}function _f(s){if(!isFinite(s))return"";let t=s/1e3;return(t>=0?"+":"-")+Math.abs(t).toFixed(3)}function Mf(s){let t=typeof s=="number"?s:parseInt(s.replace("#",""),16);return[t>>16&255,t>>8&255,t&255]}var iu=s=>new Promise(t=>setTimeout(t,s)),Ri=()=>new Promise(s=>requestAnimationFrame(()=>s()));var su=new Map,wf=8;function Sf(s){wf=s}function Se(s,t){return su.has(s)||su.set(s,t()),su.get(s)}function le(s,t=s){let e=document.createElement("canvas");return e.width=s,e.height=t,{c:e,g:e.getContext("2d",{willReadFrequently:!1})}}function Wt(s,{repeat:t=[1,1],srgb:e=!0,aniso:n=!0,wrap:i=!0}={}){let r=new lr(s);return i&&(r.wrapS=r.wrapT=gs),r.repeat.set(t[0],t[1]),r.colorSpace=e?qe:ii,r.anisotropy=n?wf:1,r.needsUpdate=!0,r}function Ts(s,t,e,n=2){let{c:i,g:r}=le(t,e),a=r.createImageData(t,e),o=a.data;for(let l=0;l<e;l++)for(let c=0;c<t;c++){let h=s[l*t+(c-1+t)%t],u=s[l*t+(c+1)%t],d=s[(l-1+e)%e*t+c],f=s[(l+1)%e*t+c],m=(h-u)*n,x=(f-d)*n,g=1,p=Math.hypot(m,x,g);m/=p,x/=p,g/=p;let v=(l*t+c)*4;o[v]=(m*.5+.5)*255,o[v+1]=(x*.5+.5)*255,o[v+2]=(g*.5+.5)*255,o[v+3]=255}return r.putImageData(a,0,0),i}function hi(s,t,e){let{c:n,g:i}=le(s,t),r=i.createImageData(s,t),a=r.data,o=[0,0,0,255];for(let l=0;l<t;l++)for(let c=0;c<s;c++){e(c,l,o);let h=(l*s+c)*4;a[h]=o[0],a[h+1]=o[1],a[h+2]=o[2],a[h+3]=o[3]}return i.putImageData(r,0,0),{c:n,g:i}}function ru({seed:s=7,size:t=512,base:e=[52,54,58],edge:n="#f2f2f2",centerDash:i=!1,centerColor:r="#f2f2f2",wet:a=!1,rubber:o=!0,patches:l=!1,edgeRed:c=!1}={}){let h=`road:${s}:${t}:${e}:${n}:${i}:${r}:${a}:${o}:${l}:${c}`;return Se(h,()=>{let u=t,d=t*2,f=je(s,8,6),m=je(s+9,32,3),x=je(s+21,2,3),g=$t(s),p=new Float32Array(u*d),v=le(u,d),{c:y,g:_}=hi(u,d,(D,U,F)=>{let q=D/u,V=U/d,J=x(q,V*2),G=f(q,V*2)*.5+m(q,V*2)*.5,nt=g()<.06?(g()-.3)*60:0,ht=0;if(o){let st=Math.abs(q-.5-J*.08);ht=Math.exp(-st*st*30)*16}let Et=1+J*.12,Ot=e[0]*Et+G*22+nt-ht,re=e[1]*Et+G*22+nt-ht,Z=e[2]*Et+G*22+nt-ht;l&&J>.25&&(Ot-=10,re-=10,Z-=8),F[0]=$(Ot,0,255),F[1]=$(re,0,255),F[2]=$(Z,0,255),F[3]=255,p[U*u+D]=G*.5+(nt>0?.25:0)});_.globalAlpha=.92;let S=u*.022,M=u*.035,E=D=>{if(c)for(let U=0;U<d;U+=d/8)_.fillStyle=Math.round(U/(d/8))%2?"#d01818":"#f0f0f0",_.fillRect(D,U,S,d/8);else _.fillStyle=n,_.fillRect(D,0,S,d)};if(E(M),E(u-M-S),i){_.fillStyle=r;for(let D=0;D<d;D+=d/2)_.fillRect(u/2-S/2,D+d*.05,S,d*.22)}_.globalAlpha=1;let A=_.getImageData(0,0,u,d);for(let D=0;D<A.data.length;D+=4)g()<.18&&(A.data[D]*=.85,A.data[D+1]*=.85,A.data[D+2]*=.85);_.putImageData(A,0,0);let w=v.g,b=w.createImageData(u,d);for(let D=0;D<d;D++)for(let U=0;U<u;U++){let F=(D*u+U)*4,q=p[D*u+U],V=a?70+q*90:200+q*50;if(a){let J=U/u,G=D/d,nt=x(J*1,G*2)>.15?.25:1;V*=nt}b.data[F]=V,b.data[F+1]=V,b.data[F+2]=V,b.data[F+3]=255}w.putImageData(b,0,0);let P=Ts(p,u,d,3);return{map:Wt(y),normalMap:Wt(P,{srgb:!1}),roughnessMap:Wt(v.c,{srgb:!1}),aspect:d/u}})}var bf={grass:{a:[58,92,34],b:[96,128,52],c:[44,64,28],scale:6,blades:!0,rough:235,bump:2.5},dryGrass:{a:[120,116,60],b:[150,140,80],c:[92,88,48],scale:6,blades:!0,rough:240,bump:2.5},sand:{a:[196,120,70],b:[222,156,98],c:[160,92,54],scale:4,ripples:!0,rough:230,bump:2},snow:{a:[228,234,244],b:[250,252,255],c:[196,208,226],scale:3,rough:150,bump:1.5},dirt:{a:[104,78,54],b:[134,102,70],c:[76,56,40],scale:6,pebbles:!0,rough:240,bump:3},gravel:{a:[150,144,132],b:[184,178,166],c:[110,104,96],scale:16,pebbles:!0,rough:245,bump:4},forest:{a:[52,62,30],b:[84,74,40],c:[36,40,22],scale:5,pebbles:!0,blades:!0,rough:240,bump:3},rock:{a:[150,82,52],b:[186,112,72],c:[112,58,38],scale:3,strata:!0,rough:220,bump:5},asphaltDark:{a:[30,32,36],b:[48,50,56],c:[22,22,26],scale:10,rough:200,bump:2},volcanic:{a:[34,30,30],b:[58,50,48],c:[20,18,18],scale:6,pebbles:!0,rough:230,bump:4}};function ra(s="grass",t=3,e=512){return Se(`ground:${s}:${t}:${e}`,()=>{let n=bf[s]||bf.grass,i=e,r=je(t,n.scale,6),a=je(t+5,3,3),o=je(t+11,64,2),l=$t(t*7+1),c=new Float32Array(i*i),{c:h,g:u}=hi(i,i,(m,x,g)=>{let p=m/i,v=x/i,y=r(p,v)*.5+.5,_=a(p,v)*.5+.5,S=y;if(n.ripples){let w=Math.sin((v*22+a(p,v)*3)*Math.PI*2)*.5+.5;y=y*.7+w*.3,S=w}if(n.strata){let w=Math.sin((v*14+r(p,v)*2)*Math.PI*2)*.5+.5;y=y*.6+w*.4,S=w*.7+y*.3}if(n.blades){let w=o(p,v)*.5+.5;y=y*.6+w*.4,S=S*.5+w*.5}let M=l(),E;n.pebbles&&M<.05?(E=n.c.map(w=>w*.8+30*l()),S+=.4):E=[0,1,2].map(w=>n.a[w]+(n.b[w]-n.a[w])*y*.8+(n.c[w]-n.a[w])*(1-_)*.5);let A=(l()-.5)*10;g[0]=$(E[0]+A,0,255),g[1]=$(E[1]+A,0,255),g[2]=$(E[2]+A,0,255),g[3]=255,c[x*i+m]=S}),d=Ts(c,i,i,n.bump),f=hi(i,i,(m,x,g)=>{let p=n.rough-c[x*i+m]*30;g[0]=g[1]=g[2]=p,g[3]=255});return{map:Wt(h),normalMap:Wt(d,{srgb:!1}),roughnessMap:Wt(f.c,{srgb:!1})}})}function Ef(s="#d81c1c",t="#f4f4f4"){return Se(`curb:${s}:${t}`,()=>{let{c:e,g:n}=le(128,256);for(let a=0;a<2;a++)n.fillStyle=a?t:s,n.fillRect(0,a*128,128,128);let i=n.createLinearGradient(0,0,128,0);i.addColorStop(0,"rgba(0,0,0,0.35)"),i.addColorStop(.3,"rgba(255,255,255,0.12)"),i.addColorStop(1,"rgba(0,0,0,0.0)"),n.fillStyle=i,n.fillRect(0,0,128,256);let r=$t(4);for(let a=0;a<400;a++)n.fillStyle=`rgba(30,30,30,${r()*.25})`,n.fillRect(r()*128,r()*256,2+r()*3,2+r()*3);return Wt(e)})}function Tf(s=null,t=2){return Se(`concrete:${s}:${t}`,()=>{let n=je(t,8,5),{c:i,g:r}=hi(256,256,(a,o,l)=>{let c=170+n(a/256,o/256)*40;l[0]=c,l[1]=c,l[2]=c*.98,l[3]=255});return r.fillStyle="rgba(0,0,0,0.35)",r.fillRect(0,0,3,256),s&&(r.fillStyle=s,r.fillRect(0,256*.62,256,256*.12)),r.fillStyle="rgba(0,0,0,0.25)",r.fillRect(0,256*.92,256,256*.08),Wt(i)})}function Af(){return Se("tirewall",()=>{let{c:s,g:t}=le(256,128);t.fillStyle="#111",t.fillRect(0,0,256,128);for(let e=0;e<3;e++)for(let n=0;n<4;n++){let i=n*64+32+e%2*32,r=e*42+22,a=t.createRadialGradient(i,r,4,i,r,30);a.addColorStop(0,"#000"),a.addColorStop(.45,"#000"),a.addColorStop(.5,"#2a2a2a"),a.addColorStop(.9,"#1a1a1a"),a.addColorStop(1,"#080808"),t.fillStyle=a,t.beginPath(),t.arc(i,r,30,0,Math.PI*2),t.fill(),t.beginPath(),t.arc(i-64*4,r,30,0,Math.PI*2),t.fill()}return t.fillStyle="#c8102e",t.fillRect(0,54,256,16),t.fillStyle="#fff",t.fillRect(0,58,256,3),Wt(s)})}function Rf(){return Se("armco",()=>{let{c:s,g:t}=le(64,64),e=t.createLinearGradient(0,0,0,64);return e.addColorStop(0,"#9aa0a6"),e.addColorStop(.25,"#e6eaee"),e.addColorStop(.5,"#8d9399"),e.addColorStop(.75,"#d9dde1"),e.addColorStop(1,"#7d8389"),t.fillStyle=e,t.fillRect(0,0,64,64),Wt(s)})}function au(s=1,{night:t=!1,hue:e=210,cols:n=6,rows:i=12,glass:r=!1}={}){return Se(`facade:${s}:${t}:${e}:${n}:${i}:${r}`,()=>{let l=$t(s),c=le(256,512),h=le(256,512),u=c.g,d=h.g,f=20+l()*25;u.fillStyle=`hsl(${e},${8+l()*12}%,${t?f*.5:f+20}%)`,u.fillRect(0,0,256,512),d.fillStyle="#000",d.fillRect(0,0,256,512);let m=256/n,x=512/i;for(let g=0;g<i;g++)for(let p=0;p<n;p++){let v=p*m+m*.15,y=g*x+x*.18,_=m*.7,S=x*.6,M=l()<(t?.55:.1);if(r?u.fillStyle=`hsl(${e+10},40%,${t?10:30+l()*20}%)`:u.fillStyle=t?"#0b0d12":`hsl(${e},25%,${18+l()*14}%)`,u.fillRect(v,y,_,S),M){let A=l()<.6?`hsl(${35+l()*15},90%,${55+l()*20}%)`:`hsl(${190+l()*40},80%,${60+l()*15}%)`;d.fillStyle=A,d.fillRect(v,y,_,S),u.fillStyle=A,u.globalAlpha=t?.9:.25,u.fillRect(v,y,_,S),u.globalAlpha=1,l()<.4&&(d.fillStyle="rgba(0,0,0,0.5)",d.fillRect(v,y,_,S*l()))}}return{map:Wt(c.c),emissiveMap:Wt(h.c)}})}function Cf(s,t="#ff2bd6",e=1){return Se(`neon:${s}:${t}:${e}`,()=>{let{c:n,g:i}=le(512,128);return i.fillStyle="#05050a",i.fillRect(0,0,512,128),i.font="900 72px Orbitron, Arial, sans-serif",i.textAlign="center",i.textBaseline="middle",i.shadowColor=t,i.shadowBlur=24,i.strokeStyle=t,i.lineWidth=6,i.strokeText(s,256,66),i.fillStyle="#fff",i.shadowBlur=8,i.fillText(s,256,66),Wt(n,{wrap:!1})})}function Pf(s,t="#0a2a6a",e="#ffffff",n="#ffcc00"){return Se(`bill:${s}:${t}:${e}:${n}`,()=>{let{c:i,g:r}=le(512,128),a=r.createLinearGradient(0,0,512,128);return a.addColorStop(0,t),a.addColorStop(1,yv(t,-30)),r.fillStyle=a,r.fillRect(0,0,512,128),r.fillStyle=n,r.fillRect(0,108,512,20),r.beginPath(),r.moveTo(0,0),r.lineTo(70,0),r.lineTo(30,108),r.lineTo(0,108),r.fill(),r.font="900 64px Orbitron, Arial, sans-serif",r.textAlign="center",r.textBaseline="middle",r.fillStyle=e,r.fillText(s,280,56,420),Wt(i,{wrap:!1})})}function yv(s,t){let[e,n,i]=Mf(s),r=a=>$(Math.round(a+t/100*255),0,255);return`rgb(${r(e)},${r(n)},${r(i)})`}function $o(){return Se("carbon",()=>{let n=new Float32Array(16384),{c:i}=hi(128,128,(r,a,o)=>{let l=Math.floor(r/16),c=Math.floor(a/16),h=r%16/16,u=a%16/16,d=(l+c&1)===0,m=Math.sin((d?h:u)*Math.PI),x=18+m*38+(d?6:0);o[0]=x,o[1]=x,o[2]=x+4,o[3]=255,n[a*128+r]=m});return{map:Wt(i,{repeat:[1,1]}),normalMap:Wt(Ts(n,128,128,1.5),{srgb:!1})}})}function If(){return Se("brushed",()=>{let t=$t(12),e=new Float32Array(256).map(()=>t()),{c:n}=hi(256,256,(i,r,a)=>{let o=150+e[r]*50+(t()-.5)*20;a[0]=o,a[1]=o,a[2]=o,a[3]=255});return Wt(n,{srgb:!1})})}function Zo(){return Se("leather",()=>{let t=je(31,24,3),e=new Float32Array(256*256),{c:n}=hi(256,256,(i,r,a)=>{let o=t(i/256,r/256)*.5+.5;e[r*256+i]=o;let l=22+o*14;a[0]=l,a[1]=l,a[2]=l,a[3]=255});return{map:Wt(n),normalMap:Wt(Ts(e,256,256,4),{srgb:!1})}})}function Lf(){return Se("gridfloor",()=>{let t=je(77,8,4),{c:e,g:n}=hi(1024,1024,(i,r,a)=>{let o=18+t(i/1024,r/1024)*8;a[0]=o,a[1]=o,a[2]=o+2,a[3]=255});n.strokeStyle="rgba(255,255,255,0.05)",n.lineWidth=3;for(let i=0;i<=8;i++)n.beginPath(),n.moveTo(i*1024/8,0),n.lineTo(i*1024/8,1024),n.stroke(),n.beginPath(),n.moveTo(0,i*1024/8),n.lineTo(1024,i*1024/8),n.stroke();return Wt(e)})}function Df(){return Se("radiator",()=>{let{c:s,g:t}=le(128,128);t.fillStyle="#111",t.fillRect(0,0,128,128),t.strokeStyle="#3a3a3a",t.lineWidth=2;for(let e=0;e<128;e+=6)t.beginPath(),t.moveTo(0,e),t.lineTo(128,e),t.stroke();t.strokeStyle="#222";for(let e=0;e<128;e+=4)t.beginPath(),t.moveTo(e,0),t.lineTo(e,128),t.stroke();return Wt(s)})}function kf(){return Se("titanium",()=>{let{c:s,g:t}=le(16,256),e=t.createLinearGradient(0,0,0,256);return e.addColorStop(0,"#c9b27a"),e.addColorStop(.18,"#a9805a"),e.addColorStop(.32,"#6a5a8a"),e.addColorStop(.45,"#5a6e96"),e.addColorStop(.62,"#9aa3ad"),e.addColorStop(1,"#c4c8cc"),t.fillStyle=e,t.fillRect(0,0,16,256),Wt(s)})}function aa(){return Se("softcircle",()=>{let{c:s,g:t}=le(64,64),e=t.createRadialGradient(32,32,0,32,32,32);return e.addColorStop(0,"rgba(255,255,255,1)"),e.addColorStop(.4,"rgba(255,255,255,0.55)"),e.addColorStop(1,"rgba(255,255,255,0)"),t.fillStyle=e,t.fillRect(0,0,64,64),Wt(s,{wrap:!1,aniso:!1})})}function Uf(){return Se("smoke",()=>{let t=je(5,4,5),{c:e}=hi(128,128,(n,i,r)=>{let a=n/128-.5,o=i/128-.5,l=Math.sqrt(a*a+o*o)*2,c=$(1-l,0,1),h=$(c*c*(.6+t(n/128,i/128)*.8),0,1);r[0]=r[1]=r[2]=255,r[3]=h*255});return Wt(e,{wrap:!1,aniso:!1})})}function Nf(){return Se("flame",()=>{let{c:s,g:t}=le(64,256),e=t.createLinearGradient(0,0,0,256);e.addColorStop(0,"rgba(255,255,255,1)"),e.addColorStop(.15,"rgba(120,200,255,1)"),e.addColorStop(.45,"rgba(60,90,255,0.8)"),e.addColorStop(.7,"rgba(255,120,40,0.5)"),e.addColorStop(1,"rgba(255,60,0,0)"),t.fillStyle=e,t.fillRect(0,0,64,256);let n=t.createLinearGradient(0,0,64,0);n.addColorStop(0,"rgba(0,0,0,1)"),n.addColorStop(.5,"rgba(0,0,0,0)"),n.addColorStop(1,"rgba(0,0,0,1)"),t.globalCompositeOperation="destination-out",t.fillStyle=n,t.fillRect(0,0,64,256);let i=Wt(s,{wrap:!1,aniso:!1});return i.flipY=!1,i})}function Ff(){return Se("stars",()=>{let{c:e,g:n}=le(2048,1024);n.fillStyle="#000",n.fillRect(0,0,2048,1024);let i=$t(99);for(let l=0;l<4e3;l++){let c=Math.pow(i(),1.6)*1024*.55,h=i();n.fillStyle=`rgba(${200+i()*55},${200+i()*55},255,${.3+h*.7})`;let u=h>.97?2.2:h>.85?1.4:.9;n.fillRect(i()*2048,c,u,u)}let r=je(3,4,5),a=n.getImageData(0,0,2048,1024);for(let l=0;l<1024*.5;l++)for(let c=0;c<2048;c+=1){let u=Math.exp(-Math.pow((l-225.28-Math.sin(c/2048*Math.PI*2)*1024*.12)/61.44,2))*(r(c/2048,l/1024)*.5+.5)*40,d=(l*2048+c)*4;a.data[d]+=u*.8,a.data[d+1]+=u*.85,a.data[d+2]+=u}n.putImageData(a,0,0);let o=Wt(e,{wrap:!1});return o.wrapS=gs,o})}function Of(s=8,t=.5){return Se(`cloud:${s}:${t}`,()=>{let i=je(s,4,6),r=.62-t*.3,{c:a}=hi(1024,256,(l,c,h)=>{let u=i(l/1024,c/256)*.5+.5,d=Math.sin(c/256*Math.PI),f=$((u-r)*3.2,0,1)*d;h[0]=h[1]=h[2]=255,h[3]=f*255}),o=Wt(a,{wrap:!1});return o.wrapS=gs,o})}function Bf(s,t="#ffffff",e="#111111"){return Se(`plate:${s}:${t}:${e}`,()=>{let{c:n,g:i}=le(256,256);return i.fillStyle=t,i.fillRect(0,0,256,256),i.font="900 170px Orbitron, Arial, sans-serif",i.textAlign="center",i.textBaseline="middle",i.fillStyle=e,i.fillText(String(s),128,140,230),Wt(n,{wrap:!1})})}function oa(s=!1){return Se(`tire:${s}`,()=>{let{c:n,g:i}=le(1024,128);i.fillStyle="#1b1b1d",i.fillRect(0,0,1024,128);let r=$t(s?3:2);for(let a=0;a<3e3;a++)i.fillStyle=`rgba(255,255,255,${r()*.03})`,i.fillRect(r()*1024,r()*128,2,2);if(i.fillStyle="#141416",i.fillRect(0,128*.3,1024,128*.4),!s){i.strokeStyle="#0a0a0b",i.lineWidth=3;for(let a=0;a<24;a++){let o=a/24*1024;i.beginPath(),i.moveTo(o,128*.36),i.quadraticCurveTo(o+18,128*.5,o+40,128*.46),i.stroke()}}i.font="700 22px Orbitron, Arial, sans-serif",i.fillStyle="rgba(210,210,210,0.55)",i.textBaseline="middle";for(let a=0;a<2;a++)i.fillText("M\xCDTICO RACE",a*1024/2+40,128*.14),i.fillText("M\xCDTICO RACE",a*1024/2+40,128*.86);i.fillStyle="rgba(255,210,0,0.55)";for(let a=0;a<2;a++)i.fillText("SOFT",a*1024/2+330,128*.14),i.fillText("SOFT",a*1024/2+330,128*.86);return Wt(n)})}function zf(s,t="",e=""){let n=`livery:${JSON.stringify(s)}:${t}:${e}`;return Se(n,()=>{let{c:a,g:o}=le(1024,1024),{base:l,second:c,accent:h,pattern:u="stripe"}=s;o.fillStyle=l,o.fillRect(0,0,1024,1024);let d=m=>(1-m)*1024,f=(m,x,g)=>{o.fillStyle=g,o.fillRect(0,d(m+x),1024,x*2*1024)};if(u==="stripe")f(.5,.05,c),f(.5,.012,h),f(.25,.03,c),f(.75,.03,c);else if(u==="split")o.fillStyle=c,o.fillRect(0,d(.36),1024,d(.14)-d(.36)),o.fillRect(0,d(.86),1024,d(.64)-d(.86)),f(.36,.01,h),f(.64,.01,h);else if(u==="arrow"){o.fillStyle=c;for(let m of[.25,.75])o.beginPath(),o.moveTo(1024*.1,d(m-.08)),o.lineTo(1024*.75,d(m-.02)),o.lineTo(1024*.95,d(m+.02)),o.lineTo(1024*.75,d(m+.1)),o.lineTo(1024*.1,d(m+.04)),o.closePath(),o.fill();f(.5,.008,h)}else if(u==="retro")for(let m=0;m<3;m++){o.fillStyle=[c,h,"#ffffff"][m];for(let x of[.22,.78])o.fillRect(0,d(x+.06-m*.04),1024,.025*1024)}else if(u==="neon"){o.strokeStyle=h,o.lineWidth=6;for(let m of[.25,.75]){o.beginPath();for(let x=0;x<=1024;x+=8)o.lineTo(x,d(m+Math.sin(x/1024*Math.PI*3)*.04));o.stroke()}f(.5,.006,h)}else if(u==="flames"){o.fillStyle=c;for(let m of[.25,.75]){let x=m<.5?1:-1;o.beginPath(),o.moveTo(1024,d(m-.15*x));for(let g=0;g<=6;g++){let p=1024*(.95-g*.1);o.lineTo(p,d(m+(g%2?.1:-.02)*x))}o.lineTo(1024*.3,d(m+.02*x)),o.lineTo(1024,d(m+.16*x)),o.closePath(),o.fill()}}return t&&(o.font="900 52px Orbitron, Arial, sans-serif",o.textAlign="center",o.textBaseline="middle",o.save(),o.translate(1024*.45,d(.27)),o.fillStyle=h,o.fillText(t,0,0,1024*.32),o.restore(),o.save(),o.translate(1024*.45,d(.73)),o.rotate(Math.PI),o.fillStyle=h,o.fillText(t,0,0,1024*.32),o.restore()),e&&(o.font="900 110px Orbitron, Arial, sans-serif",o.textAlign="center",o.textBaseline="middle",o.lineWidth=8,o.strokeStyle=l,o.save(),o.translate(1024*.22,d(.27)),o.fillStyle="#fff",o.strokeText(e,0,0),o.fillText(e,0,0),o.restore(),o.save(),o.translate(1024*.22,d(.73)),o.rotate(Math.PI),o.fillStyle="#fff",o.strokeText(e,0,0),o.fillText(e,0,0),o.restore()),Wt(a,{wrap:!1})})}function Hf(){return Se("waternormal",()=>{let t=je(42,6,5),e=new Float32Array(256*256);for(let n=0;n<256;n++)for(let i=0;i<256;i++)e[n*256+i]=t(i/256,n/256);return Wt(Ts(e,256,256,6),{srgb:!1})})}function Vf(s="drilled",t="#c9a227"){return Se(`disc:${s}:${t}`,()=>{let{c:i,g:r}=le(256,256);r.clearRect(0,0,256,256);let a=127,o=128*.66,l=r.createRadialGradient(128,128,o,128,128,a);if(l.addColorStop(0,"#8d9298"),l.addColorStop(.5,"#c6cace"),l.addColorStop(1,"#7f8489"),r.fillStyle=l,r.beginPath(),s==="wave")for(let d=0;d<=12*8;d++){let f=d/96*Math.PI*2,m=a-(Math.sin(f*12)*.5+.5)*128*.06,x=128+Math.cos(f)*m,g=128+Math.sin(f)*m;d?r.lineTo(x,g):r.moveTo(x,g)}else r.arc(128,128,a,0,Math.PI*2);r.arc(128,128,o,0,Math.PI*2,!0),r.fill(),r.strokeStyle="rgba(60,60,60,0.25)",r.lineWidth=1;for(let u=o+4;u<a-4;u+=5)r.beginPath(),r.arc(128,128,u,0,Math.PI*2),r.stroke();r.globalCompositeOperation="destination-out";let c=s==="plain"?0:2;for(let u=0;u<c;u++){let f=o+(a-o)*(.33+u*.34);for(let m=0;m<24;m++){let x=m/24*Math.PI*2+u*(Math.PI/24);r.beginPath(),r.arc(128+Math.cos(x)*f,128+Math.sin(x)*f,3.2,0,Math.PI*2),r.fill()}}r.globalCompositeOperation="source-over",r.fillStyle=t,r.beginPath(),r.arc(128,128,o+3,0,Math.PI*2),r.arc(128,128,128*.3,0,Math.PI*2,!0),r.fill(),r.globalCompositeOperation="destination-out";for(let u=0;u<6;u++){let d=u/6*Math.PI*2;r.beginPath(),r.ellipse(128+Math.cos(d)*128*.5,128+Math.sin(d)*128*.5,128*.11,128*.07,d,0,Math.PI*2),r.fill()}r.globalCompositeOperation="source-over",r.fillStyle="#e8e8e8";for(let u=0;u<10;u++){let d=u/10*Math.PI*2;r.beginPath(),r.arc(128+Math.cos(d)*(o+1),128+Math.sin(d)*(o+1),4,0,Math.PI*2),r.fill()}return Wt(i,{wrap:!1})})}function Gf(s="#111",t="#eee",e=8){return Se(`checker:${s}:${t}:${e}`,()=>{let{c:n,g:i}=le(256,64),r=256/e;for(let a=0;a<2;a++)for(let o=0;o<e;o++)i.fillStyle=(o+a)%2?s:t,i.fillRect(o*r,a*32,r,32);return Wt(n)})}var _v={uniforms:{tDiffuse:{value:null},uTime:{value:0},uBlur:{value:0},uCA:{value:.0015},uVignette:{value:.32},uGrain:{value:.035},uFlash:{value:0},uFlashColor:{value:new ot(1,1,1)},uTint:{value:new ot(1,1,1)},uTintAmt:{value:0},uSat:{value:1.08},uContrast:{value:1.04},uCenter:{value:new tt(.5,.52)},uDamage:{value:0}},vertexShader:`
    varying vec2 vUv;
    void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }
  `,fragmentShader:`
    uniform sampler2D tDiffuse;
    uniform float uTime, uBlur, uCA, uVignette, uGrain, uFlash, uTintAmt, uSat, uContrast, uDamage;
    uniform vec3 uFlashColor, uTint;
    uniform vec2 uCenter;
    varying vec2 vUv;
    float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233))) * 43758.5453); }
    void main(){
      vec2 dir = vUv - uCenter;
      float dist = length(dir);
      vec3 col;
      float ca = uCA * (1.0 + uBlur * 6.0) * dist;
      if (uBlur > 0.001) {
        vec3 acc = vec3(0.0);
        float wsum = 0.0;
        float amt = uBlur * smoothstep(0.08, 0.6, dist) * 0.09;
        for (int i = 0; i < 10; i++) {
          float t = float(i) / 9.0;
          float w = 1.0 - t * 0.7;
          vec2 uv = vUv - dir * amt * t;
          acc.r += texture2D(tDiffuse, uv + dir * ca).r * w;
          acc.g += texture2D(tDiffuse, uv).g * w;
          acc.b += texture2D(tDiffuse, uv - dir * ca).b * w;
          wsum += w;
        }
        col = acc / wsum;
      } else {
        col.r = texture2D(tDiffuse, vUv + dir * ca).r;
        col.g = texture2D(tDiffuse, vUv).g;
        col.b = texture2D(tDiffuse, vUv - dir * ca).b;
      }
      // grading
      float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
      col = mix(vec3(l), col, uSat);
      col = (col - 0.5) * uContrast + 0.5;
      col = mix(col, col * uTint, uTintAmt);
      // vignette
      float v = smoothstep(0.95, 0.25, dist * (1.0 + uVignette));
      col *= mix(1.0, v, uVignette * 2.2);
      // damage pulse (red edges)
      col = mix(col, vec3(0.9, 0.05, 0.02), uDamage * smoothstep(0.3, 0.75, dist));
      // grain
      float n = hash(vUv * vec2(1920.0, 1080.0) + fract(uTime * 7.31)) - 0.5;
      col += n * uGrain;
      col = mix(col, uFlashColor, uFlash);
      gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
    }
  `},Ko=class{constructor(t){this.container=t;let e=new vo({antialias:!1,powerPreference:"high-performance",stencil:!1});e.outputColorSpace=qe,e.toneMapping=ta,e.toneMappingExposure=1,e.shadowMap.enabled=!0,e.shadowMap.type=kh,e.domElement.id="gl",t.appendChild(e.domElement),this.renderer=e,Sf(Math.min(8,e.capabilities.getMaxAnisotropy())),this.camera=new Ue(60,1,.1,6e3),this.scene=new pn,this.time=0,this.dt=0,this.fps=60,this.frameMs=16,this.dynScale=1,this.onUpdate=null,this.paused=!1,this._last=performance.now(),this._fpsAcc=0,this._fpsFrames=0,this._slowTime=0,this._fastTime=0,this.applyQuality(),window.addEventListener("resize",()=>this.resize()),this.resize()}applyQuality(){let t=rt.quality;this.quality=t;let e=this.renderer;if(e.shadowMap.enabled=t.shadows>0,e.shadowMap.needsUpdate=!0,this.composer&&(this.composer.dispose?.(),this.composer=null),t.post){let n=e.getDrawingBufferSize(new tt),i=new Ne(Math.max(1,n.x),Math.max(1,n.y),{type:ln,samples:t.msaa}),r=new Go(e,i);this.renderPass=new Wo(this.scene,this.camera),r.addPass(this.renderPass),this.bloom=new pr(new tt(n.x/2,n.y/2),.55,.6,.86),this.bloom.enabled=t.bloom,r.addPass(this.bloom),r.addPass(new Xo),this.finalPass=new fr(_v),r.addPass(this.finalPass),this.composer=r}else this.bloom=null,this.finalPass=null;this.resize()}setScene(t,e=this.camera){this.scene=t,this.camera=e,this.renderPass&&(this.renderPass.scene=t,this.renderPass.camera=e),this.resize()}setBloom(t=.55,e=.6,n=.86){this.bloom&&(this.bloom.strength=t,this.bloom.radius=e,this.bloom.threshold=n)}get fx(){return this.finalPass?this.finalPass.uniforms:null}resize(){let t=this.container.clientWidth||window.innerWidth,e=this.container.clientHeight||window.innerHeight,n=this.quality||rt.quality,r=Math.min(window.devicePixelRatio||1,n.maxDpr)*n.pixelRatio*(rt.settings.resScale||1)*this.dynScale;this.renderer.setPixelRatio($(r,.35,3)),this.renderer.setSize(t,e),this.camera.aspect=t/e,this.camera.updateProjectionMatrix(),this.composer&&(this.composer.setPixelRatio(this.renderer.getPixelRatio()),this.composer.setSize(t,e)),this.width=t,this.height=e}start(){let t=e=>{requestAnimationFrame(t);let n=(e-this._last)/1e3;this._last=e,n>.1&&(n=.1),n<=0&&(n=1e-4),this.dt=n,this.time+=n,this._fpsAcc+=n,this._fpsFrames++,this._fpsAcc>=.5&&(this.fps=this._fpsFrames/this._fpsAcc,this._fpsAcc=0,this._fpsFrames=0,this._adapt());try{this.onUpdate&&this.onUpdate(n),this.render()}catch(i){console.error(i),this.onError&&this.onError(i)}};requestAnimationFrame(t)}_adapt(){this.adaptive&&(this.fps<45?(this._slowTime+=.5,this._fastTime=0):this.fps>58?(this._fastTime+=.5,this._slowTime=0):(this._slowTime=0,this._fastTime=0),this._slowTime>=1.5&&this.dynScale>.55&&(this.dynScale=Math.max(.55,this.dynScale-.1),this._slowTime=0,this.resize()),this._fastTime>=4&&this.dynScale<1&&(this.dynScale=Math.min(1,this.dynScale+.05),this._fastTime=0,this.resize()))}render(){this.finalPass&&(this.finalPass.uniforms.uTime.value=this.time),this.composer?this.composer.render(this.dt):this.renderer.render(this.scene,this.camera)}};var ou=.12,lu=class{constructor(){this.keys=new Set,this.pressed=new Set,this.touch={throttle:0,brake:0,steer:0,nitro:0,rear:0,wheelie:0},this.state={throttle:0,brake:0,steer:0,rearBrake:0,nitro:!1,wheelie:!1,lookBack:!1},this.edges={shiftUp:!1,shiftDown:!1,camera:!1,pause:!1,reset:!1,confirm:!1,back:!1,up:!1,down:!1,left:!1,right:!1,any:!1},this._kbSteer=0,this._padPrev=[],this.usingPad=!1,this.listeners=[],window.addEventListener("keydown",t=>{if(t.repeat){this._isGameKey(t.code)&&t.preventDefault();return}this.keys.add(t.code),this.pressed.add(t.code),this.usingPad=!1,this._isGameKey(t.code)&&t.preventDefault();for(let e of this.listeners)e(t.code)}),window.addEventListener("keyup",t=>{this.keys.delete(t.code)}),window.addEventListener("blur",()=>{this.keys.clear()})}_isGameKey(t){return["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space","Tab"].includes(t)}onKey(t){return this.listeners.push(t),()=>{this.listeners=this.listeners.filter(e=>e!==t)}}down(...t){for(let e of t)if(this.keys.has(e))return!0;return!1}hit(...t){for(let e of t)if(this.pressed.has(e))return!0;return!1}setTouch(t,e){this.touch[t]=e}getPad(){let t=navigator.getGamepads?navigator.getGamepads():[];for(let e of t)if(e&&e.connected)return e;return null}rumble(t=.5,e=.5,n=120){if(!rt.settings.vibration)return;let i=this.getPad();try{i?.vibrationActuator?.playEffect?.("dual-rumble",{duration:n,strongMagnitude:t,weakMagnitude:e})}catch{}if(navigator.vibrate&&rt.settings.touch&&t>.6)try{navigator.vibrate(Math.min(n,80))}catch{}}update(t){let e=this.state,n=(...g)=>this.down(...g),i=n("KeyW","ArrowUp")?1:0,r=n("KeyS","ArrowDown")?1:0,a=(n("KeyD","ArrowRight")?1:0)-(n("KeyA","ArrowLeft")?1:0),o=a===0?7:Math.sign(a)!==Math.sign(this._kbSteer)&&this._kbSteer!==0?9:4.5;this._kbSteer=yf(this._kbSteer,a,o*t);let l=this._kbSteer,c=n("Space")?1:0,h=n("ShiftLeft","ShiftRight","KeyN"),u=n("KeyX"),d=n("KeyB"),f=this.edges;f.shiftUp=this.hit("KeyE"),f.shiftDown=this.hit("KeyQ"),f.camera=this.hit("KeyC"),f.pause=this.hit("Escape","KeyP"),f.reset=this.hit("KeyR"),f.confirm=this.hit("Enter","NumpadEnter"),f.back=this.hit("Escape","Backspace"),f.up=this.hit("ArrowUp","KeyW"),f.down=this.hit("ArrowDown","KeyS"),f.left=this.hit("ArrowLeft","KeyA"),f.right=this.hit("ArrowRight","KeyD"),f.any=this.pressed.size>0;let m=this.getPad();if(m){let g=M=>m.buttons[M]?m.buttons[M].value||(m.buttons[M].pressed?1:0):0,p=M=>{let E=g(M)>.5,A=this._padPrev[M];return this._padPrev[M]=E,E&&!A},v=m.axes[0]||0;Math.abs(v)<ou?v=0:v=Math.sign(v)*(Math.abs(v)-ou)/(1-ou);let y=g(7),_=g(6),S=m.axes[1]||0;(Math.abs(v)>0||y>.05||_>.05||m.buttons.some(M=>M.pressed))&&(this.usingPad=!0),this.usingPad&&(i=Math.max(i,y),r=Math.max(r,_),Math.abs(v)>Math.abs(l)&&(l=v*Math.abs(v)*.35+v*.65),c=Math.max(c,g(1)),h=h||g(0)>.5,u=u||g(2)>.5||S>.75,d=d||g(10)>.5),f.shiftUp=f.shiftUp||p(5),f.shiftDown=f.shiftDown||p(4),f.camera=f.camera||p(3),f.pause=f.pause||p(9),f.reset=f.reset||p(8),f.confirm=f.confirm||p(0),f.back=f.back||p(1),f.up=f.up||p(12)||this._axisEdge("ay-",S<-.6),f.down=f.down||p(13)||this._axisEdge("ay+",S>.6),f.left=f.left||p(14)||this._axisEdge("ax-",(m.axes[0]||0)<-.6),f.right=f.right||p(15)||this._axisEdge("ax+",(m.axes[0]||0)>.6),f.any=f.any||m.buttons.some(M=>M.pressed)}let x=this.touch;i=Math.max(i,x.throttle),r=Math.max(r,x.brake),Math.abs(x.steer)>Math.abs(l)&&(l=x.steer),h=h||x.nitro>.5,c=Math.max(c,x.rear),u=u||x.wheelie>.5,e.throttle=$(i,0,1),e.brake=$(r,0,1),e.steer=$(l,-1,1),e.rearBrake=$(c,0,1),e.nitro=h,e.wheelie=u,e.lookBack=d,this.pressed.clear()}_axisEdge(t,e){this._ax=this._ax||{};let n=this._ax[t];return this._ax[t]=e,e&&!n}},ze=new lu;typeof window<"u"&&(window.__INPUT=ze);var Wf={i4:{cyl:4,stroke:4,wave:"sawtooth",sub:.25,am:.04,amDiv:1,cutoff:1800,cutoffRpm:5200,dist:18,noise:.18,gain:.55,harm2:.35,decelPops:.5},v4:{cyl:4,stroke:4,wave:"sawtooth",sub:.5,am:.22,amDiv:2,cutoff:1300,cutoffRpm:4200,dist:26,noise:.22,gain:.6,harm2:.3,decelPops:1},i3:{cyl:3,stroke:4,wave:"sawtooth",sub:.45,am:.12,amDiv:1.5,cutoff:1200,cutoffRpm:4200,dist:22,noise:.2,gain:.6,harm2:.25,decelPops:1},vtwin:{cyl:2,stroke:4,wave:"sawtooth",sub:.9,am:.55,amDiv:2,cutoff:380,cutoffRpm:1800,dist:40,noise:.25,gain:.8,harm2:.15,decelPops:.7},vtwin2:{cyl:2,stroke:4,wave:"square",sub:1,am:.6,amDiv:2,cutoff:320,cutoffRpm:1500,dist:48,noise:.28,gain:.75,harm2:.1,decelPops:1.2},twin:{cyl:2,stroke:4,wave:"sawtooth",sub:.6,am:.3,amDiv:1,cutoff:650,cutoffRpm:2600,dist:30,noise:.22,gain:.65,harm2:.2,decelPops:.9},single:{cyl:1,stroke:4,wave:"square",sub:.4,am:.45,amDiv:1,cutoff:700,cutoffRpm:2600,dist:34,noise:.3,gain:.6,harm2:.3,decelPops:1},singleBig:{cyl:1,stroke:4,wave:"square",sub:.7,am:.5,amDiv:1,cutoff:520,cutoffRpm:2200,dist:40,noise:.3,gain:.65,harm2:.2,decelPops:1.3},boxer:{cyl:2,stroke:4,wave:"sawtooth",sub:.55,am:.2,amDiv:1,cutoff:600,cutoffRpm:2600,dist:28,noise:.22,gain:.62,harm2:.2,decelPops:.6},muscle:{cyl:4,stroke:4,wave:"sawtooth",sub:.8,am:.3,amDiv:2,cutoff:700,cutoffRpm:2600,dist:42,noise:.25,gain:.7,harm2:.2,decelPops:1},twoStroke:{cyl:4,stroke:2,wave:"square",sub:.15,am:.1,amDiv:4,cutoff:1500,cutoffRpm:5200,dist:30,noise:.35,gain:.45,harm2:.4,decelPops:.3,pipe:!0},electric:{electric:!0,gain:.5}},Mv=null;function bv(s){let e=new Float32Array(1024);for(let n=0;n<1024;n++){let i=n*2/1024-1;e[n]=(1+s)*i/(1+s*Math.abs(i))}return e}var cu=class{constructor(t,e,{positional:n=!1,lite:i=!1}={}){let r=t.ctx;this.sys=t,this.ctx=r,this.spec=e,this.p=Wf[e.engine.sound]||Wf.i4,this.out=r.createGain(),this.out.gain.value=0,n?(this.panner=r.createPanner(),Object.assign(this.panner,{panningModel:"equalpower",distanceModel:"inverse",refDistance:5,maxDistance:400,rolloffFactor:1.3}),this.out.connect(this.panner),this.panner.connect(t.sfx)):this.out.connect(t.sfx);let a=this.p;this.filter=r.createBiquadFilter(),this.filter.type="lowpass",this.filter.Q.value=2.5,this.filter.connect(this.out),a.electric?(this.o1=r.createOscillator(),this.o1.type="sine",this.o2=r.createOscillator(),this.o2.type="triangle",this.g1=r.createGain(),this.g2=r.createGain(),this.g1.gain.value=.6,this.g2.gain.value=.25,this.o1.connect(this.g1).connect(this.filter),this.o2.connect(this.g2).connect(this.filter),this.filter.frequency.value=4e3,i||(this.o3=r.createOscillator(),this.o3.type="sine",this.g3=r.createGain(),this.g3.gain.value=.08,this.o3.connect(this.g3).connect(this.out),this.o3.start()),this.o1.start(),this.o2.start()):(this.shaper=r.createWaveShaper(),this.shaper.curve=bv(a.dist),this.shaper.oversample=i?"none":"2x",this.pre=r.createGain(),this.pre.gain.value=.5,this.am=r.createGain(),this.am.gain.value=1,this.pre.connect(this.shaper).connect(this.am).connect(this.filter),this.o1=r.createOscillator(),this.o1.type=a.wave,this.g1=r.createGain(),this.g1.gain.value=.6,this.o1.connect(this.g1).connect(this.pre),this.o2=r.createOscillator(),this.o2.type="square",this.g2=r.createGain(),this.g2.gain.value=a.sub*.5,this.o2.connect(this.g2).connect(this.pre),i||(this.o3=r.createOscillator(),this.o3.type="sawtooth",this.g3=r.createGain(),this.g3.gain.value=a.harm2*.4,this.o3.connect(this.g3).connect(this.pre),this.o3.start(),this.lfo=r.createOscillator(),this.lfo.type="sine",this.lfoGain=r.createGain(),this.lfoGain.gain.value=a.am,this.lfo.connect(this.lfoGain).connect(this.am.gain),this.lfo.start(),this.ns=r.createBufferSource(),this.ns.buffer=t.noise,this.ns.loop=!0,this.nf=r.createBiquadFilter(),this.nf.type="bandpass",this.nf.Q.value=1.2,this.ng=r.createGain(),this.ng.gain.value=0,this.ns.connect(this.nf).connect(this.ng).connect(this.filter),this.ns.start(),a.pipe&&(this.pipe=r.createBiquadFilter(),this.pipe.type="peaking",this.pipe.Q.value=3,this.pipe.gain.value=0,this.filter.disconnect(),this.filter.connect(this.pipe).connect(this.out))),this.o1.start(),this.o2.start()),this.popT=0,this.vol=1}set(t,e,{limiter:n=!1,dopp:i=1,load:r=1,decel:a=!1}={}){let o=this.ctx.currentTime,l=this.p,c=.025;if(l.electric){let m=Math.max(20,t/60*6)*i;this.o1.frequency.setTargetAtTime(m,o,c),this.o2.frequency.setTargetAtTime(m*2.01,o,c),this.o3&&this.o3.frequency.setTargetAtTime(m*7.3,o,c);let x=$(t/9e3,0,1);this.out.gain.setTargetAtTime(l.gain*this.vol*(.08+x*.5+e*.35),o,.05),this.filter.frequency.setTargetAtTime(1200+x*5e3+e*1500,o,.05);return}let h=t/60*(l.cyl/(l.stroke===2?1:2))*i;this.o1.frequency.setTargetAtTime(h,o,c),this.o2.frequency.setTargetAtTime(h*.5,o,c),this.o3&&this.o3.frequency.setTargetAtTime(h*2,o,c),this.lfo&&this.lfo.frequency.setTargetAtTime(Math.max(2,h/l.amDiv/(l.cyl>1?l.cyl/2:1)),o,c);let u=$(t/(this.spec.engine.redline||1e4),0,1),d=l.cutoff+l.cutoffRpm*u*(.5+e*.7);if(this.filter.frequency.setTargetAtTime(d,o,c),this.pre.gain.setTargetAtTime(.25+e*.75*r,o,.04),this.ng&&(this.nf.frequency.setTargetAtTime(h*3,o,c),this.ng.gain.setTargetAtTime(l.noise*(.2+e*.8),o,.05)),this.pipe){let m=$((u-.6)*4,0,1)*e;this.pipe.frequency.setTargetAtTime(h*1.5,o,c),this.pipe.gain.setTargetAtTime(m*14,o,.05)}let f=l.gain*this.vol*(.35+e*.45+u*.35);n&&(f*=.55+Math.random()*.45),this.out.gain.setTargetAtTime(f,o,.03),a&&u>.45&&Math.random()<.06*l.decelPops&&this.sys.pop(this.panner?this.out:null,.5+Math.random()*.5)}setPosition(t,e,n){if(!this.panner)return;let i=this.ctx.currentTime;this.panner.positionX?(this.panner.positionX.setTargetAtTime(t,i,.02),this.panner.positionY.setTargetAtTime(e,i,.02),this.panner.positionZ.setTargetAtTime(n,i,.02)):this.panner.setPosition(t,e,n)}fade(t,e=.3){this.out.gain.setTargetAtTime(t,this.ctx.currentTime,e/3)}stop(){let t=this.ctx.currentTime;this.out.gain.setTargetAtTime(0,t,.05),setTimeout(()=>{for(let e of[this.o1,this.o2,this.o3,this.lfo,this.ns])try{e&&e.stop()}catch{}try{(this.panner||this.out).disconnect()}catch{}},300)}},Jo=s=>440*Math.pow(2,(s-69)/12),wv={menu:{bpm:100,prog:[[57,60,64],[53,57,60],[48,52,55],[55,59,62]],progB:[[50,53,57],[53,57,60],[55,59,62],[52,56,59]],drums:"half"},race:{bpm:126,prog:[[57,60,64],[57,60,64],[53,57,60],[55,59,62]],progB:[[50,53,57],[48,52,55],[53,57,60],[52,56,59]],drums:"four"},podium:{bpm:112,prog:[[48,52,55],[55,59,62],[57,60,64],[53,57,60]],progB:[[53,57,60],[55,59,62],[48,52,55],[55,59,62]],drums:"four"}},hu=class{constructor(t){this.sys=t,this.ctx=t.ctx,this.out=this.ctx.createGain(),this.out.gain.value=0,this.out.connect(t.music),this.delay=this.ctx.createDelay(1),this.fb=this.ctx.createGain(),this.fb.gain.value=.35,this.delay.connect(this.fb).connect(this.delay),this.delayOut=this.ctx.createGain(),this.delayOut.gain.value=.4,this.delay.connect(this.delayOut).connect(this.out),this.song=null,this.timer=null}play(t){this.songName!==t&&(this.songName=t,this.song=wv[t],this.step=0,this.next=this.ctx.currentTime+.1,this.delay.delayTime.value=60/this.song.bpm*.75,this.out.gain.cancelScheduledValues(this.ctx.currentTime),this.out.gain.setTargetAtTime(t==="race"?.5:.85,this.ctx.currentTime,.6),this.timer||(this.timer=setInterval(()=>this._tick(),30)))}stop(){this.songName=null,this.out.gain.setTargetAtTime(0,this.ctx.currentTime,.4),setTimeout(()=>{this.songName||(clearInterval(this.timer),this.timer=null)},1600)}_tick(){if(!this.song)return;let t=60/this.song.bpm/4;for(;this.next<this.ctx.currentTime+.15;)this._schedule(this.step,this.next,t),this.next+=t,this.step++}_schedule(t,e,n){let i=this.song,r=Math.floor(t/16),a=t%16,o=Math.floor(r/8)%2,c=(o?i.progB:i.prog)[r%4];(i.drums==="four"?a%4===0:a===0||a===10)&&this._kick(e),(a===4||a===12)&&this._snare(e),a%2===0&&this._hat(e,a%4===2?.08:.04),a%2===0&&this._bass(e,Jo(c[0]-24+(a===14?12:0)),n*1.8),a===0&&this._pad(e,c,n*16);let h=[0,1,2,1,0,2,1,2];r%8>=2&&this._pluck(e,Jo(c[h[a%8]]+12+(a>7?12:0)),n),o&&a%4===0&&r%2===1&&this._lead(e,Jo(c[a/4%3]+24),n*3)}_env(t,e,n,i,r,a=1e-4){t.gain.setValueAtTime(1e-4,e),t.gain.exponentialRampToValueAtTime(i,e+n),t.gain.exponentialRampToValueAtTime(a,e+n+r)}_kick(t){let e=this.ctx.createOscillator(),n=this.ctx.createGain();e.frequency.setValueAtTime(140,t),e.frequency.exponentialRampToValueAtTime(42,t+.12),this._env(n,t,.003,.9,.3),e.connect(n).connect(this.out),e.start(t),e.stop(t+.35)}_snare(t){let e=this.ctx.createBufferSource();e.buffer=this.sys.noise;let n=this.ctx.createBiquadFilter();n.type="highpass",n.frequency.value=1500;let i=this.ctx.createGain();this._env(i,t,.002,.35,.18),e.connect(n).connect(i).connect(this.out),e.start(t,Math.random()),e.stop(t+.22);let r=this.ctx.createOscillator(),a=this.ctx.createGain();r.frequency.value=190,this._env(a,t,.002,.25,.08),r.connect(a).connect(this.out),r.start(t),r.stop(t+.1)}_hat(t,e){let n=this.ctx.createBufferSource();n.buffer=this.sys.noise;let i=this.ctx.createBiquadFilter();i.type="highpass",i.frequency.value=7e3;let r=this.ctx.createGain();this._env(r,t,.001,e,.04),n.connect(i).connect(r).connect(this.out),n.start(t,Math.random()),n.stop(t+.06)}_bass(t,e,n){let i=this.ctx.createOscillator();i.type="sawtooth",i.frequency.value=e;let r=this.ctx.createBiquadFilter();r.type="lowpass",r.Q.value=6,r.frequency.setValueAtTime(900,t),r.frequency.exponentialRampToValueAtTime(160,t+n);let a=this.ctx.createGain();this._env(a,t,.005,.22,n),i.connect(r).connect(a).connect(this.out),i.start(t),i.stop(t+n+.05)}_pad(t,e,n){let i=this.ctx.createGain();i.gain.setValueAtTime(1e-4,t),i.gain.exponentialRampToValueAtTime(.06,t+.6),i.gain.setValueAtTime(.06,t+n-.4),i.gain.exponentialRampToValueAtTime(1e-4,t+n);let r=this.ctx.createBiquadFilter();r.type="lowpass",r.frequency.value=1400,r.connect(i).connect(this.out);for(let a of e)for(let o of[-7,7]){let l=this.ctx.createOscillator();l.type="sawtooth",l.frequency.value=Jo(a),l.detune.value=o,l.connect(r),l.start(t),l.stop(t+n+.05)}}_pluck(t,e,n){let i=this.ctx.createOscillator();i.type="square",i.frequency.value=e;let r=this.ctx.createBiquadFilter();r.type="lowpass",r.frequency.setValueAtTime(3200,t),r.frequency.exponentialRampToValueAtTime(500,t+.15);let a=this.ctx.createGain();this._env(a,t,.002,.07,.18),i.connect(r).connect(a),a.connect(this.out),a.connect(this.delay),i.start(t),i.stop(t+.25)}_lead(t,e,n){let i=this.ctx.createOscillator();i.type="sawtooth",i.frequency.value=e;let r=this.ctx.createOscillator();r.frequency.value=5.5;let a=this.ctx.createGain();a.gain.value=6,r.connect(a).connect(i.detune);let o=this.ctx.createBiquadFilter();o.type="lowpass",o.frequency.value=2400;let l=this.ctx.createGain();this._env(l,t,.03,.06,n),i.connect(o).connect(l),l.connect(this.out),l.connect(this.delay),i.start(t),r.start(t),i.stop(t+n+.1),r.stop(t+n+.1)}},uu=class{constructor(){this.ctx=null,this.ready=!1}init(){if(this.ctx){this.ctx.state==="suspended"&&this.ctx.resume();return}let t=window.AudioContext||window.webkitAudioContext;if(!t)return;this.ctx=new t;let e=this.ctx;this.master=e.createGain(),this.comp=e.createDynamicsCompressor(),this.comp.threshold.value=-14,this.comp.ratio.value=4,this.master.connect(this.comp).connect(e.destination),this.sfx=e.createGain(),this.sfx.connect(this.master),this.music=e.createGain(),this.music.connect(this.master),this.ui=e.createGain(),this.ui.connect(this.master);let n=e.sampleRate*2;this.noise=e.createBuffer(1,n,e.sampleRate);let i=this.noise.getChannelData(0);for(let r=0;r<n;r++)i[r]=Math.random()*2-1;Mv=this.noise,this.musicPlayer=new hu(this),this.applyVolumes(),this.ready=!0,this.wind=this._loopNoise("bandpass",600,.6),this.screech=this._loopNoise("bandpass",1900,6),this.scrapeV=this._loopNoise("highpass",3500,.7),this.rumble=this._loopNoise("lowpass",160,1),this._pendingMusic&&(this.playMusic(this._pendingMusic),this._pendingMusic=null)}_loopNoise(t,e,n){let i=this.ctx.createBufferSource();i.buffer=this.noise,i.loop=!0;let r=this.ctx.createBiquadFilter();r.type=t,r.frequency.value=e,r.Q.value=n;let a=this.ctx.createGain();return a.gain.value=0,i.connect(r).connect(a).connect(this.sfx),i.start(0,Math.random()*1.5),{src:i,f:r,g:a}}applyVolumes(){if(!this.ctx)return;let t=rt.settings;this.master.gain.value=t.masterVol,this.music.gain.value=t.musicVol*.55,this.sfx.gain.value=t.sfxVol,this.ui.gain.value=t.sfxVol*.7}engine(t,e){return this.ctx?new cu(this,t,e):null}setListener(t){if(!this.ctx)return;let e=this.ctx.listener,n=this.ctx.currentTime,i=t.position,r=t.getWorldDirection(this._fwd||(this._fwd=t.position.clone()));e.positionX?(e.positionX.setTargetAtTime(i.x,n,.02),e.positionY.setTargetAtTime(i.y,n,.02),e.positionZ.setTargetAtTime(i.z,n,.02),e.forwardX.setTargetAtTime(r.x,n,.02),e.forwardY.setTargetAtTime(r.y,n,.02),e.forwardZ.setTargetAtTime(r.z,n,.02),e.upX.setTargetAtTime(0,n,.02),e.upY.setTargetAtTime(1,n,.02),e.upZ.setTargetAtTime(0,n,.02)):(e.setPosition(i.x,i.y,i.z),e.setOrientation(r.x,r.y,r.z,0,1,0))}layers({speed:t=0,slip:e=0,scrape:n=0,rumble:i=0}={}){if(!this.ctx)return;let r=this.ctx.currentTime,a=$(t/90,0,1);this.wind.g.gain.setTargetAtTime(a*a*.35,r,.1),this.wind.f.frequency.setTargetAtTime(400+a*1600,r,.1),this.screech.g.gain.setTargetAtTime($(e,0,1)*.22,r,.04),this.screech.f.frequency.setTargetAtTime(1500+Math.random()*600,r,.05),this.scrapeV.g.gain.setTargetAtTime($(n,0,1)*.3,r,.03),this.rumble.g.gain.setTargetAtTime($(i,0,1)*.5,r,.05)}silenceLayers(){this.layers({})}_blip(t,e,n="sine",i=.2,r=this.ui,a=0){if(!this.ctx)return;let o=this.ctx.currentTime,l=this.ctx.createOscillator();l.type=n,l.frequency.setValueAtTime(t,o),a&&l.frequency.exponentialRampToValueAtTime(t*a,o+e);let c=this.ctx.createGain();c.gain.setValueAtTime(i,o),c.gain.exponentialRampToValueAtTime(1e-4,o+e),l.connect(c).connect(r),l.start(o),l.stop(o+e+.02)}_noiseHit(t,e,n,i,r=this.sfx,a=1){if(!this.ctx)return;let o=this.ctx.currentTime,l=this.ctx.createBufferSource();l.buffer=this.noise;let c=this.ctx.createBiquadFilter();c.type=t,c.frequency.value=e,c.Q.value=a;let h=this.ctx.createGain();h.gain.setValueAtTime(i,o),h.gain.exponentialRampToValueAtTime(1e-4,o+n),l.connect(c).connect(h).connect(r),l.start(o,Math.random()),l.stop(o+n+.02)}hover(){this._blip(1800,.04,"sine",.05)}click(){this._blip(900,.07,"triangle",.14),this._blip(1350,.06,"sine",.06)}back(){this._blip(600,.09,"triangle",.12,this.ui,.6)}select(){this._blip(660,.12,"square",.06),setTimeout(()=>this._blip(990,.18,"square",.06),70)}beep(t=!1){this._blip(t?1320:660,t?.6:.25,"square",.12,this.sfx)}lap(){[880,1108,1318].forEach((t,e)=>setTimeout(()=>this._blip(t,.2,"triangle",.12,this.sfx),e*90))}fanfare(){[523,659,784,1046,784,1046].forEach((t,e)=>setTimeout(()=>this._blip(t,.3,"square",.08,this.sfx),e*140))}warn(){this._blip(440,.2,"sawtooth",.08,this.sfx),setTimeout(()=>this._blip(440,.2,"sawtooth",.08,this.sfx),260)}impact(t=1){this._noiseHit("lowpass",400,.35,.6*$(t,.2,1.5)),this._blip(90,.25,"sine",.5*$(t,.2,1.2),this.sfx,.5),this._noiseHit("bandpass",2500,.2,.25*t,this.sfx,2)}crash(){this.impact(1.4),setTimeout(()=>this._noiseHit("highpass",3e3,.9,.35),80),setTimeout(()=>this.impact(.8),300)}shiftClunk(){this._noiseHit("bandpass",300,.05,.12,this.sfx,3)}pop(t,e=1){this.ctx&&this._noiseHit("bandpass",900+Math.random()*900,.06,.35*e,t||this.sfx,1.5)}nitro(){this._noiseHit("bandpass",1200,.8,.3,this.sfx,.8),this._blip(200,.6,"sawtooth",.08,this.sfx,3)}thunder(){this.ctx&&(this._noiseHit("lowpass",220,3.5,.9,this.sfx,.7),setTimeout(()=>this._noiseHit("lowpass",120,2.5,.7,this.sfx,.5),300))}whoosh(){this._noiseHit("bandpass",800,.4,.2,this.sfx,.7)}playMusic(t){if(!this.ctx){this._pendingMusic=t;return}this.musicPlayer.play(t)}stopMusic(){this.musicPlayer&&this.musicPlayer.stop()}},It=new uu;var jo=class extends pn{constructor(){super();let t=new jt;t.deleteAttribute("uv");let e=new at({side:Ce}),n=new at,i=new ur(16777215,900,28,2);i.position.set(.418,16.199,.3),this.add(i);let r=new it(t,e);r.position.set(-.757,13.219,.717),r.scale.set(31.713,28.305,28.591),this.add(r);let a=new it(t,n);a.position.set(-10.906,2.009,1.846),a.rotation.set(0,-.195,0),a.scale.set(2.328,7.905,4.651),this.add(a);let o=new it(t,n);o.position.set(-5.607,-.754,-.758),o.rotation.set(0,.994,0),o.scale.set(1.97,1.534,3.955),this.add(o);let l=new it(t,n);l.position.set(6.167,.857,7.803),l.rotation.set(0,.561,0),l.scale.set(3.927,6.285,3.687),this.add(l);let c=new it(t,n);c.position.set(-2.017,.018,6.124),c.rotation.set(0,.333,0),c.scale.set(2.002,4.566,2.064),this.add(c);let h=new it(t,n);h.position.set(2.291,-.756,-2.621),h.rotation.set(0,-.286,0),h.scale.set(1.546,1.552,1.496),this.add(h);let u=new it(t,n);u.position.set(-2.193,-.369,-5.547),u.rotation.set(0,.516,0),u.scale.set(3.875,3.487,2.986),this.add(u);let d=new it(t,mr(50));d.position.set(-16.116,14.37,8.208),d.scale.set(.1,2.428,2.739),this.add(d);let f=new it(t,mr(50));f.position.set(-16.109,18.021,-8.207),f.scale.set(.1,2.425,2.751),this.add(f);let m=new it(t,mr(17));m.position.set(14.904,12.198,-1.832),m.scale.set(.15,4.265,6.331),this.add(m);let x=new it(t,mr(43));x.position.set(-.462,8.89,14.52),x.scale.set(4.38,5.441,.088),this.add(x);let g=new it(t,mr(20));g.position.set(3.235,11.486,-12.541),g.scale.set(2.5,2,.1),this.add(g);let p=new it(t,mr(100));p.position.set(0,20,0),p.scale.set(1,.1,1),this.add(p)}dispose(){let t=new Set;this.traverse(e=>{e.isMesh&&(t.add(e.geometry),t.add(e.material))});for(let e of t)e.dispose()}};function mr(s){let t=new De;return t.color.setScalar(s),t}var la=class s extends it{constructor(t,e={}){super(t),this.isReflector=!0,this.type="Reflector",this.camera=new Ue;let n=this,i=e.color!==void 0?new ot(e.color):new ot(8355711),r=e.textureWidth||512,a=e.textureHeight||512,o=e.clipBias||0,l=e.shader||s.ReflectorShader,c=e.multisample!==void 0?e.multisample:4,h=new Wn,u=new C,d=new C,f=new C,m=new Lt,x=new C(0,0,-1),g=new ue,p=new C,v=new C,y=new ue,_=new Lt,S=this.camera,M=new Ne(r,a,{samples:c,type:ln}),E=new ve({name:l.name!==void 0?l.name:"unspecified",uniforms:Tn.clone(l.uniforms),fragmentShader:l.fragmentShader,vertexShader:l.vertexShader});E.uniforms.tDiffuse.value=M.texture,E.uniforms.color.value=i,E.uniforms.textureMatrix.value=_,this.material=E,this.onBeforeRender=function(A,w,b){if(d.setFromMatrixPosition(n.matrixWorld),f.setFromMatrixPosition(b.matrixWorld),m.extractRotation(n.matrixWorld),u.set(0,0,1),u.applyMatrix4(m),p.subVectors(d,f),p.dot(u)>0)return;p.reflect(u).negate(),p.add(d),m.extractRotation(b.matrixWorld),x.set(0,0,-1),x.applyMatrix4(m),x.add(f),v.subVectors(d,x),v.reflect(u).negate(),v.add(d),S.position.copy(p),S.up.set(0,1,0),S.up.applyMatrix4(m),S.up.reflect(u),S.lookAt(v),S.far=b.far,S.updateMatrixWorld(),S.projectionMatrix.copy(b.projectionMatrix),_.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),_.multiply(S.projectionMatrix),_.multiply(S.matrixWorldInverse),_.multiply(n.matrixWorld),h.setFromNormalAndCoplanarPoint(u,d),h.applyMatrix4(S.matrixWorldInverse),g.set(h.normal.x,h.normal.y,h.normal.z,h.constant);let P=S.projectionMatrix;y.x=(Math.sign(g.x)+P.elements[8])/P.elements[0],y.y=(Math.sign(g.y)+P.elements[9])/P.elements[5],y.z=-1,y.w=(1+P.elements[10])/P.elements[14],g.multiplyScalar(2/g.dot(y)),P.elements[2]=g.x,P.elements[6]=g.y,P.elements[10]=g.z+1-o,P.elements[14]=g.w,n.visible=!1;let D=A.getRenderTarget(),U=A.xr.enabled,F=A.shadowMap.autoUpdate;A.xr.enabled=!1,A.shadowMap.autoUpdate=!1,A.setRenderTarget(M),A.state.buffers.depth.setMask(!0),A.autoClear===!1&&A.clear(),A.render(w,S),A.xr.enabled=U,A.shadowMap.autoUpdate=F,A.setRenderTarget(D);let q=b.viewport;q!==void 0&&A.state.viewport(q),n.visible=!0},this.getRenderTarget=function(){return M},this.dispose=function(){M.dispose(),n.material.dispose()}}};la.ReflectorShader={name:"ReflectorShader",uniforms:{color:{value:null},tDiffuse:{value:null},textureMatrix:{value:null}},vertexShader:`
		uniform mat4 textureMatrix;
		varying vec4 vUv;

		#include <common>
		#include <logdepthbuf_pars_vertex>

		void main() {

			vUv = textureMatrix * vec4( position, 1.0 );

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

			#include <logdepthbuf_vertex>

		}`,fragmentShader:`
		uniform vec3 color;
		uniform sampler2D tDiffuse;
		varying vec4 vUv;

		#include <logdepthbuf_pars_fragment>

		float blendOverlay( float base, float blend ) {

			return( base < 0.5 ? ( 2.0 * base * blend ) : ( 1.0 - 2.0 * ( 1.0 - base ) * ( 1.0 - blend ) ) );

		}

		vec3 blendOverlay( vec3 base, vec3 blend ) {

			return vec3( blendOverlay( base.r, blend.r ), blendOverlay( base.g, blend.g ), blendOverlay( base.b, blend.b ) );

		}

		void main() {

			#include <logdepthbuf_fragment>

			vec4 base = texture2DProj( tDiffuse, vUv );
			gl_FragColor = vec4( blendOverlay( base.rgb, color ), 1.0 );

			#include <tonemapping_fragment>
			#include <colorspace_fragment>

		}`};function An(s,t=!1){let e=s[0].index!==null,n=new Set(Object.keys(s[0].attributes)),i=new Set(Object.keys(s[0].morphAttributes)),r={},a={},o=s[0].morphTargetsRelative,l=new Gt,c=0;for(let h=0;h<s.length;++h){let u=s[h],d=0;if(e!==(u.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(let f in u.attributes){if(!n.has(f))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have compatible attributes; make sure "'+f+'" attribute exists among all geometries, or in none of them.'),null;r[f]===void 0&&(r[f]=[]),r[f].push(u.attributes[f]),d++}if(d!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of attributes."),null;if(o!==u.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(let f in u.morphAttributes){if(!i.has(f))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+".  .morphAttributes must be consistent throughout all geometries."),null;a[f]===void 0&&(a[f]=[]),a[f].push(u.morphAttributes[f])}if(t){let f;if(e)f=u.index.count;else if(u.attributes.position!==void 0)f=u.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,f,h),c+=f}}if(e){let h=0,u=[];for(let d=0;d<s.length;++d){let f=s[d].index;for(let m=0;m<f.count;++m)u.push(f.getX(m)+h);h+=s[d].attributes.position.count}l.setIndex(u)}for(let h in r){let u=Xf(r[h]);if(!u)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" attribute."),null;l.setAttribute(h,u)}for(let h in a){let u=a[h][0].length;if(u===0)break;l.morphAttributes=l.morphAttributes||{},l.morphAttributes[h]=[];for(let d=0;d<u;++d){let f=[];for(let x=0;x<a[h].length;++x)f.push(a[h][x][d]);let m=Xf(f);if(!m)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" morphAttribute."),null;l.morphAttributes[h].push(m)}}return l}function Xf(s){let t,e,n,i=-1,r=0;for(let c=0;c<s.length;++c){let h=s[c];if(t===void 0&&(t=h.array.constructor),t!==h.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(e===void 0&&(e=h.itemSize),e!==h.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=h.normalized),n!==h.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(i===-1&&(i=h.gpuType),i!==h.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=h.count*e}let a=new t(r),o=new Vt(a,e,n),l=0;for(let c=0;c<s.length;++c){let h=s[c];if(h.isInterleavedBufferAttribute){let u=l/e;for(let d=0,f=h.count;d<f;d++)for(let m=0;m<e;m++){let x=h.getComponent(d,m);o.setComponent(d+u,m,x)}}else a.set(h.array,l);l+=h.count*e}return i!==void 0&&(o.gpuType=i),o}var u_=new Lt,Qo=class{constructor(){this.inner=new Qt,this.groups={},this.buckets=new Map,this.inverse={},this.addGroup("chassis",this.inner)}addGroup(t,e,n=[0,0,0],i=[0,0,0]){let r=t==="chassis"?new Qt:new Qt;return r.name=t,r.position.set(...n),r.rotation.set(...i),(typeof e=="string"?this.groups[e]:e).add(r),this.groups[t]=r,this.inner.updateMatrixWorld(!0),r}_inv(t){let e=this.groups[t];this.inner.updateMatrixWorld(!0);let n=new Lt().copy(this.inner.matrixWorld).invert();return new Lt().multiplyMatrices(n,e.matrixWorld).invert()}add(t,e,n,{local:i=!1}={}){if(!e)return;let r=e;r.index,!i&&t!=="chassis"&&(r=r.clone(),r.applyMatrix4(this._inv(t))),this.buckets.has(t)||this.buckets.set(t,new Map);let a=this.buckets.get(t);a.has(n)||a.set(n,[]),a.get(n).push(r)}finalize({castShadow:t=!0}={}){let e=[];for(let[n,i]of this.buckets)for(let[r,a]of i){let o=a.map(h=>Sv(h)),l;try{l=An(o,!1)}catch{l=null}if(!l){for(let h of o){let u=new it(h,r);u.castShadow=t&&!r.transparent,u.receiveShadow=!0,this.groups[n].add(u),e.push(u)}continue}l.computeBoundingSphere();let c=new it(l,r);c.castShadow=t&&!r.transparent&&!(r.emissiveIntensity>1&&r.color&&r.color.getHex()===0),c.receiveShadow=!r.transparent,c.name=`${n}:${r.name||r.type}`,this.groups[n].add(c),e.push(c);for(let h of o)h.dispose()}return this.buckets.clear(),e}};function Sv(s){let t=s;if(t.attributes.normal||t.computeVertexNormals(),!t.attributes.uv){let e=t.attributes.position.count;t.setAttribute("uv",new wt(new Float32Array(e*2),2))}for(let e of Object.keys(t.attributes))e!=="position"&&e!=="normal"&&e!=="uv"&&t.deleteAttribute(e);if(!t.index){let e=t.attributes.position.count,n=new(e>65535?Uint32Array:Uint16Array)(e);for(let i=0;i<e;i++)n[i]=i;t.setIndex(new Vt(n,1))}return t.morphAttributes={},t}var ca=new C;function Rn(s,t,e,n,i,r){let a=2*Math.PI*i/4,o=Math.max(r-2*i,0),l=Math.PI/4;ca.copy(t),ca[n]=0,ca.normalize();let c=.5*a/(a+o),h=1-ca.angleTo(s)/l;return Math.sign(ca[e])===1?h*c:o/(a+o)+c+c*(1-h)}var tl=class extends jt{constructor(t=1,e=1,n=1,i=2,r=.1){if(i=i*2+1,r=Math.min(t/2,e/2,n/2,r),super(1,1,1,i,i,i),i===1)return;let a=this.toNonIndexed();this.index=null,this.attributes.position=a.attributes.position,this.attributes.normal=a.attributes.normal,this.attributes.uv=a.attributes.uv;let o=new C,l=new C,c=new C(t,e,n).divideScalar(2).subScalar(r),h=this.attributes.position.array,u=this.attributes.normal.array,d=this.attributes.uv.array,f=h.length/6,m=new C,x=.5/i;for(let g=0,p=0;g<h.length;g+=3,p+=2)switch(o.fromArray(h,g),l.copy(o),l.x-=Math.sign(l.x)*x,l.y-=Math.sign(l.y)*x,l.z-=Math.sign(l.z)*x,l.normalize(),h[g+0]=c.x*Math.sign(o.x)+l.x*r,h[g+1]=c.y*Math.sign(o.y)+l.y*r,h[g+2]=c.z*Math.sign(o.z)+l.z*r,u[g+0]=l.x,u[g+1]=l.y,u[g+2]=l.z,Math.floor(g/f)){case 0:m.set(1,0,0),d[p+0]=Rn(m,l,"z","y",r,n),d[p+1]=1-Rn(m,l,"y","z",r,e);break;case 1:m.set(-1,0,0),d[p+0]=1-Rn(m,l,"z","y",r,n),d[p+1]=1-Rn(m,l,"y","z",r,e);break;case 2:m.set(0,1,0),d[p+0]=1-Rn(m,l,"x","z",r,t),d[p+1]=Rn(m,l,"z","x",r,n);break;case 3:m.set(0,-1,0),d[p+0]=1-Rn(m,l,"x","z",r,t),d[p+1]=1-Rn(m,l,"z","x",r,n);break;case 4:m.set(0,0,1),d[p+0]=1-Rn(m,l,"x","y",r,t),d[p+1]=1-Rn(m,l,"y","x",r,e);break;case 5:m.set(0,0,-1),d[p+0]=Rn(m,l,"x","y",r,t),d[p+1]=1-Rn(m,l,"y","x",r,e);break}}};var Kn=C;function Ev(s,t,e,n,i){let r=i*i,a=r*i;return .5*(2*t+(-s+e)*i+(2*s-5*t+4*e-n)*r+(-s+3*t-3*e+n)*a)}var Tv=["x","y","w","ht","hb","n","z","nb"];function Av(s){return{x:s.x,y:s.y??0,w:s.w??.1,ht:s.ht??s.h??.1,hb:s.hb??s.ht??s.h??.1,n:s.n??2.4,z:s.z??0,nb:s.nb??s.n??2.4}}function te(s,t={}){let e=t.radial??28,n=t.sub??6,i=t.t0??-Math.PI/2,r=t.t1??Math.PI*1.5,a=t.t0===void 0&&t.t1===void 0,o=s.map(Av);o[o.length-1].x<o[0].x&&(o=o.reverse(),t={...t,capStart:t.capEnd,capEnd:t.capStart});let l=[];for(let p=0;p<o.length-1;p++){let v=o[Math.max(0,p-1)],y=o[p],_=o[p+1],S=o[Math.min(o.length-1,p+2)],M=p===o.length-2?n+1:n;for(let E=0;E<M;E++){let A=E/n,w={};for(let b of Tv)w[b]=Ev(v[b],y[b],_[b],S[b],A);w.w=Math.max(w.w,5e-4),w.ht=Math.max(w.ht,5e-4),w.hb=Math.max(w.hb,5e-4),w.n=Math.max(w.n,.6),w.nb=Math.max(w.nb,.6),l.push(w)}}let c=l[0].x,h=l[l.length-1].x,u=e+1,d=[],f=[],m=[];for(let p=0;p<l.length;p++){let v=l[p];for(let y=0;y<u;y++){let _=i+(r-i)*(y/e),S=Math.cos(_),M=Math.sin(_),E=2/(M>=0?v.n:v.nb),A=v.z+v.w*Math.sign(S)*Math.pow(Math.abs(S),E),w=v.y+(M>=0?v.ht:v.hb)*Math.sign(M)*Math.pow(Math.abs(M),E);d.push(v.x,w,A),f.push((v.x-c)/(h-c||1),(_+Math.PI/2)/(Math.PI*2))}}for(let p=0;p<l.length-1;p++)for(let v=0;v<e;v++){let y=p*u+v,_=y+1,S=y+u,M=S+1;m.push(y,S,_,_,S,M)}let x=(p,v)=>{let y=l[p],_=d.length/3;d.push(y.x,y.y,y.z),f.push(p===0?0:1,.5);for(let S=0;S<e;S++){let M=p*u+S,E=M+1;v?m.push(_,M,E):m.push(_,E,M)}};t.capStart&&x(0,!0),t.capEnd&&x(l.length-1,!1);let g=new Gt;return g.setAttribute("position",new wt(d,3)),g.setAttribute("uv",new wt(f,2)),g.setIndex(m),g.computeVertexNormals(),t.flip&&gr(g),g}function gr(s){let t=s.index.array;for(let n=0;n<t.length;n+=3){let i=t[n+1];t[n+1]=t[n+2],t[n+2]=i}s.index.needsUpdate=!0;let e=s.attributes.normal;if(e){for(let n=0;n<e.array.length;n++)e.array[n]*=-1;e.needsUpdate=!0}return s}function Oe(s,t=.02,{segments:e,radial:n=10,closed:i=!1,tension:r=.5,type:a="catmullrom"}={}){let o=s.map(h=>h.isVector3?h:new Kn(h[0],h[1],h[2]??0)),l=new En(o,i,a,r),c=e??Math.max(8,Math.round(l.getLength()*40));return new ci(l,c,t,n,i)}function qf(s,t,{radial:e=12,segments:n=48,capEnds:i=!0}={}){let r=s.map(m=>m.isVector3?m:new Kn(m[0],m[1],m[2]??0)),a=new En(r,!1,"catmullrom",.5),o=a.computeFrenetFrames(n,!1),l=[],c=[],h=[],u=m=>{let x=m*(t.length-1),g=Math.min(Math.floor(x),t.length-2),p=x-g;return t[g]*(1-p)+t[g+1]*p};for(let m=0;m<=n;m++){let x=m/n,g=a.getPointAt(x),p=o.normals[m],v=o.binormals[m],y=u(x);for(let _=0;_<=e;_++){let S=_/e*Math.PI*2,M=Math.cos(S),E=Math.sin(S);l.push(g.x+y*(M*p.x+E*v.x),g.y+y*(M*p.y+E*v.y),g.z+y*(M*p.z+E*v.z)),c.push(_/e,x)}}let d=e+1;for(let m=0;m<n;m++)for(let x=0;x<e;x++){let g=m*d+x,p=g+1,v=g+d,y=v+1;h.push(g,p,v,p,y,v)}if(i)for(let m of[0,n]){let x=a.getPointAt(m/n),g=l.length/3;l.push(x.x,x.y,x.z),c.push(.5,m?1:0);for(let p=0;p<e;p++){let v=m*d+p,y=v+1;m===0?h.push(g,y,v):h.push(g,v,y)}}let f=new Gt;return f.setAttribute("position",new wt(l,3)),f.setAttribute("uv",new wt(c,2)),f.setIndex(h),f.computeVertexNormals(),f}function ha(s,t=32,e="y",n=0,i=Math.PI*2){let r=s.map(([o,l])=>new tt(Math.max(o,1e-4),l)),a=new vs(r,t,n,i);return e==="z"?a.rotateX(Math.PI/2):e==="x"&&a.rotateZ(-Math.PI/2),a}function kt(s,t,e,n=0){return n>0?new tl(s,t,e,2,Math.min(n,Math.min(s,t,e)/2-1e-4)):new jt(s,t,e)}function rn(s,t,e,n=20,i="y",r=!1){let a=new ke(s,t,e,n,1,r);return i==="z"?a.rotateX(Math.PI/2):i==="x"&&a.rotateZ(Math.PI/2),a}function ui(s,t=20,e=14){return new mn(s,t,e)}function St(s,{p:t=[0,0,0],r:e=[0,0,0],s:n=[1,1,1]}={}){let i=new Lt().compose(new Kn(t[0],t[1],t[2]),new Fe().setFromEuler(new nn(e[0],e[1],e[2])),new Kn(n[0],n[1],n[2]));return s.applyMatrix4(i),s}function Yf(s,t,e){let n=new Kn(...t),i=new Kn(...e),r=i.clone().sub(n),a=r.length();s.applyMatrix4(new Lt().makeScale(1,a,1));let o=new Fe().setFromUnitVectors(new Kn(0,1,0),r.normalize());s.applyMatrix4(new Lt().makeRotationFromQuaternion(o));let l=n.add(i).multiplyScalar(.5);return s.translate(l.x,l.y,l.z),s}function Ht(s,t,e=.015,n=10){let i=new ke(e,e,1,n,1,!1);return Yf(i,s,t)}function ua(s,t,e=.035,n=.007,i=9){let r=[],a=i*16;for(let m=0;m<=a;m++){let x=m/a,g=x*i*Math.PI*2;r.push(new Kn(Math.cos(g)*e,x,Math.sin(g)*e))}let o=new En(r),l=new ci(o,a,n,6,!1),c=new Kn(...s),u=new Kn(...t).clone().sub(c),d=u.length();l.applyMatrix4(new Lt().makeScale(1,d,1));let f=new Fe().setFromUnitVectors(new Kn(0,1,0),u.normalize());return l.applyMatrix4(new Lt().makeRotationFromQuaternion(f)),l.translate(c.x,c.y,c.z),l}function $f(s,t,e=48){return new Ms(s,t,e,1)}function Zf(s,t,e=32,n=8,i=Math.PI*2){return new $i(s,t,n,e,i)}var du=new Map;function Pe(s,t){return du.has(s)||du.set(s,t()),du.get(s)}var k={paint(s,{metal:t=.55,rough:e=.32,clear:n=1,map:i=null}={}){let r=`paint:${s}:${t}:${e}:${n}:${i?i.uuid:""}`;return Pe(r,()=>new $n({color:i?16777215:s,map:i,metalness:t,roughness:e,clearcoat:n,clearcoatRoughness:.06}))},matte(s,t=.75){return Pe(`matte:${s}:${t}`,()=>new at({color:s,roughness:t,metalness:.15}))},chrome(){return Pe("chrome",()=>new at({color:15922424,metalness:1,roughness:.06}))},darkChrome(){return Pe("darkchrome",()=>new at({color:5593182,metalness:1,roughness:.15}))},aluminum(){return Pe("alu",()=>{let s=If();return new at({color:13225169,metalness:1,roughness:.32,roughnessMap:s})})},anodized(s=2237480){return Pe(`anod:${s}`,()=>new at({color:s,metalness:.85,roughness:.38}))},gold(){return Pe("gold",()=>new at({color:13935665,metalness:1,roughness:.22}))},copper(){return Pe("copper",()=>new at({color:12872250,metalness:1,roughness:.3}))},titanium(){return Pe("ti",()=>new at({map:kf(),metalness:1,roughness:.25}))},carbon(){return Pe("carbon",()=>{let{map:s,normalMap:t}=$o();return s.repeat.set(6,6),t.repeat.set(6,6),new $n({map:s,normalMap:t,normalScale:new tt(.4,.4),metalness:.3,roughness:.4,clearcoat:1,clearcoatRoughness:.05})})},rubber(){return Pe("rubber",()=>new at({color:1710620,roughness:.92,metalness:0}))},tire(s=!1){return Pe(`tire:${s}`,()=>new at({map:oa(s),roughness:.88,metalness:0}))},plastic(s=1315862){return Pe(`plastic:${s}`,()=>new at({color:s,roughness:.55,metalness:.05}))},leather(s=2763306){return Pe(`leather:${s}`,()=>{let{map:t,normalMap:e}=Zo();return t.repeat.set(3,3),e.repeat.set(3,3),new at({color:s,map:t,normalMap:e,normalScale:new tt(.6,.6),roughness:.68,metalness:0})})},glass(s=2241348,t=.35){return Pe(`glass:${s}:${t}`,()=>new $n({color:s,metalness:0,roughness:.03,transparent:!0,opacity:t,clearcoat:1,depthWrite:!1,side:xe}))},lens(){return Pe("lens",()=>new $n({color:16777215,metalness:.2,roughness:.02,transparent:!0,opacity:.55,clearcoat:1}))},emissive(s,t=3){return Pe(`emis:${s}:${t}`,()=>new at({color:0,emissive:s,emissiveIntensity:t,roughness:.4}))},radiator(){return Pe("radiator",()=>{let s=Df();return s.repeat.set(3,3),new at({map:s,metalness:.6,roughness:.6})})},engine(s=2829617){return Pe(`engine:${s}`,()=>new at({color:s,metalness:.75,roughness:.42}))},disc(){return Pe("disc",()=>new at({color:11054258,metalness:1,roughness:.28}))},spring(s=14857505){return Pe(`spring:${s}`,()=>new at({color:s,metalness:.6,roughness:.35}))},black(){return Pe("black",()=>new at({color:723724,roughness:.6,metalness:.3}))},screen(){return Pe("screen",()=>new at({color:329224,emissive:662056,emissiveIntensity:1,roughness:.2}))}};var xr=(s,t,e=0)=>new C(s,t,e),Cn=Math.PI/180;function Rv(s){let t=0;for(let e=0;e<s.length;e++){let[n,i]=s[e],[r,a]=s[(e+1)%s.length];t+=n*a-r*i}return t/2}function cn(s,t=32,e="z"){let n=s.slice();return Rv(n)<0&&n.reverse(),n.push(n[0]),ha(n,t,e)}function Pn(s){let{A:t,m:e}=s,n=e.wb;s.rear={x:-n/2,y:e.rear.R,...e.rear},s.front={x:n/2,y:e.front.R,...e.front},s.rake=e.rake*Cn,s.offset=e.forkOffset??.032,s.Lf=e.forkLen??.56,s.headLen=e.headLen??.15,s.fw=e.forkWidth??Math.max(.085,s.front.w/2+.045);let i=s.rake;s.d=xr(-Math.sin(i),Math.cos(i)),s.n=xr(Math.cos(i),Math.sin(i)),s.fp=(h,u=0)=>[s.front.x+s.d.x*h,s.front.y+s.d.y*h,u],s.sp=(h,u=0)=>[s.front.x+s.d.x*h-s.n.x*s.offset,s.front.y+s.d.y*h-s.n.y*s.offset,u];let r=s.sp(s.Lf);s.head=r,s.headTop=s.sp(s.Lf+s.headLen),s.pivot=e.pivot||[-.16,.44],t.addGroup("steer","chassis",[r[0],r[1],0],[0,0,i]);let a=s.front.x-r[0],o=s.front.y-r[1],l=a*Math.cos(-i)-o*Math.sin(-i),c=a*Math.sin(-i)+o*Math.cos(-i);t.addGroup("forkSlider","steer",[l,c,0]),t.addGroup("frontWheel","forkSlider"),t.addGroup("swingarm","chassis",[s.pivot[0],s.pivot[1],0]),t.addGroup("rearWheel","swingarm",[s.rear.x-s.pivot[0],s.rear.y-s.pivot[1],0]),s.exhausts=[],s.headlights=[],s.tails=[]}function pu(s,t,e){let{A:n}=s,i=e.R,r=e.rim,a=e.w,o=e.style||"cast",l=[],c=18,h=e.knobby?.28:e.exp??.42;for(let x=0;x<=c;x++){let g=-Math.PI/2+Math.PI*(x/c),p=a/2*Math.sin(g),v=r-.006+(i-r+.006-(e.knobby?.012:0))*Math.pow(Math.max(Math.cos(g),0),h);l.push([v,p])}if(n.add(t,ha(l,56,"z"),k.tire(!!e.knobby),{local:!0}),e.knobby){let x=[],g=Math.round(2*Math.PI*i/.042);for(let p=-1;p<=1;p++)for(let v=0;v<g;v++){let y=v/g*Math.PI*2+(p===0?0:Math.PI/g*p*.5);if(p!==0&&v%2)continue;let _=i-.012+(p===0?.006:.002),S=kt(.014,.022,p===0?.03:.022);St(S,{p:[Math.cos(y)*_,Math.sin(y)*_,p*a*.3],r:[p*.35,0,y]}),x.push(S)}for(let p of x)n.add(t,p,k.rubber(),{local:!0})}let u=a*(e.knobby?.6:.82),d=e.rimMat||s.mats.wheel;o!=="hubless"&&(n.add(t,cn([[r+.008,-u/2],[r-.002,-u/2-.003],[r-.016,-u/2+.006],[r-.03,-u*.25],[r-.03,u*.25],[r-.016,u/2-.006],[r-.002,u/2+.003],[r+.008,u/2],[r+.002,u/2-.008],[r-.006,0],[r+.002,-u/2+.008]],56),d,{local:!0}),e.rimStripe&&(n.add(t,cn([[r+.0035,-u/2-.0015],[r+.0055,-u/2-.0015],[r+.0055,-u/2+.003],[r+.0035,-u/2+.003]],56),e.rimStripe,{local:!0}),n.add(t,cn([[r+.0035,u/2+.0015],[r+.0055,u/2+.0015],[r+.0055,u/2-.003],[r+.0035,u/2-.003]],56),e.rimStripe,{local:!0})));let f=e.hubW??Math.max(.05,a*.45);o!=="hubless"&&(n.add(t,cn([[.016,-f],[.05,-f],[.056,-f+.012],[.042,-.012],[.042,.012],[.056,f-.012],[.05,f],[.016,f]],24),o==="wire"?k.aluminum():d,{local:!0}),n.add(t,rn(.018,.018,f*2+.03,12,"z"),k.chrome(),{local:!0}));let m=r-.026;if(o==="cast"||o==="split"){let x=e.spokes||5,g=e.sweep??.25,p=o==="split";for(let v=0;v<x;v++){let y=v/x*Math.PI*2,_=p?[y-.07,y+.07]:[y];for(let S of _)n.add(t,Kf(.05,m,p?.017:e.spokeW??.028,e.spokeT??.018,S,g,p?S<y?-.06:.06:0),d,{local:!0})}}else if(o==="wire"){let x=e.spokes||36;for(let g=0;g<x;g++){let p=g/x*Math.PI*2,v=g%2?1:-1,y=(g%4<2?1:-1)*.38,_=[Math.cos(p+y)*.045,Math.sin(p+y)*.045,v*f*.8],S=[Math.cos(p)*(m+.01),Math.sin(p)*(m+.01),v*.006];n.add(t,Ht(_,S,.0022,5),k.chrome(),{local:!0})}}else if(o==="disc")n.add(t,cn([[.05,-f*.7],[m+.01,-.012],[m+.01,.012],[.05,f*.7]],48),d,{local:!0});else if(o==="hubless"){let x=r;n.add(t,cn([[x+.008,-u/2],[x-.06,-u/2],[x-.075,-u/3],[x-.075,u/3],[x-.06,u/2],[x+.008,u/2],[x-.004,0]],64),d,{local:!0}),n.add(t,cn([[x-.076,-u*.12],[x-.082,-u*.12],[x-.082,u*.12],[x-.076,u*.12]],64),s.mats.neon,{local:!0})}else if(o==="turbine"){let x=e.spokes||14;for(let g=0;g<x;g++)n.add(t,Kf(.05,m,.02,.008,g/x*Math.PI*2,.7,0),d,{local:!0})}if(e.discs)for(let x of e.discs){let g=Cv(x.style||"drilled",x.carrier||"#c9a227"),p=$f(x.r*.3,x.r,64);p.translate(0,0,x.z),n.add(t,p,g,{local:!0})}if(e.sprocket){let x=e.sprocket,g=cn([[.04,-.003],[x.r,-.003],[x.r,.003],[.04,.003]],40);g.translate(0,0,x.z),n.add(t,g,k.anodized(x.color??9080726),{local:!0});let p=[];for(let v=0;v<40;v++){let y=v/40*Math.PI*2,_=kt(.008,.006,.006);St(_,{p:[Math.cos(y)*(x.r+.004),Math.sin(y)*(x.r+.004),x.z],r:[0,0,y]}),p.push(_)}for(let v of p)n.add(t,v,k.anodized(x.color??9080726),{local:!0})}}var fu=new Map;function Cv(s,t){let e=s+t;return fu.has(e)||fu.set(e,new at({map:Vf(s,t),alphaTest:.5,side:xe,metalness:.95,roughness:.3})),fu.get(e)}function Kf(s,t,e,n,i,r,a){let o=t-s,l=new jt(o,e,n,10,1,1);l.translate(o/2,0,0);let c=l.attributes.position;for(let h=0;h<c.count;h++){let u=c.getX(h),d=c.getY(h),f=c.getZ(h),m=u/o,x=s+u,g=1.35-m*.55,p=i+r*m*m+d*g/x+a*(1-m)*0,v=f*(1.25-m*.4);c.setXYZ(h,Math.cos(p)*x,Math.sin(p)*x,v)}return l.computeVertexNormals(),l}function el(s,t,e,n,i,r,a=13114910,o=1){let l=r*Cn,c=n*.86,h=kt(.05*o,.1*o,.034,.012);St(h,{p:[e[0]+Math.cos(l)*c,e[1]+Math.sin(l)*c,i+Math.sign(i||1)*.008],r:[0,0,l+Math.PI/2]}),s.A.add(t,h,k.anodized(a));let u=kt(.03*o,.07*o,.04,.006);St(u,{p:[e[0]+Math.cos(l)*(c+.02),e[1]+Math.sin(l)*(c+.02),i],r:[0,0,l+Math.PI/2]}),s.A.add(t,u,k.anodized(a))}function In(s,t={}){let{A:e}=s,n=t.type||"usd",i=s.fw,r=s.Lf,a=r+s.headLen+(t.extra??.04),o=s.fp,l=t.outerMat||(n==="usd"?k.anodized(1908514):k.aluminum()),c=t.innerMat||(n==="usd"?k.gold():k.chrome());for(let u of[-i,i])if(n==="usd"){e.add("forkSlider",Ht(o(0,u),o(.4,u),t.innerR??.023,18),c);let d=kt(.06,.09,.05,.012);St(d,{p:o(.01,u),r:[0,0,s.rake]}),e.add("forkSlider",d,k.anodized(1710618)),e.add("steer",Ht(o(.3,u),o(a,u),t.outerR??.029,20),l),e.add("steer",Ht(o(a,u),o(a+.012,u),(t.outerR??.029)*.8,12),k.anodized(t.capColor??13935665))}else if(n==="conv"||n==="cruiser"||n==="mx"){let d=t.lowerR??(n==="cruiser"?.034:.03),f=t.lowerLen??.34;if(e.add("forkSlider",Ht(o(-.02,u),o(f,u),d,18),t.lowerMat||(n==="cruiser"?k.chrome():k.aluminum())),e.add("steer",Ht(o(f-.06,u),o(a,u),t.stanchionR??.022,18),c),n==="cruiser"&&t.gaiters&&e.add("steer",Ht(o(f,u),o(f+.12,u),.04,18),k.rubber()),n==="mx"){let m=kt(.04,.24,.02,.008);St(m,{p:o(.18,u+Math.sign(u)*.01),r:[0,0,s.rake]}),e.add("forkSlider",m,t.guardMat||k.plastic(15921906))}}else if(n==="springer"){e.add("steer",Ht(o(0,u),o(a,u),.016,12),k.chrome());let d=f=>{let m=o(f,u);return[m[0]-s.n.x*.06,m[1]-s.n.y*.06,u]};e.add("steer",Ht(d(0),d(a),.018,12),k.black()),e.add("steer",ua(d(a-.25),d(a-.02),.022,.005,8),k.chrome())}for(let[u,d]of[[r,.03],[r+s.headLen,.026]]){let f=s.sp(u),m=o(u),x=[(f[0]+m[0])/2,(f[1]+m[1])/2,0],g=kt(s.offset+.08,d,i*2+.07,.01);St(g,{p:x,r:[0,0,s.rake]}),e.add("steer",g,t.clampMat||k.anodized(2763824))}let h=rn(.013,.013,i*2+.06,12,"z");St(h,{p:[s.front.x,s.front.y,0]}),e.add("forkSlider",h,k.aluminum())}function Ln(s,t={}){let e=s.front.R+(t.gap??.025),n=t.w??s.front.w*1.15,i=t.from??.95,r=t.len??2,a=new ke(e,e,n,32,1,!0,i,r);a.rotateX(Math.PI/2);let o=new ke(e-.004,e-.004,n,32,1,!0,i,r);o.rotateX(Math.PI/2),gr(o);for(let l of[a,o])l.translate(s.front.x+(t.dx??0),s.front.y+(t.dy??0),0),s.A.add(t.group||"forkSlider",l,t.mat||s.mats.paint);if(t.skirts)for(let l of[-n/2,n/2]){let c=new Ms(e-t.skirts,e,24,1,Math.PI/2-i-r+Math.PI,r);c.translate(s.front.x,s.front.y,l),l<0&&gr(c),s.A.add(t.group||"forkSlider",c,t.mat||s.mats.paint)}}function As(s,t={}){let e=s.rear.R+(t.gap??.03),n=t.w??s.rear.w*1.1,i=t.from??2.6,r=t.len??1.6,a=new ke(e,e,n,28,1,!0,i,r);a.rotateX(Math.PI/2);let o=new ke(e-.004,e-.004,n,28,1,!0,i,r);o.rotateX(Math.PI/2),gr(o);for(let l of[a,o])l.translate(s.rear.x,s.rear.y,0),s.A.add(t.group||"swingarm",l,t.mat||k.black());if(t.skirts)for(let l of[-n/2,n/2]){let c=new Ms(e-t.skirts,e,24,1,Math.PI/2-i-r+Math.PI,r);c.translate(s.rear.x,s.rear.y,l),l<0&&gr(c),s.A.add(t.group||"chassis",c,t.mat||k.black())}}function Dn(s,t={}){let{A:e}=s,[n,i]=s.pivot,r=s.rear.x,a=s.rear.y,o=t.style||"banana",l=t.side??Math.max(.1,s.rear.w/2+.04),c=t.mat||k.aluminum(),h=o==="single"?[-l]:[-l,l];for(let d of h)if(o==="tube")e.add("swingarm",Ht([n,i,d*.85],[r+.02,a,d],.02,12),c);else{let f=o==="single"?.06:t.h??.05,m=(i+a)/2+(o==="banana"?.03:0),x=te([{x:n,y:i,w:.022,ht:f,n:4,z:d*.8},{x:n+(r-n)*.35,y:i+(a-i)*.35+(o==="banana"?.035:0),w:.02,ht:f*.95,n:4,z:d*.97},{x:n+(r-n)*.7,y:m+(a-m)*.4,w:.018,ht:f*.75,n:4,z:d},{x:r-.02,y:a,w:.016,ht:f*.6,n:4,z:d}],{radial:16,sub:5,capStart:!0,capEnd:!0});if(e.add("swingarm",x,c),o==="single"){let g=rn(.075,.075,.05,28,"z");St(g,{p:[r,a,d]}),e.add("swingarm",g,c)}}o!=="single"&&e.add("swingarm",Ht([n+.08,i-.01,-l*.85],[n+.08,i-.01,l*.85],.02,10),c),e.add("swingarm",rn(.028,.028,l*2+.06,16,"z").translate(n,i,0),k.aluminum());let u=rn(.014,.014,l*2+.05,12,"z");u.translate(r,a,0),e.add("swingarm",u,k.aluminum());for(let d of h){let f=kt(.05,.025,.012,.004);St(f,{p:[r-.01,a,d+Math.sign(d)*.018]}),e.add("swingarm",f,k.anodized(13935665))}}function Qi(s,t={}){let e=t.z??-(s.rear.w/2+.012),[n,i]=s.pivot,r=[n+.06,i+.02],a=[s.rear.x,s.rear.y],o=t.rearR??.1,l=.04,c=[r[0],r[1]+l,e],h=[a[0],a[1]+o,e],u=[r[0],r[1]-l,e],d=[a[0],a[1]-o,e];s.A.add("swingarm",Ht(c,h,.006,6),k.darkChrome()),s.A.add("swingarm",Ht(u,d,.006,6),k.darkChrome());let f=rn(l,l,.01,16,"z");if(f.translate(r[0],r[1],e),s.A.add("chassis",f,k.darkChrome()),t.guard!==!1){let m=kt(.25,.006,.03,.002);St(m,{p:[(c[0]+h[0])/2,(c[1]+h[1])/2+.03,e],r:[0,0,Math.atan2(h[1]-c[1],h[0]-c[0])]}),s.A.add("swingarm",m,k.plastic())}return{z:e,r:o}}function jf(s){let t=-(s.rear.w/2+.015),[e,n]=s.pivot,i=[e+.04,n+.01],r=.13,a=.05;return s.A.add("swingarm",Ht([i[0],i[1]+a,t],[s.rear.x,s.rear.y+r,t],.012,4),k.rubber()),s.A.add("swingarm",Ht([i[0],i[1]-a,t],[s.rear.x,s.rear.y-r,t],.012,4),k.rubber()),{z:t,r}}function di(s,t,e,n={}){s.A.add("chassis",Ht(t,e,n.bodyR??.014,12),n.bodyMat||k.anodized(2236962));let i=.18,r=[t[0]+(e[0]-t[0])*i,t[1]+(e[1]-t[1])*i,t[2]+(e[2]-t[2])*i],a=[t[0]+(e[0]-t[0])*.82,t[1]+(e[1]-t[1])*.82,t[2]+(e[2]-t[2])*.82];if(s.A.add("chassis",ua(r,a,n.r??.03,n.wire??.0065,n.turns??8),n.springMat||k.spring(n.springColor??14857505)),n.reservoir){let o=rn(.02,.02,.12,14,"y");St(o,{p:[t[0]-.03,t[1]-.04,t[2]+.04]}),s.A.add("chassis",o,k.anodized(n.resColor??13935665))}}function Ci(s,t,e,n,i={}){let r=i.fins??9,a=i.core??.05,o=i.fin??.075,l=[[.001,0]];for(let u=0;u<r;u++){let d=u/r*n,f=(u+.45)/r*n,m=(u+1)/r*n,x=o*(i.taper?1-u/r*i.taper:1);l.push([a,d+.002],[x,d+.004],[x,f],[a,f+.002],[a,m])}l.push([.001,n]);let c=i.square?4:24,h=ha(l,c,"y",i.square?Math.PI/4:0);if(i.square){let u=h.toNonIndexed();return u.computeVertexNormals(),Jf(s,u,t,e,i)}return Jf(s,h,t,e,i)}function Jf(s,t,e,n,i){let r=new C(...n).normalize(),a=new Fe().setFromUnitVectors(xr(0,1,0),r);return t.applyMatrix4(new Lt().makeRotationFromQuaternion(a)),t.translate(e[0],e[1],e[2]??0),s.A.add(i.group||"chassis",t,i.mat||k.engine(3816770)),t}function Jn(s,t,e,n={}){let i=kt(e[0],e[1],e[2],n.r??.04);if(St(i,{p:t,r:[0,0,n.tilt??0]}),s.A.add("chassis",i,n.mat||k.engine()),n.covers!==!1)for(let r of[-1,1]){let a=rn(n.coverR??e[1]*.38,n.coverR??e[1]*.38,.03,32,"z");St(a,{p:[t[0]+(n.coverDx??0),t[1]+(n.coverDy??-e[1]*.08),t[2]+r*(e[2]/2+.01)]}),s.A.add("chassis",a,n.coverMat||k.engine(5593439));let o=rn(.02,.02,.01,8,"z");St(o,{p:[t[0]+(n.coverDx??0),t[1]+(n.coverDy??-e[1]*.08),t[2]+r*(e[2]/2+.027)]}),s.A.add("chassis",o,k.chrome())}}function vr(s,t,e,n,i={}){let r=kt(.04,n,e,.008);St(r,{p:t,r:[0,0,i.tilt??-.2]}),s.A.add("chassis",r,k.radiator());let a=kt(.045,n+.02,e+.02,.006);St(a,{p:[t[0]-.004,t[1],t[2]],r:[0,0,i.tilt??-.2]}),s.A.add("chassis",a,k.black())}function hn(s,t,e=.02,n){s.A.add("chassis",Oe(t,e,{radial:10}),n||k.titanium())}function kn(s,t,e,n={}){let i=n.r??.055,r=Math.hypot(e[0]-t[0],e[1]-t[1],(e[2]??0)-(t[2]??0)),a=n.type||"round",o;a==="megaphone"?o=[[.001,0],[i*.45,0],[i*.55,r*.2],[i,r*.97],[i*.92,r],[i*.6,r*.98],[.001,r*.96]]:a==="shotgun"?o=[[.001,0],[i,.01],[i,r*.98],[i*.85,r],[i*.6,r*.985],[.001,r*.98]]:a==="cone"?o=[[.001,0],[i*.5,0],[i,r*.3],[i*.95,r*.95],[i*.7,r],[i*.45,r*.97],[.001,r*.96]]:o=[[.001,0],[i*.55,0],[i*.95,r*.12],[i,r*.3],[i,r*.9],[i*.85,r],[i*.5,r],[i*.45,r*.97],[.001,r*.97]];let l=a==="hex"?6:28,c=ha(o,l,"y");a==="hex"&&(c=c.toNonIndexed(),c.computeVertexNormals());let h=new C(e[0]-t[0],e[1]-t[1],(e[2]??0)-(t[2]??0)).normalize();c.applyMatrix4(new Lt().makeRotationFromQuaternion(new Fe().setFromUnitVectors(xr(0,1,0),h))),c.translate(t[0],t[1],t[2]??0),s.A.add(n.group||"chassis",c,n.mat||k.titanium());let u=rn(i*.42,i*.42,.01,16,"y");u.applyMatrix4(new Lt().makeRotationFromQuaternion(new Fe().setFromUnitVectors(xr(0,1,0),h)));let d=[e[0]-h.x*.012,e[1]-h.y*.012,(e[2]??0)-h.z*.012];if(u.translate(...d),s.A.add(n.group||"chassis",u,k.black()),n.endcap){let f=rn(i*1.01,i*1.01,.03,l,"y");f.applyMatrix4(new Lt().makeRotationFromQuaternion(new Fe().setFromUnitVectors(xr(0,1,0),h))),f.translate(e[0]-h.x*.02,e[1]-h.y*.02,(e[2]??0)-h.z*.02),s.A.add("chassis",f,n.endcap)}s.exhausts.push({pos:[e[0],e[1],e[2]??0],dir:[h.x,h.y,h.z],r:i})}function mu(s,t,e=.055,n){let i=[.018,.02,.03,e*.8,e,e,e*.7,.025,.016,.016],r=qf(t,i,{radial:14,segments:64});s.A.add("chassis",r,n||k.darkChrome());let a=t[t.length-1],o=t[t.length-2],l=new C(a[0]-o[0],a[1]-o[1],a[2]-o[2]).normalize();s.exhausts.push({pos:a,dir:[l.x,l.y,l.z],r:.016})}function yr(s,t,e=.085,n={}){let i=n.group||"steer",r=n.dir??0,a=cn([[.001,-e*1.1],[e*.8,-e*.9],[e*1.02,-e*.2],[e*1.05,0],[e*.98,.012],[.001,-.004]],32,"x");St(a,{p:t,r:[0,0,r]}),s.A.add(i,a,n.shellMat||k.chrome());let o=ui(e*.95,24,12);o.scale(.25,1,1),St(o,{p:[t[0]+.004,t[1],t[2]]}),s.A.add(i,o,s.mats.head);let l=Zf(e*.98,.006,32,6);l.rotateY(Math.PI/2),l.translate(t[0]+.01,t[1],t[2]),s.A.add(i,l,k.chrome()),s.headlights.push({pos:t,group:i,r:e})}function nl(s,t,e,n=.006,i="chassis",r){s.A.add(i,Ht(t,e,n,6),r||s.mats.head)}function jn(s,t,e=.06,n=.02,i={}){let r=kt(.02,n,e,Math.min(n,.008)/2);St(r,{p:t,r:[0,0,i.tilt??.2]}),s.A.add(i.group||"chassis",r,s.mats.tail),s.tails.push({pos:t})}function _r(s,t,e,n={}){let i=e*(n.reach??.27),r=[t[0],t[1],t[2]],a=[t[0]+(n.dx??-.02),t[1]+(n.up??.16),i];s.A.add(n.group||"steer",Ht(r,a,.007,8),k.black());let o=kt(.04,.068,.135,.02);St(o,{p:[a[0],a[1]+.02,a[2]+e*.04],r:[e*.12,e*-.15,0]}),s.A.add(n.group||"steer",o,n.mat||k.black());let l=new we(.115,.052);l.rotateY(-Math.PI/2),St(l,{p:[a[0]-.0215,a[1]+.02,a[2]+e*.04],r:[e*.12,e*-.15,0]}),s.A.add(n.group||"steer",l,k.chrome())}function Un(s,t={}){let e=t.type||"wide",n=s.Lf+s.headLen,i=s.A,r=s.fw,a=[];if(e==="clipon")for(let o of[-1,1]){let l=s.fp(n-.035,o*r),c=[l[0]-.09,l[1]-.03,o*(r+.21)];i.add("steer",Ht(l,c,.012,10),k.anodized(2236962)),i.add("steer",Ht([l[0]-.05,l[1]-.016,o*(r+.08)],c,.017,12),k.rubber()),a.push(c)}else{let o=t.rise??.1,l=t.back??.1,c=t.half??.38,h=s.sp(n+.02),u=d=>[[h[0],h[1]+.02,0],[h[0]-l*.3,h[1]+o*.8,d*c*.45],[h[0]-l*.8,h[1]+o,d*c*.85],[h[0]-l,h[1]+o*.95,d*c]];if(e==="ape"){let d=f=>[[h[0],h[1]+.02,f*.06],[h[0]+.02,h[1]+.35,f*.12],[h[0]-.05,h[1]+.42,f*.28],[h[0]-.16,h[1]+.38,f*.38]];for(let f of[-1,1])i.add("steer",Oe(d(f),.013),k.chrome());a=[-1,1].map(f=>d(f)[3])}else{for(let f of[-1,1])i.add("steer",Oe(u(f),t.r??.012),t.mat||k.anodized(1710618));a=[-1,1].map(f=>u(f)[3]),e==="mx"&&i.add("steer",Ht(u(-1)[1],u(1)[1],.012,8).translate(0,.05,0),t.mat||k.anodized(1710618));let d=kt(.05,.03,.12,.01);St(d,{p:[h[0],h[1]+.03,0],r:[0,0,s.rake]}),i.add("steer",d,k.anodized(2236962))}for(let d of a){let f=Math.sign(d[2]),m=Ht([d[0],d[1],d[2]-f*.12],d,.017,12);i.add("steer",m,k.rubber())}}for(let o of a){let l=Math.sign(o[2]);i.add("steer",Ht([o[0]+.02,o[1],o[2]-l*.13],[o[0]+.07,o[1]-.02,o[2]-l*.02],.005,6),k.aluminum());let c=kt(.04,.035,.04,.01);if(St(c,{p:[o[0],o[1],o[2]-l*.14]}),i.add("steer",c,k.black()),l>0){let h=rn(.018,.018,.03,12,"y");St(h,{p:[o[0]+.02,o[1]+.035,o[2]-l*.16]}),i.add("steer",h,k.anodized(1118481))}}return s.barEnds=a,a}function Nn(s,t,e=.13,n=.08,i={}){let r=kt(.03,n+.02,e+.02,.01);St(r,{p:t,r:[0,0,i.tilt??-.9]}),s.A.add(i.group||"chassis",r,k.black());let a=new we(e,n);a.rotateY(-Math.PI/2),a.rotateZ(i.tilt??-.9),a.translate(t[0]-.016*Math.cos(i.tilt??-.9),t[1]-.016*Math.sin(i.tilt??-.9)+0,t[2]),s.A.add(i.group||"chassis",a,s.mats.dash),s.dashPos=t}function Qn(s,t,e,n=.17,i={}){for(let r of[-1,1]){let a=Ht([t,e,r*(n-.05)],[t,e,r*n],.011,8);s.A.add("chassis",a,k.aluminum());let o=Ht([t,e,r*(n-.01)],[t-0,e,r*(n+.04)],.014,8);if(s.A.add("chassis",o,k.rubber()),i.plates){let l=kt(.12,.08,.008,.004);St(l,{p:[t+.02,e+.04,r*(n-.06)]}),s.A.add("chassis",l,k.aluminum())}}}function da(s,t,e,n,i={}){let r=new we(e[0],e[1]);St(r,{p:t,r:i.r??[0,0,0]}),s.A.add(i.group||"chassis",r,n)}function ti(s,t={}){let e=s.front,n=s.rear,i=t.fDiscR??.155,r=t.rDiscR??.11,a=t.singleFrontDisc?[{r:i,z:-(s.fw-.03),style:t.discStyle,carrier:t.carrier}]:[{r:i,z:-(s.fw-.03),style:t.discStyle,carrier:t.carrier},{r:i,z:s.fw-.03,style:t.discStyle,carrier:t.carrier}];pu(s,"frontWheel",{...e,discs:t.noFrontDisc?null:a,rimMat:s.mats.wheel,rimStripe:t.rimStripe}),pu(s,"rearWheel",{...n,discs:t.noRearDisc?null:[{r,z:n.w/2+.03,style:t.discStyle==="wave"?"wave":"drilled",carrier:"#2a2a2a"}],rimMat:s.mats.wheel,rimStripe:t.rimStripe,sprocket:t.noSprocket?null:{r:t.sprocketR??.1,z:-(n.w/2+.012),color:t.sprocketColor}});let o=t.caliperColor??13114910;t.noFrontDisc||(el(s,"forkSlider",[e.x,e.y],i,-(s.fw-.03),150,o),t.singleFrontDisc||el(s,"forkSlider",[e.x,e.y],i,s.fw-.03,150,o)),t.noRearDisc||el(s,"swingarm",[n.x,n.y],r,n.w/2+.03,300,2763306,.8)}function gu(s,t={}){let e=s.head,[n,i]=s.pivot,r=t.z??.13;for(let a of[-1,1]){let o=te([{x:e[0]+.02,y:e[1]+.06,w:.03,ht:.06,n:4,z:a*.05},{x:e[0]-.12,y:e[1]+.02,w:.025,ht:.07,n:4,z:a*r*.85},{x:(e[0]+n)/2,y:(e[1]+i)/2+.07,w:.022,ht:.065,n:4,z:a*r},{x:n+.06,y:i+.05,w:.022,ht:.08,n:4,z:a*r*.95},{x:n-.01,y:i-.02,w:.024,ht:.07,n:4,z:a*r*.9}],{radial:16,sub:6,capStart:!0,capEnd:!0});s.A.add("chassis",o,t.mat||k.aluminum())}s.A.add("chassis",Ht(s.sp(s.Lf-.01),s.sp(s.Lf+s.headLen+.01),.038,18),t.mat||k.aluminum())}function fi(s,t,e,n,i,r,a={}){let o=te([{x:e,y:n-.005,w:i*(a.rearW??.8),ht:r*.8,hb:.02,n:3},{x:e+(t-e)*.4,y:n+(a.dip??0),w:i,ht:r,hb:.025,n:3.2},{x:t,y:n+(a.frontRise??0),w:i*(a.frontW??.7),ht:r*.9,hb:.025,n:3}],{radial:22,sub:6,capStart:!0,capEnd:!0});s.A.add("chassis",o,s.mats.seat)}function xu(s,t){let{A:e,mats:n}=s,i=t.k??1,r=t.nose??.92,a=t.round?2.1:2.4,o=te([{x:r,y:.84,w:.03*i,ht:.018,hb:.022,n:2},{x:r-.06,y:.845,w:.11*i,ht:.06,hb:.075,n:a},{x:r-.18,y:.84,w:.18*i,ht:.105,hb:.13,n:a+.1},{x:r-.32,y:.8,w:.22*i,ht:.155,hb:.13,n:a+.3},{x:.46,y:.72,w:.245*i,ht:.235,hb:.23,n:2.9},{x:.39,y:.6,w:.25*i,ht:.36,hb:.38,n:3.1},{x:.2,y:.57,w:.25*i,ht:.35,hb:.39,n:3.2},{x:0,y:.54,w:.225*i,ht:.29,hb:.36,n:3},{x:-.1,y:.52,w:.17*i,ht:.2,hb:.27,n:2.8},{x:-.17,y:.56,w:.08*i,ht:.08,hb:.1,n:2.4}],{radial:40,sub:7,capStart:!0,capEnd:!0});e.add("chassis",o,n.paint);let l=te([{x:.45,y:.92,w:.1*i,ht:.045,hb:.06,n:2.6},{x:.3,y:.935,w:.175*i,ht:.085,hb:.1,n:2.9},{x:.08,y:.935,w:.185*i,ht:.085,hb:.1,n:2.9},{x:-.08,y:.885,w:.15*i,ht:.05,hb:.08,n:2.7},{x:-.15,y:.86,w:.1*i,ht:.02,hb:.05,n:2.4}],{radial:30,sub:6,capStart:!0,capEnd:!0});e.add("chassis",l,n.paint);let c=t.tailX??-.8,h=te([{x:-.06,y:.72,w:.16*i,ht:.11,hb:.08,n:2.8},{x:-.3,y:.79,w:.14*i,ht:.075,hb:.1,n:2.9},{x:(-.3+c)/2-.02,y:.87,w:.095*i,ht:t.hump??.06,hb:.065,n:2.7},{x:c,y:.95,w:.03,ht:.024,hb:.022,n:2.2}],{radial:28,sub:6,capStart:!0,capEnd:!0});e.add("chassis",h,n.paint),fi(s,-.12,-.44,.865,.125*i,.03);let u=te([{x:r-.07,y:.905,w:.085*i,ht:.025,n:2},{x:r-.22,y:.985,w:.16*i,ht:.04,n:2.2},{x:r-.36,y:1.02,w:.18*i,ht:.03,n:2.2}],{radial:18,sub:6,t0:.12,t1:Math.PI-.12});e.add("chassis",u,n.glass);for(let d of[-1,1]){let f=kt(.16,.05,.01,.004);St(f,{p:[.28,.52,d*.25*i],r:[0,0,.35]}),e.add("chassis",f,k.black());let m=kt(.12,.035,.01,.004);St(m,{p:[.22,.44,d*.248*i],r:[0,0,.35]}),e.add("chassis",m,k.black())}}function Pv(s){let{A:t,mats:e}=s;Pn(s),In(s,{type:"usd"}),ti(s,{caliperColor:13114910,rimStripe:e.accentSolid}),Dn(s,{style:"banana",mat:k.aluminum()}),Qi(s),gu(s,{mat:e.frame}),Jn(s,[.08,.32,0],[.42,.2,.3],{tilt:.05,covers:!0});let n=kt(.2,.24,.34,.03);St(n,{p:[.2,.52,0],r:[0,0,-.5]}),t.add("chassis",n,k.engine());let i=kt(.12,.08,.32,.03);St(i,{p:[.27,.66,0],r:[0,0,-.5]}),t.add("chassis",i,e.accentSolid),vr(s,[.37,.5,0],.36,.3,{tilt:-.25});for(let a=0;a<4;a++){let o=-.09+a*.06;hn(s,[[.33,.56,o],[.42,.4,o*1.1],[.36,.18,o*.6],[.15,.12,o*.3],[-.02,.15,.06]],.018)}hn(s,[[-.02,.15,.06],[-.14,.2,.14],[-.22,.27,.17]],.03),kn(s,[-.22,.27,.17],[-.56,.42,.17],{type:"hex",r:.06,mat:k.titanium(),endcap:k.carbon()}),xu(s,{});for(let a of[-1,1]){let o=te([{x:.86,y:.84,w:.012,ht:.012,n:2,z:a*.05},{x:.8,y:.85,w:.022,ht:.018,n:2.4,z:a*.11},{x:.74,y:.87,w:.012,ht:.01,n:2,z:a*.155}],{radial:12,sub:4,capStart:!0,capEnd:!0});t.add("chassis",o,e.head)}let r=ui(.05,16,10);r.scale(.5,.6,1),r.translate(.885,.835,0),t.add("chassis",r,k.black()),s.headlights.push({pos:[.85,.85,0],group:"chassis",r:.05}),jn(s,[-.77,.925,0],.08,.02,{tilt:.4}),Un(s,{type:"clipon"}),Nn(s,[.5,.97,0],.12,.075,{tilt:-1.1});for(let a of[-1,1])_r(s,[.62,.95,a*.2],a,{group:"chassis",reach:.3,up:.06,dx:-.03});Qn(s,-.2,.4,.17,{plates:!0}),di(s,[-.08,.62,0],[-.2,.36,0],{r:.026,springColor:14857505}),Ln(s,{from:1.8,len:1.7,w:.13,mat:e.paintSolid}),As(s,{from:1.9,len:1.4,mat:k.carbon(),w:.2})}function Iv(s){let{A:t,mats:e}=s;Pn(s),In(s,{type:"usd",innerMat:k.gold(),outerMat:k.anodized(1118481)}),ti(s,{caliperColor:1118481,carrier:"#333333",fDiscR:.17,discStyle:"plain",rimStripe:e.accentSolid}),Dn(s,{style:"banana",mat:k.carbon(),h:.06}),Qi(s),gu(s,{mat:k.aluminum()}),Jn(s,[.06,.32,0],[.4,.2,.28],{tilt:.08});for(let[i,r]of[[.24,-.75],[0,.55]]){let a=kt(.16,.24,.3,.03);St(a,{p:[i,.52,0],r:[0,0,r]}),t.add("chassis",a,k.engine(2763824))}vr(s,[.38,.5,0],.34,.32,{tilt:-.22}),hn(s,[[.33,.5,.06],[.4,.3,.08],[.2,.16,.1],[-.05,.2,.12],[-.2,.4,.12],[-.42,.62,.07]],.022),hn(s,[[.33,.5,-.06],[.4,.3,-.08],[.2,.16,-.1],[-.05,.2,-.12],[-.25,.32,-.15],[-.42,.36,-.16]],.022),kn(s,[-.42,.62,.07],[-.66,.72,.07],{type:"round",r:.045,mat:k.titanium()}),kn(s,[-.42,.36,-.16],[-.62,.44,-.16],{type:"round",r:.04,mat:k.titanium()}),xu(s,{k:.95,tailX:-.74,hump:.085});let n=ui(.07,16,10);n.scale(.5,.55,1),n.translate(.905,.825,0),t.add("chassis",n,k.black());for(let i of[-1,1]){for(let a=0;a<2;a++){let o=kt(.14,.012,.12,.005);St(o,{p:[.72-a*.04,.8-a*.07,i*(.24+a*.01)],r:[i*-.1,0,.12]}),t.add("chassis",o,k.carbon())}let r=kt(.16,.12,.008,.004);St(r,{p:[.7,.77,i*.305]}),t.add("chassis",r,k.carbon());for(let a=0;a<3;a++){let o=kt(.12,.008,.04,.003);St(o,{p:[.15,.32+a*.05,i*.25],r:[0,0,.3]}),t.add("chassis",o,k.carbon())}}da(s,[.86,.885,0],[.12,.08],e.plate,{r:[0,Math.PI/2,.55]}),jn(s,[-.735,.88,0],.03,.018,{tilt:.3}),Un(s,{type:"clipon"}),Nn(s,[.52,.96,0],.11,.06,{tilt:-1.1}),Qn(s,-.22,.42,.16,{plates:!0}),di(s,[-.06,.62,0],[-.18,.36,0],{r:.025,springColor:14211288}),Ln(s,{from:1.8,len:1.6,w:.13,mat:k.carbon()}),s.headlights.push({pos:[.88,.84,0],group:"chassis",r:0,none:!0})}function Lv(s){let{A:t,mats:e}=s;Pn(s),In(s,{type:"usd",innerMat:k.gold(),outerMat:k.anodized(1710618)}),ti(s,{caliperColor:13935665,carrier:"#222222",rimStripe:e.accentSolid}),Dn(s,{style:"single",mat:k.aluminum()}),Qi(s);let n=s.head,[i,r]=s.pivot,a=m=>[n[0]+(i+.05-n[0])*m,n[1]+.07+(r+.2-n[1]-.07)*m],o=m=>[n[0]-.05+(i+.02-n[0]+.05)*m,n[1]-.15+(r-.02-n[1]+.15)*m],l=e.frame;for(let m of[-1,1]){let p=y=>m*(.06+.07*Math.min(1,y*2));for(let y=0;y<5;y++){let _=y/5,S=(y+1)/5,M=a(_),E=a(S),A=o(_),w=o(S);t.add("chassis",Ht([M[0],M[1],p(_)],[E[0],E[1],p(S)],.011,8),l),t.add("chassis",Ht([A[0],A[1],p(_)],[w[0],w[1],p(S)],.011,8),l),t.add("chassis",Ht([M[0],M[1],p(_)],[w[0],w[1],p(S)],.009,8),l)}t.add("chassis",Ht([a(1)[0],a(1)[1],m*.13],[-.62,.8,m*.07],.01,8),l),t.add("chassis",Ht([o(1)[0],o(1)[1]+.05,m*.13],[-.5,.78,m*.08],.009,8),l)}t.add("chassis",Ht(s.sp(s.Lf-.01),s.sp(s.Lf+s.headLen+.01),.036,16),l),Jn(s,[.04,.3,0],[.4,.2,.26],{tilt:.05,coverMat:k.engine(6975093)}),Ci(s,[.13,.4,0],[.4,1,0],.22,{core:.12,fin:.135,fins:6,square:!0,mat:k.engine(3093046)});let c=kt(.16,.08,.3,.025);St(c,{p:[.23,.64,0],r:[0,0,-.38]}),t.add("chassis",c,k.engine(6975093));let h=kt(.12,.04,.27,.02);St(h,{p:[.25,.69,0],r:[0,0,-.38]}),t.add("chassis",h,e.accentSolid),vr(s,[.36,.48,0],.32,.24,{tilt:-.15});for(let m=0;m<3;m++){let x=-.07+m*.07;hn(s,[[.3,.58,x],[.4,.42,x],[.32,.2,x*.5],[.1,.14,.04],[-.06,.18,.1]],.019,k.titanium())}kn(s,[-.06,.2,.12],[-.3,.3,.17],{type:"cone",r:.06,mat:k.darkChrome(),endcap:k.carbon()});let u=te([{x:.4,y:.88,w:.11,ht:.05,hb:.08,n:3.2},{x:.26,y:.95,w:.19,ht:.085,hb:.12,n:3.6},{x:.05,y:.94,w:.18,ht:.08,hb:.12,n:3.4},{x:-.12,y:.86,w:.12,ht:.05,hb:.08,n:3}],{radial:28,sub:6,capStart:!0,capEnd:!0});t.add("chassis",u,e.paint);for(let m of[-1,1]){let x=te([{x:.46,y:.78,w:.02,ht:.05,hb:.07,n:3,z:m*.17},{x:.3,y:.78,w:.035,ht:.07,hb:.1,n:3.2,z:m*.2},{x:.14,y:.8,w:.02,ht:.05,hb:.06,n:3,z:m*.17}],{radial:14,sub:5,capStart:!0,capEnd:!0});t.add("chassis",x,e.paint2Solid)}let d=te([{x:-.1,y:.8,w:.11,ht:.04,hb:.05,n:3},{x:-.4,y:.85,w:.09,ht:.05,hb:.05,n:3},{x:-.68,y:.92,w:.035,ht:.03,hb:.025,n:2.6}],{radial:22,sub:6,capStart:!0,capEnd:!0});t.add("chassis",d,e.paint),fi(s,-.1,-.46,.86,.12,.04);for(let m of[-1,1])yr(s,[.66,.86,m*.055],.05,{shellMat:k.black()});let f=te([{x:.7,y:.93,w:.07,ht:.02,n:2},{x:.62,y:.99,w:.09,ht:.02,n:2}],{radial:12,sub:4,t0:.2,t1:Math.PI-.2});t.add("steer",f,e.glass),jn(s,[-.69,.91,0],.05,.015),Un(s,{type:"wide",rise:.07,back:.12,half:.37}),Nn(s,[.55,.99,0],.1,.065,{group:"steer",tilt:-1});for(let m of[-1,1])_r(s,[s.barEnds[m>0?1:0][0]+.05,s.barEnds[0][1],m*.24],m,{reach:.3,up:.14});Qn(s,-.22,.41,.17,{plates:!0}),di(s,[-.05,.66,.02],[-.18,.37,.02],{r:.027,springColor:13114910,reservoir:!0}),Ln(s,{from:1.8,len:1.6,w:.13,mat:e.paintSolid}),As(s,{from:1.9,len:1.3,mat:k.black(),w:.19})}function Dv(s){let{A:t,mats:e}=s;Pn(s),In(s,{type:"usd",innerMat:k.chrome(),outerMat:e.paint2Solid,capColor:1118481}),ti(s,{noSprocket:!0,noFrontDisc:!0,noRearDisc:!0});for(let[l,c]of[["forkSlider",s.front],["swingarm",s.rear]]){let h=cn([[c.rim-.095,-c.w*.2],[c.rim-.084,-c.w*.2],[c.rim-.084,c.w*.2],[c.rim-.095,c.w*.2]],64);h.translate(c.x,c.y,0),t.add(l,h,k.anodized(1382170));let u=kt(.06,.13,c.w*.42,.012);St(u,{p:[c.x-.05,c.y+c.rim-.13,0],r:[0,0,.35]}),t.add(l,u,k.anodized(1382170));let d=kt(.07,.035,c.w*.5,.01);St(d,{p:[c.x-c.rim*.62,c.y+c.rim*.62,0],r:[0,0,-.78]}),t.add(l,d,e.paint2Solid)}Dn(s,{style:"single",mat:e.paint2Solid,side:.13});let i=te([{x:.95,y:.845,w:.02,ht:.012,hb:.016,n:2},{x:.86,y:.835,w:.085,ht:.06,hb:.06,n:2.6},{x:.64,y:.79,w:.165,ht:.11,hb:.15,n:3.2},{x:.4,y:.66,w:.2,ht:.235,hb:.25,n:3.8},{x:.12,y:.68,w:.19,ht:.31,hb:.3,n:3.8},{x:-.15,y:.71,w:.15,ht:.16,hb:.2,n:3.4},{x:-.45,y:.85,w:.1,ht:.065,hb:.07,n:3},{x:-.82,y:.97,w:.025,ht:.015,hb:.015,n:2.2}],{radial:40,sub:7,capStart:!0,capEnd:!0});t.add("chassis",i,e.paint);let r=kt(.46,.16,.24,.04);St(r,{p:[.14,.3,0]}),t.add("chassis",r,k.anodized(1776928));for(let l of[-1,1]){for(let u=0;u<6;u++){let d=kt(.05,.09,.006,.002);St(d,{p:[-.06+u*.07,.3,l*.122]}),t.add("chassis",d,e.neon)}let c=[[.8,.82,.115],[.62,.78,.172],[.4,.67,.205],[.12,.69,.196],[-.15,.73,.155],[-.45,.86,.104],[-.72,.94,.05]];t.add("chassis",Oe(c.map(([u,d,f])=>[u,d,l*f]),.0065,{radial:6}),e.neon);let h=kt(.22,.09,.01,.01);St(h,{p:[.36,.54,l*.2],r:[0,0,.25]}),t.add("chassis",h,k.black())}let a=rn(.11,.11,.2,32,"z");a.translate(-.06,.38,0),t.add("chassis",a,k.aluminum());for(let l of[-1,1]){let c=rn(.09,.09,.012,32,"z");c.translate(-.06,.38,l*.105),t.add("chassis",c,e.neon),t.add("chassis",Oe([[.1,.32,l*.1],[.02,.36,l*.13],[-.04,.42,l*.1]],.012),k.matte(16738816,.5))}fi(s,-.14,-.5,.905,.12,.03);for(let l of[-1,1])nl(s,[.945,.845,l*.02],[.84,.86,l*.09],.007,"chassis"),nl(s,[.84,.81,l*.09],[.7,.8,l*.16],.005,"chassis",e.neon);s.headlights.push({pos:[.93,.845,0],group:"chassis",r:.03}),nl(s,[-.81,.968,-.03],[-.81,.968,.03],.008,"chassis",e.tail),s.tails.push({pos:[-.81,.968,0]});let o=te([{x:.8,y:.88,w:.07,ht:.02,n:2},{x:.62,y:.95,w:.13,ht:.03,n:2}],{radial:14,sub:5,t0:.2,t1:Math.PI-.2});t.add("chassis",o,e.glass),Un(s,{type:"clipon"}),Nn(s,[.42,.95,0],.14,.07,{tilt:-1.05}),Qn(s,-.2,.42,.18),Ln(s,{from:1.8,len:1.6,w:.13,mat:e.paint2Solid})}function kv(s){let{A:t,mats:e}=s;Pn(s),In(s,{type:"cruiser",stanchionR:.025,lowerR:.036,gaiters:!1,clampMat:k.chrome()}),ti(s,{caliperColor:2763306,carrier:"#9a9a9a",fDiscR:.15,noSprocket:!0,discStyle:"drilled"}),Dn(s,{style:"tube",mat:e.frame,side:.14}),jf(s);let n=e.frame,i=s.head,[r,a]=s.pivot;t.add("chassis",Ht(s.sp(s.Lf-.02),s.sp(s.Lf+s.headLen+.02),.038,16),n);for(let d of[-1,1])t.add("chassis",Oe([[i[0],i[1]+.12,0],[i[0]-.3,i[1]+.03,d*.04],[-.2,.62,d*.1],[-.42,.62,d*.12],[-.72,.6,d*.13]],.016),n),t.add("chassis",Oe([[i[0],i[1],d*.03],[i[0]-.08,.38,d*.08],[.25,.13,d*.1],[-.15,.12,d*.12],[r,a-.02,d*.12]],.017),n),t.add("chassis",Ht([r,a,d*.12],[-.42,.62,d*.12],.015,10),n);Jn(s,[0,.27,0],[.42,.2,.22],{tilt:0,coverR:.1,coverMat:k.chrome(),coverDx:-.06});let o=k.engine(2763308);Ci(s,[.07,.34,0],[Math.sin(22.5*Cn),Math.cos(22.5*Cn),0],.3,{core:.06,fin:.1,fins:11,mat:o}),Ci(s,[-.07,.34,0],[-Math.sin(22.5*Cn),Math.cos(22.5*Cn),0],.3,{core:.06,fin:.1,fins:11,mat:o});for(let d of[-1,1]){let f=kt(.13,.07,.15,.03);St(f,{p:[d*.19,.66,0],r:[0,0,-d*22.5*Cn]}),t.add("chassis",f,k.chrome())}let l=cn([[.001,0],[.13,0],[.14,.02],[.12,.05],[.001,.055]],40,"z");l.scale(1.4,1,1),l.rotateY(Math.PI),l.translate(-.18,.28,-.14),t.add("chassis",l,k.chrome());let c=cn([[.001,0],[.11,0],[.12,.03],[.1,.07],[.001,.075]],40,"z");c.translate(0,.52,.1),t.add("chassis",c,k.chrome()),hn(s,[[.16,.56,.06],[.28,.42,.12],[.18,.2,.17],[-.1,.17,.2]],.026,k.chrome()),hn(s,[[-.16,.56,.06],[-.22,.42,.14],[-.2,.3,.2],[-.3,.27,.21]],.026,k.chrome()),kn(s,[-.1,.17,.2],[-.95,.24,.2],{type:"shotgun",r:.045,mat:k.chrome()}),kn(s,[-.3,.27,.21],[-1,.36,.21],{type:"shotgun",r:.045,mat:k.chrome()});let h=te([{x:.48,y:.83,w:.09,ht:.06,hb:.08,n:2.2},{x:.32,y:.87,w:.19,ht:.1,hb:.12,n:2.3},{x:.08,y:.85,w:.2,ht:.1,hb:.13,n:2.3},{x:-.12,y:.76,w:.13,ht:.07,hb:.08,n:2.2}],{radial:30,sub:7,capStart:!0,capEnd:!0});t.add("chassis",h,e.paint);let u=te([{x:.36,y:.965,w:.03,ht:.01,hb:.01,n:2},{x:.2,y:.975,w:.06,ht:.014,hb:.01,n:2.5},{x:0,y:.95,w:.04,ht:.01,hb:.01,n:2}],{radial:16,sub:4,capStart:!0,capEnd:!0});t.add("chassis",u,k.chrome()),fi(s,-.12,-.48,.67,.17,.05,{dip:-.02,frontRise:.04}),fi(s,-.48,-.72,.72,.11,.04),Ln(s,{from:1.3,len:2.7,w:.17,gap:.03,mat:e.paintSolid}),As(s,{from:1.8,len:2.6,w:.25,gap:.035,mat:e.paintSolid,group:"chassis"});for(let d of[-1,1])di(s,[-.6,.37,d*.15],[-.56,.62,d*.14],{r:.026,springMat:k.chrome(),bodyMat:k.chrome()});yr(s,[s.sp(s.Lf+.06)[0]+.14,s.sp(s.Lf+.06)[1],0],.1);for(let d of[-1,1])yr(s,[s.sp(s.Lf-.04)[0]+.12,s.sp(s.Lf-.04)[1]-.06,d*.14],.045);jn(s,[-.97,.66,0],.08,.03,{group:"chassis",tilt:.6}),Un(s,{type:"wide",rise:.14,back:.28,half:.38,mat:k.chrome(),r:.014}),Nn(s,[.2,.99,0],.07,.05,{tilt:-1.4});for(let d of[-1,1])_r(s,[s.barEnds[0][0]+.12,s.barEnds[0][1]-.02,d*.25],d,{reach:.3,up:.18,mat:k.chrome()});for(let d of[-1,1]){let f=kt(.26,.015,.1,.006);St(f,{p:[.22,.3,d*.27]}),t.add("chassis",f,k.rubber());let m=kt(.27,.02,.11,.006);St(m,{p:[.22,.29,d*.27]}),t.add("chassis",m,k.chrome())}}function Uv(s){let{A:t,mats:e}=s;Pn(s),In(s,{type:"springer",clampMat:k.black()}),ti(s,{singleFrontDisc:!0,caliperColor:1710618,carrier:"#444444",fDiscR:.14,noSprocket:!1,sprocketR:.13,sprocketColor:1118481}),Dn(s,{style:"tube",mat:e.frame,side:.13}),Qi(s,{rearR:.13,guard:!1});let n=e.frame,i=s.head,[r,a]=s.pivot;t.add("chassis",Ht(s.sp(s.Lf-.02),s.sp(s.Lf+s.headLen+.02),.036,16),n);for(let h of[-1,1])t.add("chassis",Oe([[i[0],i[1]+.1,0],[i[0]-.35,i[1]+0,h*.05],[-.25,.6,h*.1],[-.55,.52,h*.12]],.016),n),t.add("chassis",Oe([[i[0],i[1],h*.03],[i[0]-.08,.36,h*.08],[.22,.12,h*.1],[-.15,.11,h*.11],[r,a-.02,h*.12]],.017),n);Jn(s,[0,.26,0],[.4,.19,.2],{coverR:.09,coverMat:k.black(),coverDx:-.05,mat:k.black()}),Ci(s,[.06,.33,0],[Math.sin(24*Cn),Math.cos(24*Cn),0],.28,{core:.055,fin:.095,fins:10,mat:k.darkChrome()}),Ci(s,[-.06,.33,0],[-Math.sin(24*Cn),Math.cos(24*Cn),0],.28,{core:.055,fin:.095,fins:10,mat:k.darkChrome()});let o=cn([[.001,0],[.09,0],[.1,.05],[.001,.06]],32,"z");o.translate(0,.5,.1),t.add("chassis",o,k.black()),hn(s,[[.15,.54,.06],[.26,.4,.13],[.15,.25,.17],[-.2,.25,.19],[-.62,.3,.19]],.025,k.black()),hn(s,[[-.15,.54,.06],[-.2,.42,.15],[-.25,.36,.2],[-.62,.4,.2]],.025,k.black()),s.exhausts.push({pos:[-.62,.3,.19],dir:[-1,.1,0],r:.025},{pos:[-.62,.4,.2],dir:[-1,.1,0],r:.025});let l=te([{x:.42,y:.85,w:.07,ht:.05,hb:.06,n:2.2},{x:.3,y:.89,w:.12,ht:.075,hb:.08,n:2.2},{x:.12,y:.87,w:.12,ht:.07,hb:.08,n:2.2},{x:-.02,y:.81,w:.07,ht:.04,hb:.05,n:2}],{radial:28,sub:6,capStart:!0,capEnd:!0});t.add("chassis",l,e.paint);let c=te([{x:-.42,y:.69,w:.13,ht:.03,hb:.02,n:2.6},{x:-.3,y:.69,w:.15,ht:.035,hb:.02,n:2.8},{x:-.12,y:.72,w:.06,ht:.025,hb:.02,n:2.4}],{radial:20,sub:5,capStart:!0,capEnd:!0});t.add("chassis",c,e.seat);for(let h of[-1,1])t.add("chassis",ua([-.4,.55,h*.08],[-.4,.67,h*.08],.018,.004,6),k.chrome());As(s,{from:2.6,len:1.5,w:.2,gap:.03,mat:e.paintSolid}),jn(s,[-.83,.42,0],.04,.02,{group:"swingarm",tilt:1.2}),yr(s,[s.sp(s.Lf+.05)[0]+.15,s.sp(s.Lf+.05)[1],0],.07,{shellMat:k.black()}),Un(s,{type:"wide",rise:.03,back:.06,half:.34,mat:k.black()}),Nn(s,[.3,.95,0],.05,.05,{tilt:-1.4}),Qn(s,.28,.28,.24),Ln(s,{from:2,len:1.3,w:.15,mat:e.paintSolid,gap:.02})}function Nv(s){let{A:t,mats:e}=s;Pn(s),In(s,{type:"conv",lowerMat:k.aluminum(),innerMat:k.chrome(),stanchionR:.02,lowerR:.028}),ti(s,{singleFrontDisc:!0,caliperColor:13935665,carrier:"#9a9a9a",fDiscR:.15,sprocketR:.11}),Dn(s,{style:"tube",mat:e.frame,side:.11}),Qi(s,{rearR:.11});let n=e.frame,i=s.head,[r,a]=s.pivot;t.add("chassis",Ht(s.sp(s.Lf-.02),s.sp(s.Lf+s.headLen+.02),.033,16),n);for(let d of[-1,1])t.add("chassis",Oe([[i[0],i[1]+.1,0],[i[0]-.3,i[1]+.01,d*.05],[-.2,.75,d*.09],[-.64,.77,d*.09]],.014),n),t.add("chassis",Oe([[i[0],i[1],d*.03],[i[0]-.06,.4,d*.08],[.2,.15,d*.09],[-.12,.14,d*.1],[r,a-.02,d*.1]],.015),n);Jn(s,[.03,.29,0],[.34,.18,.26],{coverMat:k.chrome(),coverR:.08});for(let d of[-.06,.06])Ci(s,[.07,.37,d],[.22,1,0],.24,{core:.05,fin:.065,fins:10,mat:k.aluminum()});let o=kt(.14,.07,.28,.025);St(o,{p:[.13,.64,0],r:[0,0,-.2]}),t.add("chassis",o,k.aluminum());for(let d of[-1,1])hn(s,[[.16,.56,d*.06],[.28,.45,d*.1],[.22,.22,d*.14],[0,.2,d*.16],[-.2,.27,d*.17]],.022,k.chrome()),kn(s,[-.2,.27,d*.17],[-.68,.42,d*.17],{type:"megaphone",r:.05,mat:k.chrome()});let l=te([{x:.47,y:.85,w:.075,ht:.045,hb:.05,n:2.2},{x:.34,y:.875,w:.14,ht:.07,hb:.075,n:2.4},{x:.1,y:.87,w:.135,ht:.065,hb:.07,n:2.4},{x:-.1,y:.84,w:.13,ht:.05,hb:.06,n:2.4},{x:-.18,y:.82,w:.09,ht:.02,hb:.04,n:2.2}],{radial:28,sub:6,capStart:!0,capEnd:!0});t.add("chassis",l,e.paint);let c=kt(.28,.2,.2,.05);St(c,{p:[-.2,.63,0]}),t.add("chassis",c,e.paint2Solid);let h=kt(.36,.02,.2,.008);St(h,{p:[-.3,.775,0]}),t.add("chassis",h,k.black());for(let d of[-1,1]){let f=ui(.05,14,10);f.scale(1.2,.8,.2),f.translate(.12,.86,d*.13),t.add("chassis",f,k.rubber())}fi(s,-.12,-.46,.8,.12,.035);let u=te([{x:-.42,y:.8,w:.12,ht:.03,hb:.03,n:2.6},{x:-.52,y:.86,w:.11,ht:.07,hb:.06,n:2.6},{x:-.66,y:.84,w:.07,ht:.05,hb:.05,n:2.4}],{radial:22,sub:5,capStart:!0,capEnd:!0});t.add("chassis",u,e.paint),jn(s,[-.67,.83,0],.035,.03,{tilt:.2}),yr(s,[s.sp(s.Lf+.04)[0]+.13,s.sp(s.Lf+.04)[1]-.01,0],.085),Un(s,{type:"clipon"});for(let d of s.barEnds){let f=Math.sign(d[2]),m=ui(.04,14,10);m.scale(.4,.8,1),m.translate(d[0]-.02,d[1],d[2]+f*.04),t.add("steer",m,k.chrome())}for(let d of[-1,1]){let f=cn([[.001,0],[.04,0],[.042,.03],[.001,.032]],20,"y");f.rotateZ(.5),f.translate(s.sp(s.Lf+s.headLen+.05)[0]+.03,s.sp(s.Lf+s.headLen+.05)[1],d*.05),t.add("steer",f,k.chrome())}Nn(s,[s.sp(s.Lf+s.headLen+.06)[0]+.02,s.sp(s.Lf+s.headLen+.06)[1]+.02,0],.05,.04,{group:"steer",tilt:-1.2}),Qn(s,-.25,.38,.15);for(let d of[-1,1])di(s,[-.6,.36,d*.13],[-.5,.75,d*.1],{r:.024,springMat:k.chrome(),bodyMat:k.chrome()});Ln(s,{from:1.6,len:2,w:.12,mat:k.chrome(),gap:.02}),As(s,{from:2.4,len:1.6,mat:k.chrome(),w:.15})}function Fv(s){let{A:t,mats:e}=s;Pn(s),In(s,{type:"conv",lowerMat:k.black(),innerMat:k.chrome(),stanchionR:.026,lowerR:.036}),ti(s,{caliperColor:13114910,carrier:"#2a2a2a",fDiscR:.16,noSprocket:!0,rimStripe:k.chrome()}),Dn(s,{style:"single",mat:k.black(),side:.16}),t.add("swingarm",Ht([s.pivot[0],s.pivot[1],-.17],[s.rear.x,s.rear.y,-.17],.035,14),k.black());let n=e.frame,i=s.head,[r,a]=s.pivot;t.add("chassis",Ht(s.sp(s.Lf-.02),s.sp(s.Lf+s.headLen+.02),.04,16),n);for(let d of[-1,1])t.add("chassis",Oe([[i[0],i[1]+.1,d*.03],[i[0]-.3,i[1]-.02,d*.12],[-.2,.62,d*.13],[-.55,.66,d*.1]],.02),n);Jn(s,[0,.3,0],[.5,.22,.3],{coverMat:k.chrome(),coverR:.1});for(let d of[-1,1]){let f=kt(.2,.26,.32,.04);St(f,{p:[d*.15,.55,0],r:[0,0,-d*.6]}),t.add("chassis",f,k.engine(2763310));let m=kt(.12,.06,.34,.025);St(m,{p:[d*.23,.67,0],r:[0,0,-d*.6]}),t.add("chassis",m,k.chrome())}let o=te([{x:.46,y:.82,w:.1,ht:.06,hb:.08,n:3},{x:.28,y:.88,w:.17,ht:.09,hb:.12,n:3.2},{x:.02,y:.86,w:.17,ht:.08,hb:.12,n:3.2},{x:-.16,y:.78,w:.13,ht:.05,hb:.08,n:3}],{radial:28,sub:6,capStart:!0,capEnd:!0});t.add("chassis",o,e.paint);for(let d of[-1,1]){let f=te([{x:.5,y:.74,w:.04,ht:.07,hb:.07,n:3,z:d*.2},{x:.35,y:.74,w:.07,ht:.09,hb:.09,n:3.4,z:d*.24},{x:.12,y:.74,w:.04,ht:.06,hb:.06,n:3,z:d*.2}],{radial:16,sub:5,capEnd:!0});t.add("chassis",f,k.chrome());let m=ui(.07,14,10);m.scale(.15,1.1,.9),m.translate(.505,.74,d*.2),t.add("chassis",m,k.black())}for(let d of[-1,1])hn(s,[[.3,.5,d*.1],[.35,.25,d*.14],[.1,.13,d*.18],[-.2,.18,d*.2]],.026,k.chrome()),kn(s,[-.2,.18,d*.2],[-.62,.3,d*.22],{type:"round",r:.058,mat:k.chrome()});fi(s,-.14,-.5,.72,.17,.05,{frontRise:.04});let l=te([{x:-.46,y:.72,w:.13,ht:.04,hb:.04,n:3},{x:-.68,y:.74,w:.08,ht:.03,hb:.03,n:3}],{radial:18,sub:4,capStart:!0,capEnd:!0});t.add("chassis",l,e.paint),jn(s,[-.69,.74,0],.08,.02,{tilt:.2}),As(s,{from:1.9,len:1.4,mat:k.black(),w:.28});let c=s.sp(s.Lf+.05),h=kt(.06,.09,.17,.02);St(h,{p:[c[0]+.12,c[1],0],r:[0,0,.2]}),t.add("steer",h,k.black());let u=kt(.01,.07,.15,.01);St(u,{p:[c[0]+.155,c[1],0],r:[0,0,.2]}),t.add("steer",u,s.mats.head),s.headlights.push({pos:[c[0]+.16,c[1],0],group:"steer",r:.06}),Un(s,{type:"wide",rise:.04,back:.12,half:.36,mat:k.chrome()}),Nn(s,[.32,.96,0],.09,.05,{tilt:-1.3});for(let d of[-1,1])_r(s,[s.barEnds[0][0]+.1,s.barEnds[0][1],d*.24],d,{reach:.3,up:.14});Qn(s,.05,.32,.2);for(let d of[-1,1])di(s,[-.6,.38,d*.16],[-.42,.64,d*.13],{r:.026,springColor:13114910});Ln(s,{from:1.8,len:1.6,w:.14,mat:e.paintSolid})}function Qf(s,t){let{A:e,mats:n}=s;Pn(s),In(s,{type:"usd",innerMat:k.gold(),outerMat:t?k.anodized(1710618):k.anodized(1908514),outerR:.03,innerR:.025}),ti(s,{singleFrontDisc:!0,caliperColor:t?13935665:2763306,carrier:"#2a2a2a",fDiscR:t?.16:.135,rDiscR:.11,discStyle:"wave",sprocketR:.12,sprocketColor:t?13935665:1118481}),Dn(s,{style:"box",mat:k.aluminum(),h:.04}),Qi(s,{rearR:.12});let i=s.head,[r,a]=s.pivot,o=n.frame;e.add("chassis",Ht(s.sp(s.Lf-.02),s.sp(s.Lf+s.headLen+.02),.034,16),o);for(let f of[-1,1])e.add("chassis",Oe([[i[0],i[1]+.08,f*.03],[i[0]-.25,i[1]-.05,f*.11],[r+.06,a+.12,f*.12],[r,a-.04,f*.11]],.016),o),e.add("chassis",Oe([[r,a-.05,f*.1],[r+.05,.28,f*.08],[.22,.24,f*.06]],.015),o),e.add("chassis",Oe([[r+.04,a+.12,f*.12],[-.4,.78,f*.09],[-.62,.86,f*.08]],.011),k.aluminum());e.add("chassis",Oe([[i[0]-.02,i[1]-.02,0],[i[0]-.08,.4,0],[.24,.24,0]],.018),o),Jn(s,[0,.33,0],[.3,.2,.2],{coverR:.08,coverMat:k.engine(9080726)}),Ci(s,[.04,.42,0],[.12,1,0],.22,{core:.06,fin:.07,fins:4,mat:k.engine(3093046)});let l=kt(.14,.08,.16,.02);St(l,{p:[.08,.68,0],r:[0,0,-.1]}),e.add("chassis",l,k.engine(9080726));for(let f of[-1,1])vr(s,[.18,.62,f*.11],.04,.22,{tilt:-.3});t?(hn(s,[[.12,.62,.03],[.22,.52,.07],[.2,.32,.12],[0,.3,.14],[-.25,.48,.14]],.022,k.titanium()),kn(s,[-.25,.48,.14],[-.6,.66,.14],{type:"hex",r:.05,mat:k.carbon(),endcap:k.titanium()})):(hn(s,[[.12,.62,.03],[.22,.52,.08],[.18,.38,.13],[-.05,.5,.14],[-.3,.66,.13]],.022,k.titanium()),kn(s,[-.3,.66,.13],[-.66,.8,.12],{type:"round",r:.045,mat:k.aluminum(),endcap:k.black()}));let c=te([{x:.28,y:.85,w:.08,ht:.045,hb:.07,n:2.6},{x:.14,y:.87,w:.13,ht:.06,hb:.1,n:2.8},{x:-.06,y:.86,w:.12,ht:.05,hb:.1,n:2.6}],{radial:24,sub:5,capStart:!0,capEnd:!0});e.add("chassis",c,n.paint);for(let f of[-1,1]){let m=te([{x:.38,y:.78,w:.012,ht:.05,hb:.18,n:3,z:f*.13},{x:.22,y:.8,w:.02,ht:.08,hb:.2,n:3.4,z:f*.165},{x:.02,y:.84,w:.012,ht:.06,hb:.12,n:3,z:f*.14}],{radial:16,sub:5,capStart:!0,capEnd:!0});e.add("chassis",m,n.paint);let x=te([{x:-.1,y:.8,w:.012,ht:.06,hb:.1,n:3.4,z:f*.115},{x:-.36,y:.83,w:.014,ht:.075,hb:.1,n:3.6,z:f*.125},{x:-.62,y:.88,w:.01,ht:.03,hb:.05,n:3,z:f*.09}],{radial:14,sub:5,capStart:!0,capEnd:!0});e.add("chassis",x,n.paint2Solid),da(s,[-.36,.82,f*.141],[.15,.11],n.plate,{r:[0,f>0?0:Math.PI,0]})}fi(s,.08,-.62,.93,.1,.035,{frontRise:.02});let h=te([{x:-.42,y:.86,w:.1,ht:.015,hb:.01,n:3},{x:-.7,y:.9,w:.08,ht:.015,hb:.01,n:3},{x:-.92,y:.95,w:.04,ht:.01,hb:.008,n:2.4}],{radial:16,sub:5,capEnd:!0});if(e.add("chassis",h,n.paintSolid),t){Ln(s,{from:1.8,len:1.6,w:.13,mat:n.paintSolid,gap:.02});let f=kt(.03,.06,.08,.01);St(f,{p:[s.fp(s.Lf+.03)[0]+.07,s.fp(s.Lf+.03)[1],0],r:[0,0,.35]}),e.add("steer",f,s.mats.head),s.headlights.push({pos:[s.fp(s.Lf+.03)[0]+.09,s.fp(s.Lf+.03)[1],0],group:"steer",r:.03}),jn(s,[-.9,.94,0],.04,.012,{tilt:.3})}else{let f=te([{x:s.fp(s.Lf)[0]-.12,y:s.fp(s.Lf)[1]-.05,w:.06,ht:.012,hb:.008,n:3},{x:s.fp(s.Lf)[0]+.05,y:s.fp(s.Lf)[1]-.04,w:.08,ht:.015,hb:.008,n:3},{x:s.fp(s.Lf)[0]+.28,y:s.fp(s.Lf)[1]-.1,w:.06,ht:.012,hb:.008,n:3},{x:s.fp(s.Lf)[0]+.4,y:s.fp(s.Lf)[1]-.12,w:.04,ht:.01,hb:.006,n:2.6}],{radial:16,sub:5,capStart:!0,capEnd:!0});e.add("steer",f,n.paintSolid),s.headlights.push({pos:[.7,1,0],group:"steer",r:0,none:!0})}let u=te([{x:0,y:0,w:.1,ht:.11,hb:.08,n:3.4},{x:.015,y:0,w:.1,ht:.11,hb:.08,n:3.4}],{radial:18,sub:1,capStart:!0,capEnd:!0}),d=s.fp(s.Lf+.06);u.rotateZ(s.rake*.6),u.translate(d[0]+.05,d[1],0),e.add("steer",u,n.paint2Solid),da(s,[d[0]+.068,d[1]+.01,0],[.13,.12],n.plate,{r:[0,Math.PI/2,s.rake*.6],group:"steer"}),Un(s,{type:"mx",rise:.11,back:.08,half:.4,mat:k.anodized(t?1118481:13935665),r:.013});for(let f of s.barEnds){let m=Math.sign(f[2]),x=te([{x:f[0]+.02,y:f[1],w:.04,ht:.03,hb:.01,n:2.4,z:f[2]-m*.1},{x:f[0]+.07,y:f[1]+.01,w:.05,ht:.04,hb:.01,n:2.4,z:f[2]-m*.04}],{radial:12,sub:3,t0:0,t1:Math.PI});e.add("steer",x,k.plastic(15921906))}Nn(s,[d[0]+0,d[1]+.1,0],.05,.03,{group:"steer",tilt:-1}),Qn(s,-.12,.42,.17),di(s,[-.1,.78,0],[-.26,.42,0],{r:.034,springColor:t?13114910:4885034,reservoir:!0})}function Ov(s){Qf(s,!1)}function Bv(s){Qf(s,!0)}function zv(s){let{A:t,mats:e}=s;Pn(s),In(s,{type:"usd",innerMat:k.gold(),outerMat:k.anodized(1908514),outerR:.03}),ti(s,{caliperColor:13935665,carrier:"#2a2a2a",fDiscR:.16,noSprocket:!0}),Dn(s,{style:"single",mat:k.aluminum(),side:.12}),t.add("swingarm",Ht([s.pivot[0],s.pivot[1],-.13],[s.rear.x,s.rear.y,-.13],.04,14),k.anodized(2763306));let n=e.frame,i=s.head,[r,a]=s.pivot;t.add("chassis",Ht(s.sp(s.Lf-.02),s.sp(s.Lf+s.headLen+.02),.036,16),n);for(let d of[-1,1])t.add("chassis",Oe([[i[0],i[1]+.1,d*.03],[i[0]-.3,i[1]-.02,d*.1],[r+.05,a+.18,d*.12],[r,a,d*.12]],.018),n),t.add("chassis",Oe([[r+.05,a+.18,d*.12],[-.45,.84,d*.12],[-.72,.86,d*.12]],.013),n);Jn(s,[.02,.4,0],[.32,.24,.2],{covers:!1,mat:k.engine(3816770)});for(let d of[-1,1]){Ci(s,[.1,.38,d*.1],[.15,.08,d*1],.18,{core:.06,fin:.075,fins:7,mat:k.engine(3093046)});let f=kt(.15,.13,.08,.03);St(f,{p:[.135,.4,d*.31]}),t.add("chassis",f,k.aluminum());let m=kt(.13,.11,.03,.02);St(m,{p:[.135,.4,d*.355]}),t.add("chassis",m,e.paint2Solid),t.add("chassis",Oe([[.32,.58,d*.13],[.36,.45,d*.33],[.25,.28,d*.36],[0,.3,d*.3],[-.05,.5,d*.15]],.012),k.black())}hn(s,[[.2,.36,.34],[.28,.24,.24],[.05,.16,.14],[-.22,.28,.16],[-.35,.48,.2]],.024,k.aluminum()),kn(s,[-.35,.48,.2],[-.68,.62,.2],{type:"hex",r:.06,mat:k.aluminum(),endcap:k.black()});let o=te([{x:.42,y:.92,w:.12,ht:.05,hb:.08,n:2.8},{x:.26,y:.98,w:.21,ht:.09,hb:.15,n:3},{x:.04,y:.97,w:.2,ht:.08,hb:.15,n:3},{x:-.12,y:.9,w:.13,ht:.05,hb:.1,n:2.6}],{radial:28,sub:6,capStart:!0,capEnd:!0});t.add("chassis",o,e.paint);let l=te([{x:.82,y:1.03,w:.06,ht:.05,hb:.06,n:2.6},{x:.72,y:1.05,w:.15,ht:.09,hb:.12,n:2.8},{x:.55,y:1.02,w:.21,ht:.1,hb:.17,n:3},{x:.42,y:.96,w:.22,ht:.06,hb:.15,n:3}],{radial:28,sub:6,capStart:!0});t.add("chassis",l,e.paint);let c=te([{x:.62,y:.88,w:.1,ht:.03,hb:.01,n:2.6},{x:.8,y:.86,w:.08,ht:.025,hb:.01,n:2.6},{x:.94,y:.8,w:.04,ht:.015,hb:.008,n:2.4}],{radial:16,sub:5,capStart:!0,capEnd:!0});t.add("chassis",c,e.paint2Solid);for(let d of[-1,1]){let f=ui(.05,16,10);f.scale(.4,.75,1),f.translate(.83,1.02,d*.05),t.add("chassis",f,s.mats.head)}s.headlights.push({pos:[.85,1.02,0],group:"chassis",r:.05});let h=te([{x:.76,y:1.12,w:.13,ht:.03,n:2},{x:.66,y:1.26,w:.17,ht:.03,n:2},{x:.6,y:1.36,w:.16,ht:.02,n:2}],{radial:16,sub:6,t0:.25,t1:Math.PI-.25});t.add("chassis",h,e.glass),fi(s,-.1,-.5,.92,.15,.05,{frontRise:-.02}),fi(s,-.5,-.74,.96,.12,.04);for(let d of[-1,1]){let f=kt(.42,.34,.14,.02);St(f,{p:[-.62,.66,d*.26]}),t.add("chassis",f,k.aluminum());let m=kt(.43,.04,.15,.015);St(m,{p:[-.62,.85,d*.26]}),t.add("chassis",m,k.black()),t.add("chassis",Ht([-.4,.82,d*.19],[-.84,.82,d*.19],.01,8),k.black())}let u=kt(.3,.24,.36,.03);St(u,{p:[-.84,1.08,0]}),t.add("chassis",u,k.aluminum()),jn(s,[-.99,1.06,0],.1,.02,{tilt:0}),Un(s,{type:"wide",rise:.1,back:.14,half:.41});for(let d of s.barEnds){let f=Math.sign(d[2]),m=te([{x:d[0]+.02,y:d[1],w:.04,ht:.03,hb:.01,n:2.4,z:d[2]-f*.1},{x:d[0]+.07,y:d[1]+.01,w:.05,ht:.04,hb:.01,n:2.4,z:d[2]-f*.04}],{radial:12,sub:3,t0:0,t1:Math.PI});t.add("steer",m,k.plastic(1710618))}Nn(s,[.58,1.1,0],.14,.09,{tilt:-1.05});for(let d of[-1,1])_r(s,[.6,1.06,d*.2],d,{group:"chassis",reach:.32,up:.12});Qn(s,-.12,.42,.19),di(s,[-.08,.7,.03],[-.25,.4,.03],{r:.03,springColor:13935665,reservoir:!0}),Ln(s,{from:1.8,len:1.7,w:.12,mat:e.paintSolid,gap:.02})}function Hv(s){let{A:t,mats:e}=s;Pn(s),In(s,{type:"conv",lowerMat:k.gold(),innerMat:k.chrome(),stanchionR:.022,lowerR:.03}),ti(s,{caliperColor:13935665,carrier:"#d4a431",fDiscR:.15,discStyle:"drilled"}),Dn(s,{style:"banana",mat:k.aluminum(),h:.055}),Qi(s),gu(s,{mat:e.frame,z:.12}),Jn(s,[.06,.32,0],[.32,.18,.26],{tilt:.05});for(let[i,r]of[[.17,-.7],[-.02,.55]]){let a=kt(.12,.18,.28,.02);St(a,{p:[i,.5,0],r:[0,0,r]}),t.add("chassis",a,k.engine(5593439))}vr(s,[.35,.5,0],.32,.26,{tilt:-.2});for(let i of[-1,1])mu(s,[[.26,.42,i*.06],[.36,.3,i*.08],[.32,.16,i*.1],[.12,.11,i*.1],[-.12,.13,i*.12],[-.28,.2,i*.14],[-.38,.26,i*.15]],.05),mu(s,[[0,.56,i*.05],[-.06,.48,i*.1],[-.15,.5,i*.13],[-.32,.6,i*.1],[-.48,.7,i*.05],[-.62,.78,i*.04]],.045);xu(s,{k:.9,round:!0,nose:.9,tailX:-.7,hump:.09});let n=ui(.1,20,12);n.scale(.08,.6,.85),n.translate(.895,.84,0),t.add("chassis",n,e.plateSolid),da(s,[.905,.84,0],[.12,.09],e.plate,{r:[0,Math.PI/2,0]}),s.headlights.push({pos:[.88,.8,0],group:"chassis",r:0,none:!0}),jn(s,[-.68,.86,0],.03,.015),Un(s,{type:"clipon"}),Nn(s,[.5,.93,0],.07,.06,{tilt:-1}),Qn(s,-.22,.42,.15,{plates:!0}),di(s,[-.06,.6,0],[-.18,.35,0],{r:.024,springColor:13935665}),Ln(s,{from:1.8,len:1.7,w:.12,mat:e.paintSolid})}var t0={superbike:Pv,gp:Iv,naked:Lv,electric:Dv,cruiser:kv,bobber:Uv,cafe:Nv,drag:Fv,mx:Ov,sm:Bv,adventure:zv,twostroke:Hv};function Vv(s,t,e){let n=!!t.matte,i=zf(t,s.short,t.number||""),r=l=>new $n({metalness:n?.2:.45,roughness:n?.62:.28,clearcoat:n?0:1,clearcoatRoughness:.05,...l}),a={paint:r({map:i}),paintSolid:r({color:t.base}),paint2Solid:r({color:t.second}),accentSolid:r({color:t.accent}),frame:new at({color:t.frame,metalness:.6,roughness:.35}),wheel:new at({color:t.wheel,metalness:.65,roughness:.32}),seat:k.leather(t.seat??1842206),glass:k.glass(1714746,.42),head:new at({color:0,emissive:16774368,emissiveIntensity:4,roughness:.2}),tail:new at({color:2228224,emissive:16715792,emissiveIntensity:1.6,roughness:.3}),neon:new at({color:0,emissive:t.accent,emissiveIntensity:3.2,roughness:.3}),plate:new at({map:Bf(t.number||"1",t.plate||"#ffffff","#111111"),roughness:.5,side:xe}),plateSolid:new at({color:t.plate||"#ffffff",roughness:.45})},o=le(256,128);return a.dashCanvas=o,a.dashTex=Wt(o.c,{wrap:!1,aniso:!1}),a.dash=new at({color:0,emissive:16777215,emissiveMap:a.dashTex,emissiveIntensity:1.4,roughness:.2}),vu(a.dashCanvas,0,0,1,s,1),a.dashTex.needsUpdate=!0,a}function vu(s,t,e,n,i,r){let{g:a,c:o}=s;a.fillStyle="#020306",a.fillRect(0,0,o.width,o.height);let l=24;for(let c=0;c<l;c++){let h=c/l<e,u=c/l>.82;a.fillStyle=h?u?"#ff2a2a":c/l>.6?"#ffd000":"#22e6ff":"#0b1a22",a.fillRect(10+c*9.8,12,7.5,22)}a.fillStyle="#e8f6ff",a.font="700 54px Orbitron, Arial, sans-serif",a.textAlign="left",a.textBaseline="alphabetic",a.fillText(String(Math.round(t)).padStart(3," "),14,104),a.font="700 16px Orbitron, Arial, sans-serif",a.fillStyle="#7fb8d0",a.fillText("KM/H",136,104),a.font="900 64px Orbitron, Arial, sans-serif",a.fillStyle="#22e6ff",a.textAlign="right",a.fillText(i.engine.electric?"D":n<=0?"N":String(n),246,108),a.fillStyle="#ff7a00",a.fillRect(14,112,120*$(r,0,1),6)}var ts=class{constructor(t,e=0,n={}){this.spec=t,this.liveryIndex=e%t.liveries.length,this.livery=t.liveries[this.liveryIndex];let i=new Qo,r=Vv(t,this.livery,n),a={A:i,m:t.model,mats:r,spec:t};t0[t.design](a),this.meshes=i.finalize({castShadow:n.castShadow!==!1}),this.ctx=a,this.mats=r,this.groups=i.groups,this.wb=t.model.wb,this.root=new Qt,this.lean=new Qt,this.pitch=new Qt,this.offset=new Qt,this.model=new Qt,this.root.add(this.lean),this.lean.add(this.pitch),this.pitch.add(this.offset),this.offset.add(this.model),this.model.add(i.inner),this.model.rotation.y=-Math.PI/2,this.pitch.position.z=-this.wb/2,this.offset.position.z=this.wb/2,this.groups.steer.rotation.order="ZYX",this.steerRest=this.groups.steer.rotation.z,this.sliderRest=this.groups.forkSlider.position.clone(),this.wheelSpinF=0,this.wheelSpinR=0,this.root.userData.bike=this,this.exhausts=a.exhausts,this.headlights=a.headlights.filter(l=>!l.none),this.tailMat=r.tail,this.headMat=r.head,this.neonMat=r.neon;let o=new qn().setFromObject(i.inner);this.bounds=o,this.height=o.max.y,this.length=o.max.x-o.min.x,this._v=new C}animate(t,e){let n=this.spec.model.front.R,i=this.spec.model.rear.R,r=(t.speed||0)*e;this.wheelSpinF-=r/n,this.wheelSpinR-=(r+(t.wheelSpinExtra||0)*e)/i,this.groups.frontWheel.rotation.z=this.wheelSpinF,this.groups.rearWheel.rotation.z=this.wheelSpinR,this.groups.steer.rotation.y=-(t.steerAngle||0);let a=$(t.compF||0,-.04,.09),o=$(t.compR||0,-.04,.08);this.groups.forkSlider.position.y=this.sliderRest.y+a;let l=Math.hypot(this.ctx.rear.x-this.ctx.pivot[0],this.ctx.rear.y-this.ctx.pivot[1]);this.groups.swingarm.rotation.z=-o/l,this.offset.position.y=-(a+o)*.5,this.lean.rotation.z=t.lean||0;let c=t.pitch||0;c>=0?(this.pitch.position.z=-this.wb/2,this.offset.position.z=this.wb/2,this.pitch.rotation.x=-c):(this.pitch.position.z=this.wb/2,this.offset.position.z=-this.wb/2,this.pitch.rotation.x=-c),this.tailMat.emissiveIntensity=t.braking?7:1.6}setVisible(t){this.root.visible=t}setGhost(t=4251903){let e=new at({color:0,emissive:t,emissiveIntensity:.9,transparent:!0,opacity:.32,depthWrite:!1,roughness:.5});this.root.traverse(n=>{n.isMesh&&(n.material=e,n.castShadow=!1,n.receiveShadow=!1)}),this.ghostMat=e}worldPoint(t,e=new C){return e.set(t[0],t[1],t[2]??0),this.ctx.A.inner.localToWorld(e)}dispose(){this.root.traverse(t=>{t.isMesh&&t.geometry.dispose()});for(let t of["paint","paintSolid","paint2Solid","accentSolid","frame","wheel","head","tail","neon","plate","plateSolid","dash"])this.mats[t]?.dispose?.();this.mats.dashTex?.dispose(),this.root.removeFromParent()}};var il=class{constructor(t){this.engine=t;let e=new pn;this.scene=e,e.background=new ot(329226),e.fog=new _o(329226,14,40);let n=new Yi(t.renderer);this.envTex=n.fromScene(new jo,.04).texture,e.environment=this.envTex,e.environmentIntensity=.55,n.dispose(),this.camera=new Ue(32,1,.05,200),this.time=0,this.mode="menu",this.yaw=.6,this.pitch=.12,this.dist=4.6,this.targetYaw=.6,this.autoSpin=!0,this.bikes=[],this._buildStage(),this._bindPointer()}_buildStage(){let t=this.scene,e=rt.quality;if(e.post&&e.shadows>=2048){let M=new la(new ys(30,64),{textureWidth:1024,textureHeight:1024,color:8357264,clipBias:.003});M.rotation.x=-Math.PI/2,M.position.y=-.002,t.add(M),this.mirror=M}let n=Lf();n.repeat.set(10,10);let i=new it(new ys(30,64),new at({map:n,color:10133674,roughness:.35,metalness:.3,transparent:!!this.mirror,opacity:this.mirror?.82:1}));i.rotation.x=-Math.PI/2,i.receiveShadow=!0,t.add(i);let r=new Qt,a=new it(new ke(1.7,1.75,.08,96),new at({color:1382172,metalness:.8,roughness:.25}));a.position.y=.04,a.receiveShadow=!0,a.castShadow=!1,r.add(a);let o=new at({color:0,emissive:55551,emissiveIntensity:3});this.ringMat=o;let l=new it(new $i(1.74,.012,8,128),o);l.rotation.x=Math.PI/2,l.position.y=.075,r.add(l);let c=new it(new $i(1.2,.006,6,128),o);c.rotation.x=Math.PI/2,c.position.y=.081,r.add(c);for(let M=0;M<24;M++){let E=new it(new jt(.5,.004,.012),o),A=M/24*Math.PI*2;E.position.set(Math.cos(A)*1.45,.082,Math.sin(A)*1.45),E.rotation.y=-A,r.add(E)}r.position.y=0,t.add(r),this.turntable=r,this.bikeHolder=new Qt,this.bikeHolder.position.y=.08,r.add(this.bikeHolder);let h=new at({color:724242,roughness:.6,metalness:.4,side:Ce}),u=new it(new ke(12,12,9,64,1,!0),h);u.position.y=4.5,t.add(u);let d=new at({color:0,emissive:16777215,emissiveIntensity:2.2});this.stripMat=d;for(let M=0;M<28;M++){let E=M/28*Math.PI*2,A=new it(new jt(.06,6.5,.06),d);A.position.set(Math.cos(E)*11.85,3.6,Math.sin(E)*11.85),t.add(A)}let f=new at({color:0,emissive:16777215,emissiveIntensity:1.6});for(let M of[2.6,3.4]){let E=new it(new $i(M,.03,8,96),f);E.rotation.x=Math.PI/2,E.position.y=6.2,t.add(E)}let m=new Zi(10137855,1052688,.35);t.add(m);let x=new Ki(16777215,120,30,.42,.6,1.6);x.position.set(3.5,7,4),x.target.position.set(0,.5,0),x.castShadow=e.shadows>0,x.shadow.mapSize.set(Math.min(2048,e.shadows||1024),Math.min(2048,e.shadows||1024)),x.shadow.bias=-4e-4,x.shadow.camera.near=2,x.shadow.camera.far=20,t.add(x,x.target);let g=new Ki(4245759,90,30,.5,.7,1.6);g.position.set(-4,4,-4),g.target.position.set(0,.6,0),t.add(g,g.target);let p=new Ki(16726634,60,30,.5,.7,1.6);p.position.set(4,3,-5),p.target.position.set(0,.6,0),t.add(p,p.target),this.rimLights=[g,p];let v=300,y=new Float32Array(v*3),_=$t(5);for(let M=0;M<v;M++)y[M*3]=_.range(-8,8),y[M*3+1]=_.range(.2,6),y[M*3+2]=_.range(-8,8);let S=new Gt;S.setAttribute("position",new Vt(y,3)),this.dust=new Ai(S,new or({color:8956620,size:.025,transparent:!0,opacity:.5,depthWrite:!1})),t.add(this.dust)}_bindPointer(){let t=this.engine.renderer.domElement,e=!1,n=0,i=0;this._onDown=r=>{!this.active||this.mode==="menu"||(e=!0,n=r.clientX,i=r.clientY,this.autoSpin=!1)},this._onMove=r=>{e&&(this.targetYaw-=(r.clientX-n)*.008,this.pitch=$(this.pitch+(r.clientY-i)*.004,.02,.7),n=r.clientX,i=r.clientY)},this._onUp=()=>{e=!1,clearTimeout(this._spinT),this._spinT=setTimeout(()=>{this.autoSpin=!0},3500)},this._onWheel=r=>{!this.active||this.mode==="menu"||(this.dist=$(this.dist+Math.sign(r.deltaY)*.35,2.6,7.5))},t.addEventListener("pointerdown",this._onDown),window.addEventListener("pointermove",this._onMove),window.addEventListener("pointerup",this._onUp),t.addEventListener("wheel",this._onWheel,{passive:!0})}setBike(t,e=0){for(let i of this.bikes)i.dispose();this.bikes=[];let n=new ts(t,e);return n.animate({speed:0,steerAngle:.18,lean:0,pitch:0},0),this.bikeHolder.add(n.root),n.root.rotation.y=0,this.bikes.push(n),this.bike=n,this.ringMat.emissive.set(n.livery.accent==="#111111"||n.livery.accent==="#1a1a1a"?n.livery.base:n.livery.accent),this._flash=1,n}setPodium(t){for(let i of this.bikes)i.dispose();if(this.bikes=[],!this.podium){let i=new Qt,r=new at({color:1711396,metalness:.6,roughness:.3}),a=new at({color:0,emissive:16763955,emissiveIntensity:2});[[0,.9,16763955],[-2.3,.6,13687008],[2.3,.35,14719578]].forEach(([m,x,g],p)=>{let v=new it(new jt(2.1,x,2.6),r);v.position.set(m,x/2,0),v.castShadow=!0,v.receiveShadow=!0,i.add(v);let y=new it(new jt(2.12,.04,2.62),a.clone());y.material.emissive.set(g),y.position.set(m,x,0),i.add(y);let _=document.createElement("canvas");_.width=128,_.height=128;let S=_.getContext("2d");S.fillStyle="#"+new ot(g).getHexString(),S.font="900 100px Orbitron, Arial",S.textAlign="center",S.textBaseline="middle",S.fillText(String(p+1),64,70);let M=new lr(_);M.colorSpace=qe;let E=new it(new we(Math.min(.8,x*.9),Math.min(.8,x*.9)),new De({map:M,transparent:!0}));E.position.set(m,x/2,1.31),i.add(E)}),this.podium=i,this.scene.add(i);let l=600,c=new Float32Array(l*3),h=new Float32Array(l*3),u=$t(11),d=[58879,16722902,16763955,16777215,4063114].map(m=>new ot(m));for(let m=0;m<l;m++){c[m*3]=u.range(-6,6),c[m*3+1]=u.range(0,9),c[m*3+2]=u.range(-4,4);let x=d[m%d.length];h[m*3]=x.r,h[m*3+1]=x.g,h[m*3+2]=x.b}let f=new Gt;f.setAttribute("position",new Vt(c,3)),f.setAttribute("color",new Vt(h,3)),this.confetti=new Ai(f,new or({size:.07,vertexColors:!0,transparent:!0,opacity:.95,depthWrite:!1})),this.scene.add(this.confetti)}this.podium.visible=!0,this.confetti.visible=!0,this.turntable.visible=!1;let e=[0,-2.3,2.3],n=[.9,.6,.35];t.forEach((i,r)=>{if(!i)return;let a=new ts(i.spec,i.livery||0);a.animate({speed:0,steerAngle:.25,lean:0,pitch:r===0?.22:0},0),a.root.position.set(e[r],n[r],0),a.root.rotation.y=Math.PI/2+(r===0?0:r===1?.35:-.35),a.root.scale.setScalar(.85),this.scene.add(a.root),this.bikes.push(a)}),this.bike=null}clearPodium(){this.podium&&(this.podium.visible=!1,this.confetti.visible=!1),this.turntable.visible=!0}setMode(t){t!=="podium"&&this.clearPodium(),this.mode=t,t==="menu"&&(this.dist=5.4,this.pitch=.1),t==="garage"&&(this.dist=4.4,this.pitch=.16,this.autoSpin=!0),t==="podium"&&(this.dist=6,this.pitch=.18)}activate(){this.active=!0,this.engine.setScene(this.scene,this.camera),this.engine.setBloom(.5,.55,.82);let t=this.engine.fx;t&&(t.uBlur.value=0,t.uVignette.value=.38,t.uTintAmt.value=0,t.uFlash.value=0,t.uDamage.value=0)}deactivate(){this.active=!1}update(t){this.time+=t;let e=this.time;this.autoSpin&&(this.targetYaw+=t*(this.mode==="menu"?.18:.28)),this.yaw=Ze(this.yaw,this.targetYaw,4,t);let n=new C(0,.62,0),i=this.yaw,r=this.pitch,a=this.dist;this.mode==="menu"&&(i=e*.12+.6,r=.08+Math.sin(e*.21)*.05,a=5.2+Math.sin(e*.17)*.5,n.set(0,.55,0));let o=this.camera;o.position.set(Math.sin(i)*Math.cos(r)*a,.25+Math.sin(r)*a+.4,Math.cos(i)*Math.cos(r)*a),o.lookAt(n);let c=this.engine.width<this.engine.height?0:this.mode==="menu"?-1.25:this.mode==="garage"?-.75:0;if(c){o.updateMatrixWorld();let h=new C().setFromMatrixColumn(o.matrixWorld,0).multiplyScalar(c);o.position.add(h)}if(o.aspect=this.engine.width/this.engine.height,o.fov=this.engine.width<this.engine.height?48:32,o.updateProjectionMatrix(),this.rimLights[0].intensity=80+Math.sin(e*1.3)*20,this.rimLights[1].intensity=50+Math.cos(e*.9)*15,this._flash>0&&(this._flash=Math.max(0,this._flash-t*2.5)),this.ringMat.emissiveIntensity=2.5+Math.sin(e*3)*.6+this._flash*6,this.stripMat.emissiveIntensity=1.8+this._flash*2,this.dust.rotation.y=e*.02,this.confetti&&this.confetti.visible){let h=this.confetti.geometry.attributes.position;for(let u=0;u<h.count;u++){let d=h.getY(u)-t*(.8+u%7*.12);d<0&&(d+=9),h.setY(u,d),h.setX(u,h.getX(u)+Math.sin(e*2+u)*t*.3)}h.needsUpdate=!0}if(this.mode==="podium"){let h=this.camera,u=e*.15;h.position.set(Math.sin(u)*7.5,2.6+Math.sin(e*.3)*.4,6.5+Math.cos(u)*1.5),h.lookAt(0,1.2,0),h.updateProjectionMatrix()}this.bike&&(this.bike.root.position.y=Math.sin(e*40)*8e-4)}};function I(s,t={},...e){let n=document.createElement(s);for(let[i,r]of Object.entries(t||{}))r==null||r===!1||(i==="class"?n.className=r:i==="style"&&typeof r=="object"?Object.assign(n.style,r):i.startsWith("on")&&typeof r=="function"?n.addEventListener(i.slice(2).toLowerCase(),r):i==="html"?n.innerHTML=r:n.setAttribute(i,r===!0?"":r));for(let i of e.flat(3))i==null||i===!1||n.appendChild(i instanceof Node?i:document.createTextNode(String(i)));return n}function Mr(s){for(;s.firstChild;)s.removeChild(s.firstChild);return s}function br(s,t,e){let n=document.createElement("canvas"),i=Math.min(2,window.devicePixelRatio||1);return n.width=Math.round(s*i),n.height=Math.round(t*i),e&&(n.className=e),n._dpr=i,n}var Fn={i4:[[0,.42],[.25,.6],[.5,.82],[.72,1],[.88,.97],[1,.86]],v4:[[0,.5],[.25,.7],[.5,.9],[.7,1],[.9,.95],[1,.85]],i3:[[0,.55],[.25,.78],[.5,.95],[.7,1],[.9,.9],[1,.8]],vtwin:[[0,.75],[.2,.92],[.4,1],[.6,.95],[.8,.82],[1,.68]],twin:[[0,.65],[.25,.85],[.5,1],[.7,.96],[.9,.85],[1,.75]],single:[[0,.6],[.25,.82],[.55,1],[.75,.94],[.9,.82],[1,.7]],boxer:[[0,.7],[.25,.88],[.5,1],[.7,.97],[.9,.86],[1,.76]],twoStroke:[[0,.3],[.4,.42],[.6,.62],[.72,.95],[.85,1],[.95,.9],[1,.7]],electric:[[0,1],[.35,1],[.5,.72],[.7,.52],[.85,.43],[1,.36]],muscle:[[0,.65],[.25,.85],[.5,.97],[.7,1],[.9,.9],[1,.8]]},He=[{id:"raptor",name:"RAPTOR RR1000",short:"RAPTOR",klass:"SUPERBIKE",design:"superbike",blurb:"Superbike de cuatro cilindros en l\xEDnea. Agresiva, precisa y brutal a alta velocidad.",engine:{label:"999 cc \xB7 4 en l\xEDnea",hp:215,redline:14500,idle:1300,curve:Fn.i4,gears:[2.6,2.05,1.72,1.5,1.34,1.22],sound:"i4"},mass:199,topKmh:299,maxLean:58,leanRate:3,brakeG:1.18,grip:1,offroad:.45,wheelieTend:.7,cda:null,model:{wb:1.42,rake:24,forkLen:.55,forkOffset:.032,pivot:[-.12,.47],front:{R:.3,w:.12,rim:.216,style:"cast",spokes:5,sweep:.35},rear:{R:.315,w:.19,rim:.216,style:"cast",spokes:5,sweep:.35}},liveries:[{name:"Rosso Corsa",base:"#c4121a",second:"#f2f2f2",accent:"#111111",frame:"#9ea3aa",wheel:"#151515",pattern:"arrow"},{name:"Azul Racing",base:"#123fb0",second:"#f2f2f2",accent:"#e6b800",frame:"#2b2d31",wheel:"#e6b800",pattern:"split"},{name:"Noche Oro",base:"#101012",second:"#2d2d32",accent:"#d4a431",frame:"#101012",wheel:"#d4a431",pattern:"stripe"}]},{id:"apex",name:"APEX GP-V4",short:"APEX GP",klass:"PROTOTIPO GP",design:"gp",blurb:"Prototipo de gran premio con alerones aerodin\xE1micos y V4 de 290 CV. La cima absoluta.",engine:{label:"1000 cc \xB7 V4 big bang",hp:290,redline:18e3,idle:2200,curve:Fn.v4,gears:[2.4,1.95,1.66,1.45,1.3,1.19],sound:"v4"},mass:157,topKmh:345,maxLean:62,leanRate:3.4,brakeG:1.32,grip:1.12,offroad:.35,wheelieTend:1,model:{wb:1.44,rake:23.5,forkLen:.54,forkOffset:.03,pivot:[-.1,.48],front:{R:.3,w:.125,rim:.216,style:"cast",spokes:7,sweep:.15,spokeW:.02},rear:{R:.32,w:.2,rim:.216,style:"cast",spokes:7,sweep:.15,spokeW:.022}},liveries:[{name:"F\xE1brica Ne\xF3n",base:"#0b0b0d",second:"#00e5ff",accent:"#ff1e56",frame:"#1b1b1d",wheel:"#111111",pattern:"neon",number:"93"},{name:"Naranja Fuego",base:"#ff5a00",second:"#111111",accent:"#ffffff",frame:"#1b1b1d",wheel:"#111111",pattern:"arrow",number:"46"},{name:"Plata M\xEDtica",base:"#c7ccd3",second:"#6a00ff",accent:"#111111",frame:"#1b1b1d",wheel:"#6a00ff",pattern:"split",number:"1"}]},{id:"viper",name:"VIPER 900 TRIPLE",short:"VIPER",klass:"NAKED",design:"naked",blurb:"Streetfighter tricil\xEDndrica con chasis multitubular y basculante monobrazo.",engine:{label:"890 cc \xB7 3 en l\xEDnea",hp:140,redline:12e3,idle:1200,curve:Fn.i3,gears:[2.65,2.08,1.74,1.5,1.33,1.2],sound:"i3"},mass:189,topKmh:252,maxLean:54,leanRate:3.2,brakeG:1.12,grip:.98,offroad:.55,wheelieTend:1,model:{wb:1.45,rake:24.5,forkLen:.58,forkOffset:.03,pivot:[-.13,.46],front:{R:.3,w:.12,rim:.216,style:"cast",spokes:3,sweep:.5,spokeW:.04,spokeT:.022},rear:{R:.315,w:.18,rim:.216,style:"cast",spokes:3,sweep:.5,spokeW:.045,spokeT:.024}},liveries:[{name:"Verde \xC1cido",base:"#7cff00",second:"#1a1a1a",accent:"#1a1a1a",frame:"#c4121a",wheel:"#1a1a1a",pattern:"split"},{name:"Grafito",base:"#3a3d42",second:"#ff5a00",accent:"#ff5a00",frame:"#ff5a00",wheel:"#ff5a00",pattern:"stripe"},{name:"Blanco Hielo",base:"#eef2f6",second:"#c4121a",accent:"#c4121a",frame:"#c4121a",wheel:"#111111",pattern:"arrow"}]},{id:"volt",name:"VOLT PHANTOM X",short:"VOLT",klass:"EL\xC9CTRICA",design:"electric",blurb:"Hiper-moto el\xE9ctrica con ruedas sin buje, par instant\xE1neo y silencio futurista.",engine:{label:"150 kW \xB7 Motor el\xE9ctrico",hp:204,redline:13e3,idle:0,curve:Fn.electric,gears:[1],sound:"electric",electric:!0},mass:230,topKmh:290,maxLean:56,leanRate:2.7,brakeG:1.14,grip:1,offroad:.5,wheelieTend:.8,model:{wb:1.5,rake:25,forkLen:.56,forkOffset:.03,pivot:[-.1,.45],front:{R:.31,w:.125,rim:.226,style:"hubless"},rear:{R:.325,w:.2,rim:.226,style:"hubless"}},liveries:[{name:"Cian Plasma",base:"#e9eef2",second:"#0d0f12",accent:"#00f0ff",frame:"#0d0f12",wheel:"#0d0f12",pattern:"neon"},{name:"Magenta Void",base:"#0d0f12",second:"#26292e",accent:"#ff2bd6",frame:"#26292e",wheel:"#26292e",pattern:"neon"},{name:"Lima Cromo",base:"#5d636b",second:"#0d0f12",accent:"#b6ff00",frame:"#0d0f12",wheel:"#0d0f12",pattern:"neon"}]},{id:"baron",name:"IRON BARON 1800",short:"BARON",klass:"CRUISER",design:"cruiser",blurb:"Crucero V-twin de 1800 cc: cromo, guardabarros profundos y par de locomotora.",engine:{label:"1801 cc \xB7 V-twin 45\xB0",hp:100,redline:5800,idle:850,curve:Fn.vtwin,gears:[3,2.1,1.6,1.3,1.1,.95],sound:"vtwin"},mass:340,topKmh:198,maxLean:34,leanRate:1.6,brakeG:.86,grip:.92,offroad:.5,wheelieTend:.2,model:{wb:1.72,rake:32,forkLen:.64,forkOffset:.04,pivot:[-.3,.38],headLen:.18,front:{R:.33,w:.13,rim:.24,style:"wire",spokes:40},rear:{R:.33,w:.2,rim:.205,style:"wire",spokes:40}},liveries:[{name:"Vino Profundo",base:"#5a0b14",second:"#e8e2d0",accent:"#d4a431",frame:"#0d0d0f",wheel:"#d8dbe0",pattern:"stripe",seat:3809812},{name:"Azul Medianoche",base:"#0b1c3a",second:"#c0c4ca",accent:"#c0c4ca",frame:"#0d0d0f",wheel:"#d8dbe0",pattern:"flames",seat:1447446},{name:"Crema Cl\xE1sico",base:"#e8dfc8",second:"#2c1a10",accent:"#8a1a10",frame:"#0d0d0f",wheel:"#d8dbe0",pattern:"split",seat:5913120}]},{id:"bobber",name:"GHOST BOBBER",short:"GHOST",klass:"BOBBER",design:"bobber",blurb:"Bobber mate con horquilla springer, asiento flotante y escapes rectos.",engine:{label:"1200 cc \xB7 V-twin",hp:88,redline:6500,idle:900,curve:Fn.vtwin,gears:[2.8,1.95,1.5,1.22,1.03],sound:"vtwin2"},mass:250,topKmh:192,maxLean:33,leanRate:1.9,brakeG:.9,grip:.92,offroad:.55,wheelieTend:.4,model:{wb:1.6,rake:30,forkLen:.6,forkOffset:.05,pivot:[-.28,.36],headLen:.16,front:{R:.33,w:.14,rim:.205,style:"wire",spokes:40},rear:{R:.33,w:.18,rim:.205,style:"wire",spokes:40}},liveries:[{name:"Negro Fantasma",base:"#141414",second:"#2a2a2a",accent:"#b0b0b0",frame:"#0b0b0b",wheel:"#111111",pattern:"stripe",matte:!0,seat:4006932},{name:"Verde Militar",base:"#3c4a2c",second:"#20261a",accent:"#e8e0c8",frame:"#0b0b0b",wheel:"#111111",pattern:"stripe",matte:!0,seat:2759184},{name:"\xD3xido",base:"#7a3a1a",second:"#3a1a0a",accent:"#d0b080",frame:"#0b0b0b",wheel:"#111111",pattern:"flames",matte:!0,seat:1710618}]},{id:"cafe",name:"CAF\xC9 BULLET 650",short:"BULLET",klass:"CAF\xC9 RACER",design:"cafe",blurb:"Caf\xE9 racer bicil\xEDndrica de radios y semimanillares. Elegancia de los a\xF1os 60.",engine:{label:"648 cc \xB7 Bicil\xEDndrico 270\xB0",hp:78,redline:8200,idle:1e3,curve:Fn.twin,gears:[2.75,1.95,1.55,1.3,1.12],sound:"twin"},mass:190,topKmh:205,maxLean:48,leanRate:2.6,brakeG:1,grip:.95,offroad:.5,wheelieTend:.5,model:{wb:1.42,rake:25,forkLen:.6,forkOffset:.035,pivot:[-.18,.4],front:{R:.31,w:.1,rim:.23,style:"wire",spokes:36},rear:{R:.31,w:.13,rim:.23,style:"wire",spokes:36}},liveries:[{name:"Verde Brit\xE1nico",base:"#0f3d2a",second:"#e8e0c8",accent:"#d4a431",frame:"#111111",wheel:"#cfd3d8",pattern:"stripe",seat:2759184},{name:"Plata Ton-Up",base:"#b8bcc2",second:"#111111",accent:"#c4121a",frame:"#111111",wheel:"#cfd3d8",pattern:"stripe",seat:1447446},{name:"Rojo Cereza",base:"#8a0e1a",second:"#f0e8d8",accent:"#f0e8d8",frame:"#111111",wheel:"#cfd3d8",pattern:"retro",seat:3809812}]},{id:"drag",name:"THUNDER DRAG V-MAX",short:"THUNDER",klass:"POWER CRUISER",design:"drag",blurb:"Muscle bike V4 con neum\xE1tico trasero gigante y tomas de aire cromadas.",engine:{label:"1679 cc \xB7 V4",hp:200,redline:9500,idle:1e3,curve:Fn.muscle,gears:[2.55,1.85,1.45,1.2,1.02],sound:"muscle"},mass:310,topKmh:270,maxLean:40,leanRate:1.8,brakeG:.98,grip:.96,offroad:.4,wheelieTend:.9,model:{wb:1.7,rake:31,forkLen:.62,forkOffset:.04,pivot:[-.26,.4],headLen:.17,front:{R:.31,w:.12,rim:.23,style:"cast",spokes:5,sweep:.2,spokeW:.034},rear:{R:.33,w:.25,rim:.205,style:"cast",spokes:5,sweep:.2,spokeW:.04}},liveries:[{name:"Negro Trueno",base:"#0c0c0e",second:"#c4121a",accent:"#c0c4ca",frame:"#0c0c0e",wheel:"#2a2a2e",pattern:"split",seat:1118481},{name:"Titanio",base:"#5a5e66",second:"#0c0c0e",accent:"#00b0ff",frame:"#0c0c0e",wheel:"#0c0c0e",pattern:"arrow",seat:1118481},{name:"Rojo Sangre",base:"#7a0008",second:"#0c0c0e",accent:"#e0e0e0",frame:"#0c0c0e",wheel:"#c0c4ca",pattern:"stripe",seat:1118481}]},{id:"hornet",name:"MUD HORNET 450",short:"HORNET",klass:"MOTOCROSS",design:"mx",blurb:"Motocross monocil\xEDndrica ultraligera. Reina absoluta fuera del asfalto.",engine:{label:"449 cc \xB7 Monocil\xEDndrico",hp:64,redline:13e3,idle:1600,curve:Fn.single,gears:[2.9,2.2,1.75,1.45,1.22],sound:"single"},mass:106,topKmh:178,maxLean:50,leanRate:3.6,brakeG:1,grip:.95,offroad:1,wheelieTend:1.2,model:{wb:1.48,rake:27,forkLen:.72,forkOffset:.022,pivot:[-.2,.58],headLen:.16,front:{R:.36,w:.085,rim:.267,style:"wire",spokes:36,knobby:!0},rear:{R:.35,w:.115,rim:.241,style:"wire",spokes:36,knobby:!0}},liveries:[{name:"Naranja Factory",base:"#ff6a00",second:"#111111",accent:"#ffffff",frame:"#ff6a00",wheel:"#111111",pattern:"arrow",number:"7"},{name:"Amarillo Avispa",base:"#ffd400",second:"#1a3aa0",accent:"#111111",frame:"#9ea3aa",wheel:"#d4a431",pattern:"split",number:"21"},{name:"Verde Lima",base:"#56e000",second:"#111111",accent:"#ffffff",frame:"#9ea3aa",wheel:"#111111",pattern:"stripe",number:"3"}]},{id:"fang",name:"FANG SM 700",short:"FANG",klass:"SUPERMOTARD",design:"sm",blurb:"Supermotard de 700 cc: derrapes, caballitos y frenada imposible.",engine:{label:"693 cc \xB7 Monocil\xEDndrico",hp:78,redline:1e4,idle:1400,curve:Fn.single,gears:[2.7,2.05,1.65,1.4,1.22,1.1],sound:"singleBig"},mass:147,topKmh:205,maxLean:55,leanRate:3.5,brakeG:1.15,grip:1.04,offroad:.82,wheelieTend:1.3,model:{wb:1.47,rake:26,forkLen:.66,forkOffset:.024,pivot:[-.2,.55],headLen:.16,front:{R:.3,w:.12,rim:.216,style:"wire",spokes:36,discs:"wave"},rear:{R:.31,w:.165,rim:.216,style:"wire",spokes:36}},liveries:[{name:"Blanco Colmillo",base:"#f4f4f4",second:"#d0101a",accent:"#111111",frame:"#d0101a",wheel:"#d0101a",pattern:"arrow",number:"11"},{name:"Negro \xC1mbar",base:"#141414",second:"#ffb000",accent:"#ffb000",frame:"#ffb000",wheel:"#111111",pattern:"split",number:"88"},{name:"Azul El\xE9ctrico",base:"#0050ff",second:"#ffffff",accent:"#00e5ff",frame:"#9ea3aa",wheel:"#111111",pattern:"stripe",number:"5"}]},{id:"atlas",name:"ATLAS GT 1300",short:"ATLAS",klass:"ADVENTURE",design:"adventure",blurb:"Trail aventurera con motor b\xF3xer, maletas de aluminio y suspensi\xF3n de largo recorrido.",engine:{label:"1300 cc \xB7 B\xF3xer bicil\xEDndrico",hp:145,redline:9e3,idle:1e3,curve:Fn.boxer,gears:[2.7,2,1.6,1.35,1.17,1.04],sound:"boxer"},mass:249,topKmh:232,maxLean:46,leanRate:2.2,brakeG:1.02,grip:.96,offroad:.86,wheelieTend:.5,model:{wb:1.53,rake:26,forkLen:.66,forkOffset:.03,pivot:[-.2,.47],headLen:.17,front:{R:.34,w:.11,rim:.241,style:"wire",spokes:40},rear:{R:.325,w:.15,rim:.216,style:"wire",spokes:40}},liveries:[{name:"Tricolor Rally",base:"#f2f2f2",second:"#123fb0",accent:"#c4121a",frame:"#123fb0",wheel:"#111111",pattern:"split",seat:1118481},{name:"Arena Dakar",base:"#c8b48a",second:"#2a2a2a",accent:"#ff6a00",frame:"#2a2a2a",wheel:"#d4a431",pattern:"stripe",seat:3811866},{name:"Verde Selva",base:"#2e5a2a",second:"#111111",accent:"#e6b800",frame:"#111111",wheel:"#111111",pattern:"arrow",seat:1118481}]},{id:"ringo",name:"RINGO 2T 500",short:"RINGO",klass:"CL\xC1SICA 2T",design:"twostroke",blurb:"R\xE9plica GP de dos tiempos de los 80. Banda de potencia explosiva y c\xE1maras de expansi\xF3n.",engine:{label:"499 cc \xB7 V4 dos tiempos",hp:168,redline:12500,idle:1800,curve:Fn.twoStroke,gears:[2.5,1.98,1.66,1.44,1.29,1.18],sound:"twoStroke"},mass:131,topKmh:292,maxLean:55,leanRate:3.3,brakeG:1.05,grip:.94,offroad:.4,wheelieTend:1.1,model:{wb:1.38,rake:24,forkLen:.55,forkOffset:.032,pivot:[-.12,.45],front:{R:.295,w:.11,rim:.216,style:"cast",spokes:3,sweep:0,spokeW:.035},rear:{R:.31,w:.17,rim:.216,style:"cast",spokes:3,sweep:0,spokeW:.04}},liveries:[{name:"Retro Azul",base:"#f4f4f4",second:"#123f8a",accent:"#d4a431",frame:"#c9ccd1",wheel:"#d4a431",pattern:"retro",number:"4",plate:"#ffd400"},{name:"Amarillo 500",base:"#ffd400",second:"#111111",accent:"#c4121a",frame:"#c9ccd1",wheel:"#111111",pattern:"retro",number:"2",plate:"#ffd400"},{name:"Rojo Leyenda",base:"#c4121a",second:"#f4f4f4",accent:"#111111",frame:"#c9ccd1",wheel:"#f4f4f4",pattern:"retro",number:"34",plate:"#ffffff"}]}],un=Object.fromEntries(He.map(s=>[s.id,s]));function e0(s){let t=s.engine.hp/s.mass;return{velocidad:fa((s.topKmh-170)/180),aceleracion:fa((t-.28)/(1.85-.28)),manejo:fa((s.maxLean-32)/30*.5+(s.leanRate-1.5)/2.1*.5),frenada:fa((s.brakeG-.82)/(1.34-.82)),offroad:fa((s.offroad-.3)/.7)}}function fa(s){return Math.max(.04,Math.min(1,s))}var We=[{id:"gp",name:"AUT\xD3DROMO M\xCDTICO",place:"Circuito internacional",theme:"gp",time:"day",weather:"clear",blurb:"Circuito de Gran Premio con recta de 650 m, horquilla y chicane final. Grip m\xE1ximo.",width:14,runoff:13,runoffMat:"gravel",bank:.25,laps:3,corners:[[0,700,45],[150,760,60],[380,620,120],[420,450,30],[250,420,50],[330,250,80],[600,180,25],[560,40,150],[300,-60,40],[240,60,35],[160,-20,35],[40,-120,70]],startEdge:11,elevation:[[0,0],[.15,4],[.3,12],[.45,8],[.6,2],[.75,6],[.9,1]]},{id:"coast",name:"COSTA DORADA",place:"Carretera costera",theme:"coast",time:"sunset",weather:"clear",blurb:"Curvas r\xE1pidas junto al acantilado con el sol cayendo sobre el mar.",width:12,runoff:6,runoffMat:"sand",bank:.5,laps:3,corners:[[0,0,120],[-150,400,200],[0,800,90],[300,900,150],[550,700,70],[450,500,100],[650,300,160],[600,-100,110],[300,-200,140]],startEdge:8,elevation:[[0,6],[.12,14],[.25,22],[.38,18],[.5,9],[.62,4],[.75,12],[.88,8]]},{id:"city",name:"NEO TOKIO",place:"Circuito urbano nocturno",theme:"city",time:"night",weather:"wet",blurb:"Muros a cent\xEDmetros, neones y asfalto mojado. Precisi\xF3n o muro.",width:13,runoff:2.5,runoffMat:"concrete",bank:.1,laps:3,corners:[[0,0,25],[0,600,25],[300,600,25],[300,400,22],[500,400,25],[500,750,30],[800,750,25],[800,150,25],[550,150,20],[550,-150,25],[250,-150,25],[250,0,20]],startEdge:0,elevation:[[0,0],[.25,2],[.5,6],[.75,2]]},{id:"desert",name:"CA\xD1\xD3N ROJO",place:"Desierto de las Mesetas",theme:"desert",time:"day",weather:"clear",blurb:"Rectas eternas, crestas que te hacen volar y curvas de alta velocidad.",width:14,runoff:16,runoffMat:"sand",bank:.35,laps:3,corners:[[0,0,200],[0,1e3,150],[400,1250,300],[900,1e3,120],[700,650,90],[1e3,400,200],[800,-100,250],[300,-250,180]],startEdge:0,elevation:[[0,0],[.08,14],[.12,6],[.2,20],[.3,4],[.42,26],[.5,12],[.58,30],[.7,10],[.8,18],[.9,4]],bumps:[[140,2.6,52],[300,3.2,62],[-420,3,58],[-230,2.2,44]]},{id:"alpine",name:"ALPES NEVADOS",place:"Puerto de monta\xF1a",theme:"alpine",time:"day",weather:"snow",blurb:"Paso de monta\xF1a con horquillas, desnivel brutal y nieve cayendo.",width:11,runoff:3.5,runoffMat:"snow",bank:.3,laps:2,corners:[[0,0,80],[400,100,32],[60,200,32],[420,300,32],[80,400,32],[300,600,100],[700,550,140],[900,200,120],[700,-150,160],[250,-200,120]],startEdge:0,elevation:[[0,0],[.1,18],[.2,38],[.3,58],[.4,70],[.5,64],[.62,48],[.75,30],[.88,12]]},{id:"forest",name:"BOSQUE TORMENTA",place:"Selva negra",theme:"forest",time:"dusk",weather:"storm",blurb:"Tormenta el\xE9ctrica al anochecer, bosque cerrado y lluvia torrencial.",width:12,runoff:5,runoffMat:"grass",bank:.4,laps:3,corners:[[0,0,60],[-50,350,45],[150,450,70],[100,650,40],[350,700,90],[500,500,50],[350,350,60],[500,150,80],[350,-100,70],[100,-150,60]],startEdge:0,elevation:[[0,0],[.15,8],[.3,3],[.45,14],[.6,20],[.75,9],[.9,4]],bumps:[[120,2.5,40],[-150,3,45]]}],Gv=Object.fromEntries(We.map(s=>[s.id,s]));var n0=Math.PI*2;function Wv(s,t=1){let e=s.corners,n=e.length,i=[];for(let f=0;f<n;f++){let m=e[(f-1+n)%n],x=e[f],g=e[(f+1)%n],p=x[0]-m[0],v=x[1]-m[1],y=g[0]-x[0],_=g[1]-x[1],S=Math.hypot(p,v),M=Math.hypot(y,_);p/=S,v/=S,y/=M,_/=M;let E=p*_-v*y,A=p*y+v*_,w=Math.atan2(E,A);i.push({V:x,ax:p,az:v,bx:y,bz:_,la:S,lb:M,theta:w,R:x[2]??40})}for(let f=0;f<n;f++){let m=i[f],x=i[(f+1)%n],g=m.R*Math.tan(Math.abs(m.theta)/2),p=x.R*Math.tan(Math.abs(x.theta)/2);if(g+p>m.lb*.98){let v=m.lb*.98/(g+p);m.R*=v,x.R*=v}}let r=[];for(let f=0;f<n;f++){let m=i[f],x=m.R*Math.tan(Math.abs(m.theta)/2),g=[m.V[0]-m.ax*x,m.V[1]-m.az*x],p=Math.atan2(m.ax,m.az),v=-m.theta,y=Math.abs(v)*m.R,_=Math.max(2,Math.round(y/t)),S=g[0],M=g[1],E=p;r.push([S,M]);for(let U=0;U<_;U++){let F=y/_;E+=v/_/2,S+=Math.sin(E)*F,M+=Math.cos(E)*F,E+=v/_/2,r.push([S,M])}let A=i[(f+1)%n],w=A.R*Math.tan(Math.abs(A.theta)/2),b=[A.V[0]-A.ax*w,A.V[1]-A.az*w],P=Math.hypot(b[0]-S,b[1]-M),D=Math.max(1,Math.round(P/t));for(let U=1;U<D;U++)r.push([S+(b[0]-S)*(U/D),M+(b[1]-M)*(U/D)])}let a=s.startEdge??Xv(e),o=e[a],l=e[(a+1)%n],c=[(o[0]+l[0])/2,(o[1]+l[1])/2],h=0,u=1/0;for(let f=0;f<r.length;f++){let m=Math.hypot(r[f][0]-c[0],r[f][1]-c[1]);m<u&&(u=m,h=f)}return{pts:r.slice(h).concat(r.slice(0,h)),fil:i}}function Xv(s){let t=0,e=0;for(let n=0;n<s.length;n++){let i=s[n],r=s[(n+1)%s.length],a=Math.hypot(r[0]-i[0],r[1]-i[1]);a>e&&(e=a,t=n)}return t}function i0(s,t){let e=s.slice(),n=e[e.length-1],i=e[0];Math.hypot(n[0]-i[0],n[1]-i[1])<.5&&e.pop();let r=e.length,a=new Float64Array(r+1);for(let u=0;u<r;u++){let d=e[u],f=e[(u+1)%r];a[u+1]=a[u]+Math.hypot(f[0]-d[0],f[1]-d[1])}let o=a[r],l=Math.max(16,Math.round(o/t)),c=[],h=0;for(let u=0;u<l;u++){let d=u/l*o;for(;a[h+1]<d;)h++;let f=(d-a[h])/(a[h+1]-a[h]||1),m=e[h],x=e[(h+1)%r];c.push([m[0]+(x[0]-m[0])*f,m[1]+(x[1]-m[1])*f])}return{pts:c,L:o}}function qv(s,t,e=.5){let n=s.map(r=>r.slice()),i=n.length;for(let r=0;r<t;r++){let a=n.map(o=>o.slice());for(let o=0;o<i;o++){let l=n[(o-1+i)%i],c=n[(o+1)%i];a[o][0]=n[o][0]+e*((l[0]+c[0])/2-n[o][0]),a[o][1]=n[o][1]+e*((l[1]+c[1])/2-n[o][1])}n=a}return n}function Yv(s,t){let e=s.length,n=e-1;for(let v=0;v<e;v++)if(s[v][0]>t){n=v-1;break}n<0&&(n=e-1);let i=s[n],r=s[(n+1)%e],a=s[(n-1+e)%e],o=s[(n+2)%e],l=i[0],c=r[0];c<=l&&(c+=1);let h=t;h<l&&(h+=1);let u=(h-l)/(c-l||1),d=a[1],f=i[1],m=r[1],x=o[1],g=u*u,p=g*u;return .5*(2*f+(-d+m)*u+(2*d-5*f+4*m-x)*g+(-d+3*f-3*m+x)*p)}function sl(s,t=2){let e=Wv(s,1),{pts:n}=i0(e.pts,t);n=qv(n,s.smooth??6,.5);let i=i0(n,t);n=i.pts;let r=n.length,a=i.L,o=new Float32Array(r),l=new Float32Array(r),c=new Float32Array(r),h=new Float32Array(r),u=new Float32Array(r),d=new Float32Array(r),f=new Float32Array(r),m=new Float32Array(r),x=new Float32Array(r),g=new Float32Array(r),p=new Float32Array(r);for(let M=0;M<r;M++)o[M]=n[M][0],c[M]=n[M][1],g[M]=M/r*a;for(let M=0;M<r;M++){let E=n[(M-1+r)%r],A=n[(M+1)%r],w=A[0]-E[0],b=A[1]-E[1],P=Math.hypot(w,b)||1;h[M]=w/P,u[M]=b/P,d[M]=-u[M],f[M]=h[M]}for(let M=0;M<r;M++){let E=(M+1)%r,A=Math.atan2(h[M],u[M]),b=Math.atan2(h[E],u[E])-A;for(;b>Math.PI;)b-=n0;for(;b<-Math.PI;)b+=n0;m[M]=b/(a/r)}let v=pa(m,12),y=s.bank??.6;for(let M=0;M<r;M++)x[M]=Math.max(-.2,Math.min(.2,v[M]*y*18));let _=pa(x,8);x.set(_);let S=(s.elevation||[[0,0]]).slice().sort((M,E)=>M[0]-E[0]);for(let M=0;M<r;M++)l[M]=S.length>1?Yv(S,M/r):S[0][1];for(let[M,E,A]of s.bumps||[]){let w=M<0?a+M:M;for(let b=0;b<r;b++){let P=b/r*a-w;P>a/2&&(P-=a),P<-a/2&&(P+=a),Math.abs(P)<A&&(l[b]+=E*.5*(1+Math.cos(Math.PI*P/A)))}}for(let M=0;M<r;M++)p[M]=(l[(M+1)%r]-l[(M-1+r)%r])/(2*a/r);return{N:r,L:a,ds:a/r,x:o,y:l,z:c,tx:h,tz:u,rx:d,rz:f,kappa:m,kappaSmooth:v,bank:x,s:g,grade:p,fil:e.fil}}function pa(s,t){let e=s.length,n=new Float32Array(e),i=t*2+1,r=0;for(let a=-t;a<=t;a++)r+=s[(a+e)%e];for(let a=0;a<e;a++)n[a]=r/i,r+=s[(a+t+1)%e]-s[(a-t+e)%e];return n}var ce={race:"\u25B6",champ:"\u265B",trial:"\u25F7",free:"\u221E",garage:"\u2699",settings:"\u2630",records:"\u2605",back:"\u25C0",play:"\u25B6",retry:"\u21BB",replay:"\u23F5",exit:"\u23CF",cam:"\u25C9"},s0={day:"D\xCDA",sunset:"ATARDECER",dusk:"ANOCHECER",night:"NOCHE"},r0={clear:"DESPEJADO",wet:"MOJADO",snow:"NIEVE",storm:"TORMENTA",rain:"LLUVIA"},Pi=[["facil","F\xC1CIL"],["normal","NORMAL"],["mitico","M\xCDTICO"]],a0=["Inclinar m\xE1s no siempre es girar m\xE1s: si te pasas del l\xEDmite de agarre, la moto se abre.","Frena recto y suelta el freno al inclinar. El neum\xE1tico s\xF3lo tiene un 100% de agarre para repartir.","Ponte detr\xE1s de un rival para aprovechar el rebufo: menos resistencia y el nitro se recarga m\xE1s r\xE1pido.","Los saltos largos recargan el nitro. Gas en el aire levanta el morro, freno lo baja.","Freno trasero (ESPACIO) en mitad de la curva = derrape controlado al estilo supermotard.","Pulsa C para cambiar de c\xE1mara: persecuci\xF3n, lejana, a bordo o a ras de rueda.","En mojado y nieve el agarre baja: frena antes y abre gas con suavidad.","Las motos de campo (motocross, supermotard, trail) apenas pierden velocidad fuera del asfalto.","X para hacer un caballito. Cuidado: si te pasas, te vas al suelo.","En contrarreloj compites contra tu propio fantasma: tu mejor vuelta queda guardada."];function ma(s,t=300,e=200){let n=br(t,e),i=n.getContext("2d"),r=n.width,a=n.height,o={gp:["#12301e","#1d4a2c"],coast:["#3a1e2a","#ff8a4a"],city:["#0a0820","#2a0a3a"],desert:["#3a1a10","#a0502a"],alpine:["#1a2a40","#a8c0e0"],forest:["#0a1a10","#203a20"]}[s.theme]||["#111","#333"],l=i.createLinearGradient(0,0,r,a);l.addColorStop(0,o[0]),l.addColorStop(1,o[1]),i.fillStyle=l,i.fillRect(0,0,r,a),i.globalAlpha=.07,i.strokeStyle="#fff";for(let M=-a;M<r;M+=14)i.beginPath(),i.moveTo(M,0),i.lineTo(M+a,a),i.stroke();i.globalAlpha=1;let c=ma.cache[s.id]||(ma.cache[s.id]=sl(s,6)),h=1/0,u=-1/0,d=1/0,f=-1/0;for(let M=0;M<c.N;M++)h=Math.min(h,c.x[M]),u=Math.max(u,c.x[M]),d=Math.min(d,c.z[M]),f=Math.max(f,c.z[M]);let m=r*.12,x=Math.min((r-m*2)/(u-h),(a-m*2.2)/(f-d)),g=(h+u)/2,p=(d+f)/2,v=M=>[r/2-(c.x[M]-g)*x,a*.44-(c.z[M]-p)*x];i.lineJoin="round",i.lineCap="round";let y=new Path2D;for(let M=0;M<=c.N;M++){let[E,A]=v(M%c.N);M?y.lineTo(E,A):y.moveTo(E,A)}i.strokeStyle="rgba(0,0,0,0.5)",i.lineWidth=r*.035,i.stroke(y),i.strokeStyle="#ffffff",i.lineWidth=r*.014,i.shadowColor="#00e5ff",i.shadowBlur=r*.04,i.stroke(y),i.shadowBlur=0;let[_,S]=v(0);return i.fillStyle="#00e5ff",i.beginPath(),i.arc(_,S,r*.018,0,Math.PI*2),i.fill(),n.__len=c.L,n}ma.cache={};var rl=class{constructor(t){this.game=t,this.root=document.getElementById("ui"),this.layer=I("div",{class:"layer",style:{position:"absolute",inset:"0"}}),this.root.appendChild(this.layer),this.nav=[],this.navI=0,this.current=null,this.modal=null}_screen(t=""){if(this.current){let n=this.current;n.classList.remove("show"),setTimeout(()=>n.remove(),350)}let e=I("div",{class:"screen "+t});return this.layer.appendChild(e),requestAnimationFrame(()=>e.classList.add("show")),this.current=e,this.nav=[],this.navI=0,this.onBack=null,this.onLeftRight=null,e}btn(t,e,n,i=""){let r=I("button",{class:"btn "+i},I("span",{class:"ico"},e||""),I("span",{},t));return r.addEventListener("click",()=>{It.init(),It.click(),n()}),r.addEventListener("mouseenter",()=>{let a=this.nav.indexOf(r);a>=0&&this._focus(a,!1),It.hover()}),r}_setNav(t,e=0){this.nav=t,this._focus(e,!1)}_focus(t,e=!0){this.nav.length&&(this.navI=(t+this.nav.length)%this.nav.length,this.nav.forEach((n,i)=>n.classList.toggle("focus",i===this.navI)),e&&It.hover())}update(t){let e=ze.edges;this.game.race&&!this.game.race.paused&&this.game.race.phase!=="results"&&this.game.race.phase!=="replay"||!this.nav.length&&!this.onBack||(e.up&&this._focus(this.navI-1),e.down&&this._focus(this.navI+1),(e.left||e.right)&&this.onLeftRight&&this.onLeftRight(e.left?-1:1),e.confirm&&this.nav[this.navI]&&this.nav[this.navI].click(),e.back&&this.onBack&&!(this.game.race&&this.game.race.paused&&e.pause)&&(It.back(),this.onBack()))}closeModal(){this.modal&&(this.modal.remove(),this.modal=null),this.nav=this._savedNav||[],this.onBack=this._savedBack||null}_modal(t,e){return this.modal&&this.modal.remove(),this._savedNav=this.nav,this._savedBack=this.onBack,this.modal=I("div",{class:"modal-wrap"},t),this.layer.appendChild(this.modal),this.onBack=e,this.modal}mainMenu(){this.game.garage.setMode("menu");let e=this._screen(),n=un[rt.data.garage.bike]||He[0],i=[this.btn("Carrera r\xE1pida",ce.race,()=>this.trackSelect("race"),"primary"),this.btn("Campeonato",ce.champ,()=>this.champHub()),this.btn("Contrarreloj",ce.trial,()=>this.trackSelect("trial")),this.btn("Paseo libre",ce.free,()=>this.trackSelect("free")),this.btn("Garaje",ce.garage,()=>this.garage()),this.btn("R\xE9cords",ce.records,()=>this.records()),this.btn("Ajustes",ce.settings,()=>this.settings(()=>this.mainMenu()))],r=rt.data.stats;e.append(I("div",{class:"menu-left"},I("div",{class:"logo"},I("div",{class:"l1"},"MOTO"),I("div",{class:"l2"},"M\xCDTICO"),I("div",{class:"l3"},"ULTRA RACING 3D")),...i),I("div",{class:"stats-strip"},I("span",{class:"pill c1"},`${r.races} carreras`),I("span",{class:"pill gold"},`${r.wins} victorias`),I("span",{class:"pill c2"},`${r.podiums} podios`)),I("div",{class:"menu-bike-tag"},I("div",{class:"k"},n.klass),I("div",{class:"n"},n.name)),I("div",{class:"menu-foot"},I("span",{},I("span",{class:"keycap"},"\u2191")," ",I("span",{class:"keycap"},"\u2193")," navegar"),I("span",{},I("span",{class:"keycap"},"ENTER")," aceptar"),I("span",{},I("span",{class:"keycap"},"ESC")," volver"),I("span",{class:"grow"}),I("span",{},"v1.0 \xB7 Motor 3D procedural \xB7 12 motos \xB7 6 circuitos"))),this._setNav(i),It.playMusic("menu")}garage(t=null){let e=this.game;e.garage.setMode("garage");let n=this._screen(),i=Math.max(0,He.findIndex(x=>x.id===rt.data.garage.bike)),r=rt.data.garage.livery[He[i].id]??0,a=I("div",{class:"garage-list glass"}),o=I("div",{class:"spec-panel glass"}),l=He.map((x,g)=>{let p=I("div",{class:"bike-item"},I("div",{class:"sw",style:{background:`linear-gradient(${x.liveries[0].base}, ${x.liveries[0].second})`}}),I("div",{},I("div",{class:"t"},x.name),I("div",{class:"c"},x.klass)));return p.addEventListener("click",()=>{It.select(),c(g)}),a.appendChild(p),p}),c=(x,g=!1)=>{i=(x+He.length)%He.length;let p=He[i];g||(r=rt.data.garage.livery[p.id]??0),l.forEach((y,_)=>y.classList.toggle("on",_===i)),l[i].scrollIntoView({block:"nearest",behavior:"smooth"}),e.garage.setBike(p,r);let v=e0(p);Mr(o).append(I("div",{class:"kicker"},p.klass),I("div",{class:"bn"},p.name),I("div",{class:"blurb"},p.blurb),...[["Velocidad",v.velocidad],["Aceleraci\xF3n",v.aceleracion],["Manejo",v.manejo],["Frenada",v.frenada],["Off-road",v.offroad]].map(([y,_])=>I("div",{class:"stat"},I("div",{class:"lab"},I("span",{},y),I("span",{},String(Math.round(_*10)))),I("div",{class:"bar"},I("i",{style:{width:`${_*100}%`}})))),I("div",{class:"specs-grid"},I("div",{},I("span",{},"Motor"),I("b",{},p.engine.label)),I("div",{},I("span",{},"Potencia"),I("b",{},`${p.engine.hp} CV`)),I("div",{},I("span",{},"Peso"),I("b",{},`${p.mass} kg`)),I("div",{},I("span",{},"V. m\xE1xima"),I("b",{},`${p.topKmh} km/h`)),I("div",{},I("span",{},"Inclinaci\xF3n"),I("b",{},`${p.maxLean}\xB0`)),I("div",{},I("span",{},"Cambio"),I("b",{},p.engine.electric?"Directo":`${p.engine.gears.length} vel.`))),I("div",{class:"kicker",style:{marginTop:"16px"}},`Decoraci\xF3n \xB7 ${p.liveries[r].name}`),I("div",{class:"liveries"},...p.liveries.map((y,_)=>{let S=I("div",{class:"livery"+(_===r?" on":""),title:y.name},I("i",{style:{background:`linear-gradient(135deg, ${y.base} 0 50%, ${y.second} 50% 80%, ${y.accent} 80%)`}}));return S.addEventListener("click",()=>{It.select(),r=_,c(i,!0)}),S})))},h=()=>{rt.data.garage.bike=He[i].id,rt.data.garage.livery[He[i].id]=r,rt.save(),t?t():this.mainMenu()},u=this.btn(t?"Elegir y continuar":"Elegir moto",ce.play,h,"primary"),d=this.btn("Volver",ce.back,()=>t?this.trackSelectBack():this.mainMenu(),"small"),f=I("div",{class:"arrow-btn",style:{left:"calc(min(300px, 40vw) + 34px)"}},"\u2039"),m=I("div",{class:"arrow-btn",style:{right:"calc(min(360px, 44vw) + 34px)"}},"\u203A");f.addEventListener("click",()=>{It.select(),c(i-1)}),m.addEventListener("click",()=>{It.select(),c(i+1)}),n.append(I("div",{class:"top-bar"},I("h2",{},"GARAJE"),I("span",{class:"pill c1"},"12 MOTOS"),I("span",{class:"grow"}),I("span",{class:"dim"},"Arrastra para girar \xB7 rueda para zoom")),a,o,f,m,I("div",{class:"bottom-bar"},d,u)),c(i),this._setNav([u,d]),this.onLeftRight=x=>{It.select(),c(i+x)},this.onBack=()=>t?this.trackSelectBack():this.mainMenu()}trackSelect(t){this._tsMode=t;let e=this.game;e.garage.setMode("garage");let n=this._screen(),i=rt.settings,r=Math.max(0,We.findIndex(x=>x.id===(this._lastTrack||"gp"))),a=I("div",{class:"tracks-grid"}),o=We.map((x,g)=>{let p=ma(x),v=rt.data.records[x.id],y=I("div",{class:"track-card"},p,I("div",{class:"badges"},I("span",{class:"pill"},s0[x.time]),I("span",{class:"pill c1"},r0[x.weather])),I("div",{class:"info"},I("div",{class:"nm"},x.name),I("div",{class:"meta"},`${(p.__len/1e3).toFixed(2)} km \xB7 ${x.place}`),I("div",{class:"meta"},v&&v.lap?`R\xE9cord: ${Ke(v.lap*1e3)}`:"Sin r\xE9cord")));return y.addEventListener("click",()=>{It.select(),c(g)}),a.appendChild(y),y}),l=I("div",{class:"race-opts glass"}),c=x=>{r=(x+We.length)%We.length,this._lastTrack=We[r].id,o.forEach((g,p)=>g.classList.toggle("on",p===r)),o[r].scrollIntoView({block:"nearest",behavior:"smooth"}),u()},h=(x,g,p,v)=>{let y=I("span",{class:"v"},v(g())),_=S=>{let M=I("button",{},S<0?"\u2212":"+");return M.addEventListener("click",()=>{It.click(),p(S),y.textContent=v(g())}),M};return I("div",{class:"opt"},I("span",{class:"lab"},x),I("div",{class:"stepper"},_(-1),y,_(1)))},u=()=>{let x=We[r],g=un[rt.data.garage.bike]||He[0];Mr(l),l.append(I("div",{class:"kicker"},t==="race"?"CARRERA R\xC1PIDA":t==="trial"?"CONTRARRELOJ":"PASEO LIBRE"),I("div",{class:"bn",style:{fontFamily:"var(--font-h)",fontWeight:900,fontSize:"24px",margin:"6px 0 4px"}},x.name),I("div",{class:"dim",style:{fontSize:"15px",marginBottom:"10px"}},x.blurb)),t!=="free"&&l.append(h("Vueltas",()=>i.laps,y=>{i.laps=$(i.laps+y,1,10),rt.save()},y=>String(y))),t==="race"&&(l.append(h("Rivales",()=>i.rivals,y=>{i.rivals=$(i.rivals+y,1,11),rt.save()},y=>String(y))),l.append(h("Dificultad",()=>Pi.findIndex(y=>y[0]===i.difficulty),y=>{let _=$(Pi.findIndex(S=>S[0]===i.difficulty)+y,0,2);i.difficulty=Pi[_][0],rt.save()},y=>Pi[y][1])));let p=I("div",{class:"opt"},I("span",{class:"lab"},"Moto"),I("span",{style:{fontFamily:"var(--font-h)",fontWeight:700}},g.short));l.append(p);let v=rt.data.ghosts[x.id];t==="trial"&&l.append(I("div",{class:"opt"},I("span",{class:"lab"},"Fantasma"),I("span",{},v?`${Ke(v.lap*1e3)} \xB7 ${(un[v.bike]||g).short}`:"Ninguno")))},d=this.btn("\xA1A correr!",ce.play,()=>{let x=We[r];e.startRace({mode:t,trackDef:x,bikeId:rt.data.garage.bike,livery:rt.data.garage.livery[rt.data.garage.bike]??0,laps:t==="free"?9999:i.laps,rivals:t==="race"?i.rivals:0,difficulty:i.difficulty})},"primary"),f=this.btn("Cambiar moto",ce.garage,()=>this.garage(()=>this.trackSelect(t)),"small"),m=this.btn("Volver",ce.back,()=>this.mainMenu(),"small");n.append(I("div",{class:"top-bar"},I("h2",{},"ELIGE CIRCUITO"),I("span",{class:"pill c1"},`${We.length} CIRCUITOS`)),a,l,I("div",{class:"bottom-bar"},m,f,d)),c(r),this._setNav([d,f,m]),this.onLeftRight=x=>{It.select(),c(r+x)},this.onBack=()=>this.mainMenu()}trackSelectBack(){this.trackSelect(this._tsMode||"race")}loading(t){let e=this._screen("loading"),n=I("i",{}),i=I("div",{class:"boot-msg"},"Cargando\u2026"),r=ma(t,460,460);return r.className="mini",e.append(r,I("div",{class:"kicker"},`${s0[t.time]} \xB7 ${r0[t.weather]}`),I("div",{class:"tn"},t.name),I("div",{class:"tp"},t.place),I("div",{class:"tip"},"\u{1F4A1} "+a0[Math.floor(Math.random()*a0.length)]),I("div",{class:"boot-bar"},n),i),e.style.background="radial-gradient(ellipse at 70% 30%, #10203c, #05060a 70%)",(a,o)=>{n.style.width=`${Math.round(a*100)}%`,o&&(i.textContent=o)}}hideScreens(){if(this.current){let t=this.current;t.classList.remove("show"),setTimeout(()=>t.remove(),350),this.current=null}this.nav=[],this.onBack=null,this.onLeftRight=null}pauseMenu(t){let e=[this.btn("Continuar",ce.play,()=>t.togglePause(),"primary"),this.btn("Reiniciar",ce.retry,()=>{this.closeModal(),this.game.restartRace()}),this.btn("Cambiar c\xE1mara",ce.cam,()=>{t.cam.next(),rt.settings.camera=t.cam.mode,t.hud.camName(["PERSECUCI\xD3N","LEJANA","A BORDO","RUEDA"][t.cam.mode])}),this.btn("Ajustes",ce.settings,()=>{this.closeModal(),this.settings(()=>{this.hideScreens(),this.pauseMenu(t)},!0)}),this.btn("Salir al men\xFA",ce.exit,()=>{this.closeModal(),this.game.exitRace()})],n=I("div",{class:"modal glass"},I("h2",{},"PAUSA"),I("div",{class:"dim",style:{marginBottom:"14px"}},`${t.track.def.name} \xB7 ${Ke(t.time*1e3)}`),I("div",{class:"btns"},...e),I("div",{class:"dim",style:{marginTop:"16px",fontSize:"13px"}},this._controlsHint()));this._modal(n,()=>t.togglePause()),this._setNav(e)}_controlsHint(){return I("div",{},"W/\u2191 gas \xB7 S/\u2193 freno \xB7 A/D inclinar \xB7 ESPACIO freno trasero \xB7 SHIFT nitro \xB7 X caballito \xB7 C c\xE1mara \xB7 R volver a pista")}results(t,e,n){let i=this._screen("results"),r=e.find(h=>h.player),a=r.pos<=3?`p${r.pos}`:"",o=I("table",{class:"res-table"},...e.map(h=>I("tr",{class:h.player?"me":""},I("td",{class:`pos p${h.pos}`},String(h.pos)),I("td",{},I("span",{style:{display:"inline-block",width:"8px",height:"16px",background:h.color,borderRadius:"2px",marginRight:"8px",verticalAlign:"middle"}}),h.name,h.player?"  (T\xDA)":""),I("td",{class:"t"},h.pos===1?Ke(h.time*1e3):`+${(h.time-e[0].time).toFixed(3)}`),I("td",{class:"t"},h.best?Ke(h.best*1e3):"\u2014"),t.mode!=="trial"?I("td",{class:"pts"},`+${h.points}`):null))),l=[];n&&n.next?l.push(this.btn("Siguiente ronda",ce.play,()=>this.game.champNext(),"primary")):n&&n.done?l.push(this.btn("Clasificaci\xF3n final",ce.champ,()=>this.game.champFinal(),"primary")):l.push(this.btn("Continuar",ce.play,()=>this.game.exitRace(),"primary")),n||l.push(this.btn("Revancha",ce.retry,()=>this.game.restartRace())),l.push(this.btn("Ver repetici\xF3n",ce.replay,()=>this.game.watchReplay())),n&&l.push(this.btn("Salir",ce.exit,()=>this.game.exitRace()));let c=Math.min(...e.filter(h=>h.best).map(h=>h.best));i.append(I("div",{class:"results"},I("div",{class:"res-panel glass"},I("div",{class:"kicker"},t.mode==="trial"?"CONTRARRELOJ":t.mode==="champ"?`CAMPEONATO \xB7 RONDA ${n?.round??""}`:"RESULTADO FINAL"),I("div",{class:"row"},I("div",{class:"big-place "+a},t.mode==="trial"?Ke((r.best||0)*1e3):`${r.pos}\xBA`),I("div",{style:{marginLeft:"16px"}},I("div",{style:{fontFamily:"var(--font-h)",fontSize:"20px",fontWeight:900}},t.track.def.name),I("div",{class:"dim"},`Tu mejor vuelta: ${Ke((r.best||0)*1e3)}`),I("div",{class:"dim"},`Vuelta r\xE1pida: ${isFinite(c)?Ke(c*1e3):"\u2014"}`),I("div",{class:"dim"},`Vel. punta: ${Math.round(t.player.phys.topSpeedSeen*3.6)} km/h`))),t.mode==="trial"?null:o,I("div",{class:"btns",style:{display:"flex",gap:"10px",flexWrap:"wrap",marginTop:"18px"}},...l)))),this._setNav(l),this.onBack=null}replayOverlay(){let t=this._screen(),e=this.btn("Salir de la repetici\xF3n",ce.back,()=>this.game.endReplay(),"small"),n=this.btn("Cambiar c\xE1mara",ce.cam,()=>this.game.race.cam.next(),"small");t.append(I("div",{class:"replay-badge"},"\u25CF REPETICI\xD3N"),I("div",{class:"bottom-bar"},n,e)),this._setNav([e,n]),this.onBack=()=>this.game.endReplay()}champHub(){let t=this.game;t.garage.setMode("garage");let e=this._screen(),n=rt.data.champ,i=I("div",{class:"spec-panel glass",style:{width:"min(560px, 92vw)",left:"auto"}}),r=[];if(!n||n.done){i.append(I("div",{class:"kicker"},"CAMPEONATO M\xCDTICO"),I("div",{class:"bn"},"6 RONDAS"),I("div",{class:"blurb"},"Recorre los seis circuitos contra los 11 rivales. Puntos estilo Gran Premio: 25-20-16-13-11\u2026 El que m\xE1s sume se corona campe\xF3n."),I("div",{class:"rounds"},...We.map((h,u)=>I("span",{class:"round"},`${u+1}. ${h.name}`))));let o=I("div",{class:"opt"}),l=rt.settings,c=()=>{Mr(o).append(I("span",{class:"lab"},"Dificultad"),I("div",{class:"stepper"},(()=>{let h=I("button",{},"\u2212");return h.onclick=()=>{l.difficulty=Pi[$(Pi.findIndex(u=>u[0]===l.difficulty)-1,0,2)][0],It.click(),c()},h})(),I("span",{class:"v"},Pi.find(h=>h[0]===l.difficulty)[1]),(()=>{let h=I("button",{},"+");return h.onclick=()=>{l.difficulty=Pi[$(Pi.findIndex(u=>u[0]===l.difficulty)+1,0,2)][0],It.click(),c()},h})()))};c(),i.append(o,I("div",{class:"opt"},I("span",{class:"lab"},"Moto"),I("span",{},(un[rt.data.garage.bike]||He[0]).name))),r.push(this.btn("Empezar campeonato",ce.play,()=>t.champStart(),"primary")),r.push(this.btn("Cambiar moto",ce.garage,()=>this.garage(()=>this.champHub()),"small"))}else i.append(I("div",{class:"kicker"},"CAMPEONATO EN CURSO"),I("div",{class:"bn"},`RONDA ${n.round+1} / ${We.length}`),I("div",{class:"rounds"},...We.map((o,l)=>I("span",{class:"round "+(l<n.round?"done":l===n.round?"cur":"")},`${l+1}. ${o.name}`))),this._standingsTable(n)),r.push(this.btn(`Correr: ${We[n.round].name}`,ce.play,()=>t.champRace(),"primary")),r.push(this.btn("Abandonar campeonato",ce.exit,()=>{rt.data.champ=null,rt.save(),this.champHub()},"small"));let a=this.btn("Volver",ce.back,()=>this.mainMenu(),"small");r.push(a),i.append(I("div",{class:"btns",style:{display:"flex",flexDirection:"column",gap:"10px",marginTop:"18px"}},...r)),e.append(I("div",{class:"top-bar"},I("h2",{},"CAMPEONATO")),i),this._setNav(r),this.onBack=()=>this.mainMenu()}_standingsTable(t){let e=Object.entries(t.points).sort((n,i)=>i[1]-n[1]);return I("table",{class:"champ-table"},...e.map(([n,i],r)=>{let a=un[n];return I("tr",{class:n===t.bike?"me":""},I("td",{style:{fontFamily:"var(--font-h)",width:"30px"}},String(r+1)),I("td",{},a?a.name:n,n===t.bike?" (T\xDA)":""),I("td",{style:{textAlign:"right",fontFamily:"var(--font-h)",color:"var(--c1)"}},String(i)))}))}champFinal(t){let e=this._screen("results"),i=Object.entries(t.points).sort((a,o)=>o[1]-a[1]).findIndex(([a])=>a===t.bike)+1,r=[this.btn("Volver al men\xFA",ce.back,()=>this.game.exitRace(),"primary")];e.append(I("div",{class:"results"},I("div",{class:"res-panel glass"},I("div",{class:"kicker"},"CAMPEONATO FINALIZADO"),I("div",{class:"big-place "+(i<=3?`p${i}`:"")},i===1?"\xA1CAMPE\xD3N!":`${i}\xBA FINAL`),this._standingsTable(t),I("div",{class:"btns",style:{marginTop:"18px"}},...r)))),this._setNav(r)}records(){let t=this._screen(),e=We.map(a=>{let o=rt.data.records[a.id]||{},l=rt.data.ghosts[a.id];return I("tr",{},I("td",{style:{fontFamily:"var(--font-h)"}},a.name),I("td",{class:"t"},o.lap?Ke(o.lap*1e3):"\u2014"),I("td",{},o.lapBike&&un[o.lapBike]?.short||""),I("td",{class:"t"},o.race?Ke(o.race*1e3):"\u2014"),I("td",{},l?"\u{1F47B}":""))}),n=rt.data.stats,i=this.btn("Volver",ce.back,()=>this.mainMenu(),"small"),r=this.btn("Borrar r\xE9cords","\u2715",()=>{rt.data.records={},rt.data.ghosts={},rt.save(),this.records()},"small");t.append(I("div",{class:"top-bar"},I("h2",{},"R\xC9CORDS")),I("div",{class:"spec-panel glass",style:{left:"18px",right:"auto",width:"min(720px, 94vw)"}},I("table",{class:"res-table"},I("tr",{},I("td",{class:"dim"},"CIRCUITO"),I("td",{class:"dim t"},"VUELTA"),I("td",{class:"dim"},"MOTO"),I("td",{class:"dim t"},"CARRERA"),I("td",{})),...e),I("div",{class:"specs-grid",style:{gridTemplateColumns:"repeat(3, 1fr)",marginTop:"20px"}},I("div",{},I("span",{},"Carreras"),I("b",{},String(n.races))),I("div",{},I("span",{},"Victorias"),I("b",{},String(n.wins))),I("div",{},I("span",{},"Podios"),I("b",{},String(n.podiums))),I("div",{},I("span",{},"Ca\xEDdas"),I("b",{},String(n.crashes))),I("div",{},I("span",{},"Km recorridos"),I("b",{},(n.km||0).toFixed(1))),I("div",{},I("span",{},"Punta m\xE1x."),I("b",{},`${Math.round(n.topSpeed||0)} km/h`)))),I("div",{class:"bottom-bar"},r,i)),this._setNav([i,r]),this.onBack=()=>this.mainMenu()}settings(t,e=!1){let n=this._screen(),i=rt.settings,r="graficos",a=I("div",{}),o=I("div",{class:"tabs"}),l=(x,g)=>I("div",{class:"opt"},I("span",{class:"lab"},x),g),c=(x,g)=>{let p=I("div",{class:"toggle"+(i[x]?" on":"")});return p.addEventListener("click",()=>{i[x]=!i[x],p.classList.toggle("on",i[x]),It.click(),rt.save(),g&&g()}),p},h=(x,g)=>{let p=I("input",{type:"range",class:"slider",min:"0",max:"1",step:"0.05",value:String(i[x])});return p.addEventListener("input",()=>{i[x]=+p.value,rt.save(),g&&g()}),p},u=(x,g,p)=>{let v=I("span",{class:"v"}),y=()=>{v.textContent=g.find(S=>S[0]===i[x])?.[1]??String(i[x])},_=S=>{let M=I("button",{},S<0?"\u2039":"\u203A");return M.addEventListener("click",()=>{let E=g.findIndex(A=>A[0]===i[x]);i[x]=g[(E+S+g.length)%g.length][0],y(),It.click(),rt.save(),p&&p()}),M};return y(),I("div",{class:"stepper"},_(-1),v,_(1))},d=()=>{Mr(o);for(let[x,g]of[["graficos","GR\xC1FICOS"],["sonido","SONIDO"],["juego","JUEGO"],["controles","CONTROLES"]]){let p=I("div",{class:"tab"+(r===x?" on":"")},g);p.addEventListener("click",()=>{r=x,It.click(),d()}),o.appendChild(p)}if(Mr(a),r==="graficos")a.append(l("Calidad",u("quality",Object.entries(Yo).map(([x,g])=>[x,g.label]),()=>{this.game.applyQuality()})),l("Escala de resoluci\xF3n",u("resScale",[[.5,"50%"],[.75,"75%"],[1,"100%"],[1.25,"125%"]],()=>this.game.engine.resize())),l("Desenfoque de velocidad",c("motionBlur")),l("Mostrar FPS",c("showFps")),I("div",{class:"dim",style:{fontSize:"13px",marginTop:"10px"}},e?"Algunos cambios de calidad se aplican en la pr\xF3xima carrera.":"BAJO para equipos modestos \xB7 ULTRA para tarjetas gr\xE1ficas potentes."));else if(r==="sonido")a.append(l("Volumen general",h("masterVol",()=>It.applyVolumes())),l("M\xFAsica",h("musicVol",()=>It.applyVolumes())),l("Efectos",h("sfxVol",()=>It.applyVolumes())));else if(r==="juego")a.append(l("Unidades",u("units",[["kmh","KM/H"],["mph","MPH"]])),l("Cambio",u("transmission",[["auto","AUTOM\xC1TICO"],["manual","MANUAL"]])),l("Ayudas de pilotaje",c("assist")),l("Vibraci\xF3n",c("vibration")),l("Controles t\xE1ctiles",c("touch")),l("C\xE1mara inicial",u("camera",[[0,"PERSECUCI\xD3N"],[1,"LEJANA"],[2,"A BORDO"],[3,"RUEDA"]])));else{let x=[["Acelerar","W / \u2191","RT"],["Frenar","S / \u2193","LT"],["Inclinar","A D / \u2190 \u2192","Stick izq."],["Freno trasero / derrape","ESPACIO","B"],["Nitro","SHIFT / N","A"],["Caballito","X","X"],["Subir / bajar marcha","E / Q","RB / LB"],["C\xE1mara","C","Y"],["Mirar atr\xE1s","B","L3"],["Volver a pista","R","SELECT"],["Pausa","ESC / P","START"]];a.append(I("table",{class:"controls-table"},I("tr",{},I("td",{class:"dim"},"ACCI\xD3N"),I("td",{class:"dim"},"TECLADO"),I("td",{class:"dim"},"MANDO")),...x.map(([g,p,v])=>I("tr",{},I("td",{},g),I("td",{},I("span",{class:"keycap"},p)),I("td",{},I("span",{class:"keycap"},v))))))}};d();let f=this.btn("Volver",ce.back,()=>t(),"small"),m=this.btn("Restablecer todo","\u2715",()=>{confirm("\xBFBorrar ajustes, r\xE9cords y progreso?")&&(rt.reset(),this.game.applyQuality(),this.settings(t,e))},"small");n.append(I("div",{class:"modal-wrap"},I("div",{class:"modal glass",style:{width:"min(640px, 94vw)"}},I("h2",{},"AJUSTES"),o,a,I("div",{class:"row",style:{marginTop:"20px",justifyContent:"flex-end"}},e?null:m,f)))),this._setNav([f]),this.onBack=t}error(t){let e=I("div",{class:"error-box glass"},I("h2",{},"Algo sali\xF3 mal"),I("div",{class:"dim"},String(t&&t.message||t)),I("div",{style:{marginTop:"14px"}},I("button",{class:"btn small",onclick:()=>location.reload()},I("span",{},"Recargar"))));this.root.appendChild(e)}};var o0={gp:{ground:"grass",runoffGround:"gravel",barrier:"tirewall",fence:!0,grandstands:!0,road:{base:[58,60,64],edge:"#f4f4f4",centerDash:!1,rubber:!0,edgeRed:!1},terrain:{amp:18,scale:420,base:-2,ridged:!1,color:8034896,rockColor:9076848},far:{height:140,color:6978152,snow:!1},trees:{pine:.25,broad:.75,palm:0,density:1},rocks:.2,lamps:!1,billboards:!0,buildings:!1,water:null},coast:{ground:"dryGrass",runoffGround:"sand",barrier:"armco",fence:!1,road:{base:[62,60,60],edge:"#f2f2f2",centerDash:!0,centerColor:"#f4c400",rubber:!1},terrain:{amp:30,scale:380,base:6,ridged:!1,color:10522720,rockColor:10123866,ocean:{dir:[-1,.25],start:-260,drop:.35}},far:{height:180,color:8022640,snow:!1},trees:{pine:.15,broad:.25,palm:.6,density:.7},rocks:.5,lamps:!1,billboards:!0,buildings:"villas",water:{level:-1.5,color:670298}},city:{ground:"asphaltDark",runoffGround:"asphaltDark",barrier:"concrete",neonWalls:!0,fence:!0,road:{base:[44,46,50],edge:"#ffffff",centerDash:!0,centerColor:"#ffffff",rubber:!1,patches:!0},terrain:{amp:0,scale:400,base:-.6,ridged:!1,color:3158582,rockColor:3158582,flat:!0},far:{height:0,color:1052696,skyline:!0},trees:{pine:0,broad:0,palm:0,density:0},rocks:0,lamps:!0,billboards:!0,buildings:"city",water:null},desert:{ground:"sand",runoffGround:"sand",barrier:"tirewall",fence:!1,road:{base:[70,62,58],edge:"#f4f4f4",centerDash:!0,centerColor:"#f4f4f4",rubber:!1},terrain:{amp:55,scale:600,base:-4,ridged:!0,mesa:!0,color:12613712,rockColor:10506288},far:{height:260,color:12089946,snow:!1,mesa:!0},trees:{pine:0,broad:0,palm:0,cactus:1,density:.5},rocks:1.2,lamps:!1,billboards:!0,buildings:!1,water:null},alpine:{ground:"snow",runoffGround:"snow",barrier:"armco",fence:!1,road:{base:[54,56,60],edge:"#f4f4f4",centerDash:!0,centerColor:"#f4f4f4",rubber:!1},terrain:{amp:120,scale:520,base:0,ridged:!0,color:15265526,rockColor:6975096,followTrack:!0},far:{height:700,color:13161700,snow:!0},trees:{pine:1,broad:0,palm:0,density:1.2,snowy:!0},rocks:.6,lamps:!1,billboards:!1,buildings:"chalets",water:null},forest:{ground:"forest",runoffGround:"grass",barrier:"armco",fence:!1,road:{base:[50,52,56],edge:"#f0f0f0",centerDash:!0,centerColor:"#f0f0f0",rubber:!1},terrain:{amp:40,scale:360,base:0,ridged:!1,color:4876858,rockColor:5921360},far:{height:220,color:2767412,snow:!1},trees:{pine:.6,broad:.4,palm:0,density:2},rocks:.5,lamps:!1,billboards:!1,buildings:!1,water:null}},yu={day:{sunElev:52,sunAzim:135,turbidity:3,rayleigh:2.2,mie:.004,exposure:.5,bloom:[.22,.4,1.4],sun:3.2,sunColor:16774374,hemi:.9,hemiSky:12375295,hemiGround:6969920,fog:[12110044,45e-5],env:.9},sunset:{sunElev:4,sunAzim:250,turbidity:9,rayleigh:2.6,mie:.012,exposure:.6,bloom:[.3,.5,1.2],sun:2.6,sunColor:16752736,hemi:.55,hemiSky:16758928,hemiGround:4206656,fog:[14195320,8e-4],env:.8},dusk:{sunElev:6,sunAzim:200,turbidity:14,rayleigh:.8,mie:.02,exposure:.68,bloom:[.45,.5,.85],sun:1.1,sunColor:11056336,hemi:1.1,hemiSky:5925512,hemiGround:1712152,fog:[3818576,.0026],env:.45,overcast:!0},night:{sunElev:-20,sunAzim:60,exposure:.85,bloom:[.5,.45,.8],sun:.35,sunColor:9089279,hemi:.35,hemiSky:2767466,hemiGround:657938,fog:[658456,.0016],env:.35,night:!0}};var es=20,al=class{constructor(t){this.def=t,this.theme=o0[t.theme];let e=sl(t,2);this.c=e,this.N=e.N,this.L=e.L,this.ds=e.ds,this.W=t.width,this.halfW=t.width/2,this.runoff=t.runoff,this.barrierD=this.halfW+this.runoff,this.wet=t.weather==="wet"||t.weather==="storm",this._buildGrid(),this.computeRacingLine()}_buildGrid(){let{x:t,z:e,N:n}=this.c,i=1/0,r=1/0,a=-1/0,o=-1/0;for(let l=0;l<n;l++)i=Math.min(i,t[l]),a=Math.max(a,t[l]),r=Math.min(r,e[l]),o=Math.max(o,e[l]);this.bounds={minX:i,minZ:r,maxX:a,maxZ:o,cx:(i+a)/2,cz:(r+o)/2,size:Math.max(a-i,o-r)},this.gMinX=i-es*4,this.gMinZ=r-es*4,this.gCols=Math.ceil((a-i)/es)+9,this.gRows=Math.ceil((o-r)/es)+9,this.grid=new Array(this.gCols*this.gRows);for(let l=0;l<n;l++){let c=Math.floor((t[l]-this.gMinX)/es),u=Math.floor((e[l]-this.gMinZ)/es)*this.gCols+c;(this.grid[u]||(this.grid[u]=[])).push(l)}}nearestIndex(t,e){let{x:n,z:i}=this.c,r=Math.floor((t-this.gMinX)/es),a=Math.floor((e-this.gMinZ)/es),o=-1,l=1/0;for(let c=1;c<=12&&o<0;c+=2)for(let h=a-c;h<=a+c;h++)if(!(h<0||h>=this.gRows))for(let u=r-c;u<=r+c;u++){if(u<0||u>=this.gCols)continue;let d=this.grid[h*this.gCols+u];if(d)for(let f of d){let m=(n[f]-t)**2+(i[f]-e)**2;m<l&&(l=m,o=f)}}if(o<0)for(let c=0;c<this.N;c++){let h=(n[c]-t)**2+(i[c]-e)**2;h<l&&(l=h,o=c)}return o}wrap(t){let e=this.N;return(t%e+e)%e}wrapS(t){let e=this.L;return(t%e+e)%e}project(t,e,n=-1,i={}){let{x:r,z:a,y:o,tx:l,tz:c,bank:h,kappaSmooth:u,grade:d}=this.c,f=this.N,m=-1;if(n>=0){let F=n,q=1/0;for(let V=-12;V<=12;V++){let J=(n+V+f)%f,G=(r[J]-t)**2+(a[J]-e)**2;G<q&&(q=G,F=J)}q<(this.barrierD+25)**2&&(m=F)}m<0&&(m=this.nearestIndex(t,e));let x=m,g=0,p=1/0;for(let F of[(m-1+f)%f,m]){let q=(F+1)%f,V=r[q]-r[F],J=a[q]-a[F],G=V*V+J*J||1,nt=((t-r[F])*V+(e-a[F])*J)/G;nt=nt<0?0:nt>1?1:nt;let ht=r[F]+V*nt,Et=a[F]+J*nt,Ot=(t-ht)**2+(e-Et)**2;Ot<p&&(p=Ot,x=F,g=nt)}let v=(x+1)%f,y=r[x]+(r[v]-r[x])*g,_=a[x]+(a[v]-a[x])*g,S=l[x]+(l[v]-l[x])*g,M=c[x]+(c[v]-c[x])*g,E=Math.hypot(S,M)||1;S/=E,M/=E;let A=-M,w=S,b=(t-y)*A+(e-_)*w,P=h[x]+(h[v]-h[x])*g,D=o[x]+(o[v]-o[x])*g;i.i=x,i.t=g,i.s=(x+g)*this.ds,i.d=b,i.cx=y,i.cz=_,i.cy=D,i.yBase=D+b*Math.tan(P),i.y=i.yBase+this.curbHeight(x,b),i.tx=S,i.tz=M,i.rx=A,i.rz=w,i.bank=P,i.kappa=u[x],i.grade=d[x]+(d[v]-d[x])*g;let U=Math.abs(b);return i.onRoad=U<=this.halfW,i.onCurb=this.curbMask?this.curbAt(x,b):!1,i.offRoad=U>this.halfW+(i.onCurb?1.2:0),i.barrier=U>=this.barrierD-.35,i}pointAt(t,e=0,n={}){let{x:i,z:r,y:a,tx:o,tz:l,bank:c}=this.c;t=this.wrapS(t);let h=t/this.ds,u=Math.floor(h)%this.N,d=(u+1)%this.N,f=h-Math.floor(h),m=o[u]+(o[d]-o[u])*f,x=l[u]+(l[d]-l[u])*f,g=Math.hypot(m,x)||1;m/=g,x/=g;let p=c[u]+(c[d]-c[u])*f;return n.x=i[u]+(i[d]-i[u])*f-x*e,n.z=r[u]+(r[d]-r[u])*f+m*e,n.y=a[u]+(a[d]-a[u])*f+e*Math.tan(p),n.tx=m,n.tz=x,n.heading=Math.atan2(m,x),n.i=u,n.bank=p,n}curbHeight(t,e){if(!this.curbMask)return 0;let n=Math.abs(e);if(n<this.halfW-.2||n>this.halfW+1.2||!this.curbAt(t,e))return 0;let i=(n-(this.halfW-.2))/1.4;return Math.sin(i*Math.PI)*.045}curbAt(t,e){let n=this.curbMask[t];return n?e<0?(n&1)!==0:(n&2)!==0:!1}computeRacingLine(){let{x:t,z:e,rx:n,rz:i,N:r}={...this.c,N:this.N},a=this.halfW-1.3,o=new Float32Array(r),l=new Float32Array(r),c=new Float32Array(r),h=[[24,120],[12,160],[6,160],[3,80]];for(let[d,f]of h)for(let m=0;m<f;m++){for(let x=0;x<r;x++)l[x]=t[x]+n[x]*o[x],c[x]=e[x]+i[x]*o[x];for(let x=0;x<r;x++){let g=(x-d+r)%r,p=(x+d)%r,v=(l[g]+l[p])/2,y=(c[g]+c[p])/2,_=(v-t[x])*n[x]+(y-e[x])*i[x];o[x]=$(o[x]+(_-o[x])*.5,-a,a)}}this.lineD=pa(o,2);let u=new Float32Array(r);for(let d=0;d<r;d++)l[d]=t[d]+n[d]*this.lineD[d],c[d]=e[d]+i[d]*this.lineD[d];for(let d=0;d<r;d++){let f=(d-3+r)%r,m=(d+3)%r,x=Math.atan2(l[d]-l[f],c[d]-c[f]),p=Math.atan2(l[m]-l[d],c[m]-c[d])-x;for(;p>Math.PI;)p-=Math.PI*2;for(;p<-Math.PI;)p+=Math.PI*2;let v=Math.hypot(l[m]-l[d],c[m]-c[d])+Math.hypot(l[d]-l[f],c[d]-c[f]);u[d]=p/(v/2||1)}this.lineK=pa(u,3),this.lineX=new Float32Array(r),this.lineZ=new Float32Array(r),this.lineH=new Float32Array(r);for(let d=0;d<r;d++)this.lineX[d]=l[d],this.lineZ[d]=c[d];for(let d=0;d<r;d++){let f=(d-1+r)%r,m=(d+1)%r;this.lineH[d]=Math.atan2(l[m]-l[f],c[m]-c[f])}}speedProfile(t,e,n){let i=this.N,r=this.ds,a=new Float32Array(i);for(let o=0;o<i;o++){let l=Math.abs(this.lineK[o]);a[o]=l>1e-5?Math.min(n,Math.sqrt(t/l)):n}for(let o=0;o<2;o++)for(let l=i-1;l>=0;l--){let c=(l+1)%i,h=Math.sqrt(a[c]*a[c]+2*e*r);a[l]>h&&(a[l]=h)}return a}build(t){let e=new Qt;e.name="track",this._computeCurbs();let n=this.theme,i=ru({seed:this.def.id.length*7,size:t.density>.8?512:256,base:n.road.base,edge:n.road.edge,centerDash:n.road.centerDash,centerColor:n.road.centerColor,wet:this.wet,rubber:n.road.rubber,patches:n.road.patches}),r=Math.max(1,Math.round(this.L/(this.W*2)));this.roadMat=new at({map:i.map,normalMap:i.normalMap,roughnessMap:i.roughnessMap,roughness:this.wet?.55:1,metalness:this.wet?.15:0,normalScale:new tt(.6,.6),envMapIntensity:this.wet?1.6:.6,color:this.wet?12106948:16777215});let a=this.ribbon([-this.halfW,this.halfW],8,(d,f)=>0,(d,f)=>[f,d/this.N*r]),o=new it(a,this.roadMat);o.receiveShadow=!0,o.name="road",e.add(o);let l=ra(n.runoffGround||"grass",11),c=new at({map:l.map,normalMap:l.normalMap,roughnessMap:l.roughnessMap,color:16777215});for(let d of[-1,1]){let f=d*this.halfW,m=d*(this.barrierD+2.5),x=this.ribbon(d<0?[m,f]:[f,m],4,()=>-.012,null,null,!0),g=new it(x,c);g.receiveShadow=!0,e.add(g)}let h=Ef(),u=new at({map:h,roughness:.6});for(let d of this.curbRuns){let f=d.side,m=f*(this.halfW-.2),x=f*(this.halfW+1.2),g=this.ribbon(f<0?[x,m]:[m,x],6,(v,y)=>{let _=(Math.abs(y)-(this.halfW-.2))/1.4;return Math.sin($(_,0,1)*Math.PI)*.045+.004},(v,y)=>[f<0?1-y:y,v*this.ds/2.4],[d.i0,d.i1]),p=new it(g,u);p.receiveShadow=!0,e.add(p)}return e.add(this._buildBarriers(t)),e.add(this._buildStart()),this.group=e,e}_computeCurbs(){let t=this.N,e=this.c.kappaSmooth,n=1/160,i=new Uint8Array(t),r=Math.round(14/this.ds),a=Math.round(26/this.ds);for(let l=0;l<t;l++){if(Math.abs(e[l])<n)continue;let c=e[l]>0?1:2,h=c===1?2:1;for(let u=-r;u<=r;u++)i[(l+u+t)%t]|=c;for(let u=-r+a;u<=r+a;u++)i[(l+u+t)%t]|=h}for(let l=-30;l<=30;l++)i[(l+t)%t]=0;this.curbMask=i;let o=[];for(let[l,c]of[[1,-1],[2,1]]){let h=-1,u=0;for(;u<t&&i[u]&l;)u++;for(let d=0;d<=t;d++){let f=(u+d)%t,m=(i[f]&l)!==0&&d<t;m&&h<0&&(h=u+d),!m&&h>=0&&(o.push({side:c,i0:h,i1:u+d}),h=-1)}}this.curbRuns=o}ribbon([t,e],n,i,r,a=null,o=!1){let{x:l,y:c,z:h,rx:u,rz:d,bank:f}=this.c,m=this.N,x=a?a[0]:0,p=(a?a[1]:m)-x+1,v=new Float32Array(p*(n+1)*3),y=new Float32Array(p*(n+1)*2),_=0,S=0;for(let b=0;b<p;b++){let P=x+b,D=(P%m+m)%m,U=Math.tan(f[D]);for(let F=0;F<=n;F++){let q=F/n,V=t+(e-t)*q,J=l[D]+u[D]*V,G=h[D]+d[D]*V;if(v[_++]=J,v[_++]=c[D]+V*U+(i?i(D,V):0),v[_++]=G,o)y[S++]=J/8,y[S++]=G/8;else{let[nt,ht]=r?r(P,q):[q,P/m];y[S++]=nt,y[S++]=ht}}}let M=[];for(let b=0;b<p-1;b++)for(let P=0;P<n;P++){let D=b*(n+1)+P,U=D+1,F=D+n+1,q=F+1;M.push(D,F,U,U,F,q)}let E=new Gt;E.setAttribute("position",new Vt(v,3)),E.setAttribute("uv",new Vt(y,2)),E.setIndex(M),E.computeVertexNormals();let A=E.attributes.normal,w=0;for(let b=0;b<A.count;b++)w+=A.getY(b);if(w<0){for(let b=0;b<M.length;b+=3){let P=M[b+1];M[b+1]=M[b+2],M[b+2]=P}E.setIndex(M),E.computeVertexNormals()}return E.computeBoundingSphere(),E}extrude(t,e=4,n=null,i=1){let{x:r,y:a,z:o,rx:l,rz:c,bank:h}=this.c,u=this.N,d=n?n[0]:0,f=n?n[1]:u,m=[],x=[],g=[],p=[];for(let y of t){let _=m.length/3,S=0;for(let M=d;M<=f;M+=i){let E=(M%u+u)%u,A=Math.tan(h[E]);for(let[w,b]of[[0,y.a],[1,y.b]]){let P=b[0];m.push(r[E]+l[E]*P,a[E]+P*A+b[1],o[E]+c[E]*P);let D=l[E]*y.n[0],U=y.n[1],F=c[E]*y.n[0],q=Math.hypot(D,U,F)||1;x.push(D/q,U/q,F/q),g.push(y.u?y.u[w]:w,M*this.ds/e)}S++}for(let M=0;M<S-1;M++){let E=_+M*2,A=E+1,w=E+2,b=E+3,P=new C(m[E*3],m[E*3+1],m[E*3+2]),D=new C(m[A*3],m[A*3+1],m[A*3+2]),U=new C(m[w*3],m[w*3+1],m[w*3+2]),F=new C().subVectors(D,P).cross(new C().subVectors(U,P)),q=new C(x[E*3],x[E*3+1],x[E*3+2]);F.dot(q)>=0?p.push(E,A,w,A,b,w):p.push(E,w,A,A,w,b)}}let v=new Gt;return v.setAttribute("position",new wt(m,3)),v.setAttribute("normal",new wt(x,3)),v.setAttribute("uv",new wt(g,2)),v.setIndex(p),v.computeBoundingSphere(),v}_buildBarriers(t){let e=this.theme,n=new Qt,i=this.barrierD,r=(a,o,l=!0)=>{let c=new it(a,o);return c.castShadow=l&&t.shadows>0,c.receiveShadow=!0,n.add(c),c};for(let a of[-1,1]){let o=a*i;if(e.barrier==="concrete"){let c=Tf(e.neonWalls?"#202020":"#c8102e",3),h=new at({map:c,roughness:.85});if(r(this.extrude([{a:[o,0],b:[o,1.15],n:[-a,0]},{a:[o,1.15],b:[o+a*.55,1.15],n:[0,1]},{a:[o+a*.55,1.15],b:[o+a*.55,0],n:[a,0]}],4),h),e.neonWalls){let u=a<0?58879:16722902,d=new at({color:0,emissive:u,emissiveIntensity:4});r(this.extrude([{a:[o-a*.01,.9],b:[o-a*.01,1],n:[-a,0]}],4),d,!1),r(this.extrude([{a:[o-a*.01,.12],b:[o-a*.01,.16],n:[-a,0]}],4),d,!1)}}else if(e.barrier==="tirewall"){let l=Af(),c=new at({map:l,roughness:.9});r(this.extrude([{a:[o,0],b:[o,.95],n:[-a,0]},{a:[o,.95],b:[o+a*.9,.95],n:[0,1],u:[0,.3]},{a:[o+a*.9,.95],b:[o+a*.9,0],n:[a,0]}],2.6),c)}else{let l=Rf(),c=new at({map:l,metalness:.85,roughness:.35,side:xe});r(this.extrude([{a:[o,.42],b:[o-a*.06,.55],n:[-a,-.4]},{a:[o-a*.06,.55],b:[o-a*.06,.7],n:[-a,0]},{a:[o-a*.06,.7],b:[o,.82],n:[-a,.4]}],4),c);let h=Math.floor(this.L/4),u=new jt(.12,.85,.12);u.translate(0,.42,0);let d=new Yn(u,new at({color:9080982,metalness:.7,roughness:.5}),h),f=new Lt,m={};for(let x=0;x<h;x++)this.pointAt(x*4,o+a*.12,m),f.makeRotationY(m.heading),f.setPosition(m.x,m.y,m.z),d.setMatrixAt(x,f);d.castShadow=t.shadows>0,n.add(d)}if(e.fence){let l=le(64,64),c=l.g;c.clearRect(0,0,64,64),c.strokeStyle="rgba(200,205,210,1)",c.lineWidth=3,c.beginPath(),c.moveTo(0,0),c.lineTo(64,64),c.moveTo(64,0),c.lineTo(0,64),c.stroke();let h=Wt(l.c);h.repeat.set(1,1);let u=new at({map:h,alphaTest:.5,side:xe,metalness:.6,roughness:.4}),d=e.barrier==="tirewall"?1.1:.6,f=this.extrude([{a:[o+a*d,1],b:[o+a*d,3.6],n:[-a,0],u:[0,20]}],.15),m=f.attributes.uv;for(let x=0;x<m.count;x++)m.setX(x,m.getX(x));r(f,u,!1),r(this.extrude([{a:[o+a*d,3.55],b:[o+a*(d+.05),3.62],n:[0,1]}],4),new at({color:10133670,metalness:.8,roughness:.3}),!1)}}return n}_buildStart(){let t=new Qt,e=this.pointAt(0,0),n=this.W,i=Gf("#111111","#f2f2f2",16),r=new we(n,1.6);r.rotateX(-Math.PI/2);let a=new it(r,new at({map:i,roughness:.6,polygonOffset:!0,polygonOffsetFactor:-2}));a.position.set(e.x,e.y+.012,e.z),a.rotation.y=e.heading,a.receiveShadow=!0,t.add(a);let o=new De({color:15263976,polygonOffset:!0,polygonOffsetFactor:-2});for(let p=0;p<12;p++){let v=-10-p*7,y=(p%2?1:-1)*n*.22,_=this.pointAt(v,y),S=new it(new we(2.4,.18).rotateX(-Math.PI/2),o);S.position.set(_.x,_.y+.012,_.z),S.rotation.y=_.heading,t.add(S)}let l=new at({color:1711138,metalness:.7,roughness:.35}),c=this.barrierD+.5,h=new Qt;for(let p of[-1,1]){let v=new it(new jt(.9,8,.9),l);v.position.set(p*-c,4,0),v.castShadow=!0,h.add(v)}let u=new it(new jt(c*2+.9,1.6,1.2),l);u.position.set(0,7.4,0),u.castShadow=!0,h.add(u);let d=le(1024,128),f=d.g,m=f.createLinearGradient(0,0,1024,0);m.addColorStop(0,"#0a0d18"),m.addColorStop(.5,"#142040"),m.addColorStop(1,"#0a0d18"),f.fillStyle=m,f.fillRect(0,0,1024,128),f.font="900 84px Orbitron, Arial, sans-serif",f.textAlign="center",f.textBaseline="middle",f.fillStyle="#ffffff",f.shadowColor="#00d8ff",f.shadowBlur=20,f.fillText("MOTO M\xCDTICO",512,68);let x=Wt(d.c,{wrap:!1}),g=new at({map:x,emissive:16777215,emissiveMap:x,emissiveIntensity:1.2});for(let p of[-1,1]){let v=new it(new we(c*2-1,1.2),g);v.position.set(0,7.4,p*.61),p<0&&(v.rotation.y=Math.PI),h.add(v)}this.startLights=[];for(let p=0;p<5;p++){let v=new at({color:1114112,emissive:16711680,emissiveIntensity:0});for(let _ of[-1,1]){let S=new it(new ys(.28,20),v);S.position.set((p-2)*.9,6.2,_*.62),_<0&&(S.rotation.y=Math.PI),h.add(S)}let y=new it(new jt(.75,.75,1.1),l);y.position.set((p-2)*.9,6.2,0),h.add(y),this.startLights.push(v)}return h.position.set(e.x,e.y,e.z),h.rotation.y=e.heading,t.add(h),this.gantry=h,t}setStartLights(t,e=!1){this.startLights&&this.startLights.forEach((n,i)=>{e?(n.emissive.set(65344),n.emissiveIntensity=5):(n.emissive.set(16711680),n.emissiveIntensity=i<t?6:0)})}};var ol=class{constructor(t,e){this.track=t;let n=t.theme.terrain;this.th=n,this.noise=new Es(t.def.id.length*131+7);let i=t.bounds;this.margin=900,this.size=i.size+this.margin*2,this.cx=i.cx,this.cz=i.cz,this.res=e.terrainRes,this.corridor=t.barrierD+3,this.blend=n.followTrack?90:70,this._stamp()}natural(t,e){let n=this.th,i=this.noise;if(n.flat)return n.base;let r=n.scale,a;if(n.ridged?(a=i.ridged(t/r,e/r,5),a=(a-.45)*n.amp*1.6):a=i.fbm(t/r,e/r,5)*n.amp,n.mesa){let l=a/14,c=Math.floor(l),h=l-c;a=(c+sa(.75,.95,h))*14}if(a+=i.fbm(t/40,e/40,3)*1.2,n.ocean){let[o,l]=n.ocean.dir,h=(t-this.cx)*o+(e-this.cz)*l- -n.ocean.start;h>0&&(a-=h*n.ocean.drop)}return a+n.base}_stamp(){let t=this.res,e=this.track,n=this.size,i=n/t,r=this.cx-n/2,a=this.cz-n/2;this.x0=r,this.z0=a,this.step=i;let o=(t+1)*(t+1),l=new Float32Array(o).fill(1e9),c=new Float32Array(o),h=this.corridor+this.blend,u=Math.ceil(h/i),{x:d,y:f,z:m}=e.c;for(let x=0;x<e.N;x+=2){let g=Math.round((d[x]-r)/i),p=Math.round((m[x]-a)/i);for(let v=p-u;v<=p+u;v++)if(!(v<0||v>t))for(let y=g-u;y<=g+u;y++){if(y<0||y>t)continue;let _=r+y*i,S=a+v*i,M=Math.hypot(_-d[x],S-m[x]),E=v*(t+1)+y;M<l[E]&&(l[E]=M,c[E]=f[x])}}this.dist=l,this.trackY=c}heightAtVertex(t,e){let n=this.res,i=e*(n+1)+t,r=this.x0+t*this.step,a=this.z0+e*this.step,o=this.natural(r,a),l=this.dist[i];if(l>this.corridor+this.blend)return o;let c=this.trackY[i]-.6;if(l<=this.corridor)return c;let h=sa(this.corridor,this.corridor+this.blend,l);return c+(o-c)*h}heightAt(t,e){let n=this.res,i=$((t-this.x0)/this.step,0,n-.001),r=$((e-this.z0)/this.step,0,n-.001),a=Math.floor(i),o=Math.floor(r),l=i-a,c=r-o,h=this.heights,u=h[o*(n+1)+a],d=h[o*(n+1)+a+1],f=h[(o+1)*(n+1)+a],m=h[(o+1)*(n+1)+a+1];return(u*(1-l)+d*l)*(1-c)+(f*(1-l)+m*l)*c}distanceToTrack(t,e){let n=this.res,i=$(Math.round((t-this.x0)/this.step),0,n),r=$(Math.round((e-this.z0)/this.step),0,n);return this.dist[r*(n+1)+i]}build(){let t=this.res,e=new we(this.size,this.size,t,t);e.rotateX(-Math.PI/2);let n=e.attributes.position,i=new Float32Array((t+1)*(t+1)),r=new Float32Array(n.count*3),a=new ot(this.th.color),o=new ot(this.th.rockColor),l=$t(9);for(let g=0;g<n.count;g++){let p=n.getX(g)+this.cx,v=n.getZ(g)+this.cz,y=Math.round((p-this.x0)/this.step),_=Math.round((v-this.z0)/this.step),S=this.heightAtVertex(y,_);i[_*(t+1)+y]=S,n.setXYZ(g,p,S,v)}this.heights=i,e.computeVertexNormals();let c=e.attributes.normal,h=new ot;for(let g=0;g<n.count;g++){let p=1-c.getY(g),v=sa(.12,.4,p);h.copy(a).lerp(o,v);let y=.88+l()*.12+this.noise.noise(n.getX(g)/60,n.getZ(g)/60)*.08;r[g*3]=h.r*y,r[g*3+1]=h.g*y,r[g*3+2]=h.b*y}e.setAttribute("color",new Vt(r,3));let u=e.attributes.uv;for(let g=0;g<n.count;g++)u.setXY(g,n.getX(g)/14,n.getZ(g)/14);let d=ra(this.track.theme.ground,5),f=new at({map:d.map,normalMap:d.normalMap,roughnessMap:d.roughnessMap,vertexColors:!0,color:16777215}),m=new it(e,f);m.receiveShadow=!0,m.name="terrain";let x=new Qt;return x.add(m),x.add(this._farRing()),this.track.theme.water&&x.add(this._water()),this.group=x,x}_farRing(){let t=this.track.theme.far,e=new Qt;if(t.skyline||!t.height)return e;let n=160,i=6,r=this.size*.62,a=[],o=[],l=[],c=this.noise,h=new ot(t.color),u=new ot(16054527);for(let m=0;m<=i;m++)for(let x=0;x<=n;x++){let g=x/n*Math.PI*2,p=m/i,v=c.ridged(Math.cos(g)*3+10,Math.sin(g)*3+10,5),y=Math.pow(v,2.2)*t.height*(.6+.4*c.noise(g*2,3));t.mesa&&(y=Math.round(y/40)*40*.9+y*.1);let _=r+p*r*.25,S=-20+y*Math.sin(p*Math.PI)*(p<.5?p*2:1);a.push(this.cx+Math.cos(g)*_,S,this.cz+Math.sin(g)*_);let M=t.snow?sa(t.height*.35,t.height*.6,S):0,E=h.clone().lerp(u,M);o.push(E.r,E.g,E.b)}for(let m=0;m<i;m++)for(let x=0;x<n;x++){let g=m*(n+1)+x,p=g+1,v=g+n+1,y=v+1;l.push(g,p,v,p,y,v)}let d=new Gt;d.setAttribute("position",new wt(a,3)),d.setAttribute("color",new wt(o,3)),d.setIndex(l),d.computeVertexNormals();let f=new it(d,new at({vertexColors:!0,roughness:.95,side:xe,flatShading:!0}));return e.add(f),e}_water(){let t=this.track.theme.water,e=new we(this.size*1.6,this.size*1.6,1,1);e.rotateX(-Math.PI/2),this.waterMat=new $n({color:t.color,roughness:.08,metalness:.1,clearcoat:1,clearcoatRoughness:.05,envMapIntensity:1.4});let n=new it(e,this.waterMat);return n.position.set(this.cx,t.level,this.cz),n.receiveShadow=!1,n}};var wr=class s extends it{constructor(){let t=s.SkyShader,e=new ve({name:t.name,uniforms:Tn.clone(t.uniforms),vertexShader:t.vertexShader,fragmentShader:t.fragmentShader,side:Ce,depthWrite:!1});super(new jt(1,1,1),e),this.isSky=!0}};wr.SkyShader={name:"SkyShader",uniforms:{turbidity:{value:2},rayleigh:{value:1},mieCoefficient:{value:.005},mieDirectionalG:{value:.8},sunPosition:{value:new C},up:{value:new C(0,1,0)}},vertexShader:`
		uniform vec3 sunPosition;
		uniform float rayleigh;
		uniform float turbidity;
		uniform float mieCoefficient;
		uniform vec3 up;

		varying vec3 vWorldPosition;
		varying vec3 vSunDirection;
		varying float vSunfade;
		varying vec3 vBetaR;
		varying vec3 vBetaM;
		varying float vSunE;

		// constants for atmospheric scattering
		const float e = 2.71828182845904523536028747135266249775724709369995957;
		const float pi = 3.141592653589793238462643383279502884197169;

		// wavelength of used primaries, according to preetham
		const vec3 lambda = vec3( 680E-9, 550E-9, 450E-9 );
		// this pre-calcuation replaces older TotalRayleigh(vec3 lambda) function:
		// (8.0 * pow(pi, 3.0) * pow(pow(n, 2.0) - 1.0, 2.0) * (6.0 + 3.0 * pn)) / (3.0 * N * pow(lambda, vec3(4.0)) * (6.0 - 7.0 * pn))
		const vec3 totalRayleigh = vec3( 5.804542996261093E-6, 1.3562911419845635E-5, 3.0265902468824876E-5 );

		// mie stuff
		// K coefficient for the primaries
		const float v = 4.0;
		const vec3 K = vec3( 0.686, 0.678, 0.666 );
		// MieConst = pi * pow( ( 2.0 * pi ) / lambda, vec3( v - 2.0 ) ) * K
		const vec3 MieConst = vec3( 1.8399918514433978E14, 2.7798023919660528E14, 4.0790479543861094E14 );

		// earth shadow hack
		// cutoffAngle = pi / 1.95;
		const float cutoffAngle = 1.6110731556870734;
		const float steepness = 1.5;
		const float EE = 1000.0;

		float sunIntensity( float zenithAngleCos ) {
			zenithAngleCos = clamp( zenithAngleCos, -1.0, 1.0 );
			return EE * max( 0.0, 1.0 - pow( e, -( ( cutoffAngle - acos( zenithAngleCos ) ) / steepness ) ) );
		}

		vec3 totalMie( float T ) {
			float c = ( 0.2 * T ) * 10E-18;
			return 0.434 * c * MieConst;
		}

		void main() {

			vec4 worldPosition = modelMatrix * vec4( position, 1.0 );
			vWorldPosition = worldPosition.xyz;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			gl_Position.z = gl_Position.w; // set z to camera.far

			vSunDirection = normalize( sunPosition );

			vSunE = sunIntensity( dot( vSunDirection, up ) );

			vSunfade = 1.0 - clamp( 1.0 - exp( ( sunPosition.y / 450000.0 ) ), 0.0, 1.0 );

			float rayleighCoefficient = rayleigh - ( 1.0 * ( 1.0 - vSunfade ) );

			// extinction (absorbtion + out scattering)
			// rayleigh coefficients
			vBetaR = totalRayleigh * rayleighCoefficient;

			// mie coefficients
			vBetaM = totalMie( turbidity ) * mieCoefficient;

		}`,fragmentShader:`
		varying vec3 vWorldPosition;
		varying vec3 vSunDirection;
		varying float vSunfade;
		varying vec3 vBetaR;
		varying vec3 vBetaM;
		varying float vSunE;

		uniform float mieDirectionalG;
		uniform vec3 up;

		// constants for atmospheric scattering
		const float pi = 3.141592653589793238462643383279502884197169;

		const float n = 1.0003; // refractive index of air
		const float N = 2.545E25; // number of molecules per unit volume for air at 288.15K and 1013mb (sea level -45 celsius)

		// optical length at zenith for molecules
		const float rayleighZenithLength = 8.4E3;
		const float mieZenithLength = 1.25E3;
		// 66 arc seconds -> degrees, and the cosine of that
		const float sunAngularDiameterCos = 0.999956676946448443553574619906976478926848692873900859324;

		// 3.0 / ( 16.0 * pi )
		const float THREE_OVER_SIXTEENPI = 0.05968310365946075;
		// 1.0 / ( 4.0 * pi )
		const float ONE_OVER_FOURPI = 0.07957747154594767;

		float rayleighPhase( float cosTheta ) {
			return THREE_OVER_SIXTEENPI * ( 1.0 + pow( cosTheta, 2.0 ) );
		}

		float hgPhase( float cosTheta, float g ) {
			float g2 = pow( g, 2.0 );
			float inverse = 1.0 / pow( 1.0 - 2.0 * g * cosTheta + g2, 1.5 );
			return ONE_OVER_FOURPI * ( ( 1.0 - g2 ) * inverse );
		}

		void main() {

			vec3 direction = normalize( vWorldPosition - cameraPosition );

			// optical length
			// cutoff angle at 90 to avoid singularity in next formula.
			float zenithAngle = acos( max( 0.0, dot( up, direction ) ) );
			float inverse = 1.0 / ( cos( zenithAngle ) + 0.15 * pow( 93.885 - ( ( zenithAngle * 180.0 ) / pi ), -1.253 ) );
			float sR = rayleighZenithLength * inverse;
			float sM = mieZenithLength * inverse;

			// combined extinction factor
			vec3 Fex = exp( -( vBetaR * sR + vBetaM * sM ) );

			// in scattering
			float cosTheta = dot( direction, vSunDirection );

			float rPhase = rayleighPhase( cosTheta * 0.5 + 0.5 );
			vec3 betaRTheta = vBetaR * rPhase;

			float mPhase = hgPhase( cosTheta, mieDirectionalG );
			vec3 betaMTheta = vBetaM * mPhase;

			vec3 Lin = pow( vSunE * ( ( betaRTheta + betaMTheta ) / ( vBetaR + vBetaM ) ) * ( 1.0 - Fex ), vec3( 1.5 ) );
			Lin *= mix( vec3( 1.0 ), pow( vSunE * ( ( betaRTheta + betaMTheta ) / ( vBetaR + vBetaM ) ) * Fex, vec3( 1.0 / 2.0 ) ), clamp( pow( 1.0 - dot( up, vSunDirection ), 5.0 ), 0.0, 1.0 ) );

			// nightsky
			float theta = acos( direction.y ); // elevation --> y-axis, [-pi/2, pi/2]
			float phi = atan( direction.z, direction.x ); // azimuth --> x-axis [-pi/2, pi/2]
			vec2 uv = vec2( phi, theta ) / vec2( 2.0 * pi, pi ) + vec2( 0.5, 0.0 );
			vec3 L0 = vec3( 0.1 ) * Fex;

			// composition + solar disc
			float sundisk = smoothstep( sunAngularDiameterCos, sunAngularDiameterCos + 0.00002, cosTheta );
			L0 += ( vSunE * 19000.0 * Fex ) * sundisk;

			vec3 texColor = ( Lin + L0 ) * 0.04 + vec3( 0.0, 0.0003, 0.00075 );

			vec3 retColor = pow( texColor, vec3( 1.0 / ( 1.2 + ( 1.2 * vSunfade ) ) ) );

			gl_FragColor = vec4( retColor, 1.0 );

			#include <tonemapping_fragment>
			#include <colorspace_fragment>

		}`};var Sr=Math.PI/180,ll=class{constructor(t,e,n,i){this.engine=t,this.scene=e,this.track=n,this.quality=i,this.T=yu[n.def.time]||yu.day,this.weather=n.def.weather,this.time=0,this.lampLights=[],this.onThunder=null,this._build()}_build(){let t=this.T,e=this.scene,n=this.quality,i=this.engine.renderer;i.toneMappingExposure=t.exposure,t.bloom&&this.engine.setBloom(...t.bloom);let r=(90-t.sunElev)*Sr,a=t.sunAzim*Sr;this.sunDir=new C().setFromSphericalCoords(1,r,a);let o=t.night?new C().setFromSphericalCoords(1,52*Sr,(t.sunAzim+40)*Sr):this.sunDir.clone();o.y<.12&&(o.y=.12),o.normalize(),this.lightDir=o;let l=new pn;if(t.night){this.sky=this._nightSky(4200),e.add(this.sky),l.add(this._nightSky(900));let x=$t(4);for(let g=0;g<40;g++){let p=new it(new mn(x.range(8,25),8,6),new De({color:new ot().setHSL(x.pick([.55,.85,.08,.12]),.9,.6)})),v=x()*Math.PI*2;p.position.set(Math.cos(v)*600,x.range(-20,120),Math.sin(v)*600),l.add(p)}}else{let x=new wr;x.scale.setScalar(4500);let g=x.material.uniforms;g.turbidity.value=t.turbidity,g.rayleigh.value=t.rayleigh,g.mieCoefficient.value=t.mie,g.mieDirectionalG.value=.86,g.sunPosition.value.copy(this.sunDir),e.add(x),this.sky=x;let p=new wr;p.scale.setScalar(900),Object.assign(p.material.uniforms.turbidity,{value:t.turbidity}),p.material.uniforms.rayleigh.value=t.rayleigh,p.material.uniforms.mieCoefficient.value=t.mie,p.material.uniforms.mieDirectionalG.value=.86,p.material.uniforms.sunPosition.value.copy(this.sunDir),l.add(p)}let c=new ot(t.hemiGround).multiplyScalar(t.night?.3:.8),h=new it(new mn(800,32,16,0,Math.PI*2,Math.PI/2,Math.PI/2),new De({color:c,side:Ce}));l.add(h);let u=new Yi(i);if(this.envRT=u.fromScene(l,0,1,2e3),e.environment=this.envRT.texture,e.environmentIntensity=t.env,u.dispose(),!t.night){let x=t.overcast||this.weather==="storm",g=Of(this.track.def.id.length,x?.95:this.weather==="snow"?.6:.3);g.repeat.set(3,1);let p=new De({map:g,transparent:!0,depthWrite:!1,side:Ce,fog:!1,color:new ot(x?6976128:16777215).multiplyScalar(t.sunElev<10?.9:1),opacity:x?.95:.85});t.sunElev<10&&!x&&p.color.set(16763040);let v=new mn(3e3,48,12,0,Math.PI*2,0,Math.PI*.42);if(this.clouds=new it(v,p),this.clouds.renderOrder=-1,e.add(this.clouds),x){let y=this.clouds.clone();y.material=p.clone(),y.material.opacity=.8,y.scale.setScalar(.92),y.rotation.y=1.3,this.clouds2=y,e.add(y)}}e.fog=new yo(t.fog[0],t.fog[1]*(this.weather==="storm"?1.4:this.weather==="snow"?1.3:1)),e.background=t.night?new ot(131850):null;let d=new Zi(t.hemiSky,t.hemiGround,t.hemi);e.add(d),this.hemi=d;let f=new Ss(t.sunColor,t.sun);if(f.castShadow=n.shadows>0,f.castShadow){f.shadow.mapSize.set(n.shadows,n.shadows);let x=n.shadows>=4096?55:42;Object.assign(f.shadow.camera,{left:-x,right:x,top:x,bottom:-x,near:1,far:400}),f.shadow.bias=-3e-4,f.shadow.normalBias=.03}e.add(f,f.target),this.sun=f,(this.weather==="storm"||this.weather==="rain")&&this._rain(this.weather==="storm"?9e3:5e3),this.weather==="snow"&&this._snow(6e3),this.nextLightning=6+Math.random()*6,this.flash=0;let m=t.night||t.overcast?n.shadows>=2048?8:n.shadows?5:3:0;for(let x=0;x<m;x++){let g=new ur(t.night?16766880:16769200,0,45,1.6);e.add(g),this.lampLights.push(g)}}_nightSky(t){let e=Ff(),n=new ve({uniforms:{tStars:{value:e},uHorizon:{value:new ot(1710144)},uZenith:{value:new ot(66058)},uGlow:{value:new ot(5909088)}},vertexShader:"varying vec3 vDir; void main(){ vDir = normalize(position); vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position = p.xyww; }",fragmentShader:`uniform sampler2D tStars; uniform vec3 uHorizon, uZenith, uGlow; varying vec3 vDir;
        void main(){
          float h = clamp(vDir.y, -0.2, 1.0);
          vec3 col = mix(uHorizon, uZenith, smoothstep(0.0, 0.5, h));
          col += uGlow * pow(1.0 - abs(h), 8.0) * 0.6;
          vec2 uv = vec2(atan(vDir.x, vDir.z) / 6.2831853 + 0.5, 1.0 - acos(clamp(vDir.y,-1.0,1.0)) / 3.14159265);
          vec3 st = texture2D(tStars, vec2(uv.x, 1.0 - (uv.y * 0.5 + 0.5))).rgb;
          col += st * smoothstep(0.02, 0.25, h) * 1.4;
          gl_FragColor = vec4(col, 1.0);
          #include <colorspace_fragment>
        }`,side:Ce,depthWrite:!1,fog:!1}),i=new Qt,r=new it(new mn(t,48,24),n);r.renderOrder=-2,i.add(r);let a=new De({color:15265535,fog:!1}),o=new it(new mn(t*.025,24,16),a),l=new C().setFromSphericalCoords(t*.9,55*Sr,(this.T.sunAzim+40)*Sr);o.position.copy(l),i.add(o);let c=new bo(new Kr({map:aa(),color:9089279,transparent:!0,opacity:.5,depthWrite:!1,fog:!1}));return c.scale.setScalar(t*.25),c.position.copy(l),i.add(c),i}_rain(t){let e=new Float32Array(t*2*3),n=new Float32Array(t*2*4),i=$t(77);for(let a=0;a<t;a++){let o=i(),l=i(),c=i(),h=.8+i()*.4;for(let u=0;u<2;u++){let d=a*2+u;n.set([o,l,c,u],d*4),e.set([0,0,0],d*3)}}let r=new Gt;r.setAttribute("position",new Vt(e,3)),r.setAttribute("seed",new Vt(n,4)),this.rainMat=new ve({uniforms:{uTime:{value:0},uCam:{value:new C},uBox:{value:new C(60,30,60)},uColor:{value:new ot(10136251)},uVel:{value:new C(2,-24,1)},uFlash:{value:0}},vertexShader:`attribute vec4 seed; uniform float uTime; uniform vec3 uCam, uBox, uVel; varying float vA;
        void main(){
          vec3 p = seed.xyz * uBox + uVel * uTime;
          p = mod(p, uBox) - uBox * 0.5;
          p += uCam;
          p -= normalize(uVel) * seed.w * 0.9;
          vA = seed.w;
          gl_Position = projectionMatrix * viewMatrix * vec4(p, 1.0);
        }`,fragmentShader:"uniform vec3 uColor; uniform float uFlash; varying float vA; void main(){ gl_FragColor = vec4(uColor * (1.0 + uFlash * 3.0), 0.32 * (1.0 - vA * 0.6)); }",transparent:!0,depthWrite:!1}),this.rain=new Eo(r,this.rainMat),this.rain.frustumCulled=!1,this.scene.add(this.rain)}_snow(t){let e=new Float32Array(t*3),n=new Float32Array(t*4),i=$t(78);for(let a=0;a<t;a++)n.set([i(),i(),i(),i()],a*4);let r=new Gt;r.setAttribute("position",new Vt(e,3)),r.setAttribute("seed",new Vt(n,4)),this.snowMat=new ve({uniforms:{uTime:{value:0},uCam:{value:new C},uBox:{value:new C(70,35,70)},tex:{value:aa()},uScale:{value:300}},vertexShader:`attribute vec4 seed; uniform float uTime, uScale; uniform vec3 uCam, uBox;
        void main(){
          vec3 p = seed.xyz * uBox + vec3(sin(uTime * 0.7 + seed.w * 20.0) * 1.2, -2.2 * uTime * (0.6 + seed.w), cos(uTime * 0.5 + seed.w * 13.0) * 1.2);
          p = mod(p, uBox) - uBox * 0.5;
          p += uCam;
          vec4 mv = viewMatrix * vec4(p, 1.0);
          gl_PointSize = uScale * (0.05 + seed.w * 0.06) / -mv.z;
          gl_Position = projectionMatrix * mv;
        }`,fragmentShader:"uniform sampler2D tex; void main(){ vec4 c = texture2D(tex, gl_PointCoord); gl_FragColor = vec4(vec3(1.0), c.a * 0.9); }",transparent:!0,depthWrite:!1}),this.snow=new Ai(r,this.snowMat),this.snow.frustumCulled=!1,this.scene.add(this.snow)}setLamps(t){this.lamps=t}update(t,e,n){this.time+=t;let i=this.sun,r=n||e.position,o=i.shadow.camera.right*2/(i.shadow.mapSize.x||1024),l=Math.round(r.x/o)*o,c=Math.round(r.z/o)*o;if(i.target.position.set(l,r.y,c),i.position.set(l+this.lightDir.x*200,r.y+this.lightDir.y*200,c+this.lightDir.z*200),this.sky&&this.sky.position.copy(e.position),this.clouds&&(this.clouds.position.set(e.position.x,0,e.position.z),this.clouds.rotation.y+=t*.004),this.clouds2&&(this.clouds2.position.set(e.position.x,0,e.position.z),this.clouds2.rotation.y+=t*.007),this.rainMat&&(this.rainMat.uniforms.uTime.value=this.time,this.rainMat.uniforms.uCam.value.copy(e.position)),this.snowMat&&(this.snowMat.uniforms.uTime.value=this.time,this.snowMat.uniforms.uCam.value.copy(e.position)),this.weather==="storm"){this.nextLightning-=t,this.nextLightning<=0&&(this.nextLightning=7+Math.random()*12,this.flashSeq=[0,.08,.18,.32].map(d=>this.time+d),this.onThunder&&setTimeout(()=>this.onThunder(),600+Math.random()*1600));let h=0;if(this.flashSeq)for(let d of this.flashSeq){let f=this.time-d;f>=0&&f<.12&&(h=Math.max(h,1-f/.12))}this.flash=h,this.hemi.intensity=this.T.hemi+h*4,this.rainMat&&(this.rainMat.uniforms.uFlash.value=h);let u=this.engine.fx;u&&(u.uFlash.value=Math.max(u.uFlash.value,h*.12))}if(this.lampLights.length&&this.lamps&&this.lamps.length&&(this._lampT=(this._lampT||0)-t,this._lampT<=0)){this._lampT=.2;let h=e.position,u=new C;e.getWorldDirection(u);let d=this.lamps.map((f,m)=>{let x=f.x-h.x,g=f.z-h.z,p=Math.hypot(x,g),v=(x*u.x+g*u.z)/(p||1);return[p-v*25,m]}).sort((f,m)=>f[0]-m[0]);this.lampLights.forEach((f,m)=>{let x=this.lamps[d[m][1]];f.position.set(x.x,x.y-.4,x.z),f.intensity=x.intensity??260,x.color!==void 0&&f.color.set(x.color)})}}dispose(){this.envRT?.dispose()}};function Er(s,t){let e=new ot(t),n=s.attributes.position.count,i=new Float32Array(n*3);for(let r=0;r<n;r++)i[r*3]=e.r,i[r*3+1]=e.g,i[r*3+2]=e.b;return s.setAttribute("color",new Vt(i,3)),s}function $v(s){let t=(s.index,s);for(let e of Object.keys(t.attributes))["position","normal","uv","color"].includes(e)||t.deleteAttribute(e);return t.attributes.uv||t.setAttribute("uv",new Vt(new Float32Array(t.attributes.position.count*2),2)),t.index&&(t=t.toNonIndexed()),t}function hl(s){return An(s.map($v),!1)}function Zv(s){let t=[],e=new ke(.18,.32,3,7);e.translate(0,1.5,0),t.push(Er(e,4863014));let n=5;for(let i=0;i<n;i++){let r=2.6-i*.42,a=3.2-i*.25,o=new _s(r,a,9,2),l=2.2+i*1.55+a/2;o.translate(0,l,0);let c=o.attributes.position;for(let u=0;u<c.count;u++){let d=c.getY(u),f=Math.sin(u*12.9898)*.18;c.setX(u,c.getX(u)*(1+f)),c.setZ(u,c.getZ(u)*(1-f*.5)),c.setY(u,d+f*.2)}o.computeVertexNormals();let h=new Float32Array(c.count*3);for(let u=0;u<c.count;u++){let d=(c.getY(u)-(l-a/2))/a,f=new ot(2046498).lerp(new ot(3103280),d);s&&d>.35&&f.lerp(new ot(15922943),$((d-.35)*2.2,0,.85)),h[u*3]=f.r,h[u*3+1]=f.g,h[u*3+2]=f.b}o.setAttribute("color",new Vt(h,3)),t.push(o)}return hl(t)}function l0(s){let t=[],e=$t(s),n=new ke(.22,.38,3.4,7);n.translate(0,1.7,0),t.push(Er(n,5060648));let i=new Es(s);for(let r=0;r<4;r++){let a=new ko(1.9+e()*.9,2),o=a.attributes.position;for(let u=0;u<o.count;u++){let d=new C(o.getX(u),o.getY(u),o.getZ(u)),f=1+i.noise(d.x*.9+r*3,d.y*.9+d.z*.7)*.22;d.multiplyScalar(f),o.setXYZ(u,d.x,d.y,d.z)}a.computeVertexNormals();let l=r/4*Math.PI*2+e(),c=r===0?[0,5.4,0]:[Math.cos(l)*1.5,4.2+e()*1.2,Math.sin(l)*1.5];a.translate(...c);let h=new Float32Array(o.count*3);for(let u=0;u<o.count;u++){let d=$((o.getY(u)-2.5)/5,0,1),f=new ot(2377246).lerp(new ot(5208626),d*.8+e()*.15);h[u*3]=f.r,h[u*3+1]=f.g,h[u*3+2]=f.b}a.setAttribute("color",new Vt(h,3)),t.push(a)}return hl(t)}function Kv(){let s=[],t=[];for(let i=0;i<=8;i++){let r=i/8;t.push(new C(Math.sin(r*1.2)*1.4,r*9,0))}let e=new ci(new En(t),16,.24,7,!1);s.push(Er(e,8018490));let n=t[t.length-1];for(let i=0;i<9;i++){let r=i/9*Math.PI*2,a=new we(4.2,.9,8,1),o=a.attributes.position;for(let l=0;l<o.count;l++){let c=o.getX(l)+2.1,h=o.getY(l)*(1-c/4.6);o.setXYZ(l,c,-Math.pow(c/4.2,2)*1.8,h)}a.rotateY(r),a.translate(n.x,n.y,n.z),a.computeVertexNormals(),s.push(Er(a,i%2?3828266:4880944))}return hl(s)}function Jv(){let s=[],t=new Io(.42,4.2,4,10);t.translate(0,2.5,0),s.push(t);for(let e of[-1,1]){let n=[new C(0,1.6+(e>0?.4:0),0),new C(e*1,1.9,0),new C(e*1.15,2.8,0),new C(e*1.15,3.6+(e>0?.3:0),0)],i=new ci(new En(n),12,.3,8,!1);s.push(i);let r=new mn(.3,8,6);r.translate(n[3].x,n[3].y,0),s.push(r)}return hl(s.map(e=>Er(e,4880954)))}function c0(s){let t=$t(s),e=new Do(1,1),n=e.attributes.position,i=new Es(s+5);for(let r=0;r<n.count;r++){let a=new C(n.getX(r),n.getY(r),n.getZ(r));a.multiplyScalar(1+i.noise(a.x*1.5,a.z*1.5+a.y)*.3),a.y*=.6+t()*.05,n.setXYZ(r,a.x,a.y,a.z)}return e.computeVertexNormals(),Er(e,16777215)}var cl=class{constructor(t,e,n){this.track=t,this.terrain=e,this.q=n,this.group=new Qt,this.group.name="scenery",this.lamps=[],this.r=$t(t.def.id.length*17+3)}build(){let t=this.track.theme,e=this.q.density,n=t.trees,i=this.useVegetation?0:Math.round(1400*n.density*e);if(i>0&&(n.pine&&this._scatter(Zv(!!n.snowy),Math.round(i*n.pine),{minD:6,maxD:420,scale:[.8,1.6],tint:.12}),n.broad&&this._scatter(l0(3),Math.round(i*n.broad*.6),{minD:7,maxD:380,scale:[.8,1.4],tint:.15}),n.broad&&this._scatter(l0(9),Math.round(i*n.broad*.4),{minD:7,maxD:380,scale:[.7,1.3],tint:.15}),n.palm&&this._scatter(Kv(),Math.round(i*n.palm),{minD:5,maxD:260,scale:[.8,1.3],tint:.1,near:.6}),n.cactus&&this._scatter(Jv(),Math.round(i*n.cactus),{minD:6,maxD:500,scale:[.6,1.4],tint:.12})),t.rocks){let r=t.terrain.rockColor;this._scatter(c0(4),Math.round(260*t.rocks*e),{minD:5,maxD:600,scale:[.6,4.5],tint:.15,color:r,sink:.35}),this._scatter(c0(8),Math.round(160*t.rocks*e),{minD:12,maxD:700,scale:[3,10],tint:.12,color:r,sink:.4})}return t.billboards&&this._billboards(),t.grandstands&&this._grandstands(),t.buildings==="city"&&this._city(),t.buildings==="villas"&&this._houses("villa"),t.buildings==="chalets"&&this._houses("chalet"),t.lamps&&this._lampPosts(),this._marshalPosts(),this.group}_candidate(t,e,n=0){let i=this.terrain,r=this.r;for(let a=0;a<40;a++){let o,l;if(r()<.65+n*.3){let u=this.track.pointAt(r()*this.track.L,0),d=r()<.5?-1:1,f=this.track.barrierD+t+Math.pow(r(),1.6)*(e-t);o=u.x+-u.tz*d*f,l=u.z+u.tx*d*f}else o=i.cx+(r()-.5)*i.size*.9,l=i.cz+(r()-.5)*i.size*.9;let c=i.distanceToTrack(o,l);if(c<this.track.barrierD+t||c>e+this.track.barrierD+200)continue;let h=i.heightAt(o,l);if(!(this.track.theme.water&&h<this.track.theme.water.level+.5))return{x:o,z:l,y:h}}return null}_scatter(t,e,n){if(e<=0)return;let i=new at({vertexColors:!0,roughness:.85,metalness:0,color:n.color??16777215}),r=new Yn(t,i,e),a=new Lt,o=new Fe,l=new C,c=new C,h=new ot,u=0;for(let d=0;d<e;d++){let f=this._candidate(n.minD,n.maxD,n.near||0);if(!f)continue;let m=n.scale[0]+this.r()*(n.scale[1]-n.scale[0]);o.setFromEuler(new nn((this.r()-.5)*.08,this.r()*Math.PI*2,(this.r()-.5)*.08)),l.set(m*(.9+this.r()*.2),m*(.85+this.r()*.3),m*(.9+this.r()*.2)),c.set(f.x,f.y-(n.sink?m*n.sink:.1),f.z),a.compose(c,o,l),r.setMatrixAt(u,a);let x=1-n.tint+this.r()*n.tint*2;h.setRGB(x,x*(.96+this.r()*.08),x),r.setColorAt(u,h),u++}return r.count=u,r.castShadow=this.q.shadows>0,r.receiveShadow=!0,r.computeBoundingSphere(),this.group.add(r),r}_billboards(){let t=[["NEXOIL","#0a2a6a","#ffffff","#ffcc00"],["VELOX","#111111","#ff3a3a","#ffffff"],["KRYO","#00a0d8","#ffffff","#003a5a"],["TURBOMAX","#c8102e","#ffffff","#111111"],["AURA","#2a0a4a","#ff7af0","#00e5ff"],["M\xCDTICO","#05060a","#ffffff","#00d8ff"],["ZENTEK","#f2f2f2","#111111","#ff6a00"],["RAYO","#ffd400","#111111","#111111"]],e=this.track,n=new at({color:2763824,metalness:.7,roughness:.4}),i=0;for(let r=60;r<e.L-40;r+=140){let a=e.pointAt(r,0),o=a.i;if(Math.abs(e.c.kappaSmooth[o])>1/300)continue;let l=i%2?1:-1,[c,h,u,d]=t[i%t.length];i++;let f=Pf(c,h,u,d),m=new at({map:f,roughness:.5,emissive:this.track.def.time==="night"||this.track.def.time==="dusk"?16777215:0,emissiveMap:f,emissiveIntensity:.6}),x=new Qt,g=new it(new jt(12,3,.3),[n,n,n,n,m,m]);g.position.y=4.2,g.castShadow=!0,x.add(g);for(let y of[-4.5,4.5]){let _=new it(new jt(.3,3,.3),n);_.position.set(y,1.5,0),x.add(_)}let p=l*(e.barrierD+4.5),v=e.pointAt(r,p);x.position.set(v.x,Math.min(v.y,this.terrain.heightAt(v.x,v.z))+0,v.z),x.rotation.y=a.heading+(l>0?Math.PI/2:-Math.PI/2)+Math.PI,this.group.add(x)}}_grandstands(){let t=this.track,e=new at({color:10133672,roughness:.7,metalness:.2}),n=[13111342,1195952,15921906,16765952],i=new at({color:15263976,roughness:.4,metalness:.6,side:xe});for(let[c,h,u]of[[-180,1,160],[60,1,120],[-60,-1,60]]){let d=t.pointAt(c+u/2,h*(t.barrierD+14)),f=new Qt,m=10;for(let p=0;p<m;p++){let v=new it(new jt(u,.6,1.4),p%2?e:new at({color:n[p%4],roughness:.6}));v.position.set(0,.3+p*.6,h*p*1.2),v.castShadow=!0,v.receiveShadow=!0,f.add(v)}let x=new it(new jt(u,8,.4),e);x.position.set(0,4,h*(m*1.2+.4)),f.add(x);let g=new it(new we(u,15),i);g.rotation.x=-Math.PI/2-h*.12,g.position.set(0,10,h*6),g.castShadow=!0,f.add(g);for(let p=-u/2;p<=u/2;p+=20){let v=new it(new ke(.25,.25,10),e);v.position.set(p,5,h*(m*1.2+.2)),f.add(v)}f.position.set(d.x,d.y-.2,d.z),f.rotation.y=d.heading-Math.PI/2,this.group.add(f)}let r=t.pointAt(-40,-(t.barrierD+12)),a=new Qt,o=new it(new jt(150,7,14),new at({color:14672872,roughness:.5,metalness:.2}));o.position.y=3.5,o.castShadow=!0,o.receiveShadow=!0,a.add(o);let l=new it(new jt(150.2,2.2,14.2),new at({color:1714746,roughness:.05,metalness:.9}));l.position.y=5.2,a.add(l);for(let c=0;c<12;c++){let h=new it(new we(9,4.5),new at({color:2763824,roughness:.6}));h.position.set(-66+c*12,2.3,7.05),a.add(h)}a.position.set(r.x,r.y-.1,r.z),a.rotation.y=r.heading-Math.PI/2,this.group.add(a)}_lampPosts(){let t=this.track,e=new at({color:2763824,metalness:.7,roughness:.4}),n=new at({color:0,emissive:16769712,emissiveIntensity:2.5}),i=38,r=Math.floor(t.L/i)*2,a=new Yn(new ke(.12,.16,9,8).translate(0,4.5,0),e,r),o=new jt(.12,.12,2.6).translate(0,9,1.2),l=new Yn(o,e,r),c=new Yn(new jt(.5,.15,1).translate(0,8.9,2.4),n,r),h=new Lt,u=0;for(let d=0;d<t.L-5;d+=i)for(let f of[-1,1]){let m=t.pointAt(d+(f>0?i/2:0),f*(t.barrierD+.9)),x=m.heading+(f>0?-Math.PI/2:Math.PI/2);h.makeRotationY(x),h.setPosition(m.x,m.y,m.z),a.setMatrixAt(u,h),l.setMatrixAt(u,h),c.setMatrixAt(u,h);let g=m.x+Math.sin(x)*2.4,p=m.z+Math.cos(x)*2.4;this.lamps.push({x:g,y:m.y+8.9,z:p,intensity:150}),u++}a.count=l.count=c.count=u,a.castShadow=!0,this.group.add(a,l,c)}_marshalPosts(){let t=this.track;if(t.def.theme==="city")return;let e=new at({color:15921906,roughness:.6}),n=new at({color:16747008,roughness:.6,side:xe});for(let i=250;i<t.L-100;i+=420){let r=Math.floor(i/420)%2?1:-1,a=t.pointAt(i,r*(t.barrierD+2.5)),o=new Qt,l=new it(new jt(2,2.4,2),e);l.position.y=1.2,l.castShadow=!0,o.add(l);let c=new it(new jt(2.4,.15,2.4),new at({color:13111342}));c.position.y=2.5,o.add(c);let h=new it(new ke(.03,.03,2),e);h.position.set(.9,3.4,.9),o.add(h);let u=new it(new we(.8,.5),n);u.position.set(1.3,4.1,.9),o.add(u),o.position.set(a.x,a.y,a.z),o.rotation.y=a.heading,this.group.add(o)}}_city(){let t=this.track,e=this.terrain,n=this.r,i=4,r=Array.from({length:i},()=>[]),a=[],o=["M\xCDTICO","NEO","KAZE","RYU","TOKIO","ZEN","MOTO","HIKARI","TURBO","NOVA"],l=["#ff2bd6","#00e5ff","#ffd400","#ff3a3a","#7cff00","#a07aff"],c=[],h=(g,p,v,y)=>{for(let _ of a)if(Math.abs(_.x-g)<_.hw+v+1.5&&Math.abs(_.z-p)<_.hd+y+1.5)return!0;return!1},u=this.q.density;for(let g=0;g<t.L;g+=9/Math.max(.5,u))for(let p of[-1,1]){if(n()<.25)continue;let v=10+n()*22,y=10+n()*24,_=12+Math.pow(n(),2)*120,S=t.barrierD+6+y/2+n()*10,M=t.pointAt(g,p*S),E=v/2,A=y/2,w=Math.abs(M.tx)>Math.abs(M.tz),b=w?E:A,P=w?A:E,D=!0;for(let[J,G]of[[-b,-P],[b,-P],[-b,P],[b,P],[0,0]])if(e.distanceToTrack(M.x+J,M.z+G)<t.barrierD+4){D=!1;break}if(!D||h(M.x,M.z,b,P))continue;a.push({x:M.x,z:M.z,hw:b,hd:P});let U=Math.floor(n()*i),F=new jt(b*2,_,P*2),q=F.attributes.uv,V=F.attributes.normal;for(let J=0;J<q.count;J++){let G=Math.abs(V.getX(J)),nt=Math.abs(V.getY(J)),ht=nt>.5?0:G>.5?P*2:b*2;q.setXY(J,q.getX(J)*(ht/21),q.getY(J)*(nt>.5?0:_/42))}F.translate(M.x,_/2-.5,M.z),r[U].push(F),n()<.35&&_>18&&c.push({x:M.x,z:M.z,side:p,ax:w,bw:b,bd:P,h:_,word:o[Math.floor(n()*o.length)],col:l[Math.floor(n()*l.length)],tx:M.tx,tz:M.tz})}let d=t.def.time==="night";for(let g=0;g<i;g++){if(!r[g].length)continue;let p=An(r[g],!1),v=au(g+1,{night:d,hue:[210,30,260,180][g],glass:g===2}),y=new at({map:v.map,emissiveMap:v.emissiveMap,emissive:d?16777215:0,emissiveIntensity:d?.75:0,roughness:g===2?.15:.7,metalness:g===2?.7:.1}),_=new it(p,y);_.castShadow=!1,_.receiveShadow=!0,this.group.add(_)}for(let g of c){let p=Cf(g.word,g.col),v=new De({map:p,toneMapped:!1,side:xe}),y=new it(new we(14,3.5),v),_=g.tz*g.side,S=-g.tx*g.side,M=Math.abs(_)>Math.abs(S)?g.bw:g.bd;y.position.set(g.x+_*(M+.2),Math.min(g.h-4,10+n()*20),g.z+S*(M+.2)),y.lookAt(y.position.x+_,y.position.y,y.position.z+S),this.group.add(y)}let f=[];for(let g=0;g<260;g++){let p=n()*Math.PI*2,v=e.size*(.32+n()*.18),y=20+n()*40,_=40+Math.pow(n(),1.5)*260,S=new jt(y,_,y);S.translate(e.cx+Math.cos(p)*v,_/2-1,e.cz+Math.sin(p)*v);let M=S.attributes.uv;for(let E=0;E<M.count;E++)M.setXY(E,M.getX(E)*(y/21),M.getY(E)*(_/42));f.push(S)}let m=au(9,{night:d,hue:230}),x=new at({map:m.map,emissiveMap:m.emissiveMap,emissive:d?16777215:0,emissiveIntensity:d?.6:0,roughness:.8});this.group.add(new it(An(f,!1),x))}_houses(t){let e=this.track,n=this.r,i=[],r=[],a=Math.round(70*this.q.density);for(let u=0;u<a;u++){let d=this._candidate(18,260);if(!d)continue;let f=8+n()*8,m=7+n()*6,x=t==="villa"?4+n()*4:5+n()*3,g=n()*Math.PI,p=new jt(f,x,m);p.translate(0,x/2,0),p.rotateY(g),p.translate(d.x,d.y-.3,d.z),i.push(p);let v=new _s(Math.max(f,m)*.75,t==="villa"?2:4,4,1);v.rotateY(Math.PI/4),v.scale(f/Math.max(f,m),1,m/Math.max(f,m)),v.translate(0,x+(t==="villa"?1:2),0),v.rotateY(g),v.translate(d.x,d.y-.3,d.z),r.push(v)}if(!i.length)return;let o=new at({color:t==="villa"?15920352:9067066,roughness:.85}),l=new at({color:t==="villa"?12079146:15791354,roughness:.8,flatShading:!0}),c=new it(An(i,!1),o),h=new it(An(r,!1),l);c.castShadow=h.castShadow=!0,c.receiveShadow=h.receiveShadow=!0,this.group.add(c,h)}};var _u=new Map;function Rs(s,t){return _u.has(s)||_u.set(s,t()),_u.get(s)}var Mn=(s,t,e,n=1)=>`hsla(${s},${t}%,${e}%,${n})`;function Tr(s){let t=Wt(s,{wrap:!1});return t.generateMipmaps=!0,t.minFilter=bi,t.premultiplyAlpha=!1,t}function ns(s="oak",t=1){return Rs(`leaf:${s}:${t}`,()=>{let{c:n,g:i}=le(512,512),r=$t(t*97+s.length),a={oak:{h:[86,112],s:[30,52],l:[14,36],n:430,len:[16,26],wid:[7,12],twig:"#3a2a1c"},beech:{h:[80,102],s:[38,58],l:[16,38],n:470,len:[14,22],wid:[7,11],twig:"#4a3a2a"},birch:{h:[70,92],s:[42,62],l:[22,44],n:480,len:[10,16],wid:[6,9],twig:"#2a2a2a"},autumn:{h:[18,48],s:[55,80],l:[28,50],n:240,len:[14,22],wid:[7,11],twig:"#3a2a1c"},bush:{h:[88,120],s:[30,50],l:[12,30],n:520,len:[10,16],wid:[5,8],twig:"#2a2418"},jungle:{h:[95,130],s:[40,60],l:[14,34],n:140,len:[30,46],wid:[12,18],twig:"#2a2418"}}[s]||{},o=512/2;i.strokeStyle=a.twig,i.lineCap="round";let l=[];for(let h=0;h<9;h++){let u=r()*Math.PI*2,d=512*(.18+r()*.24);i.lineWidth=3+r()*3;let f=o+Math.cos(u)*d,m=o+Math.sin(u)*d;i.beginPath(),i.moveTo(o,o+512*.05),i.quadraticCurveTo(o+Math.cos(u+.4)*d*.5,o+Math.sin(u+.4)*d*.5,f,m),i.stroke(),l.push([f,m])}let c=[];for(let h=0;h<a.n;h++){let u,d;if(r()<.6){let m=l[Math.floor(r()*l.length)];u=m[0]+(r()-.5)*512*.22,d=m[1]+(r()-.5)*512*.22}else{let m=r()*Math.PI*2,x=Math.sqrt(r())*512*.42;u=o+Math.cos(m)*x,d=o+Math.sin(m)*x}Math.hypot(u-o,d-o)/(512*.48)>1||c.push({x:u,y:d,depth:r(),a:r()*Math.PI*2})}c.sort((h,u)=>h.depth-u.depth);for(let h of c){let u=a.len[0]+r()*(a.len[1]-a.len[0]),d=a.wid[0]+r()*(a.wid[1]-a.wid[0]),f=a.h[0]+r()*(a.h[1]-a.h[0]),m=a.s[0]+r()*(a.s[1]-a.s[0]),x=a.l[0]+(a.l[1]-a.l[0])*(.35+h.depth*.65)*(.8+r()*.4);i.save(),i.translate(h.x,h.y),i.rotate(h.a);let g=i.createLinearGradient(0,-d,0,d);if(g.addColorStop(0,Mn(f,m,x+10)),g.addColorStop(.5,Mn(f,m,x)),g.addColorStop(1,Mn(f+4,m,x-8)),i.fillStyle=g,i.beginPath(),s==="oak"){i.moveTo(-u,0);for(let p=0;p<=6;p++){let v=p/6,y=-u+v*2*u,_=-d*Math.sin(v*Math.PI)*(p%2?.75:1);i.lineTo(y,_)}for(let p=6;p>=0;p--){let v=p/6,y=-u+v*2*u,_=d*Math.sin(v*Math.PI)*(p%2?.75:1);i.lineTo(y,_)}}else i.ellipse(0,0,u,d,0,0,Math.PI*2);i.fill(),i.strokeStyle=Mn(f,m-10,x-12,.6),i.lineWidth=1,i.beginPath(),i.moveTo(-u*.9,0),i.lineTo(u*.9,0),i.stroke(),i.restore()}return Tr(n)})}function Mu(s=!1,t=2){return Rs(`fir:${s}:${t}`,()=>{let{c:i,g:r}=le(512,256),a=$t(t),o=256/2;r.lineCap="round";let l=(c,h,u,d,f,m)=>{let x=c+Math.cos(u)*d,g=h+Math.sin(u)*d;r.strokeStyle="#3a2a1a",r.lineWidth=f,r.beginPath(),r.moveTo(c,h),r.lineTo(x,g),r.stroke();let p=Math.floor(d/3.2);for(let v=0;v<p;v++){let y=v/p,_=c+Math.cos(u)*d*y,S=h+Math.sin(u)*d*y,M=(1-y*.6)*(m?18:26)*(.8+a()*.4);for(let E of[-1,1]){let A=u+E*(.75+a()*.25),w=20+a()*22;r.strokeStyle=Mn(98+a()*26,24+a()*18,w*.72),r.lineWidth=1.6+a(),r.beginPath(),r.moveTo(_,S),r.lineTo(_+Math.cos(A)*M,S+Math.sin(A)*M),r.stroke()}}if(m<2)for(let v=1;v<5;v++){let y=v/5+(a()-.5)*.06,_=c+Math.cos(u)*d*y,S=h+Math.sin(u)*d*y;for(let M of[-1,1])l(_,S,u+M*(.55+a()*.3),d*(.42-y*.25),f*.6,m+1)}};if(l(4,o,0,512*.94,6,0),s)for(let c=0;c<260;c++){let h=a()*512*.9,u=o+(a()-.5)*256*.7,d=Math.abs(u-o)/(256*.4);a()<d||(r.fillStyle=`rgba(245,248,255,${.6+a()*.4})`,r.beginPath(),r.ellipse(h,u,6+a()*12,3+a()*6,(a()-.5)*.6,0,Math.PI*2),r.fill())}return Tr(i)})}function bu(s=3){return Rs(`pinetuft:${s}`,()=>{let{c:e,g:n}=le(256,256),i=$t(s);n.lineCap="round";for(let r=0;r<14;r++){let a=51.2+i()*256*.6,o=256*.2+i()*256*.6;n.strokeStyle="#4a3220",n.lineWidth=3,n.beginPath(),n.moveTo(256/2,256*.9),n.lineTo(a,o),n.stroke();for(let l=0;l<46;l++){let c=i()*Math.PI*2,h=14+i()*22;n.strokeStyle=Mn(110+i()*30,30+i()*20,16+i()*22),n.lineWidth=1.5,n.beginPath(),n.moveTo(a,o),n.lineTo(a+Math.cos(c)*h,o+Math.sin(c)*h),n.stroke()}}return Tr(e)})}function h0(s=4){return Rs(`palm:${s}`,()=>{let{c:n,g:i}=le(512,128),r=$t(s),a=128/2;i.lineCap="round";for(let o=0;o<70;o++){let l=o/70,c=10+l*492,h=(Math.sin(l*Math.PI)*.8+.2)*128*.48;for(let u of[-1,1]){let d=u*(1+r()*.2)+(l-.5)*.2;i.strokeStyle=Mn(85+r()*25,40+r()*20,20+r()*18),i.lineWidth=4+r()*2,i.beginPath(),i.moveTo(c,a),i.quadraticCurveTo(c+8,a+Math.sin(d)*h*.5,c+Math.cos(d)*12+14,a+Math.sin(d)*h),i.stroke()}}return i.strokeStyle="#5a4a2a",i.lineWidth=5,i.beginPath(),i.moveTo(0,a),i.lineTo(512,a),i.stroke(),Tr(n)})}function is(s="green",t=5){return Rs(`grass:${s}:${t}`,()=>{let{c:i,g:r}=le(256,256),a=$t(t),o={green:[95,45,20],dry:[48,45,38],flowers:[100,45,22],snow:[90,15,60],reeds:[70,35,30]}[s],l=s==="reeds"?26:70;for(let c=0;c<l;c++){let h=10+a()*236,u=256*(.45+a()*.53),d=(a()-.5)*60,f=2.5+a()*3.5,m=r.createLinearGradient(0,256,0,256-u);m.addColorStop(0,Mn(o[0],o[1],o[2]*.6)),m.addColorStop(1,Mn(o[0]+(a()-.5)*20,o[1]+10,o[2]+18+a()*10)),r.fillStyle=m,r.beginPath(),r.moveTo(h-f,256),r.quadraticCurveTo(h-f*.5+d*.4,256-u*.6,h+d,256-u),r.quadraticCurveTo(h+f*.5+d*.4,256-u*.6,h+f,256),r.closePath(),r.fill(),s==="flowers"&&a()<.35&&(r.fillStyle=a()<.5?Mn(50,90,60):a()<.5?Mn(0,0,95):Mn(300+a()*40,70,65),r.beginPath(),r.arc(h+d,256-u,4+a()*3,0,Math.PI*2),r.fill()),s==="reeds"&&(r.fillStyle="#5a4028",r.fillRect(h+d-3,256-u-2,6,22))}return Tr(i)})}function u0(s=6){return Rs(`fern:${s}`,()=>{let{c:e,g:n}=le(256,256),i=$t(s);n.lineCap="round";for(let r=0;r<7;r++){let a=-Math.PI/2+(r-3)*.32+(i()-.5)*.1,o=256*(.36+i()*.1),l=256/2,c=256*.98;n.strokeStyle="#2a4018",n.lineWidth=2.5,n.beginPath(),n.moveTo(l,c);let h=[];for(let u=0;u<=20;u++){let d=u/20,f=a+d*d*(a<-Math.PI/2?-.8:.8),m=l+Math.cos(f)*o*d*1.1,x=c+Math.sin(f)*o*d*1.1;h.push([m,x,f]),n.lineTo(m,x)}n.stroke();for(let u=2;u<h.length;u++){let[d,f,m]=h[u],x=(1-u/h.length)*26+4;for(let g of[-1,1])n.strokeStyle=Mn(95+i()*20,45,18+i()*14),n.lineWidth=4,n.beginPath(),n.moveTo(d,f),n.lineTo(d+Math.cos(m+g*1.2)*x,f+Math.sin(m+g*1.2)*x),n.stroke()}}return Tr(e)})}function d0(s="oak"){return Rs(`bark:${s}`,()=>{let n=je(s.length*13,6,5),i=je(s.length*17,24,3),{c:r,g:a}=le(256,512),o=a.createImageData(256,512),l=new Float32Array(256*512);for(let c=0;c<512;c++)for(let h=0;h<256;h++){let u=h/256,d=c/512,f,m;if(s==="birch"){let g=i(u*1,d*4)>.35?1:0,p=Math.abs(Math.sin(d*60+n(u,d)*3))<.08?1:0,v=215+n(u,d)*25;f=g||p?[40,38,36]:[v,v-4,v-10],m=g?.2:.6}else if(s==="palm"){let g=Math.sin(d*90+n(u,d)*2)*.5+.5,p=90+g*50+n(u,d)*20;f=[p,p*.82,p*.6],m=g}else if(s==="pine"){let g=Math.abs(n(u*2,d*.5)),p=70+g*90;f=[p*1.25,p*.72,p*.5],m=g}else{let g=Math.abs(Math.sin(u*Math.PI*14+n(u,d)*7)),p=40+g*55+i(u,d)*15;f=[p,p*.88,p*.74],m=g}let x=(c*256+h)*4;o.data[x]=$(f[0],0,255),o.data[x+1]=$(f[1],0,255),o.data[x+2]=$(f[2],0,255),o.data[x+3]=255,l[c*256+h]=m}return a.putImageData(o,0,0),{map:Wt(r),normalMap:Wt(Ts(l,256,512,3),{srgb:!1})}})}var xa={time:{value:0},strength:{value:1}};function jv(s,t=.25,e=1.3,n=1){return s.onBeforeCompile=i=>{i.uniforms.uWindTime=xa.time,i.uniforms.uWindStr=xa.strength,i.vertexShader=i.vertexShader.replace("#include <common>",`#include <common>
uniform float uWindTime; uniform float uWindStr;`).replace("#include <begin_vertex>",`#include <begin_vertex>
        {
          vec3 ip = vec3(0.0);
          #ifdef USE_INSTANCING
            ip = instanceMatrix[3].xyz;
          #endif
          float hgt = max(0.0, transformed.y) * ${n.toFixed(3)};
          float ph = ip.x * 0.07 + ip.z * 0.05;
          float sway = sin(uWindTime * ${e.toFixed(3)} + ph) * 0.6 + sin(uWindTime * ${(e*2.7).toFixed(3)} + ph * 3.0 + transformed.x) * 0.25;
          float flutter = sin(uWindTime * 7.0 + transformed.x * 3.0 + transformed.z * 2.0 + ph) * 0.04;
          float k = hgt * hgt * ${(t*.02).toFixed(4)} * uWindStr;
          transformed.x += sway * k + flutter * hgt * 0.15 * uWindStr;
          transformed.z += sway * k * 0.6 + flutter * hgt * 0.1 * uWindStr;
        }`)},s.customProgramCacheKey=()=>`wind${t}_${e}_${n}`,s}function Cs(s,t,e,n=6,i=1){let r=new En(s.map(d=>new C(...d))),a=Math.max(2,s.length*2),o=new ci(r,a,1,n,!1),l=o.attributes.position,c=o.attributes.normal,h=o.attributes.uv,u=r.computeFrenetFrames(a,!1);for(let d=0;d<=a;d++){let f=d/a,m=r.getPointAt(f),x=t+(e-t)*f;for(let g=0;g<=n;g++){let p=d*(n+1)+g,v=c.getX(p),y=c.getY(p),_=c.getZ(p);l.setXYZ(p,m.x+v*x,m.y+y*x,m.z+_*x),h.setXY(p,g/n,f*i)}}return o.computeVertexNormals(),o}function ga(s,t,e,n,i,r,a=.4,o=[0,0,1,1],l=null){let c=new C(...t).normalize().multiplyScalar(n/2),h=new C(...e).normalize().multiplyScalar(i/2),u=new C(...s),d=[u.clone().sub(c).sub(h),u.clone().add(c).sub(h),u.clone().add(c).add(h),u.clone().sub(c).add(h)],f=[],m=[],x=[],g=new C(...r);for(let _ of d){f.push(_.x,_.y,_.z);let S=_.clone().sub(g).normalize();S.y+=a,S.normalize(),m.push(S.x,S.y,S.z)}x.push(o[0],o[1],o[2],o[1],o[2],o[3],o[0],o[3]);let p=new Gt;p.setAttribute("position",new wt(f,3)),p.setAttribute("normal",new wt(m,3)),p.setAttribute("uv",new wt(x,2));let v=[],y=l??3;for(let _ of d){let S=Math.min(1,_.distanceTo(g)/y),M=.42+.58*Math.pow(S,.8)+Math.max(0,(_.y-g.y)/(y*4));v.push(Math.min(1.1,M),Math.min(1.1,M),Math.min(1.1,M*.96))}return p.setAttribute("color",new wt(v,3)),p.setIndex([0,1,2,0,2,3]),p}function dl(s,t,e,n,i=.5,r=3){let a=[],o=n()*Math.PI;for(let l=0;l<3;l++){let c=o+l*Math.PI/3,h=(n()-.5)*.6,u=[Math.cos(c),0,Math.sin(c)],d=[Math.sin(h)*Math.sin(c),Math.cos(h),-Math.sin(h)*Math.cos(c)];a.push(ga(s,u,l===2?[Math.cos(c+1.57),.25,Math.sin(c+1.57)]:d,t*(.9+n()*.25),t*(.9+n()*.25),e,i,void 0,r))}return a}function Ii(s,t=!1){return An(s.map(e=>{for(let n of Object.keys(e.attributes))["position","normal","uv",...t?["color"]:[]].includes(n)||e.deleteAttribute(n);if(t&&!e.attributes.color){let n=e.attributes.position.count;e.setAttribute("color",new wt(new Float32Array(n*3).fill(1),3))}return e.index?e.toNonIndexed():e}),!1)}function ul(s,t){let e=$t(s),n=t==="birch",i=n?11+e()*4:10+e()*4,r=[],a=[],o=[(e()-.5)*.7,(e()-.5)*.7],l=[];for(let g=0;g<=6;g++){let p=g/6;l.push([o[0]*p*p+Math.sin(p*5+s)*.12,p*i*.8,o[1]*p*p])}r.push(Cs(l,n?.24:.42,.1,8,3));let c=new ke(n?.25:.42,n?.4:.75,.7,8,1,!0);c.translate(0,.3,0),r.push(c);let h=[o[0]*.7,i*.66,o[1]*.7],u=n?2.3:3.6,d=n?3.4:3,f=n?6:7;for(let g=0;g<f;g++){let p=g/f*Math.PI*2+e()*.6,v=i*(.42+e()*.28),y=u*(.6+e()*.3),_=.6+e()*.4,S=[o[0]*(v/i)**2,v,o[1]*(v/i)**2],M=[S[0]+Math.cos(p)*y*.5,v+y*_*.55,S[2]+Math.sin(p)*y*.5],E=[S[0]+Math.cos(p)*y,v+y*_,S[2]+Math.sin(p)*y];r.push(Cs([S,M,E],n?.09:.15,.04,5,1))}let m=n?2:2.9,x=n?26:34;for(let g=0;g<x;g++){let p=e()*2-1,v=e()*Math.PI*2,y=Math.sqrt(1-p*p),_=.78+e()*.3,S=[h[0]+Math.cos(v)*y*u*_,h[1]+p*d*_+(p<0?p*.4:0),h[2]+Math.sin(v)*y*u*_];a.push(...dl(S,m*(.85+e()*.35),h,e,.35,Math.max(u,d)))}for(let g=0;g<(n?8:12);g++){let p=e()*Math.PI*2,v=Math.sqrt(e())*u*.5;a.push(...dl([h[0]+Math.cos(p)*v,h[1]+(e()-.5)*d,h[2]+Math.sin(p)*v],m,h,e,.35,Math.max(u,d)))}return{bark:Ii(r),leaves:Ii(a,!0),height:i}}function f0(s,t){let e=$t(s),n=14+e()*7,i=[Cs([[0,0,0],[0,n*.45,0],[0,n*.9,0]],.36,.06,7,6)],r=[],a=19,o=3.1+e()*.9;for(let l=0;l<a;l++){let c=l/a,h=1.3+c*(n-2),u=o*Math.pow(1-c,1.05)+.45+e()*.25,d=c>.75?5:7,f=e()*Math.PI*2,m=[0,h-.8,0];for(let x=0;x<d;x++){let g=f+x/d*Math.PI*2+(e()-.5)*.35,p=.22+e()*.2+c*.1,v=[Math.cos(g),-p,Math.sin(g)],y=[-Math.sin(g),0,Math.cos(g)],_=[v[0]*u*.5,h+v[1]*u*.5,v[2]*u*.5],S=u*.78+.3;r.push(ga(_,v,y,u,S,m,1,void 0,o)),r.push(ga([_[0],_[1]-.05,_[2]],v,[0,1,0],u*.95,S*.62,m,.5,void 0,o)),r.push(ga([_[0]*.92,_[1]+.15,_[2]*.92],v,[y[0]*.7,.7,y[2]*.7],u*.85,S*.7,m,.7,void 0,o))}}for(let l=0;l<3;l++){let c=l/3*Math.PI;r.push(ga([0,n-.6,0],[0,1,0],[Math.cos(c),0,Math.sin(c)],1.6,.8,[0,n-2,0],.4,void 0,o))}return{bark:Ii(i),leaves:Ii(r,!0),height:n}}function p0(s){let t=$t(s),e=12+t()*5,n=[(t()-.5)*1.2,(t()-.5)*1.2],i=[];for(let c=0;c<=5;c++){let h=c/5;i.push([n[0]*Math.sin(h*2),h*e,n[1]*Math.sin(h*2)])}let r=[Cs(i,.3,.1,7,5)],a=[],o=i[5],l=[o[0],e*.86,o[2]];for(let c=0;c<5;c++){let h=t()*Math.PI*2,u=e*(.62+t()*.25),d=2+t()*1.6,f=[n[0]*Math.sin(u/e*2),u,n[1]*Math.sin(u/e*2)],m=[f[0]+Math.cos(h)*d,u+d*.4,f[2]+Math.sin(h)*d];r.push(Cs([f,[(f[0]+m[0])/2,(f[1]+m[1])/2+.2,(f[2]+m[2])/2],m],.1,.04,5,1)),a.push(...dl(m,2.2+t(),l,t,.8))}for(let c=0;c<12;c++){let h=t()*Math.PI*2,u=Math.sqrt(t())*2.6;a.push(...dl([l[0]+Math.cos(h)*u,l[1]+(t()-.3)*2.2,l[2]+Math.sin(h)*u],2.2+t()*.8,l,t,.8))}return{bark:Ii(r),leaves:Ii(a,!0),height:e}}function Qv(s){let t=$t(s),e=8+t()*4,n=1.5+t()*2,i=[];for(let c=0;c<=6;c++){let h=c/6;i.push([Math.sin(h*1.3)*n,h*e,0])}let r=[Cs(i,.28,.2,8,8)],a=[],o=i[6],l=13;for(let c=0;c<l;c++){let h=c/l*Math.PI*2+t()*.3,u=4.2+t()*1.4,d=6,f=[],m=[],x=[],g=[],p=.4+t()*.6;for(let y=0;y<=d;y++){let _=y/d,S=_*u,M=o[1]+.4+S*(.5-p*_*1.2),E=o[0]+Math.cos(h)*S,A=o[2]+Math.sin(h)*S,w=.65*Math.sin(Math.PI*Math.min(1,_*1.15+.08)),b=-Math.sin(h),P=Math.cos(h);if(f.push(E-b*w,M,A-P*w,E+b*w,M,A+P*w),m.push(0,1,0,0,1,0),x.push(_,0,_,1),y<d){let D=y*2;g.push(D,D+2,D+1,D+1,D+2,D+3)}}let v=new Gt;v.setAttribute("position",new wt(f,3)),v.setAttribute("normal",new wt(m,3)),v.setAttribute("uv",new wt(x,2)),v.setIndex(g),v.setAttribute("color",new wt(new Float32Array(f.length).fill(1),3)),a.push(v)}for(let c=0;c<4;c++){let h=new mn(.16,8,6);h.translate(o[0]+Math.cos(c*1.6)*.25,o[1]-.1,o[2]+Math.sin(c*1.6)*.25),r.push(h)}return{bark:Ii(r),leaves:Ii(a,!0),height:e}}function m0(s){let t=$t(s),e=(i,r,a,o=12)=>{let l=[];l.push([.001,r]);let c=new vs([new tt(i*.9,r),new tt(i,r+.2),new tt(i,a-i),new tt(i*.6,a-i*.3),new tt(.01,a)],o*2),h=c.attributes.position;for(let u=0;u<h.count;u++){let d=h.getX(u),f=h.getZ(u),m=Math.atan2(f,d),x=1+Math.cos(m*o)*.08;h.setX(u,d*x),h.setZ(u,f*x)}return c.computeVertexNormals(),c},n=[e(.42,0,4.6+t()*1.5)];for(let i of[-1,1]){if(t()<.25)continue;let r=1.4+t()*1.2,a=e(.28,0,1.6+t());a.translate(i*1,r+.4,0),n.push(a);let o=Cs([[0,r,0],[i*.6,r+.05,0],[i*1,r+.45,0]],.3,.28,10,1);n.push(o)}return Ii(n)}function ty(s,t,e){let r=new Ne(256,512,{samples:4}),a=new pn;a.add(new Zi(16777215,5596740,2.6));let o=new Ss(16777215,3.2);o.position.set(3,6,8),a.add(o);let l=new Ss(16777215,1.2);l.position.set(-4,3,6),a.add(l);for(let x of t)a.add(x);let c=e*.56,h=new qi(-c*.5,c*.5,c*1+c*0,-c*0,.1,100);h.top=e*1.05,h.bottom=-.1,h.left=-e*.27,h.right=e*.27,h.updateProjectionMatrix(),h.position.set(0,0,40),h.lookAt(0,0,0),h.position.y=0;let u=s.getRenderTarget(),d=s.getClearColor(new ot),f=s.getClearAlpha(),m=s.toneMapping;s.setRenderTarget(r),s.setClearColor(0,0),s.clear(),s.render(a,h),s.setRenderTarget(u),s.setClearColor(d,f),s.toneMapping=m;for(let x of t)a.remove(x);return r.texture.colorSpace=Ji,{tex:r.texture,w:e*.54,h:e*1.15,rt:r}}function ey(s,t){let e=new we(s,t);e.translate(0,t/2-.1,0);let n=e.clone();n.rotateY(Math.PI/2);let i=An([e,n],!1),r=i.attributes.normal;for(let a=0;a<r.count;a++)r.setXYZ(a,0,1,0);return i}var fl=class{constructor(t,e,n,i){this.track=t,this.terrain=e,this.q=n,this.renderer=i,this.group=new Qt,this.group.name="vegetation",this.r=$t(t.def.id.length*131+9),this.a2c=n.msaa>0,this.near=75}_foliageMat(t,e={}){let n=new at({map:t,alphaTest:.42,side:xe,roughness:.82,metalness:0,alphaToCoverage:this.a2c,color:e.color??16777215,vertexColors:!!e.vc});return jv(n,e.amp??.25,e.freq??1.3,e.stiff??1)}_barkMat(t){let e=d0(t);return new at({map:e.map,normalMap:e.normalMap,roughness:.92})}_place(t,e,n,i={}){let r=this.track,a=this.terrain,o=this.r,l=[];for(let c=0;c<t*3&&l.length<t;c++){let h,u;if(o()<(i.trackBias??.75)){let m=r.pointAt(o()*r.L,0),x=o()<.5?-1:1,g=r.barrierD+e+Math.pow(o(),i.pow??1.4)*(n-e);h=m.x-m.tz*x*g,u=m.z+m.tx*x*g}else h=a.cx+(o()-.5)*a.size*.85,u=a.cz+(o()-.5)*a.size*.85;let d=a.distanceToTrack(h,u);if(d<r.barrierD+e||d>r.barrierD+n)continue;let f=a.heightAt(h,u);r.theme.water&&f<r.theme.water.level+.6||l.push({x:h,y:f,z:u,d})}return l}_instanced(t,e,n,i,{shadow:r=!0,tint:a=.12,sink:o=.15}={}){if(!n.length)return null;let l=new Yn(t,e,n.length),c=new Lt,h=new Fe,u=new C,d=new C,f=new nn,m=new ot;return n.forEach((x,g)=>{if(!x.m4){let v=i[0]+this.r()*(i[1]-i[0]);f.set((this.r()-.5)*.06,this.r()*Math.PI*2,(this.r()-.5)*.06),h.setFromEuler(f),u.set(v,v*(.9+this.r()*.2),v),d.set(x.x,x.y-o*v,x.z),x.m4=new Lt().compose(d,h,u)}c.copy(x.m4),l.setMatrixAt(g,c);let p=1-a+this.r()*a*2;m.setRGB(p*(x.tr??1),p*(x.tg??1),p*(x.tb??1)),l.setColorAt(g,m)}),l.castShadow=r&&this.q.shadows>0,l.receiveShadow=!0,l.computeBoundingSphere(),this.group.add(l),l}_species(t){let e=t.variants??3,n=this._place(Math.round(t.count*this.q.density),t.minD??4,this.near,{pow:1.2}),i=this._place(Math.round((t.far??0)*this.q.density),this.near,t.maxD??650,{pow:1,trackBias:.55}),r=this._foliageMat(t.leafTex,{...t.wind||{},vc:!0,color:t.leafColor}),a=this._barkMat(t.barkKind),o=null;for(let l=0;l<e;l++){let c=t.make(t.seed+l*17),h=n.filter((u,d)=>d%e===l);if(h.length){this._instanced(c.bark,a,h,t.scale,{tint:.1});let u=this._instanced(c.leaves,r,h.map(d=>d),t.scale,{tint:t.tint??.16})}if(l===0&&i.length){let u=new it(c.bark,a),d=new it(c.leaves,r);o=ty(this.renderer,[u,d],c.height)}}if(o&&i.length){let l=new at({map:o.tex,alphaTest:.5,side:xe,roughness:.9,alphaToCoverage:this.a2c});this._instanced(ey(o.w,o.h),l,i,t.scale,{shadow:!1,tint:.18,sink:0})}}_ground(t,e,n,i,r,{inRunoff:a=!1,wind:o=1,tint:l=.2,colorFn:c=null}={}){if(e<=0)return;let h=this.track,u=this.terrain,d=this.r,f=[];for(let _=0;_<e*2&&f.length<e;_++){let S=h.pointAt(d()*h.L,0),M=d()<.5?-1:1,E=a?h.halfW+1.6:h.barrierD+.6,A=E+Math.pow(d(),1.5)*(a?h.barrierD-.8-E:i),w=S.x-S.tz*M*A,b=S.z+S.tx*M*A,P;if(A<h.barrierD+2)P=h.pointAt(S.i*h.ds,M*A).y;else{if(u.distanceToTrack(w,b)<h.barrierD+.5)continue;P=u.heightAt(w,b)}if(h.theme.water&&P<h.theme.water.level+.3)continue;let D={x:w,y:P,z:b};c&&Object.assign(D,c(d)),f.push(D)}let m=r[0],x=r[1],g=[];for(let _=0;_<3;_++){let S=_*Math.PI/3,M=new we(m,x,1,2);M.translate(0,x/2,0),M.rotateY(S),g.push(M)}let p=An(g,!1),v=p.attributes.normal;for(let _=0;_<v.count;_++)v.setXYZ(_,0,1,0);let y=this._foliageMat(t,{amp:1.4*o,freq:1.8,stiff:2.2});y.alphaTest=.4,this._instanced(p,y,f,[.7,1.3],{shadow:!1,tint:l,sink:.03})}build(){let t=this.track.def.theme,e=t==="alpine",n=r=>Math.round(r),i=this.q.density>=1?1:this.q.density>=.7?.5:0;if(t==="gp")this._species({make:r=>ul(r,"oak"),leafTex:ns("oak",1),barkKind:"oak",count:n(260),far:700,scale:[.85,1.3],seed:11,minD:8}),this._species({make:r=>ul(r,"beech"),leafTex:ns("beech",2),barkKind:"oak",count:n(160),far:400,scale:[.85,1.25],seed:21,minD:8}),this._species({make:r=>p0(r),leafTex:bu(3),barkKind:"pine",count:n(90),far:300,scale:[.85,1.2],seed:31,minD:10}),this._ground(is("green",1),n(9e3*i),0,45,[1.1,.55]),this._ground(is("flowers",2),n(2500*i),0,40,[1.1,.5]),this._ground(ns("bush",4),n(260),3,60,[1.8,1.3],{wind:.4});else if(t==="coast")this._species({make:r=>Qv(r),leafTex:h0(4),barkKind:"palm",count:n(220),far:380,scale:[.85,1.25],seed:41,minD:4,wind:{amp:.5,freq:1.1}}),this._species({make:r=>p0(r),leafTex:bu(5),barkKind:"pine",count:n(110),far:300,scale:[.8,1.15],seed:51,minD:8}),this._ground(is("dry",3),n(7e3*i),0,45,[1.1,.6]),this._ground(ns("bush",6),n(320),2,70,[1.8,1.2],{wind:.4});else if(t==="desert"){let r=m0(7),a=m0(8),o=new at({color:5208638,roughness:.75}),l=this._place(n(300*this.q.density+60),6,500,{pow:1.1,trackBias:.6});this._instanced(r,o,l.filter((c,h)=>h%2===0),[.6,1.4],{tint:.15}),this._instanced(a,o,l.filter((c,h)=>h%2===1),[.6,1.3],{tint:.15}),this._ground(is("dry",9),n(2200*i+300),1,120,[1.2,.7],{wind:.6,tint:.3})}else t==="alpine"?(this._species({make:r=>f0(r,!0),leafTex:Mu(!0,2),barkKind:"pine",count:n(620),far:1800,scale:[.7,1.25],seed:61,minD:3,wind:{amp:.12,freq:.9},tint:.12}),this._ground(is("snow",10),n(1800*i),0,25,[1,.45],{wind:.6})):t==="forest"&&(this._species({make:r=>f0(r,!1),leafTex:Mu(!1,3),barkKind:"pine",count:n(560),far:2600,scale:[.75,1.3],seed:71,minD:2.5,wind:{amp:.2,freq:1}}),this._species({make:r=>ul(r,"beech"),leafTex:ns("beech",7),barkKind:"oak",count:n(300),far:900,scale:[.85,1.35],seed:81,minD:2.5,wind:{amp:.35,freq:1.4}}),this._species({make:r=>ul(r,"birch"),leafTex:ns("birch",8),barkKind:"birch",count:n(140),far:300,scale:[.85,1.2],seed:91,minD:3,wind:{amp:.4,freq:1.6}}),this._ground(u0(1),n(3200*Math.max(.35,i)),0,55,[1.5,1],{wind:.7}),this._ground(ns("bush",9),n(700),0,60,[1.9,1.4],{wind:.5}),this._ground(is("green",11),n(5e3*i),0,30,[1.1,.6]),this._ground(is("green",12),n(1500*i),0,0,[1,.5],{inRunoff:!0}));return this.group}};var pl=class s{static async create(t,e,n=()=>{}){let i=new s;i.engine=t,i.def=e;let r=rt.quality;if(i.scene=new pn,n(.05,"Trazando circuito\u2026"),await Ri(),i.track=new al(e),i.scene.add(i.track.build(r)),n(.25,"Modelando terreno\u2026"),await Ri(),i.terrain=new ol(i.track,r),i.scene.add(i.terrain.build()),n(.45,"Generando cielo y clima\u2026"),await Ri(),i.env=new ll(t,i.scene,i.track,r),n(.6,"Plantando escenario\u2026"),await Ri(),i.scenery=new cl(i.track,i.terrain,r),i.scenery.useVegetation=!0,i.scene.add(i.scenery.build()),n(.68,"Haciendo crecer el bosque\u2026"),await Ri(),i.vegetation=new fl(i.track,i.terrain,r,t.renderer),i.scene.add(i.vegetation.build()),xa.strength.value={storm:2.2,rain:1.4,wet:.9,snow:1,clear:.8}[e.weather]??1,i.env.setLamps(i.scenery.lamps),i.terrain.waterMat){let a=Hf();a.repeat.set(220,220),i.terrain.waterMat.normalMap=a,i.terrain.waterMat.normalScale=new tt(.35,.35),i.terrain.waterMat.needsUpdate=!0,i.waterNormal=a}return n(.75,"Compilando sombreadores\u2026"),await Ri(),i}update(t,e,n){xa.time.value+=t,this.env.update(t,e,n),this.waterNormal&&(this.waterNormal.offset.x+=t*.004,this.waterNormal.offset.y+=t*.0025)}dispose(){this.scene.traverse(t=>{if(t.geometry&&t.geometry.dispose(),t.material){let e=Array.isArray(t.material)?t.material:[t.material];for(let n of e)n.dispose()}}),this.env.dispose()}};var On=9.81,g0=1.2,ml=Math.PI/180;function x0(s,t){if(t<=s[0][0])return s[0][1];for(let e=1;e<s.length;e++)if(t<=s[e][0]){let[n,i]=s[e-1],[r,a]=s[e],o=(t-n)/(r-n);return i+(a-i)*(o*o*(3-2*o))}return s[s.length-1][1]}var Ar=class{constructor(t,e,n={}){this.spec=t,this.track=e,this.ai=!!n.ai,this.tune(n.perf||{}),this.x=0,this.y=0,this.z=0,this.h=0,this.vh=0,this.v=0,this.vy=0,this.lean=0,this.leanVel=0,this.pitch=0,this.pitchVel=0,this.steerAngle=0,this.gear=1,this.rpm=this.idle,this.shiftT=0,this.compF=0,this.compR=0,this.cvF=0,this.cvR=0,this.nitro=.6,this.nitroOn=!1,this.airborne=!1,this.airT=0,this.slip=0,this.wheelspin=0,this.skid=0,this.crashed=!1,this.crashT=0,this.ghostT=0,this.hint=-1,this.proj={},this.lap=0,this.s=0,this.dist=0,this.prevS=0,this.wrongWayT=0,this.events=[],this.input={throttle:0,brake:0,steer:0,rearBrake:0,nitro:!1,wheelie:!1},this.manual=!1,this.draft=0,this.offRoad=!1,this.onCurb=!1,this.accelLong=0,this.limiter=0,this.topSpeedSeen=0}tune(t={}){let e=this.spec,n=t.power??1,i=t.grip??1,r=t.top??1;this.mass=e.mass+60,this.Pmax=e.engine.hp*745.7*n,this.redline=e.engine.redline||12e3,this.idle=e.engine.idle||1e3,this.electric=!!e.engine.electric,this.r=e.model.rear.R,this.wb=e.model.wb,this.vTop=e.topKmh/3.6*r,this.gears=e.engine.gears;let a=this.redline*2*Math.PI/60;this.final=a*this.r/(this.vTop*1.04*this.gears[this.gears.length-1]);let o=0;for(let h=.05;h<=1.0001;h+=.01)o=Math.max(o,x0(e.engine.curve,h)*h*a);this.Tpeak=this.Pmax/o;let l=.92,c=.015*this.mass*On;this.CdA=Math.max(.15,2*(this.Pmax*l-c*this.vTop)/(g0*this.vTop**3)),this.mu=1.28*e.grip*i,this.maxLean=Math.min(e.maxLean*ml,Math.atan(this.mu*1.05)+4*ml),this.leanRate=e.leanRate,this.brakeA=e.brakeG*On*i,this.wheelieA=On*.82/Math.max(.3,e.wheelieTend),this.offroadGrip=e.offroad}place(t,e,n=0){let i=this.track.pointAt(t,e);this.x=i.x,this.z=i.z,this.y=i.y,this.h=this.vh=i.heading,this.v=n,this.vy=0,this.lean=0,this.pitch=0,this.hint=i.i,this.track.project(this.x,this.z,this.hint,this.proj),this.s=this.prevS=this.proj.s,this.dist=this.lap*this.track.L+this.s,this.crashed=!1,this.airborne=!1,this.gear=1,this.rpm=this.idle}get kmh(){return this.v*3.6}ratio(t=this.gear){return this.gears[Math.max(0,Math.min(this.gears.length-1,t-1))]*this.final}torqueAt(t){return this.Tpeak*x0(this.spec.engine.curve,$(t/this.redline,0,1))}shift(t){if(this.electric)return;let e=$(this.gear+t,1,this.gears.length);e!==this.gear&&(this.gear=e,this.shiftT=.09,this.events.push({type:"shift",dir:t}))}step(t,e={}){let n=this.input,i=this.track,r=i.project(this.x,this.z,this.hint,this.proj);this.hint=r.i,this.offRoad=r.offRoad,this.onCurb=r.onCurb;let a=e.wet?.86:e.snow?.8:1,o=(r.offRoad?.25+this.offroadGrip*.62:1)*(r.onRoad||r.onCurb?a:1);if(this.ghostT>0&&(this.ghostT-=t),this.crashed){this._crashStep(t,r);return}let l=this.v/this.r,c=l*this.ratio()*60/(2*Math.PI),h=this.shiftT>0?0:n.throttle;if(!this.electric){if(!this.manual){if(this.shiftT<=0&&c>this.redline*.965&&this.gear<this.gears.length)this.shift(1);else if(this.shiftT<=0&&this.gear>1){let T=l*this.ratio(this.gear-1)*60/(2*Math.PI),H=n.brake>.3?.78:.62;c<this.redline*H*.62&&T<this.redline*.9&&this.shift(-1)}}c=l*this.ratio()*60/(2*Math.PI)}let u=this.electric?0:this.idle+n.throttle*(this.redline*.55-this.idle),d=Math.max(c,this.gear===1&&!this.electric?u*$(1-this.v/9,0,1):0,this.electric?0:this.idle);this.airborne&&!this.electric&&(d=Math.max(d,this.idle+n.throttle*this.redline*.95)),this.rpm=Ze(this.rpm,d,this.airborne?6:18,t),this.shiftT>0&&(this.shiftT-=t,this.rpm*=.995);let f=!1;this.rpm>=this.redline&&(this.rpm=this.redline,f=!0),this.limiter=f?1:0;let m=this.torqueAt(this.rpm)*h;f&&(m*=.15+.5*Math.random());let x=m*this.ratio()*.92/this.r;this.nitroOn=n.nitro&&this.nitro>.02&&!this.airborne&&h>.2,this.nitroOn?(x=x*1.42+this.mass*1.6,this.nitro=Math.max(0,this.nitro-t*.24)):this.nitro=Math.min(1,this.nitro+t*(.012+this.draft*.08));let g=this.mu*o,p=Math.abs(Math.tan(this.lean)),v=Math.sqrt(Math.max(.02,g*g-Math.min(p,g)**2*.85)),y=v*this.mass*On*.95;this.wheelspin=0,(this.ai||e.assist&&n.rearBrake<.3)&&x>y*1.02?(this.tcCut=1-y*1.02/x,x=y*1.02):this.tcCut=0,x>y&&(this.wheelspin=$((x-y)/y,0,1),x=y+(x-y)*.15);let S=n.brake,M=S*this.brakeA*this.mass+n.rearBrake*.32*On*this.mass,E=v*this.mass*On*1.02;this.skid=0,M>E&&(this.skid=$((M-E)/E,0,1),M=E),this.v<.3&&(M=0);let A=.5*g0*this.CdA*(1-this.draft*.35)*(this.nitroOn?.82:1)*this.v*this.v,w=(.015+(r.offRoad?.05+(1-this.offroadGrip)*.16:0))*this.mass*On,b=Math.cos(this.vh-Math.atan2(r.tx,r.tz)),P=this.mass*On*Math.sin(Math.atan(r.grade))*b,D=0;this.airborne?D=-A/this.mass:D=(x-M-A-w*(this.v>.1?1:0)-P)/this.mass,this.accelLong=D,this.v=Math.max(0,this.v+D*t),this.v<.5&&S>.5&&n.throttle<.1&&(this.reverse=!0),n.throttle>.1&&(this.reverse=!1);let U=$(this.v/14,0,1),F=Math.atan(g)+2*ml,q=Math.min(this.maxLean,F+6*ml),V=this.airborne?this.lean*.98:n.steer*q*(.3+.7*U),J=9*(this.leanRate/3),G=(V-this.lean)*J*J-this.leanVel*2*J;this.leanVel+=G*t,this.leanVel=$(this.leanVel,-this.leanRate*1.6,this.leanRate*1.6),this.lean+=this.leanVel*t,this.lean=$(this.lean,-this.maxLean,this.maxLean);let nt=0;if(this.airborne)this.steerAngle=Ze(this.steerAngle,0,4,t);else{let T=On*Math.tan(this.lean),H=g*On*1.03,j=$(T,-H,H);this.v>.5&&(nt=-j/Math.max(this.v,3.5)*$(this.v/4,0,1));let et=$(1-this.v/10,0,1);if(this.steerAngle=Ze(this.steerAngle,n.steer*(.08+.42*et)*(this.reverse?-1:1),10,t),nt+=-this.v*Math.tan(this.steerAngle)/this.wb*et,Math.abs(T)>H*1.25&&this.v>12&&!e.assist){if(this.lowsideT=(this.lowsideT||0)+t,this.lowsideT>.6&&!this.ai){this.crash("lowside");return}}else this.lowsideT=0;this.overLean=$((Math.abs(T)-H)/H,0,1)}let ht=n.rearBrake>.3&&this.v>9?n.rearBrake:0,Et=this.wheelspin*$((Math.abs(this.lean)-.25)*2,0,1)*$((this.v-6)/10,0,1),Ot=$(ht*.9+Et+(r.offRoad?.2:0)+(e.wet?.1:0),0,1);if(!this.airborne){this.h+=nt*t;let T=Ot*(-Math.sign(this.lean)||-n.steer)*$(Math.abs(this.lean)/.5,0,1)*.9;this.h+=T*t*(ht>0?1.6:1);let H=ia(14,1.8,Ot)*(r.offRoad?.6:1);this.vh+=sn(this.h-this.vh)*Math.min(1,H*t)}this.slip=sn(this.h-this.vh);let re=e.assist?.6:.75;if(Math.abs(this.slip)>re){if(this.v>15&&!this.ai&&!e.assist){this.crash("highside");return}this.h=this.vh+Math.sign(this.slip)*re,this.slip=Math.sign(this.slip)*re}this.v*=1-Math.abs(Math.sin(this.slip))*.55*t;let Z=n.wheelie&&this.v>3&&!this.airborne,st=0;if(this.airborne)this.pitchVel+=((n.throttle-n.brake)*1.6-this.pitchVel*.8)*t,this.pitch+=this.pitchVel*t,this.pitch=$(this.pitch,-.7,.9);else{D>this.wheelieA&&h>.6&&(st=$((D-this.wheelieA)*.12,0,this.ai||e.assist?.12:.35)),Z&&(st=Math.max(st,n.throttle>.3?.62:.3)),S>.85&&this.v>8&&-D>this.brakeA*.85&&(st=-.1*S);let T=6,H=(st-this.pitch)*T*T-this.pitchVel*2*T*.9;if(this.pitchVel+=H*t,this.pitch+=this.pitchVel*t,this.pitch>.9){if(!this.ai){this.crash("loop");return}this.pitch=.9}}let Tt=this.reverse?-1:1,dt=this.reverse?Math.min(this.v,2):this.v;this.reverse&&n.brake>.5&&(this.v=Math.min(2,this.v+t*2)),this.x+=Math.sin(this.vh)*dt*t*Tt,this.z+=Math.cos(this.vh)*dt*t*Tt;let yt=i.project(this.x,this.z,this.hint,this.proj),Nt=yt.yBase;this.curbY=yt.y-yt.yBase;let Jt=Math.cos(sn(this.vh-Math.atan2(yt.tx,yt.tz))),me=yt.grade*this.v*Jt,ee=this._lastGround??Nt,Ae=Math.abs(Nt-ee)>2?0:(Nt-ee)/t;if(this._lastGround=Nt,!this.airborne){this.vyC===void 0&&(this.vyC=me);let T=this.vyC-On*t*1.2;me<T&&this.v>15?(this.airborne=!0,this.airT=0,this.vy=this.vyC):(this.vy=Ae,this.y=Nt),this.vyC=me}if(this.airborne&&(this.airT+=t,this.vy-=On*t,this.y+=this.vy*t,this.y<=Nt)){let T=me-this.vy;this.y=Nt,this.airborne=!1,this.events.push({type:"land",impact:T,air:this.airT}),this.cvF-=T*.35,this.cvR-=T*.35;let H=Math.abs(this.pitch-Math.atan(yt.grade));if((H>.7||T>14&&H>.35)&&!this.ai){this.crash("landing");return}this.airT>.4&&(this.nitro=Math.min(1,this.nitro+.05+this.airT*.05)),this.vy=Ae,this.vyC=me}let B=i.barrierD-.45;if(Math.abs(yt.d)>B){let T=Math.sign(yt.d),H=Math.abs(yt.d)-B;this.x-=yt.rx*T*H,this.z-=yt.rz*T*H;let j=Math.atan2(yt.tx,yt.tz),et=sn(this.vh-j),K=this.v*Math.cos(et),_t=this.v*Math.sin(et),ft=T>0?-_t:_t;if(ft>0){let xt=ft;if(_t=-_t*.25,K*=1-.3*$(xt/14,0,1),this.v=Math.hypot(K,_t),this.vh=j+Math.atan2(_t,K),this.h=this.vh+this.slip*.3,this.events.push({type:"wall",impact:xt,side:T,x:this.x,y:this.y+.6,z:this.z}),xt>(e.assist?16:12.5)&&!this.ai){this.crash("wall");return}if(xt>15&&this.ai){this.crash("wall");return}}else this.v*=1-.4*t,this.events.push({type:"scrape",x:this.x,y:this.y+.5,z:this.z,side:T})}let Je=(yt.offRoad?.012:0)+(yt.onCurb?.008:0),ne=Je?(Math.random()-.5)*Je*this.v*.4:0,ie=Je?(Math.random()-.5)*Je*this.v*.4:0,Ut=-D*.006,_e=D*.005,Dt=90,L=12;this.cvF+=((Ut+ne-this.compF)*Dt-this.cvF*L)*t,this.cvR+=((_e+ie-this.compR)*Dt-this.cvR*L)*t,this.compF=$(this.compF+this.cvF*t,-.04,.09),this.compR=$(this.compR+this.cvR*t,-.04,.08),this._progress(yt),this.topSpeedSeen=Math.max(this.topSpeedSeen,this.v)}_progress(t){let e=this.track.L,n=t.s,i=n-this.prevS;i<-e/2?(this.lap++,i+=e,this.events.push({type:"lap"})):i>e/2&&(this.lap--,i-=e),this.prevS=n,this.s=n,this.dist=this.lap*e+n;let r=Math.atan2(t.tx,t.tz);Math.cos(sn(this.vh-r))<-.3&&this.v>3?this.wrongWayT+=1/120:this.wrongWayT=Math.max(0,this.wrongWayT-1/60)}crash(t){this.crashed||(this.crashed=!0,this.crashT=0,this.crashSpin=(Math.random()-.5)*6,this.crashSide=this.lean!==0?Math.sign(this.lean):Math.random()<.5?-1:1,this.events.push({type:"crash",kind:t,v:this.v,x:this.x,y:this.y,z:this.z}))}_crashStep(t,e){this.crashT+=t,this.lean=Ze(this.lean,this.crashSide*1.45,6,t),this.pitch=Ze(this.pitch,0,4,t),this.h+=this.crashSpin*t,this.crashSpin*=1-1.2*t,this.v=Math.max(0,this.v-6.5*t-this.v*.6*t),this.x+=Math.sin(this.vh)*this.v*t,this.z+=Math.cos(this.vh)*this.v*t;let n=this.track.project(this.x,this.z,this.hint,this.proj);this.hint=n.i;let i=this.track.barrierD-.6;if(Math.abs(n.d)>i){let r=Math.sign(n.d),a=Math.abs(n.d)-i;this.x-=n.rx*r*a,this.z-=n.rz*r*a,this.v*=.5}this.y=n.y+.05,this.rpm=Ze(this.rpm,this.idle,3,t),this.v>2&&this.events.push({type:"scrape",x:this.x,y:this.y+.2,z:this.z,side:0}),this._progress(n),this.crashT>2.4&&this.respawn()}respawn(){let t=this.s-4,e=this.track.pointAt(t,0),n=this.lap,i=this.track.lineD?this.track.lineD[e.i]*.4:0;this.place(t,i,10),this.lap=n,this._progress(this.track.project(this.x,this.z,this.hint,this.proj)),this.prevS=this.s,this.dist=this.lap*this.track.L+this.s,this.ghostT=2.5,this.events.push({type:"respawn"})}visual(t={}){return t.speed=this.reverse?-Math.min(this.v,2):this.v,t.steerAngle=this.steerAngle+$(this.slip,-.5,.5)*.6,t.lean=this.lean,t.pitch=this.pitch,t.compF=this.compF,t.compR=this.compR,t.braking=this.input.brake>.1||this.input.rearBrake>.1,t.wheelSpinExtra=this.wheelspin*25+(this.airborne?this.input.throttle*30:0),t}};var va=9.81,ya=class{constructor(t,e,{skill:n=.93,seed:i=1,wet:r=!1}={}){this.p=t,this.track=e,this.skill=n,this.r=$t(i),this.lane=0,this.laneTarget=0,this.mistakeT=0,this.mistake=0,this.wet=r,this.rubber=1,this.nitroHold=0,this.buildProfile()}buildProfile(){let t=this.p,e=Math.min(t.mu*(this.wet?.86:1),Math.tan(t.maxLean)*.88)*va*.88*(.94+this.skill*.06),n=Math.min(t.brakeA,t.mu*va)*(this.wet?.68:.76)*this.skill;this.profile=this.track.speedProfile(e,n,t.vTop*1.02)}update(t,e){let n=this.p,i=this.track,r=n.input;if(n.crashed){r.throttle=0,r.brake=0,r.steer=0;return}let a=i.N,o=i.ds,l=n.hint<0?0:n.hint,c=null,h=1e9;for(let D of e){if(D.phys===n||D.phys.crashed)continue;let U=D.phys.dist-n.dist;if(U<-i.L/2&&(U+=i.L),U>i.L/2&&(U-=i.L),U>0&&U<28){let F=D.phys.proj.d-n.proj.d;Math.abs(F)<2.6&&U<h&&(h=U,c={gap:U,dl:F,v:D.phys.v,d:D.phys.proj.d})}}let u=i.halfW-1.2,d=i.lineD[l];if(c&&c.v<n.v+2){let D=c.d- -i.halfW,F=i.halfW-c.d>D?1:-1;this.laneTarget=$(c.d+F*2.6-d,-u-d,u-d)}else this.laneTarget*=Math.max(0,1-t*.6);this.lane+=$(this.laneTarget-this.lane,-t*2.2,t*2.2);let f=u,m=$(d+this.lane,-f,f);n.v<14&&(m=n.proj.d+(m-n.proj.d)*$(n.v/14,.15,1));let x=-(n.proj.d-m),g=sn(n.vh-i.lineH[l]),p=Math.max(n.v,3),v=p*Math.sin(g),y=(l+Math.round(p*.28/o))%a,_=i.lineK[y],S=$(2.4-p*.012,1.3,2.4),M=p*p*_-S*S*x-2*S*v*.9;M=$(M,-va*2,va*2);let E=-Math.atan(M/va);if(r.steer=$(E/Math.max(.2,n.maxLean),-1,1),n.v<5&&Math.abs(g)>.9){let U=(l+Math.round(8/o))%a,F=i.c.x[U]+i.c.rx[U]*m,q=i.c.z[U]+i.c.rz[U]*m,V=sn(Math.atan2(F-n.x,q-n.z)-n.vh);r.steer=$(-V*2.5,-1,1)}let A=(l+Math.round(n.v*.3/o))%a,w=this.profile[A]*this.rubber*(.985+this.skill*.015);this.mistake>0?(this.mistake-=t,w*=1.07):this.r()<t*.012*(1.1-this.skill)*10&&(this.mistake=.6+this.r()*.6),c&&c.gap<7&&Math.abs(c.dl)<1.4&&(w=Math.min(w,c.v-.5));let b=w-n.v;r.throttle=$(b*.45+.35,0,1),r.brake=$(-b*.35-.05,0,1),b<-.5&&(r.throttle=0),r.rearBrake=0,r.wheelie=!1,this.nitroHold>0&&(this.nitroHold-=t);let P=!0;for(let D=1;D<60;D+=6)if(this.profile[(l+D*2)%a]<n.vTop*.92){P=!1;break}r.nitro=P&&n.nitro>.25&&n.v>n.vTop*.45&&(this.nitroHold>0||this.r()<t*.8*this.skill),r.nitro&&this.nitroHold<=0&&(this.nitroHold=1.5+this.r()*2)}};var v0=["PERSECUCI\xD3N","LEJANA","A BORDO","RUEDA","TV"],gl=class{constructor(t,e){this.cam=t,this.track=e,this.mode=0,this.pos=new C,this.look=new C,this.yaw=0,this.shake=0,this.fov=62,this.roll=0,this.initialized=!1,this._v=new C,this._up=new C(0,1,0),this.tvSpots=[],this._buildTV()}_buildTV(){let t=this.track;for(let e=0;e<t.L;e+=170){let n=Math.floor(e/170)%2?1:-1,i=t.pointAt(e,n*(t.barrierD+7));this.tvSpots.push({s:e,x:i.x,y:i.y+4+Math.random()*5,z:i.z})}}next(){this.mode=(this.mode+1)%4,this.initialized=!1}set(t){this.mode=t,this.initialized=!1}addShake(t){this.shake=Math.min(1.5,this.shake+t)}update(t,e,n={}){let i=e.phys,r=e.model,a=n.forceMode??this.mode,o=this.cam,l=i.v,c=i.vh+$(sn(i.h-i.vh),-.4,.4)*.5;this.initialized||(this.yaw=c),this.yaw+=sn(c-this.yaw)*(1-Math.exp(-(a===1?4:6)*t));let h=Math.sin(this.yaw),u=Math.cos(this.yaw),d=n.lookBack?-1:1,f=0,m=60+$(l/90,0,1)*18+(i.nitroOn?7:0);if(a===0||a===1){let g=a===1,p=(g?7.6:4.6)+$(l/80,0,1)*(g?1.6:1),v=g?2.5:1.55,y=i.x-h*p*d,_=i.z-u*p*d,S=i.y+v+(i.airborne?.3:0);this.initialized||this.pos.set(y,S,_);let M=y-this.pos.x,E=_-this.pos.z,A=M*h+E*u,w=M-A*h,b=E-A*u,P=1-Math.exp(-28*t),D=1-Math.exp(-(g?4.5:6.5)*t);this.pos.x+=A*h*P+w*D,this.pos.z+=A*u*P+b*D,this.pos.y+=(S-this.pos.y)*(1-Math.exp(-5*t));let U=this.track.project(this.pos.x,this.pos.z,i.hint,this._proj||(this._proj={})),F=(Math.abs(U.d)<this.track.barrierD+3?U.y:this.pos.y-5)+.6;this.pos.y<F&&(this.pos.y=F),this.look.set(i.x+h*6*d,i.y+.95,i.z+u*6*d),f=i.lean*.2,o.position.copy(this.pos)}else if(a===2){let g=r,p=g.ctx,v=p.headTop?p.headTop[0]-.42:.1,y=(g.height||1)+.16,_=g.worldPoint([v,y,0],this._v);o.position.copy(_);let S=g.worldPoint([v+10*d,y-.6,0],new C);this.look.copy(S),f=i.lean*.8,m+=6}else if(a===3){let g=r,p=g.worldPoint([g.spec.model.wb/2+.55,.32,0],this._v);o.position.copy(p),this.look.copy(g.worldPoint([g.spec.model.wb/2+10,.3,0],new C)),f=i.lean*.5,m+=4}else if(a===4){let g=this.tvSpots[0],p=1/0;for(let y of this.tvSpots){let _=i.s-y.s;_<-this.track.L/2&&(_+=this.track.L),_>this.track.L/2&&(_-=this.track.L);let S=Math.abs(_+40);S<p&&(p=S,g=y)}o.position.set(g.x,g.y,g.z),this.look.set(i.x,i.y+.6,i.z);let v=o.position.distanceTo(this.look);m=$(2*Math.atan(5/v)*57.3,8,55),f=0}if(this.initialized=!0,this.shake>0){let g=this.shake*.12;o.position.x+=(Math.random()-.5)*g,o.position.y+=(Math.random()-.5)*g,o.position.z+=(Math.random()-.5)*g,this.shake=Math.max(0,this.shake-t*2.2)}let x=$((l-50)/40,0,1)*(a<2?.012:.006)+(i.offRoad?.02*$(l/20,0,1):0);x>0&&(o.position.y+=(Math.random()-.5)*x),this.roll=Ze(this.roll,f,6,t),o.up.set(Math.sin(this.roll)*Math.cos(this.yaw)*-1,Math.cos(this.roll),Math.sin(this.roll)*Math.sin(this.yaw)),o.lookAt(this.look),this.fov=Ze(this.fov,m,3,t),o.fov=this.fov,o.updateProjectionMatrix()}};var xl=class{constructor(t,{additive:e=!1,tex:n}){this.max=t,this.pos=new Float32Array(t*3),this.vel=new Float32Array(t*3),this.col=new Float32Array(t*4),this.size=new Float32Array(t),this.life=new Float32Array(t),this.maxLife=new Float32Array(t),this.grow=new Float32Array(t),this.drag=new Float32Array(t),this.grav=new Float32Array(t),this.alpha0=new Float32Array(t),this.next=0;let i=new Gt;this.aPos=new Vt(this.pos,3).setUsage(ea),this.aCol=new Vt(this.col,4).setUsage(ea),this.aSize=new Vt(this.size,1).setUsage(ea),i.setAttribute("position",this.aPos),i.setAttribute("aColor",this.aCol),i.setAttribute("aSize",this.aSize),this.mat=new ve({uniforms:{tex:{value:n},uScale:{value:600},fogColor:{value:new ot},fogDensity:{value:0}},vertexShader:`attribute vec4 aColor; attribute float aSize; uniform float uScale; varying vec4 vC; varying float vFog;
        void main(){ vC = aColor; vec4 mv = modelViewMatrix * vec4(position,1.0); gl_PointSize = aSize * uScale / max(0.1, -mv.z); gl_Position = projectionMatrix * mv; vFog = -mv.z; }`,fragmentShader:`uniform sampler2D tex; uniform vec3 fogColor; uniform float fogDensity; varying vec4 vC; varying float vFog;
        void main(){ vec4 t = texture2D(tex, gl_PointCoord); float f = 1.0 - exp(-fogDensity*fogDensity*vFog*vFog);
          vec3 c = mix(vC.rgb, fogColor, ${e?"0.0":"f"}); gl_FragColor = vec4(c, t.a * vC.a * ${e?"(1.0 - f)":"1.0"}); }`,transparent:!0,depthWrite:!1,blending:e?ms:Hi}),this.points=new Ai(i,this.mat),this.points.frustumCulled=!1,this.points.renderOrder=e?5:4}emit(t,e,n,i,r,a,{life:o=1,size:l=1,grow:c=1,r:h=1,g:u=1,b:d=1,a:f=1,drag:m=1,grav:x=0}={}){let g=this.next;this.next=(this.next+1)%this.max,this.pos[g*3]=t,this.pos[g*3+1]=e,this.pos[g*3+2]=n,this.vel[g*3]=i,this.vel[g*3+1]=r,this.vel[g*3+2]=a,this.col[g*4]=h,this.col[g*4+1]=u,this.col[g*4+2]=d,this.col[g*4+3]=f,this.alpha0[g]=f,this.size[g]=l,this.life[g]=o,this.maxLife[g]=o,this.grow[g]=c,this.drag[g]=m,this.grav[g]=x}update(t){for(let e=0;e<this.max;e++){if(this.life[e]<=0){this.col[e*4+3]=0;continue}this.life[e]-=t;let n=Math.max(0,1-this.drag[e]*t);this.vel[e*3]*=n,this.vel[e*3+1]=this.vel[e*3+1]*n-this.grav[e]*t,this.vel[e*3+2]*=n,this.pos[e*3]+=this.vel[e*3]*t,this.pos[e*3+1]+=this.vel[e*3+1]*t,this.pos[e*3+2]+=this.vel[e*3+2]*t,this.size[e]+=this.grow[e]*t;let i=this.life[e]/this.maxLife[e];this.col[e*4+3]=this.alpha0[e]*Math.min(1,i*1.5)*Math.min(1,(1-i)*8+.2)}this.aPos.needsUpdate=!0,this.aCol.needsUpdate=!0,this.aSize.needsUpdate=!0}},vl=class{constructor(t,e,n){this.scene=t,this.q=e;let i=e.density;this.smoke=new xl(Math.round(1600*i+400),{tex:Uf()}),this.glow=new xl(Math.round(1200*i+300),{additive:!0,tex:aa()}),t.add(this.smoke.points,this.glow.points),this.theme=n,this._buildSkids(),this.flames=new Map,this._v=new C,this._w=new C}_buildSkids(){this.skMax=2400,this.skPos=new Float32Array(2400*4*3);let e=new Uint32Array(2400*6);for(let i=0;i<2400;i++){let r=i*4;e.set([r,r+1,r+2,r+1,r+3,r+2],i*6)}let n=new Gt;this.skAttr=new Vt(this.skPos,3).setUsage(ea),n.setAttribute("position",this.skAttr),n.setIndex(new Vt(e,1)),this.skMesh=new it(n,new De({color:657930,transparent:!0,opacity:.55,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-4,polygonOffsetUnits:-4})),this.skMesh.frustumCulled=!1,this.skMesh.renderOrder=2,this.scene.add(this.skMesh),this.skNext=0,this.skLast=new Map}skid(t,e,n,i,r,a,o=.09){let l=this.skLast.get(t),c={x:e,y:n+.015,z:i,rx:r,rz:a};if(l&&(e-l.x)**2+(i-l.z)**2<25){let h=this.skNext;this.skNext=(this.skNext+1)%this.skMax;let u=this.skPos,d=h*12;u[d]=l.x-l.rx*o,u[d+1]=l.y,u[d+2]=l.z-l.rz*o,u[d+3]=l.x+l.rx*o,u[d+4]=l.y,u[d+5]=l.z+l.rz*o,u[d+6]=e-r*o,u[d+7]=c.y,u[d+8]=i-a*o,u[d+9]=e+r*o,u[d+10]=c.y,u[d+11]=i+a*o,this.skDirty=!0}this.skLast.set(t,c)}skidBreak(t){this.skLast.delete(t)}sparks(t,e,n,i=10,r=0,a=0,o=8){for(let l=0;l<i;l++){let c=r*o*.6+(Math.random()-.5)*o,h=a*o*.6+(Math.random()-.5)*o,u=Math.random()*o*.6;this.glow.emit(t,e,n,c,u,h,{life:.25+Math.random()*.35,size:.06+Math.random()*.06,grow:-.05,r:1,g:.65+Math.random()*.3,b:.25,a:1,drag:1.5,grav:9})}}tireSmoke(t,e,n,i,r,a=1){let o=.82+Math.random()*.1;this.smoke.emit(t+(Math.random()-.5)*.2,e+.15,n+(Math.random()-.5)*.2,i*.3+(Math.random()-.5),.6+Math.random(),r*.3+(Math.random()-.5),{life:1.6+Math.random(),size:.6,grow:2.2,r:o,g:o,b:o,a:.35*a,drag:1.2,grav:-.3})}dust(t,e,n,i,r,a,o=1){this.smoke.emit(t+(Math.random()-.5)*.3,e+.1,n+(Math.random()-.5)*.3,i*.2+(Math.random()-.5)*2,.5+Math.random()*1.5,r*.2+(Math.random()-.5)*2,{life:1.2+Math.random(),size:.5,grow:2.5,r:a[0],g:a[1],b:a[2],a:.45*o,drag:1.6,grav:.4})}spray(t,e,n,i,r,a=1){this.smoke.emit(t+(Math.random()-.5)*.3,e+.15,n+(Math.random()-.5)*.3,i*.5+(Math.random()-.5)*2,.8+Math.random()*1.2,r*.5+(Math.random()-.5)*2,{life:.6+Math.random()*.4,size:.4,grow:2.8,r:.75,g:.78,b:.82,a:.28*a,drag:2,grav:2})}exhaustPuff(t,e,n,i,r,a,o=!1){o?this.glow.emit(t,e,n,i,r,a,{life:.12,size:.25,grow:1.5,r:1,g:.5,b:.15,a:.9,drag:4}):this.smoke.emit(t,e,n,i,r+.3,a,{life:.6,size:.12,grow:.7,r:.6,g:.6,b:.62,a:.12,drag:2,grav:-.2})}explosionDust(t,e,n,i){for(let r=0;r<24;r++)this.dust(t,e,n,(Math.random()-.5)*12,(Math.random()-.5)*12,i,1.2);this.sparks(t,e+.3,n,30,0,0,10)}attachFlames(t){let e=t.model.exhausts;if(!e||!e.length)return;let n=Nf(),i=[];for(let r of e){let a=new De({map:n,transparent:!0,blending:ms,depthWrite:!1,side:xe,toneMapped:!1}),o=new _s(Math.max(.035,r.r*.85),.7,12,1,!0);o.translate(0,.35,0);let l=new it(o,a),c=new C(...r.dir).normalize();l.quaternion.setFromUnitVectors(new C(0,1,0),c),l.position.set(...r.pos),l.visible=!1,t.model.groups.chassis.add(l),i.push({m:l,mat:a,e:r})}this.flames.set(t,i)}updateFlames(t,e,n,i){let r=this.flames.get(t);if(r)for(let a of r){let o=e||n>0;if(a.m.visible=o,!o)continue;let l=e?.8+Math.random()*.5:.35+Math.random()*.3;a.m.scale.set(e?1.2:1,l,e?1.2:1),a.mat.opacity=e?.95:.8,a.mat.color.setRGB(e?.6:1,e?.8:.7,1)}}removeBike(t){let e=this.flames.get(t);if(e)for(let n of e)n.m.removeFromParent();this.flames.delete(t)}update(t,e,n,i){this.smoke.update(t),this.glow.update(t);let a=n.domElement.height/(2*Math.tan(e.fov*Math.PI/360));if(this.smoke.mat.uniforms.uScale.value=a,this.glow.mat.uniforms.uScale.value=a,i)for(let o of[this.smoke.mat,this.glow.mat])o.uniforms.fogColor.value.copy(i.color),o.uniforms.fogDensity.value=i.density||0;this.skDirty&&(this.skAttr.needsUpdate=!0,this.skDirty=!1)}dispose(){for(let t of[this.smoke.points,this.glow.points,this.skMesh])t.geometry.dispose(),t.material.dispose(),t.removeFromParent()}};var yl=class{constructor(t){this.n=t,this.cap=4096,this.data=new Float32Array(this.cap*t*14),this.frames=0,this.acc=0}record(t,e){if(this.acc+=t,this.acc<1/30)return;if(this.acc-=1/30,this.frames>=this.cap){if(this.cap>=30*60*15)return;let i=new Float32Array(this.cap*2*this.n*14);i.set(this.data),this.data=i,this.cap*=2}let n=this.frames*this.n*14;e.forEach((i,r)=>{let a=i.phys,o=n+r*14,l=this.data;l[o]=a.x,l[o+1]=a.y+(a.curbY||0),l[o+2]=a.z,l[o+3]=a.h,l[o+4]=a.lean,l[o+5]=a.pitch,l[o+6]=a.steerAngle,l[o+7]=a.v,l[o+8]=a.rpm,l[o+9]=a.input.throttle,l[o+10]=a.compF,l[o+11]=a.compR,l[o+12]=(a.nitroOn?1:0)+(a.crashed?2:0)+(a.input.brake>.1?4:0),l[o+13]=a.s}),this.frames++}get duration(){return this.frames/30}sample(t,e,n={}){let i=Math.max(0,Math.min(this.frames-1.001,e*30)),r=Math.floor(i),a=i-r,o=this.data,l=this.n,c=(r*l+t)*14,h=((r+1)*l+t)*14,u=m=>o[c+m]+(o[h+m]-o[c+m])*a;n.x=u(0),n.y=u(1),n.z=u(2);let d=o[h+3]-o[c+3];for(;d>Math.PI;)d-=Math.PI*2;for(;d<-Math.PI;)d+=Math.PI*2;n.h=o[c+3]+d*a,n.lean=u(4),n.pitch=u(5),n.steerAngle=u(6),n.speed=u(7),n.rpm=u(8),n.throttle=u(9),n.compF=u(10),n.compR=u(11);let f=o[c+12];return n.nitro=(f&1)!==0,n.crashed=(f&2)!==0,n.braking=(f&4)!==0,n.s=o[c+13],n}},Ps=class{constructor(){this.buf=[],this.acc=0}reset(){this.buf=[],this.acc=0}record(t,e){for(this.acc+=t;this.acc>=1/30;)this.acc-=1/30,this.buf.push(e.x,e.y+(e.curbY||0),e.z,e.h,e.lean,e.pitch,e.steerAngle,e.v)}toArray(){return new Float32Array(this.buf)}static sample(t,e,n={}){let i=t.length/8;if(i<2)return null;let r=Math.max(0,Math.min(i-1.001,e*30)),a=Math.floor(r),o=r-a,l=a*8,c=(a+1)*8,h=d=>t[l+d]+(t[c+d]-t[l+d])*o;n.x=h(0),n.y=h(1),n.z=h(2);let u=t[c+3]-t[l+3];for(;u>Math.PI;)u-=Math.PI*2;for(;u<-Math.PI;)u+=Math.PI*2;return n.h=t[l+3]+u*o,n.lean=h(4),n.pitch=h(5),n.steerAngle=h(6),n.speed=h(7),n.done=r>=i-1.01,n}static encode(t){let e=new Uint8Array(t.buffer,t.byteOffset,t.byteLength),n="";for(let i=0;i<e.length;i+=32768)n+=String.fromCharCode.apply(null,e.subarray(i,i+32768));return btoa(n)}static decode(t){let e=atob(t),n=new Uint8Array(e.length);for(let i=0;i<e.length;i++)n[i]=e.charCodeAt(i);return new Float32Array(n.buffer)}};var _l=Math.PI*2,Ml=class{constructor(t,e){this.race=e,this.root=I("div",{class:"hud screen show"}),t.appendChild(this.root),this.el={};let n=this.el;n.pos=I("div",{class:"hud-pos"},I("span",{class:"p"},"1"),I("span",{class:"of"},"/8")),n.laps=I("div",{class:"hud-laps"},I("div",{class:"lap"},"VUELTA 1/3"),I("div",{class:"times"})),n.tower=I("div",{class:"hud-tower"}),n.mapC=br(230,230,"hud-map"),n.gaugeC=br(290,290,"hud-gauge"),n.leanC=br(220,130,"hud-lean"),n.center=I("div",{class:"hud-center"}),n.cam=I("div",{class:"hud-cam"},""),n.fps=I("div",{class:"hud-fps"},""),n.ghost=I("div",{class:"hud-ghost"},""),this.root.append(n.pos,n.laps,n.tower,n.mapC,n.gaugeC,n.leanC,n.center,n.cam,n.fps,n.ghost),this.rows=new Map,this._msgT=0,this._toastT=0,this.maxLean=0,this._buildMap(),rt.settings.touch&&this._touch(t)}setVisible(t){this.root.style.display=t?"":"none",this.touchEl&&(this.touchEl.style.display=t?"":"none")}_buildMap(){let t=this.race.track,{x:e,z:n,N:i}=t.c,r=t.bounds,o=this.el.mapC.width,l=o*.1,c=(o-l*2)/r.size;this.mapT=(m,x)=>[o/2+(m-r.cx)*c*-1,o/2+(x-r.cz)*c*-1];let h=document.createElement("canvas");h.width=o,h.height=o;let u=h.getContext("2d");u.lineCap="round",u.lineJoin="round";let d=new Path2D;for(let m=0;m<=i;m+=2){let[x,g]=this.mapT(e[m%i],n[m%i]);m===0?d.moveTo(x,g):d.lineTo(x,g)}d.closePath(),u.strokeStyle="rgba(0,0,0,0.55)",u.lineWidth=o*.06,u.stroke(d),u.strokeStyle="rgba(200,225,255,0.85)",u.lineWidth=o*.022,u.stroke(d),u.strokeStyle="rgba(0,229,255,0.9)",u.lineWidth=o*.008,u.stroke(d);let f=this.mapT(e[0],n[0]);u.fillStyle="#fff",u.beginPath(),u.arc(f[0],f[1],o*.02,0,_l),u.fill(),this.mapBase=h}_drawMap(t,e){let n=this.el.mapC,i=n.getContext("2d"),r=n.width;i.clearRect(0,0,r,r),i.drawImage(this.mapBase,0,0);for(let a of t){if(a===e)continue;let[o,l]=this.mapT(a.phys.x,a.phys.z);i.fillStyle=a.color,i.strokeStyle="#000",i.lineWidth=r*.008,i.beginPath(),i.arc(o,l,r*.024,0,_l),i.fill(),i.stroke()}if(this.race.ghostPos){let[a,o]=this.mapT(this.race.ghostPos.x,this.race.ghostPos.z);i.fillStyle="rgba(64,224,255,0.6)",i.beginPath(),i.arc(a,o,r*.026,0,_l),i.fill()}if(e){let[a,o]=this.mapT(e.phys.x,e.phys.z),l=e.phys.vh;i.save(),i.translate(a,o),i.rotate(-l),i.fillStyle="#00e5ff",i.strokeStyle="#fff",i.lineWidth=r*.01,i.shadowColor="#00e5ff",i.shadowBlur=r*.05,i.beginPath(),i.moveTo(0,-r*.045),i.lineTo(r*.032,r*.032),i.lineTo(-r*.032,r*.032),i.closePath(),i.fill(),i.stroke(),i.restore()}}_drawGauge(t,e){let n=this.el.gaugeC,i=n.getContext("2d"),r=n.width,a=r/2,o=r*.42;i.clearRect(0,0,r,r);let l=Math.PI*.75,c=Math.PI*2.25,h=t.redline,u=$(t.rpm/h,0,1),d=i.createRadialGradient(a,a,o*.2,a,a,o*1.15);d.addColorStop(0,"rgba(10,16,30,0.85)"),d.addColorStop(1,"rgba(5,8,16,0.35)"),i.fillStyle=d,i.beginPath(),i.arc(a,a,o*1.12,0,_l),i.fill();let f=Math.ceil(h/1e3);for(let A=0;A<=f;A++){let w=A*1e3/h;if(w>1.0001)break;let b=l+(c-l)*w,P=w>.85;i.strokeStyle=P?"#ff3b4e":"rgba(220,235,255,0.85)",i.lineWidth=r*.012,i.beginPath(),i.moveTo(a+Math.cos(b)*o*.86,a+Math.sin(b)*o*.86),i.lineTo(a+Math.cos(b)*o*.98,a+Math.sin(b)*o*.98),i.stroke(),!e.engine.electric&&(f<=10||A%2===0)&&(i.fillStyle=P?"#ff6a78":"rgba(200,220,240,0.8)",i.font=`700 ${r*.05}px Orbitron, sans-serif`,i.textAlign="center",i.textBaseline="middle",i.fillText(String(A),a+Math.cos(b)*o*.74,a+Math.sin(b)*o*.74))}i.strokeStyle="rgba(255,59,78,0.5)",i.lineWidth=r*.03,i.beginPath(),i.arc(a,a,o*.92,l+(c-l)*.85,c),i.stroke();let m=i.createLinearGradient(0,r,r,0);m.addColorStop(0,"#00e5ff"),m.addColorStop(.6,"#8a6cff"),m.addColorStop(1,"#ff2bd6"),i.strokeStyle=m,i.lineWidth=r*.05,i.lineCap="round",i.shadowColor=u>.9?"#ff3b4e":"#00e5ff",i.shadowBlur=r*.05,i.beginPath(),i.arc(a,a,o*1.04,l,l+(c-l)*u),i.stroke(),i.shadowBlur=0,i.strokeStyle="rgba(255,255,255,0.08)",i.lineWidth=r*.022,i.beginPath(),i.arc(a,a,o*.56,l,c),i.stroke(),i.strokeStyle=t.nitroOn?"#ffffff":"#ff2bd6",i.shadowColor="#ff2bd6",i.shadowBlur=t.nitroOn?r*.06:r*.02,i.beginPath(),i.arc(a,a,o*.56,l,l+(c-l)*$(t.nitro,0,1)),i.stroke(),i.shadowBlur=0;let x=l+(c-l)*u;i.strokeStyle="#ffffff",i.lineWidth=r*.012,i.shadowColor="#ffffff",i.shadowBlur=r*.03,i.beginPath(),i.moveTo(a+Math.cos(x)*o*.62,a+Math.sin(x)*o*.62),i.lineTo(a+Math.cos(x)*o*1,a+Math.sin(x)*o*1),i.stroke(),i.shadowBlur=0;let g=rt.settings.units==="mph",p=Math.round(t.v*(g?2.23694:3.6));i.fillStyle="#ffffff",i.textAlign="center",i.textBaseline="alphabetic",i.font=`900 ${r*.2}px Orbitron, sans-serif`,i.fillText(String(p),a,a+r*.06),i.fillStyle="rgba(160,190,220,0.9)",i.font=`700 ${r*.045}px Orbitron, sans-serif`,i.fillText(g?"MPH":"KM/H",a,a+r*.13);let v=e.engine.electric?"D":String(t.gear),y=!e.engine.electric&&u>.93;i.fillStyle=y?"#ff3b4e":"rgba(0,229,255,0.16)";let _=a,S=a+r*.27,M=r*.14,E=r*.14;i.beginPath(),i.roundRect?i.roundRect(_-M/2,S-E/2,M,E,r*.02):i.rect(_-M/2,S-E/2,M,E),i.fill(),i.fillStyle=y?"#fff":"#00e5ff",i.font=`900 ${r*.1}px Orbitron, sans-serif`,i.textBaseline="middle",i.fillText(v,_,S+r*.005),i.fillStyle="rgba(160,190,220,0.8)",i.font=`700 ${r*.035}px Orbitron, sans-serif`,i.fillText(e.engine.electric?"MOTOR":"x1000 RPM",a,a-r*.09),t.nitroOn&&(i.fillStyle="#ff2bd6",i.font=`900 ${r*.05}px Orbitron, sans-serif`,i.fillText("NITRO",a,a-r*.16))}_drawLean(t){let e=this.el.leanC,n=e.getContext("2d"),i=e.width,r=e.height;n.clearRect(0,0,i,r);let a=Math.abs(t.lean)*57.3;t.crashed||(this.maxLean=Math.max(this.maxLean*.9995,a));let o=i/2,l=r*.82,c=r*.95;n.strokeStyle="rgba(255,255,255,0.12)",n.lineWidth=r*.05,n.beginPath(),n.arc(o,c,l,Math.PI*1.08,Math.PI*1.92),n.stroke();let h=t.maxLean;n.strokeStyle="rgba(255,59,78,0.45)";for(let f of[-1,1]){let m=-Math.PI/2+f*h*1.2;n.beginPath(),n.arc(o,c,l,Math.min(m,-Math.PI/2+f*Math.PI*.42),Math.max(m,-Math.PI/2+f*Math.PI*.42)),n.stroke()}let u=-Math.PI/2+t.lean*1.2,d=a>h*57.3*.92?"#ff3b4e":"#00e5ff";n.strokeStyle=d,n.lineWidth=r*.05,n.lineCap="round",n.shadowColor=d,n.shadowBlur=r*.12,n.beginPath(),n.moveTo(o,c),n.lineTo(o+Math.cos(u)*l*.92,c+Math.sin(u)*l*.92),n.stroke(),n.shadowBlur=0,n.fillStyle="#fff",n.font=`900 ${r*.26}px Orbitron, sans-serif`,n.textAlign="center",n.textBaseline="alphabetic",n.fillText(`${Math.round(a)}\xB0`,o,c-l*.28),n.fillStyle="rgba(160,190,220,0.8)",n.font=`700 ${r*.1}px Orbitron, sans-serif`,n.fillText(`INCLINACI\xD3N \xB7 M\xC1X ${Math.round(this.maxLean)}\xB0`,o,r*.16)}_drawTower(t,e){let n=this.el.tower,i=t[0];t.forEach((r,a)=>{let o=this.rows.get(r);o||(o=I("div",{class:"tw-row"+(r===e?" me":"")},I("span",{class:"n"}),I("span",{class:"c",style:{background:r.color}}),I("span",{class:"nm"},r.spec.short),I("span",{class:"g"})),n.appendChild(o),this.rows.set(r,o),o.style.position="absolute",o.style.left="0",o.style.right="0"),o.style.transform=`translateY(${a*26}px)`,o.children[0].textContent=String(a+1);let l="";if(r.finished)l=a===0?Ke(r.finishTime):_f(r.finishTime-i.finishTime);else if(a>0){let c=i.phys.dist-r.phys.dist,h=Math.max(20,r.phys.v);l=c>this.race.track.L?`+${Math.floor(c/this.race.track.L)}V`:`+${(c/h).toFixed(1)}`}else l="L\xCDDER";o.children[3].textContent=l,o.classList.toggle("out",!!r.phys.crashed)}),n.style.height=`${t.length*26}px`}message(t,e="",n=1600,i=""){let r=this.el.center;r.innerHTML="",r.appendChild(I("div",{class:"hud-msg "+i},t)),e&&r.appendChild(I("div",{class:"hud-sub"},e)),this._msgT=n/1e3}countdown(t){let e=this.el.center;e.innerHTML="",e.appendChild(I("div",{class:"hud-count"+(t===0?" go":"")},t===0?"\xA1YA!":String(t))),this._msgT=1}toast(t,e="#fff",n=1500){this._toastEl&&this._toastEl.remove(),this._toastEl=I("div",{class:"hud-toast",style:{color:e}},t),this.root.appendChild(this._toastEl),this._toastT=n/1e3}camName(t){this.el.cam.textContent=`C\xC1MARA \xB7 ${t}`,this.el.cam.classList.add("show"),clearTimeout(this._camT),this._camT=setTimeout(()=>this.el.cam.classList.remove("show"),1400)}update(t){let e=this.race,n=e.player;if(!n)return;let i=n.phys,r=this.el,a=e.order.length,o=e.order.indexOf(n)+1;r.pos.children[0].textContent=e.mode==="trial"||e.mode==="free"?"\u2014":String(o),r.pos.children[1].textContent=e.mode==="trial"||e.mode==="free"?"":`/${a}`,r.pos.classList.toggle("first",o===1&&a>1);let l=$(i.lap+1,1,e.laps);r.laps.children[0].textContent=e.mode==="free"?`VUELTA ${i.lap+1}`:`VUELTA ${l}/${e.laps}`;let c=r.laps.children[1],h=e.time-(n.lapStart??0),u=n.bestLap;if(c.innerHTML=`<b>TOTAL</b>${Ke(e.time*1e3)}<br><b>VUELTA</b>${Ke(Math.max(0,h)*1e3)}<br><b>MEJOR</b>${Ke(u?u*1e3:0)}`,e.mode!=="trial"&&e.mode!=="free"&&this._drawTower(e.order,n),this._drawMap(e.bikes,n),this._drawGauge(i,n.spec),this._drawLean(i),rt.settings.showFps?r.fps.textContent=`${Math.round(e.game.engine.fps)} FPS`:r.fps.textContent="",e.ghostDelta!==void 0&&e.ghostDelta!==null){let d=e.ghostDelta;r.ghost.textContent=`FANTASMA ${d<=0?"\u2212":"+"}${Math.abs(d).toFixed(2)} s`,r.ghost.className="hud-ghost "+(d<=0?"ahead":"behind")}else r.ghost.textContent="";this._msgT>0&&(this._msgT-=t,this._msgT<=0&&(this.el.center.innerHTML="")),this._toastT>0&&(this._toastT-=t,this._toastT<=0&&this._toastEl&&(this._toastEl.remove(),this._toastEl=null))}_touch(t){let e=I("div",{class:"touch"}),n=I("div",{class:"tb steer"},I("div",{class:"knob"})),i=I("div",{class:"tb thr"},"GAS"),r=I("div",{class:"tb brk"},"FRENO"),a=I("div",{class:"tb nit"},"NITRO"),o=I("div",{class:"tb pause"},"II");e.append(n,i,r,a,o),t.appendChild(e),this.touchEl=e;let l=n.firstChild,c=(f,m)=>{let x=p=>{p.preventDefault(),f.classList.add("on"),ze.setTouch(m,1)},g=p=>{p.preventDefault(),f.classList.remove("on"),ze.setTouch(m,0)};f.addEventListener("pointerdown",x),f.addEventListener("pointerup",g),f.addEventListener("pointercancel",g),f.addEventListener("pointerleave",g)};c(i,"throttle"),c(r,"brake"),c(a,"nitro"),o.addEventListener("pointerdown",f=>{f.preventDefault(),this.race.togglePause()});let h=null,u=f=>{let m=n.getBoundingClientRect(),x=$((f.clientX-m.left)/m.width*2-1,-1,1);ze.setTouch("steer",x),l.style.transform=`translateX(${x*m.width*.36}px)`};n.addEventListener("pointerdown",f=>{f.preventDefault(),h=f.pointerId,n.setPointerCapture(h),u(f)}),n.addEventListener("pointermove",f=>{f.pointerId===h&&u(f)});let d=f=>{f.pointerId===h&&(h=null,ze.setTouch("steer",0),l.style.transform="")};n.addEventListener("pointerup",d),n.addEventListener("pointercancel",d)}dispose(){this.root.remove(),this.touchEl&&this.touchEl.remove();for(let t of["throttle","brake","steer","nitro"])ze.setTouch(t,0)}};var _a=1/120,ny=[25,20,16,13,11,10,9,8,7,6,5,4,3,2,1],iy={facil:.86,normal:.93,mitico:1},bl={sand:[.78,.55,.38],snow:[.95,.97,1],grass:[.42,.36,.26],gravel:[.7,.68,.64],concrete:[.5,.5,.52],dryGrass:[.62,.55,.4],forest:[.35,.3,.22],asphaltDark:[.4,.4,.42]},wl=class{constructor(t,e){this.game=t,this.cfg=e,this.mode=e.mode||"race",this.laps=this.mode==="free"?9999:e.laps||3,this.time=0,this.phase="loading",this.paused=!1,this.bikes=[],this.order=[],this.finishOrder=[],this._acc=0,this._vis={}}async load(t){let e=this.game.engine,n=this.cfg.trackDef;this.ts=await pl.create(e,n,t),this.track=this.ts.track,this.scene=this.ts.scene,t(.82,"Preparando parrilla\u2026");let i=rt.quality;this.effects=new vl(this.scene,i,this.track.theme),this.env={wet:this.track.wet,snow:n.weather==="snow",assist:rt.settings.assist};let r=un[this.cfg.bikeId]||He[0],a=this.mode==="race"||this.mode==="champ"?$(this.cfg.rivals??7,0,11):0,o=He.filter(y=>y.id!==r.id),l=$t((this.cfg.seed??Date.now())&65535);for(let y=o.length-1;y>0;y--){let _=Math.floor(l()*(y+1));[o[y],o[_]]=[o[_],o[y]]}let c=o.slice(0,a),h=c.length+1,u=this.cfg.difficulty||"normal",d=h-1;this.mode==="champ"&&this.cfg.gridSlot!==void 0?d=$(this.cfg.gridSlot,0,h-1):u==="facil"?d=Math.min(h-1,Math.floor(h*.35)):u==="normal"&&(d=Math.min(h-1,Math.floor(h*.6)));let f=[],m=0;for(let y=0;y<h;y++)y===d?f.push({spec:r,livery:this.cfg.livery??0,player:!0}):f.push({spec:c[m++],livery:Math.floor(l()*3),player:!1});let x=iy[u]??.93,g=new Ar(r,this.track);f.forEach((y,_)=>{let S=new ts(y.spec,y.livery,{castShadow:i.shadows>0});this.scene.add(S.root);let M={};if(!y.player){let P=new Ar(y.spec,this.track),D=.97+l()*.06;M={power:g.Pmax/g.mass/(P.Pmax/P.mass)*D,top:g.vTop/P.vTop*(.98+l()*.04),grip:g.mu/P.mu,maxLean:Math.max(g.maxLean,.5)}}let E=new Ar(y.spec,this.track,{ai:!y.player,perf:M});M.maxLean&&(E.maxLean=M.maxLean);let A=Math.floor(_/2),w=(_%2?1:-1)*this.track.W*.22;E.place(-10-A*7-_%2*2.5,w,0),E.lap=-1,E._progress(E.proj),E.prevS=E.s,E.dist=E.lap*this.track.L+E.s,E.manual=y.player&&rt.settings.transmission==="manual";let b={id:_,spec:y.spec,livery:y.livery,model:S,phys:E,isPlayer:y.player,color:S.livery.base==="#111111"||S.livery.base==="#0c0c0e"||S.livery.base==="#0b0b0d"||S.livery.base==="#101012"||S.livery.base==="#141414"||S.livery.base==="#0d0f12"?S.livery.accent:S.livery.base,lapStart:0,lapTimes:[],bestLap:0,finished:!1,finishTime:0,popT:0};y.player||(b.ai=new ya(E,this.track,{skill:x*(.97+l()*.05),seed:_*31+7,wet:this.env.wet||this.env.snow})),this.effects.attachFlames(b),this.bikes.push(b),y.player&&(this.player=b)}),this.order=this.bikes.slice();let p=this.ts.env.T;if(p.night||p.overcast||this.track.def.weather==="storm"){let y=this.player.model.headlights[0];if(y){let _=new Ki(16773853,900,140,.42,.45,1.4);_.position.set(y.pos[0],y.pos[1],y.pos[2]);let S=new Le;S.position.set(y.pos[0]+10,y.pos[1]-1.2,y.pos[2]),(this.player.model.groups[y.group]||this.player.model.groups.chassis).add(_,S),_.target=S,_.castShadow=!1,this.headSpot=_}}if(this.mode==="trial"){this.ghostRec=new Ps;let y=rt.data.ghosts[n.id];if(y&&y.data)try{this.ghostData=Ps.decode(y.data),this.ghostSpec=un[y.bike]||r}catch{this.ghostData=null}this._makeGhostModel(this.ghostSpec||r)}this.cam=new gl(this.game.engine.camera,this.track),this.cam.set(rt.settings.camera||0),this.recorder=new yl(this.bikes.length),t(.92,"Afinando motores\u2026"),this.hud=new Ml(this.game.ui.layer,this),this.hud.setVisible(!1),this.voices=new Map,It.ready&&(this.playerVoice=It.engine(this.player.spec,{positional:!1})),this.ts.env.onThunder=()=>It.thunder();let v=this.game.engine;v.setScene(this.scene,v.camera),this._placeIntroCamera(0),this._syncModels(0),v.renderer.compile(this.scene,v.camera),t(1,"\xA1Listo!")}_makeGhostModel(t){this.ghostModel&&(this.ghostModel.dispose(),this.ghostModel=null);let e=new ts(t,0,{castShadow:!1});e.setGhost(4251903),e.root.visible=!1,this.scene.add(e.root),this.ghostModel=e}start(){this.phase="intro",this.phaseT=0,this.hud.setVisible(!0),this.hud.message(this.track.def.name,`${this.track.def.place.toUpperCase()} \xB7 ${this.mode==="free"?"PASEO LIBRE":this.mode==="trial"?"CONTRARRELOJ":`${this.laps} VUELTAS`}`,2600),It.playMusic("race"),It.whoosh()}update(t){if(this.paused||this.phase==="loading"){this.game.engine.render;return}let e=ze.state,n=ze.edges;if(n.pause&&this.phase!=="results"){this.togglePause();return}if(this.phase==="replay"){this._replayUpdate(t);return}this.phaseT+=t;let i=this.player;if(this.phase==="intro")this._placeIntroCamera(this.phaseT),(this.phaseT>3.2||n.confirm&&this.phaseT>.4)&&(this.phase="countdown",this.phaseT=0,this.lightsOn=0,this.cam.initialized=!1);else if(this.phase==="countdown"){let l=Math.min(5,Math.floor(this.phaseT/.75)+1);l!==this.lightsOn&&this.phaseT<3.75&&(this.lightsOn=l,this.track.setStartLights(l),It.beep(!1),l>=3&&this.hud.countdown(6-l)),this.goAt||(this.goAt=3.75+.3+Math.random()*.8),this.phaseT>=this.goAt&&(this.phase="race",this.phaseT=0,this.time=0,this.track.setStartLights(0,!0),setTimeout(()=>this.track.setStartLights(0),2500),this.hud.countdown(0),It.beep(!0),ze.rumble(.6,.6,200))}let r=i.phys.input,a=this.phase==="race"||this.phase==="finished";if(r.throttle=e.throttle,r.brake=e.brake,r.steer=e.steer,r.rearBrake=e.rearBrake,r.nitro=e.nitro,r.wheelie=e.wheelie,i.finished&&this.phase==="finished"&&this._autopilot(i),n.shiftUp&&(i.phys.manual=!0,i.phys.shift(1)),n.shiftDown&&(i.phys.manual=!0,i.phys.shift(-1)),n.camera&&(this.cam.next(),rt.settings.camera=this.cam.mode,this.hud.camName(v0[this.cam.mode])),n.reset&&a&&!i.phys.crashed&&(i.phys.v<4||i.phys.wrongWayT>.5)&&i.phys.respawn(),e.nitro&&!this._nitroWas&&i.phys.nitro>.05&&a&&It.nitro(),this._nitroWas=e.nitro,a)for(let l of this.bikes)l.ai&&!(l.finished&&l.coast)&&l.ai.update(t,this.bikes);this._rubberBand(),this._acc+=t;let o=0;for(;this._acc>=_a&&o<12;)if(this._acc-=_a,o++,a){for(let l of this.bikes)l.phys.step(_a,this.env);this._collisions()}else for(let l of this.bikes){let c=l.phys,h=l.isPlayer?e.throttle:this.phase==="countdown"?.35+Math.sin(this.phaseT*3+l.id)*.25:.1;c.input.throttle=h,c.rpm=Ze(c.rpm,c.idle+h*c.redline*.75,6,_a),c.v=0}a&&(this.time+=t),this._draft(),this._progressAndLaps(),this._processEvents(t),this._syncModels(t),this._fx(t),this.phase==="race"||this.phase==="countdown"?this.cam.update(t,i,{lookBack:e.lookBack}):this.phase==="finished"&&this.cam.update(t,i,{forceMode:this.phaseT<2.5?0:4}),this.recorder.record(a?t:0,this.bikes),this.mode==="trial"&&a&&this._ghostUpdate(t),this._audio(t),this.ts.update(t,this.game.engine.camera,new C(i.phys.x,i.phys.y,i.phys.z)),this.effects.update(t,this.game.engine.camera,this.game.engine.renderer,this.scene.fog),this._postFx(t),this.hud.update(t),this._dashT=(this._dashT||0)-t,this._dashT<=0&&this.cam.mode===2&&(this._dashT=.08,vu(i.model.mats.dashCanvas,i.phys.v*3.6,i.phys.rpm/i.phys.redline,i.phys.gear,i.spec,i.phys.nitro),i.model.mats.dashTex.needsUpdate=!0),i.phys.wrongWayT>1.2&&this.phase==="race"&&!this._wwShown&&(this._wwShown=!0,this.hud.message("DIRECCI\xD3N CONTRARIA","PULSA R PARA VOLVER A PISTA",2e3,"hud-warn"),It.warn()),i.phys.wrongWayT<=.2&&(this._wwShown=!1),this.phase==="finished"&&this.phaseT>7&&this._toResults()}_autopilot(t){t.autoAI||(t.autoAI=new ya(t.phys,this.track,{skill:.8,seed:99})),t.autoAI.update(_a,this.bikes),t.phys.input.throttle*=.6}_placeIntroCamera(t){let e=this.game.engine.camera,n=this.track.pointAt(-30+t*6,0),i=t*.35+.6,r=18-t*2;e.position.set(n.x+Math.sin(i)*r,n.y+4+t*.6,n.z+Math.cos(i)*r);let a=this.track.pointAt(-20,0);e.up.set(0,1,0),e.lookAt(a.x,a.y+.8,a.z),e.fov=55,e.updateProjectionMatrix()}_rubberBand(){if(this.mode!=="race"&&this.mode!=="champ")return;let t=this.player;for(let e of this.bikes){if(!e.ai)continue;let n=e.phys.dist-t.phys.dist,i=1;n>60?i=1-$((n-60)/600,0,.06):n<-60&&(i=1+$((-n-60)/500,0,.06)),e.ai.rubber=Ze(e.ai.rubber,i,.5,1/60)}}_collisions(){let t=this.bikes,e=.42;for(let n=0;n<t.length;n++){let i=t[n].phys;if(!(i.ghostT>0))for(let r=n+1;r<t.length;r++){let a=t[r].phys;if(a.ghostT>0)continue;let o=a.x-i.x,l=a.z-i.z;if(o*o+l*l>9||Math.abs(i.y-a.y)>1.2)continue;let c=null;for(let y of[-.45,.45]){let _=i.x+Math.sin(i.h)*y*i.wb,S=i.z+Math.cos(i.h)*y*i.wb;for(let M of[-.45,.45]){let E=a.x+Math.sin(a.h)*M*a.wb,A=a.z+Math.cos(a.h)*M*a.wb,w=E-_,b=A-S,P=Math.hypot(w,b);P<2*e&&(!c||P<c.d)&&(c={d:P,nx:w/(P||1),nz:b/(P||1)})}}if(!c)continue;let h=2*e-c.d,u=i.mass,d=a.mass,f=u+d;i.x-=c.nx*h*(d/f),i.z-=c.nz*h*(d/f),a.x+=c.nx*h*(u/f),a.z+=c.nz*h*(u/f);let m=Math.sin(i.vh)*i.v,x=Math.cos(i.vh)*i.v,g=Math.sin(a.vh)*a.v,p=Math.cos(a.vh)*a.v,v=(g-m)*c.nx+(p-x)*c.nz;if(v<0){let y=-1.25*v/(1/u+1/d),_=m-y/u*c.nx,S=x-y/u*c.nz,M=g+y/d*c.nx,E=p+y/d*c.nz;i.v=Math.hypot(_,S),i.vh=Math.atan2(_,S),a.v=Math.hypot(M,E),a.vh=Math.atan2(M,E),i.h+=sn(i.vh-i.h)*.3,a.h+=sn(a.vh-a.h)*.3;let A=-v;i.events.push({type:"bump",impact:A,x:(i.x+a.x)/2,y:i.y+.5,z:(i.z+a.z)/2,other:t[r]}),a.events.push({type:"bump",impact:A,x:(i.x+a.x)/2,y:a.y+.5,z:(i.z+a.z)/2,other:t[n]}),A>11&&(Math.random()<.5?i.crash("contact"):a.crash("contact"))}}}}_draft(){for(let t of this.bikes){let e=0,n=t.phys;for(let i of this.bikes){if(i===t)continue;let r=i.phys,a=r.x-n.x,o=r.z-n.z,l=a*Math.sin(n.vh)+o*Math.cos(n.vh);if(l<2||l>24)continue;let c=Math.abs(a*Math.cos(n.vh)-o*Math.sin(n.vh));c>1.6||(e=Math.max(e,(1-(l-2)/22)*(1-c/1.6)*$((n.v-25)/20,0,1)))}n.draft=Ze(n.draft,e,3,1/60)}}_progressAndLaps(){for(let e of this.bikes){let n=e.phys;for(let i of n.events)if(i.type==="lap"){if(n.lap>=1&&!e.finished){let r=this.time-e.lapStart;e.lapTimes.push(r),e.lapStart=this.time;let a=!e.bestLap||r<e.bestLap;a&&(e.bestLap=r),e.isPlayer&&this._playerLap(r,a),n.lap>=this.laps?this._finish(e):e.isPlayer&&n.lap===this.laps-1&&this.mode!=="free"&&(this.hud.message("\xDALTIMA VUELTA","",1800),It.lap())}n.lap===0&&(e.lapStart=0)}}this.order=this.bikes.slice().sort((e,n)=>e.finished&&n.finished?e.finishTime-n.finishTime:e.finished?-1:n.finished?1:n.phys.dist-e.phys.dist);let t=this.order.indexOf(this.player);this._lastPos!==void 0&&t!==this._lastPos&&this.phase==="race"&&this.time>3&&this.mode!=="trial"&&this.mode!=="free"&&(t<this._lastPos?this.hud.toast(`\u25B2 P${t+1}`,"#3dff8a",900):this.hud.toast(`\u25BC P${t+1}`,"#ff3b4e",900)),this._lastPos=t}_playerLap(t,e){let n=this.track.def,i=rt.data.records[n.id]||{},r=`VUELTA ${Ke(t*1e3)}`,a="";!i.lap||t<i.lap?(i.lap=t,i.lapBike=this.player.spec.id,rt.data.records[n.id]=i,rt.save(),a="\xA1NUEVO R\xC9CORD DE PISTA!"):e&&this.player.lapTimes.length>1&&(a="VUELTA R\xC1PIDA"),this.hud.message(r,a,2e3),It.lap(),this.mode==="trial"&&this._ghostLapDone(t)}_finish(t){if(t.finished=!0,t.finishTime=this.time,this.finishOrder.push(t),t.isPlayer){let e=this.finishOrder.length;this.phase="finished",this.phaseT=0,this.mode==="trial"?this.hud.message("\xA1SESI\xD3N COMPLETA!","",3e3):this.hud.message(e===1?"\xA1VICTORIA!":`${e}\xBA PUESTO`,e<=3?"\xA1PODIO!":"BANDERA A CUADROS",4e3),It.fanfare(),ze.rumble(.5,.8,400);let n=rt.data.stats;if(this.mode==="race"||this.mode==="champ"){n.races++,e===1&&n.wins++,e<=3&&n.podiums++;let i=rt.data.records[this.track.def.id]||{};(!i.race||this.time<i.race)&&(i.race=this.time,i.raceBike=t.spec.id,i.raceLaps=this.laps),rt.data.records[this.track.def.id]=i}rt.save()}else t.coast=!1}_processEvents(t){let e=this.player;for(let n of this.bikes){let i=n.phys,r=n.isPlayer||Math.hypot(i.x-e.phys.x,i.z-e.phys.z)<70;for(let a of i.events)switch(a.type){case"wall":r&&this.effects.sparks(a.x,a.y,a.z,Math.min(40,6+a.impact*2),0,0,4+a.impact*.5),n.isPlayer&&(this.cam.addShake($(a.impact/12,.2,1)),It.impact($(a.impact/14,.2,1.2)),ze.rumble(.8,.4,160),this._damage=Math.min(1,(this._damage||0)+a.impact/20));break;case"scrape":r&&Math.random()<.4&&this.effects.sparks(a.x,a.y,a.z,2,0,0,5),n.isPlayer&&(this._scrape=1);break;case"bump":r&&this.effects.sparks(a.x,a.y,a.z,6,0,0,5),n.isPlayer&&(this.cam.addShake($(a.impact/10,.1,.8)),It.impact($(a.impact/12,.15,.9)),ze.rumble(.6,.6,120));break;case"crash":r&&this.effects.explosionDust(a.x,a.y,a.z,bl[this.track.def.runoffMat]||bl.gravel),n.isPlayer?(this.hud.message("\xA1CA\xCDDA!","REAPARECIENDO\u2026",2200,"hud-warn"),It.crash(),this.cam.addShake(1.5),ze.rumble(1,1,500),rt.data.stats.crashes++,this._damage=1):r&&It.impact(.6),this.effects.skidBreak(n.id+"r"),this.effects.skidBreak(n.id+"f");break;case"land":n.isPlayer&&a.impact>3&&(this.cam.addShake($(a.impact/12,.1,.9)),It.impact($(a.impact/16,.1,.7)),ze.rumble(.7,.3,120),a.air>.5&&this.hud.toast(`\xA1SALTO! ${a.air.toFixed(1)} s`,"#00e5ff",900));break;case"shift":a.dir>0&&(n.popT=.09,n.isPlayer&&It.shiftClunk(),r&&Math.random()<.5&&It.pop(null,n.isPlayer?.7:.3));break;case"respawn":n.isPlayer&&this.hud.toast("DE VUELTA EN PISTA","#fff",1e3);break;default:break}i.events.length=0}}_syncModels(t){let e=this._vis;for(let n of this.bikes){let i=n.phys,r=n.model;r.root.position.set(i.x,i.y+(i.curbY||0),i.z),r.root.rotation.set(0,i.h,0),r.root.rotateZ(-(i.proj.bank||0)*Math.cos(sn(i.h-Math.atan2(i.proj.tx||0,i.proj.tz||1)))*(i.airborne?0:1)),i.visual(e),r.animate(e,t),i.ghostT>0?r.root.visible=Math.floor(i.ghostT*10)%2===0:r.root.visible=!0}}_fx(t){let e=this.effects,n=bl[this.track.def.runoffMat]||bl.gravel,i=this.game.engine.camera.position;for(let r of this.bikes){let a=r.phys,o=r.model;if((a.x-i.x)**2+(a.z-i.z)**2>160*160){e.updateFlames(r,!1,0,t);continue}let c=Math.cos(a.vh),h=-Math.sin(a.vh),u=o.worldPoint([-o.wb/2,.02,0],e._v);if(!a.airborne&&!a.crashed&&(Math.abs(a.slip)>.1||a.wheelspin>.25||a.skid>.3)&&!a.offRoad){let m=$(Math.abs(a.slip)*3+a.wheelspin+a.skid,0,1.5);Math.random()<.6*m+.2&&e.tireSmoke(u.x,u.y,u.z,Math.sin(a.vh)*a.v,Math.cos(a.vh)*a.v,$(m,.3,1)),e.skid(r.id+"r",u.x,u.y,u.z,c,h)}else e.skidBreak(r.id+"r");if(a.skid>.35&&!a.offRoad&&!a.airborne){let m=o.worldPoint([o.wb/2,.02,0],e._w);e.skid(r.id+"f",m.x,m.y,m.z,c,h,.06)}else e.skidBreak(r.id+"f");if(a.offRoad&&a.v>4&&!a.airborne){let m=$(a.v/20,.2,1.5);Math.random()<m&&e.dust(u.x,u.y,u.z,Math.sin(a.vh)*a.v,Math.cos(a.vh)*a.v,n,$(m,.4,1))}if(this.env.wet&&a.v>12&&!a.offRoad&&Math.random()<$(a.v/50,0,.9)&&e.spray(u.x,u.y,u.z,Math.sin(a.vh)*a.v*-.1,Math.cos(a.vh)*a.v*-.1,$(a.v/60,.3,1)),r.popT-=t,a.input.throttle<.05&&a.rpm>a.redline*.55&&!a.electric&&Math.random()<.03&&(r.popT=.06),e.updateFlames(r,a.nitroOn,r.popT,t),!a.electric&&o.exhausts.length&&Math.random()<.08){let m=o.exhausts[0],x=o.worldPoint(m.pos,e._w);e.exhaustPuff(x.x,x.y,x.z,0,.2,0,r.popT>0)}}}_audio(t){if(!It.ready)return;let e=this.game.engine.camera;It.setListener(e);let n=this.player,i=n.phys;if(this.playerVoice){let l=this.cam.mode>=2;this.playerVoice.vol=l?1.1:.85,this.playerVoice.set(i.rpm,i.input.throttle,{limiter:i.limiter>0,decel:i.input.throttle<.05&&i.v>8})}if(It.layers({speed:i.v,slip:(Math.abs(i.slip)>.1||i.skid>.3||i.wheelspin>.3)&&!i.offRoad&&!i.airborne?$(Math.abs(i.slip)*2+i.skid+i.wheelspin*.6,0,1):0,scrape:this._scrape||0,rumble:(i.offRoad?$(i.v/25,0,1):0)+(i.onCurb?.5:0)}),this._scrape=Math.max(0,(this._scrape||0)-t*6),this._voiceT=(this._voiceT||0)-t,this._voiceT<=0){this._voiceT=.35;let l=this.bikes.filter(c=>!c.isPlayer).map(c=>[c,(c.phys.x-e.position.x)**2+(c.phys.z-e.position.z)**2]).filter(([,c])=>c<140*140).sort((c,h)=>c[1]-h[1]).slice(0,3).map(([c])=>c);for(let[c,h]of this.voices)l.includes(c)||(h.stop(),this.voices.delete(c));for(let c of l)this.voices.has(c)||this.voices.set(c,It.engine(c.spec,{positional:!0,lite:!0}))}let r=this._lastCam||e.position.clone(),a=(e.position.x-r.x)/Math.max(t,.001),o=(e.position.z-r.z)/Math.max(t,.001);this._lastCam=e.position.clone();for(let[l,c]of this.voices){let h=l.phys;c.setPosition(h.x,h.y+.6,h.z);let u=h.x-e.position.x,d=h.z-e.position.z,f=Math.hypot(u,d)||1,m=Math.sin(h.vh)*h.v,x=Math.cos(h.vh)*h.v,g=((m-a)*u+(x-o)*d)/f,p=$(343/(343+g),.7,1.4);c.vol=.9,c.set(h.rpm,h.input.throttle,{dopp:p,limiter:h.limiter>0})}}_postFx(t){let e=this.game.engine.fx;if(!e)return;let n=this.player.phys,i=rt.settings.motionBlur,r=$((n.v-35)/55,0,1),a=i?r*.45+(n.nitroOn?.55:0):0;e.uBlur.value=Ze(e.uBlur.value,this.phase==="race"||this.phase==="finished"?a:0,4,t),e.uCA.value=.0012+(n.nitroOn?.004:0),e.uTint.value.setRGB(.75,.9,1.25),e.uTintAmt.value=Ze(e.uTintAmt.value,n.nitroOn?.25:0,5,t),this._damage=Math.max(0,(this._damage||0)-t*1.5),e.uDamage.value=this._damage*.35,e.uFlash.value=Math.max(0,e.uFlash.value-t*3),e.uVignette.value=.3+r*.1}_ghostUpdate(t){let e=this.player,n=this.time-e.lapStart;if(e.phys.lap>=0&&this.ghostRec.record(t,e.phys),this.ghostData&&e.phys.lap>=0){let i=Ps.sample(this.ghostData,n,this._gs||(this._gs={}));if(i&&!i.done){let r=this.ghostModel;r.root.visible=!0,r.root.position.set(i.x,i.y,i.z),r.root.rotation.set(0,i.h,0),r.animate({speed:i.speed,lean:i.lean,pitch:i.pitch,steerAngle:i.steerAngle},t),this.ghostPos=i;let a=this.track.project(i.x,i.z,this._ghint??-1,this._gproj||(this._gproj={}));this._ghint=a.i;let o=a.s-e.phys.s;o>this.track.L/2&&(o-=this.track.L),o<-this.track.L/2&&(o+=this.track.L),this.ghostDelta=o/Math.max(10,e.phys.v)}else this.ghostModel.root.visible=!1,this.ghostPos=null,this.ghostDelta=null}}_ghostLapDone(t){let e=this.track.def,n=this.ghostRec.toArray();this.ghostRec.reset();let i=rt.data.ghosts[e.id];(!i||!i.lap||t<i.lap)&&(rt.data.ghosts[e.id]={bike:this.player.spec.id,lap:t,data:Ps.encode(n)},rt.save(),this.ghostData=n,(!this.ghostSpec||this.ghostSpec.id!==this.player.spec.id)&&(this.ghostSpec=this.player.spec,this._makeGhostModel(this.player.spec)),this.hud.toast("NUEVO FANTASMA GUARDADO","#40e0ff",1600))}_toResults(){if(this.phase==="results")return;this.phase="results";let t=this.player.finishTime/Math.max(1,this.laps*this.track.L);for(let n of this.order){if(n.finished)continue;let i=this.laps*this.track.L-n.phys.dist;n.finished=!0,n.estimated=!0,n.finishTime=this.time+i*t*(1.02+Math.random()*.03)}this.order.sort((n,i)=>n.finishTime-i.finishTime);let e=this.order.map((n,i)=>({pos:i+1,bikeId:n.spec.id,name:n.spec.name,short:n.spec.short,color:n.color,livery:n.livery,time:n.finishTime,best:n.bestLap,player:n.isPlayer,points:ny[i]||0}));this.hud.setVisible(!1),this.silence(),this.game.onRaceFinished(this,e)}togglePause(){this.phase==="results"||this.phase==="replay"||(this.paused=!this.paused,this.paused?(this.silence(),this.game.ui.pauseMenu(this)):(this.game.ui.closeModal(),this.playerVoice&&this.playerVoice.fade(.4)))}silence(){this.playerVoice&&this.playerVoice.fade(0,.2);for(let[,t]of this.voices||[])t.fade(0,.2);It.silenceLayers()}startReplay(){this.phase="replay",this.replayT=0,this.cam.set(4),this.replayCamT=0,this.replayFocus=this.player,this.hud.setVisible(!1);for(let t of this.bikes)t.model.root.visible=!0;this.ghostModel&&(this.ghostModel.root.visible=!1),this.playerVoice&&this.playerVoice.fade(.5)}_replayUpdate(t){let e=this.recorder;this.replayT+=t,this.replayT>e.duration&&(this.replayT=0);let n=this._rs||(this._rs={});if(this.bikes.forEach((r,a)=>{let o=e.sample(a,this.replayT,n),l=r.model;l.root.position.set(o.x,o.y,o.z),l.root.rotation.set(0,o.h,0),l.animate({speed:o.speed,lean:o.lean,pitch:o.pitch,steerAngle:o.steerAngle,compF:o.compF,compR:o.compR,braking:o.braking},t);let c=r.phys;c.x=o.x,c.y=o.y,c.z=o.z,c.h=c.vh=o.h,c.v=o.speed,c.lean=o.lean,c.rpm=o.rpm,c.input.throttle=o.throttle,c.nitroOn=o.nitro,c.s=o.s,c.crashed=o.crashed,c.slip=0,c.airborne=!1,this.effects.updateFlames(r,o.nitro,0,t)}),this.replayCamT+=t,this.replayCamT>5){this.replayCamT=0;let r=[4,0,2,4,1,3];this._rcm=((this._rcm||0)+1)%r.length,this.cam.set(r[this._rcm]),Math.random()<.3?this.replayFocus=this.bikes[Math.floor(Math.random()*this.bikes.length)]:this.replayFocus=this.player}this.cam.update(t,this.replayFocus,{}),this._audio(t),this.ts.update(t,this.game.engine.camera,this.replayFocus.model.root.position),this.effects.update(t,this.game.engine.camera,this.game.engine.renderer,this.scene.fog);let i=this.game.engine.fx;i&&(i.uBlur.value=0,i.uTintAmt.value=.12,i.uTint.value.setRGB(1.05,1,.92),i.uDamage.value=0)}stopReplay(){this.phase="results",this.silence()}dispose(){this.silence(),this.playerVoice&&this.playerVoice.stop();for(let[,e]of this.voices||[])e.stop();this.voices?.clear(),this.hud?.dispose(),this.effects?.dispose();for(let e of this.bikes)e.model.dispose();this.ghostModel?.dispose(),this.ts?.dispose();let t=this.game.engine.fx;t&&(t.uBlur.value=0,t.uTintAmt.value=0,t.uDamage.value=0,t.uFlash.value=0)}};var wu=class{constructor(){this.engine=new Ko(document.getElementById("stage")),this.engine.adaptive=!0,this.ui=new rl(this),this.race=null,this.state="boot"}async boot(){let t=document.getElementById("boot-fill"),e=document.getElementById("boot-msg"),n=async(a,o)=>{t.style.width=`${a}%`,o&&(e.textContent=o),await Ri()};await n(5,"Cargando tipograf\xEDas\u2026");try{await Promise.race([document.fonts?.ready,iu(1500)])}catch{}await n(20,"Fabricando neum\xE1ticos\u2026"),oa(!1),oa(!0),await n(35,"Tejiendo fibra de carbono\u2026"),$o(),Zo(),await n(50,"Construyendo el garaje\u2026"),this.garage=new il(this.engine);let i=un[rt.data.garage.bike]||He[0];this.garage.setBike(i,rt.data.garage.livery[i.id]??0),await n(75,"Calentando motores\u2026"),this.garage.activate(),this.engine.renderer.compile(this.garage.scene,this.garage.camera),await n(100,"\xA1Listo!"),this.engine.onUpdate=a=>this.update(a),this.engine.onError=a=>{this._errShown||(this._errShown=!0,console.error(a))},this.engine.start(),document.getElementById("boot").classList.add("hide"),this.state="menu",this.ui.mainMenu();let r=()=>{It.init(),It.playMusic(this.race?"race":"menu"),window.removeEventListener("pointerdown",r),window.removeEventListener("keydown",r)};window.addEventListener("pointerdown",r),window.addEventListener("keydown",r),window.__game=this,window.__ready=!0}update(t){ze.update(t),this.state==="race"&&this.race?this.race.update(t):this.garage.update(t),this.ui.update(t)}applyQuality(){this.engine.applyQuality(),this.state==="race"&&this.race?this.engine.setScene(this.race.scene,this.engine.camera):this.garage.activate()}async startRace(t){if(this._loading)return;this._loading=!0,this.lastCfg=t,It.init(),It.stopMusic();let e=this.ui.loading(t.trackDef);await iu(120),this.garage.deactivate();try{this.race&&(this.race.dispose(),this.race=null);let n=new wl(this,t);await n.load((i,r)=>e(i,r)),this.race=n,this.state="race",this.ui.hideScreens(),this.engine.setScene(n.scene,this.engine.camera),n.start()}catch(n){console.error(n),this.ui.error(n)}this._loading=!1}restartRace(){if(!this.lastCfg)return;let t={...this.lastCfg,seed:(this.lastCfg.seed||1)+1};this.startRace(t)}exitRace(){this.race&&(this.race.dispose(),this.race=null),this.state="menu",this.garage.clearPodium();let t=un[rt.data.garage.bike]||He[0];this.garage.setBike(t,rt.data.garage.livery[t.id]??0),this.garage.activate(),this.engine.renderer.toneMappingExposure=1,this.ui.mainMenu()}onRaceFinished(t,e){let n=rt.data.stats;n.km=(n.km||0)+(t.player.phys.dist>0?t.player.phys.dist/1e3:0),n.topSpeed=Math.max(n.topSpeed||0,t.player.phys.topSpeedSeen*3.6);let i=null;if(t.mode==="champ"&&rt.data.champ){let a=rt.data.champ;for(let o of e)a.points[o.bikeId]=(a.points[o.bikeId]||0)+o.points;a.results.push(e.map(o=>({bikeId:o.bikeId,pos:o.pos}))),a.round++,i={round:a.round,next:a.round<We.length,done:a.round>=We.length},i.done&&(a.done=!0)}rt.save(),this._lastResults=e,this._lastChamp=i,this.state="results",this.engine.renderer.toneMappingExposure=1;let r=e.slice(0,3).map(a=>({spec:un[a.bikeId],livery:a.livery}));this.garage.setPodium(r),this.garage.setMode("podium"),this.garage.activate(),It.playMusic("podium"),this.ui.results(t,e,i)}watchReplay(){this.race&&(this.state="race",this.engine.setScene(this.race.scene,this.engine.camera),this.garage.deactivate(),this.race.startReplay(),this.ui.replayOverlay(),It.playMusic("race"))}endReplay(){this.race&&(this.race.stopReplay(),this.state="results",this.garage.activate(),It.playMusic("podium"),this.ui.results(this.race,this._lastResults,this._lastChamp))}champStart(){let t=He.map(e=>e.id);rt.data.champ={bike:rt.data.garage.bike,livery:rt.data.garage.livery[rt.data.garage.bike]??0,difficulty:rt.settings.difficulty,round:0,points:Object.fromEntries(t.map(e=>[e,0])),results:[],done:!1,seed:Math.floor(Math.random()*1e6)},rt.save(),this.champRace()}champRace(){let t=rt.data.champ;if(!t)return;let e=We[t.round],i=Object.entries(t.points).sort((r,a)=>a[1]-r[1]).map(([r])=>r).indexOf(t.bike);this.startRace({mode:"champ",trackDef:e,bikeId:t.bike,livery:t.livery,laps:Math.min(rt.settings.laps,e.laps||3),rivals:11,difficulty:t.difficulty,seed:t.seed+t.round,gridSlot:t.round===0?8:Math.min(11,4+Math.floor(i/2))})}champNext(){this.race&&(this.race.dispose(),this.race=null),this.champRace()}champFinal(){this.race&&(this.race.dispose(),this.race=null);let t=rt.data.champ;this.state="results";let e=Object.entries(t.points).sort((n,i)=>i[1]-n[1]).slice(0,3);this.garage.setPodium(e.map(([n])=>({spec:un[n],livery:n===t.bike?t.livery:0}))),this.garage.setMode("podium"),this.garage.activate(),this.ui.champFinal(t)}};window.addEventListener("error",s=>{console.error(s.error||s.message)});var sy=new wu;sy.boot().catch(s=>{console.error(s);let t=document.getElementById("boot-msg");t&&(t.textContent="Error: "+s.message)});})();
/*! Bundled license information:

three/build/three.module.js:
  (**
   * @license
   * Copyright 2010-2024 Three.js Authors
   * SPDX-License-Identifier: MIT
   *)
*/
