@echo off
title MOTO MITICO
cd /d "%~dp0"
rem Abre el juego en el navegador predeterminado (Chrome, Edge o Firefox)
start "" "%~dp0index.html"
