#!/bin/bash
cd "$(dirname "$0")"
xdg-open "index.html" >/dev/null 2>&1 || sensible-browser "index.html"
